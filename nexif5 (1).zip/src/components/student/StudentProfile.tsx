import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SkillItem, Achievement, Project } from '../../types';
import {
  User,
  GraduationCap,
  Sparkles,
  Award,
  Code2,
  FileText,
  Building,
  MapPin,
  CheckCircle2,
  Plus,
  Trash2,
  Edit2,
  Save,
  Globe,
  ExternalLink,
  ShieldCheck,
  School,
  X
} from 'lucide-react';

export const StudentProfile: React.FC = () => {
  const {
    currentRole,
    currentStudent,
    updateStudentProfile,
    addStudentSkill,
    removeStudentSkill,
    addStudentAchievement,
    addStudentProject,
    joinCollege,
    leaveCollege,
    colleges
  } = useApp();

  const isJobSeeker = currentRole === 'job_seeker' || currentStudent.userType === 'job_seeker' || !currentStudent.collegeName;

  const [isEditingBasic, setIsEditingBasic] = useState(false);
  const [name, setName] = useState(currentStudent.name);
  const [careerGoal, setCareerGoal] = useState(currentStudent.careerGoal);
  const [email, setEmail] = useState(currentStudent.email);
  const [phone, setPhone] = useState(currentStudent.phone);
  const [bio, setBio] = useState(currentStudent.bio || '');
  const [salaryMin, setSalaryMin] = useState(currentStudent.salaryPreferenceMinLPA);
  const [salaryMax, setSalaryMax] = useState(currentStudent.salaryPreferenceMaxLPA);
  const [workPreference, setWorkPreference] = useState(currentStudent.workPreference);
  const [locationType, setLocationType] = useState(currentStudent.locationPreferenceType);

  // New Skill Form State
  const [newSkillName, setNewSkillName] = useState('');
  const [newSkillLevel, setNewSkillLevel] = useState<'beginner' | 'intermediate' | 'advanced' | 'expert'>('intermediate');
  const [showSkillModal, setShowSkillModal] = useState(false);

  // New Experience Form State
  const [expCompany, setExpCompany] = useState('');
  const [expRole, setExpRole] = useState('');
  const [expDuration, setExpDuration] = useState('');
  const [expLocation, setExpLocation] = useState('');
  const [expDesc, setExpDesc] = useState('');
  const [showExpModal, setShowExpModal] = useState(false);

  // New Achievement Form State
  const [achTitle, setAchTitle] = useState('');
  const [achCategory, setAchCategory] = useState<Achievement['category']>('Competition');
  const [achDesc, setAchDesc] = useState('');
  const [achDate, setAchDate] = useState('');
  const [showAchModal, setShowAchModal] = useState(false);

  // New Project Form State
  const [projTitle, setProjTitle] = useState('');
  const [projDesc, setProjDesc] = useState('');
  const [projSkills, setProjSkills] = useState('');
  const [projLink, setProjLink] = useState('');
  const [showProjModal, setShowProjModal] = useState(false);

  // College Switcher Modal
  const [showCollegeModal, setShowCollegeModal] = useState(false);

  const handleSaveBasic = () => {
    updateStudentProfile({
      name,
      careerGoal,
      email,
      phone,
      bio,
      salaryPreferenceMinLPA: Number(salaryMin),
      salaryPreferenceMaxLPA: Number(salaryMax),
      workPreference,
      locationPreferenceType: locationType
    });
    setIsEditingBasic(false);
  };

  const handleAddExperience = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expCompany.trim() || !expRole.trim()) return;
    const newExp = {
      id: `exp-${Date.now()}`,
      company: expCompany.trim(),
      role: expRole.trim(),
      duration: expDuration.trim() || '2023 - Present',
      location: expLocation.trim() || 'Bangalore / Hybrid',
      description: expDesc.trim()
    };
    const currentExperiences = currentStudent.experiences || currentStudent.experience || [];
    const updatedList = [...currentExperiences, newExp];
    updateStudentProfile({
      experiences: updatedList as any,
      experience: updatedList
    });
    setExpCompany('');
    setExpRole('');
    setExpDuration('');
    setExpLocation('');
    setExpDesc('');
    setShowExpModal(false);
  };

  const handleRemoveExperience = (expId: string) => {
    const currentExperiences = currentStudent.experiences || currentStudent.experience || [];
    const updated = currentExperiences.filter((e: any) => e.id !== expId);
    updateStudentProfile({ experiences: updated as any, experience: updated });
  };

  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSkillName.trim()) return;
    addStudentSkill({
      name: newSkillName.trim(),
      level: newSkillLevel,
      verified: true
    });
    setNewSkillName('');
    setShowSkillModal(false);
  };

  const handleAddAchievement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!achTitle.trim()) return;
    addStudentAchievement({
      title: achTitle.trim(),
      category: achCategory,
      description: achDesc.trim(),
      date: achDate || '2024',
      verified: true,
      issuer: 'Official Authority'
    });
    setAchTitle('');
    setAchDesc('');
    setAchDate('');
    setShowAchModal(false);
  };

  const handleAddProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projTitle.trim()) return;
    addStudentProject({
      title: projTitle.trim(),
      description: projDesc.trim(),
      technologies: projSkills.split(',').map(s => s.trim()).filter(Boolean),
      liveUrl: projLink || undefined
    });
    setProjTitle('');
    setProjDesc('');
    setProjSkills('');
    setProjLink('');
    setShowProjModal(false);
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto px-4 sm:px-6 py-6">
      {/* Profile Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
            <img
              src={currentStudent.avatarUrl}
              alt={currentStudent.name}
              className="w-20 h-20 rounded-2xl object-cover border-2 border-slate-200 shadow-sm"
            />
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl font-bold text-slate-900 font-display">
                  {currentStudent.name}
                </h1>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border flex items-center gap-1 ${
                  isJobSeeker
                    ? 'bg-amber-50 text-amber-800 border-amber-200'
                    : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                }`}>
                  <ShieldCheck className="w-3.5 h-3.5" />
                  {isJobSeeker ? 'Verified Professional Candidate' : 'Verified Student Profile'}
                </span>
              </div>

              <p className="text-sm font-semibold text-indigo-600 flex items-center gap-1.5">
                <span>Target Ambition:</span>
                <strong className="text-slate-900">{currentStudent.careerGoal}</strong>
              </p>

              <p className="text-xs text-slate-500 flex flex-wrap items-center gap-3 pt-1">
                <span>{currentStudent.email}</span>
                <span>•</span>
                <span>{currentStudent.phone}</span>
                <span>•</span>
                <span>{currentStudent.location}</span>
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsEditingBasic(!isEditingBasic)}
            className="px-4 py-2 rounded-xl text-xs font-bold border border-slate-200 hover:bg-slate-50 text-slate-700 flex items-center gap-1.5 transition-colors self-start sm:self-center"
          >
            {isEditingBasic ? <Save className="w-4 h-4 text-emerald-600" /> : <Edit2 className="w-4 h-4" />}
            <span>{isEditingBasic ? 'Save Changes' : 'Edit Profile'}</span>
          </button>
        </div>

        {/* Edit Basic Info Form Drawer */}
        {isEditingBasic && (
          <div className="mt-6 pt-6 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Target Career Goal</label>
              <input
                type="text"
                value={careerGoal}
                onChange={(e) => setCareerGoal(e.target.value)}
                placeholder="e.g. Business Analyst, Full Stack Engineer"
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Phone Number</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">About / Bio</label>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                rows={2}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Expected Salary (LPA)</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={salaryMin}
                  onChange={(e) => setSalaryMin(Number(e.target.value))}
                  className="w-1/2 p-2 rounded-lg border border-slate-200"
                  placeholder="Min"
                />
                <span>-</span>
                <input
                  type="number"
                  value={salaryMax}
                  onChange={(e) => setSalaryMax(Number(e.target.value))}
                  className="w-1/2 p-2 rounded-lg border border-slate-200"
                  placeholder="Max"
                />
              </div>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Work Mode Preference</label>
              <select
                value={workPreference}
                onChange={(e) => setWorkPreference(e.target.value as any)}
                className="w-full p-2 rounded-lg border border-slate-200"
              >
                <option value="hybrid">Hybrid (Flexible)</option>
                <option value="remote">Remote Only</option>
                <option value="on_site">On-Site Office</option>
              </select>
            </div>
            <div className="sm:col-span-2 flex justify-end gap-2 pt-2">
              <button
                onClick={handleSaveBasic}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-xs"
              >
                Save Profile Details
              </button>
            </div>
          </div>
        )}
      </div>

      {/* College Connection & Path Status */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Institutional Affiliation Status
            </span>
            <div className="flex items-center gap-2">
              <School className="w-5 h-5 text-purple-600" />
              <h3 className="text-base font-bold text-slate-900">
                {currentStudent.collegeName ? currentStudent.collegeName : 'Independent Candidate (No College Required)'}
              </h3>
            </div>
            <p className="text-xs text-slate-600">
              {currentStudent.collegeName
                ? `Department: ${currentStudent.department || currentStudent.education.course} • Batch of ${currentStudent.education.graduationYear}`
                : 'You are using Nexif5 independently. You have complete direct access to all recruiter job postings, AI career analysis, and verified applications.'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {currentStudent.collegeName ? (
              <button
                onClick={leaveCollege}
                className="px-3.5 py-1.5 rounded-xl border border-slate-200 hover:bg-rose-50 hover:text-rose-700 text-slate-600 text-xs font-semibold transition-colors"
              >
                Disconnect College
              </button>
            ) : (
              <button
                onClick={() => setShowCollegeModal(true)}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Connect to a College</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Professional Experience Section */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Building className="w-5 h-5 text-indigo-600" />
              <h3 className="font-bold text-slate-900 text-base font-display">
                Professional Experience & Work History
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              Full-time roles, internships, apprenticeships, and freelance consulting engagements
            </p>
          </div>

          <button
            onClick={() => setShowExpModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-bold text-xs flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Experience</span>
          </button>
        </div>

        {((currentStudent.experiences && currentStudent.experiences.length > 0) || (currentStudent.experience && currentStudent.experience.length > 0)) ? (
          <div className="space-y-3">
            {(currentStudent.experiences || currentStudent.experience || []).map((exp: any) => (
              <div
                key={exp.id}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white transition-all flex flex-col sm:flex-row sm:items-start justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <strong className="text-slate-900 font-bold text-sm">{exp.role}</strong>
                    <span className="text-slate-400">•</span>
                    <span className="font-semibold text-indigo-600">{exp.company}</span>
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[10px] font-medium">
                      {exp.location}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 font-medium block">{exp.duration}</span>
                  <p className="text-slate-600 leading-relaxed text-[11px] pt-1">{exp.description}</p>
                </div>

                <button
                  onClick={() => handleRemoveExperience(exp.id)}
                  className="p-1.5 rounded-lg text-slate-300 hover:text-rose-600 hover:bg-rose-50 transition-colors self-start"
                  title="Remove experience"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 border border-dashed border-slate-200 rounded-xl bg-slate-50/50">
            <Building className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="text-xs font-semibold text-slate-700">No work experience listed yet</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Add full-time roles or previous internships to boost your recruiter visibility.</p>
          </div>
        )}
      </div>

      {/* Skills Matrix Section */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-base font-display">
              Technical & Functional Skills
            </h3>
            <p className="text-xs text-slate-500">
              Verified skills directly drive your AI Match scores on recruiter job requisitions
            </p>
          </div>

          <button
            onClick={() => setShowSkillModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-bold text-xs flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Skill</span>
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {currentStudent.skills.map((skill) => (
            <div
              key={skill.id}
              className="p-3 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-indigo-300 transition-all flex items-center justify-between text-xs"
            >
              <div>
                <strong className="text-slate-900 font-bold block">{skill.name}</strong>
                <span className="text-[10px] text-slate-500 capitalize">{skill.level}</span>
              </div>
              <button
                onClick={() => removeStudentSkill(skill.id)}
                className="p-1 rounded-md text-slate-300 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                title="Remove skill"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Section 6: Achievements (NOT Skill Passport!) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-500" />
              <h3 className="font-bold text-slate-900 text-base font-display">
                Verified Achievements
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              Competitions, hackathons, academic distinctions, and leadership milestones
            </p>
          </div>

          <button
            onClick={() => setShowAchModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-amber-50 text-amber-800 hover:bg-amber-100 font-bold text-xs flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Achievement</span>
          </button>
        </div>

        <div className="space-y-3">
          {currentStudent.achievements.map((ach) => (
            <div
              key={ach.id}
              className="p-4 rounded-xl border border-slate-200 bg-gradient-to-r from-amber-50/30 to-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 text-sm">{ach.title}</span>
                  <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold">
                    {ach.category}
                  </span>
                  {ach.verified && (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-semibold border border-emerald-200">
                      Verified
                    </span>
                  )}
                </div>
                <p className="text-slate-600 leading-relaxed text-[11px]">{ach.description}</p>
                {ach.issuer && (
                  <span className="text-[10px] text-slate-400 block">Issued by: {ach.issuer} ({ach.date})</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Projects Showcase */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Code2 className="w-5 h-5 text-indigo-600" />
              <h3 className="font-bold text-slate-900 text-base font-display">
                Projects & Portfolio Artifacts
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              Live demonstrations and problem-solving artifacts inspected by recruiters
            </p>
          </div>

          <button
            onClick={() => setShowProjModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-bold text-xs flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Project</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {currentStudent.projects.map((proj) => (
            <div
              key={proj.id}
              className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3 text-xs flex flex-col justify-between"
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 text-sm">{proj.title}</h4>
                  {proj.liveUrl && (
                    <a
                      href={proj.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-indigo-600 hover:text-indigo-800 p-1"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}
                </div>
                <p className="text-slate-600 text-[11px] leading-relaxed">{proj.description}</p>
              </div>

              <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-200">
                {proj.technologies.map((t, i) => (
                  <span
                    key={i}
                    className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-[10px] font-semibold text-slate-700"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Skill Modal */}
      {showSkillModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">Add New Skill</h3>
              <button onClick={() => setShowSkillModal(false)}><X className="w-4 h-4 text-slate-400" /></button>
            </div>
            <form onSubmit={handleAddSkill} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Skill Name</label>
                <input
                  type="text"
                  placeholder="e.g. Tableau, Python, Financial Modeling"
                  value={newSkillName}
                  onChange={(e) => setNewSkillName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Proficiency Level</label>
                <select
                  value={newSkillLevel}
                  onChange={(e) => setNewSkillLevel(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                >
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                  <option value="expert">Expert</option>
                </select>
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowSkillModal(false)}
                  className="px-3 py-2 text-slate-500 hover:text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl"
                >
                  Add Skill
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Achievement Modal */}
      {showAchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">Add Achievement</h3>
              <button onClick={() => setShowAchModal(false)}><X className="w-4 h-4 text-slate-400" /></button>
            </div>
            <form onSubmit={handleAddAchievement} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Achievement Title</label>
                <input
                  type="text"
                  placeholder="e.g. 1st Place - National Case Challenge"
                  value={achTitle}
                  onChange={(e) => setAchTitle(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Category</label>
                <select
                  value={achCategory}
                  onChange={(e) => setAchCategory(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                >
                  <option value="Competition">Competition</option>
                  <option value="Academic">Academic</option>
                  <option value="Project">Project</option>
                  <option value="Leadership">Leadership</option>
                  <option value="Certification">Certification</option>
                  <option value="Publication">Publication</option>
                </select>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description & Impact</label>
                <textarea
                  rows={2}
                  placeholder="Summarize the scope, outcome, or rank achieved..."
                  value={achDesc}
                  onChange={(e) => setAchDesc(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Year</label>
                <input
                  type="text"
                  placeholder="e.g. 2024"
                  value={achDate}
                  onChange={(e) => setAchDate(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAchModal(false)}
                  className="px-3 py-2 text-slate-500 hover:text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl"
                >
                  Save Achievement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Experience Modal */}
      {showExpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">Add Professional Experience</h3>
              <button onClick={() => setShowExpModal(false)}><X className="w-4 h-4 text-slate-400" /></button>
            </div>
            <form onSubmit={handleAddExperience} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Company / Organization</label>
                <input
                  type="text"
                  placeholder="e.g. Swiggy, Accenture, Infosys"
                  value={expCompany}
                  onChange={(e) => setExpCompany(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Role / Job Title</label>
                <input
                  type="text"
                  placeholder="e.g. Associate Data Analyst, Frontend Developer"
                  value={expRole}
                  onChange={(e) => setExpRole(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Duration / Dates</label>
                  <input
                    type="text"
                    placeholder="e.g. 2023 - Present"
                    value={expDuration}
                    onChange={(e) => setExpDuration(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Location / Mode</label>
                  <input
                    type="text"
                    placeholder="e.g. Bangalore / Remote"
                    value={expLocation}
                    onChange={(e) => setExpLocation(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Key Responsibilities & Impact</label>
                <textarea
                  rows={3}
                  placeholder="Describe your core accomplishments, technologies used, and business metrics impacted..."
                  value={expDesc}
                  onChange={(e) => setExpDesc(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowExpModal(false)}
                  className="px-3 py-2 text-slate-500 hover:text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl"
                >
                  Save Experience
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Project Modal */}
      {showProjModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">Add Project Artifact</h3>
              <button onClick={() => setShowProjModal(false)}><X className="w-4 h-4 text-slate-400" /></button>
            </div>
            <form onSubmit={handleAddProject} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Project Title</label>
                <input
                  type="text"
                  placeholder="e.g. E-Commerce Sales & Margin Dashboard"
                  value={projTitle}
                  onChange={(e) => setProjTitle(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  placeholder="What business problem did you solve and what tools did you use?"
                  value={projDesc}
                  onChange={(e) => setProjDesc(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Technologies (comma separated)</label>
                <input
                  type="text"
                  placeholder="e.g. SQL, Power BI, Excel DAX"
                  value={projSkills}
                  onChange={(e) => setProjSkills(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Live Demo / Repository URL</label>
                <input
                  type="url"
                  placeholder="https://github.com/username/project"
                  value={projLink}
                  onChange={(e) => setProjLink(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowProjModal(false)}
                  className="px-3 py-2 text-slate-500 hover:text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl"
                >
                  Add Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Connect College Modal */}
      {showCollegeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">Select Institutional College</h3>
              <button onClick={() => setShowCollegeModal(false)}><X className="w-4 h-4 text-slate-400" /></button>
            </div>
            <p className="text-xs text-slate-500">
              Connecting to a college links you to campus placement drives and institutional reporting.
            </p>
            <div className="space-y-2">
              {colleges.map((clg) => (
                <button
                  key={clg.id}
                  onClick={() => {
                    joinCollege(clg.id);
                    setShowCollegeModal(false);
                  }}
                  className="w-full text-left p-3 rounded-xl border border-slate-200 hover:border-purple-500 hover:bg-purple-50/50 flex items-center gap-3 transition-colors text-xs"
                >
                  <img src={clg.logoUrl} alt={clg.name} className="w-8 h-8 rounded-lg object-cover" />
                  <div>
                    <strong className="text-slate-900 block font-bold">{clg.name}</strong>
                    <span className="text-[10px] text-slate-500">{clg.location} • {clg.type}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
