import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CompanyRecruiter } from '../../types';
import {
  Users,
  ShieldCheck,
  Plus,
  Mail,
  UserPlus,
  Building,
  CheckCircle2,
  Trash2,
  X
} from 'lucide-react';

export const RecruiterTeam: React.FC = () => {
  const { currentCompany } = useApp();

  const [members, setMembers] = useState<CompanyRecruiter[]>(currentCompany.recruiters || []);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<CompanyRecruiter['role']>('recruiter');

  const handleInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;

    const newMember: CompanyRecruiter = {
      id: `rec-${Date.now()}`,
      companyId: currentCompany.id,
      name: name.trim(),
      email: email.trim(),
      role,
      department: 'Talent Acquisition',
      activeJobsPosted: 0
    };

    setMembers(prev => [...prev, newMember]);
    setName('');
    setEmail('');
    setShowInviteModal(false);
  };

  const handleRemove = (id: string) => {
    setMembers(prev => prev.filter(m => m.id !== id));
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
            <Users className="w-4 h-4" />
            <span>ORGANIZATION GROUP & ROLE-BASED ACCESS</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 font-display">
            Company Team & Permissions
          </h1>
          <p className="text-xs text-slate-500">
            Manage recruiter access levels under {currentCompany.name}
          </p>
        </div>

        <button
          onClick={() => setShowInviteModal(true)}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs shadow-xs hover:shadow transition-all flex items-center gap-2 w-fit"
        >
          <UserPlus className="w-4 h-4" />
          <span>Invite Team Member</span>
        </button>
      </div>

      {/* Organization Group Summary Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <img
            src={currentCompany.logoUrl}
            alt={currentCompany.name}
            className="w-14 h-14 rounded-2xl object-cover border border-slate-200"
          />
          <div>
            <h3 className="font-bold text-slate-900 text-base font-display">{currentCompany.name}</h3>
            <p className="text-xs text-slate-500">
              Corporate Entity ID: <span className="font-mono text-slate-700">{currentCompany.id}</span> • {currentCompany.companySize} Employees
            </p>
            <span className="inline-block mt-1 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200">
              Enterprise Verified Domain
            </span>
          </div>
        </div>

        <div className="text-xs text-slate-600 space-y-1 sm:text-right">
          <div>Active Seat Licenses: <strong>{members.length} of 25 Seats</strong></div>
          <div className="text-emerald-700 font-semibold">SSO & RBAC Enforcement Active</div>
        </div>
      </div>

      {/* Team Members List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Active Organization Members ({members.length})
          </span>
        </div>

        <div className="divide-y divide-slate-100">
          {members.map((member) => (
            <div
              key={member.id}
              className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs hover:bg-slate-50/50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 font-bold flex items-center justify-center text-sm border border-slate-200">
                  {member.name.charAt(0)}
                </div>
                <div>
                  <strong className="text-slate-900 font-bold text-sm block">{member.name}</strong>
                  <span className="text-[11px] text-slate-500 font-mono">{member.email}</span>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-left sm:text-right">
                  <span className={`px-2.5 py-1 rounded-full font-bold uppercase text-[10px] ${
                    member.role === 'admin' ? 'bg-purple-100 text-purple-800' :
                    member.role === 'hr_manager' ? 'bg-blue-100 text-blue-800' :
                    'bg-slate-100 text-slate-700'
                  }`}>
                    {member.role.replace('_', ' ')}
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    {member.department || 'Recruitment Team'}
                  </span>
                </div>

                {members.length > 1 && (
                  <button
                    onClick={() => handleRemove(member.id)}
                    className="p-1.5 rounded-lg text-slate-300 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="Revoke Seat"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Invite Member Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">Invite Team Member</h3>
              <button onClick={() => setShowInviteModal(false)}><X className="w-4 h-4 text-slate-400" /></button>
            </div>
            <form onSubmit={handleInvite} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  placeholder="e.g. Priya Nair"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Corporate Email</label>
                <input
                  type="email"
                  placeholder="name@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Role & Permissions</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none font-medium"
                >
                  <option value="recruiter">Recruiter (Post jobs & screen candidates)</option>
                  <option value="hr_manager">HR Manager (Manage requisitions & interviewers)</option>
                  <option value="admin">Company Admin (Full organization control)</option>
                </select>
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowInviteModal(false)}
                  className="px-3 py-2 text-slate-500 hover:text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl"
                >
                  Send Invitation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
