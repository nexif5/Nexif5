import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Bot, Send, Sparkles, Trash2 } from 'lucide-react';

export const MobileAIScreen: React.FC = () => {
  const { chatMessages, sendChatMessage, clearChat, isAiTyping, currentStudent, theme } = useApp();
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const isLight = theme === 'light';

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages, isAiTyping]);

  const handleSend = (textToSend?: string) => {
    const query = textToSend || inputText;
    if (!query.trim() || isAiTyping) return;
    sendChatMessage(query.trim());
    setInputText('');
  };

  const promptSuggestions = [
    '🎯 Suggest top matching jobs for my profile',
    '📄 How can I optimize my resume for ATS?',
    '💼 Prep me for Business Analyst interview',
    '📊 Analyze my skill gaps against market demand',
    '🚀 What certifications will increase my salary?'
  ];

  return (
    <div className={`flex flex-col h-[calc(100vh-60px)] font-sans transition-colors duration-200 ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-white'
    }`}>
      {/* Top Header */}
      <div className={`px-4 py-3 border-b flex items-center justify-between backdrop-blur-xs transition-colors ${
        isLight ? 'bg-white/95 border-slate-200' : 'bg-slate-900/90 border-slate-800'
      }`}>
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center shadow-md border border-purple-400/30">
            <Bot className="w-4 h-4 text-white" />
          </div>
          <div>
            <h1 className={`text-sm font-bold flex items-center gap-1.5 font-display ${
              isLight ? 'text-slate-900' : 'text-white'
            }`}>
              <span>Nexif5 AI Coach</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </h1>
            <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Deterministic Career & Job Intelligence
            </p>
          </div>
        </div>

        <button
          onClick={clearChat}
          className={`p-1.5 rounded-lg transition-colors ${
            isLight
              ? 'text-slate-500 hover:text-rose-500 hover:bg-slate-100'
              : 'text-slate-400 hover:text-rose-400 hover:bg-slate-800'
          }`}
          title="Clear Conversation"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {chatMessages.length === 0 && (
          <div className="text-center py-6 space-y-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mx-auto border ${
              isLight
                ? 'bg-indigo-50 text-indigo-600 border-indigo-200'
                : 'bg-indigo-600/20 text-indigo-400 border-indigo-500/30'
            }`}>
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h2 className={`text-base font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                Hi {currentStudent.name.split(' ')[0]}, how can I coach your career?
              </h2>
              <p className={`text-xs mt-1 max-w-xs mx-auto ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Ask about jobs, salary expectations, skill gaps, or mock interview preparation.
              </p>
            </div>
          </div>
        )}

        {chatMessages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.sender === 'ai' && (
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 border ${
                isLight
                  ? 'bg-indigo-100 text-indigo-700 border-indigo-200'
                  : 'bg-indigo-600/30 text-indigo-400 border-indigo-500/30'
              }`}>
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-[85%] rounded-2xl p-3.5 text-xs leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-indigo-600 text-white rounded-br-xs shadow-md'
                  : isLight
                  ? 'bg-white text-slate-800 border border-slate-200 rounded-bl-xs shadow-xs'
                  : 'bg-slate-800/90 text-slate-200 border border-slate-700/80 rounded-bl-xs shadow-xs'
              }`}
            >
              <div className="whitespace-pre-wrap space-y-1.5">
                {msg.text.split('\n\n').map((paragraph, pIdx) => (
                  <p key={pIdx}>{paragraph}</p>
                ))}
              </div>
            </div>

            {msg.sender === 'user' && (
              <img
                src={currentStudent.avatarUrl}
                alt="User"
                className="w-7 h-7 rounded-full object-cover shrink-0 mt-0.5 border border-indigo-400/50"
              />
            )}
          </div>
        ))}

        {isAiTyping && (
          <div className="flex gap-2.5 justify-start">
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 border ${
              isLight
                ? 'bg-indigo-100 text-indigo-700 border-indigo-200'
                : 'bg-indigo-600/30 text-indigo-400 border-indigo-500/30'
            }`}>
              <Bot className="w-4 h-4 animate-bounce" />
            </div>
            <div className={`border rounded-2xl rounded-bl-xs p-3 flex items-center gap-1.5 ${
              isLight ? 'bg-white border-slate-200' : 'bg-slate-800/90 border-slate-700/80'
            }`}>
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse delay-75" />
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse delay-150" />
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Chips */}
      <div className={`px-3 py-1.5 border-t flex items-center gap-1.5 overflow-x-auto no-scrollbar ${
        isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-900/60 border-slate-800/80'
      }`}>
        {promptSuggestions.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(prompt)}
            disabled={isAiTyping}
            className={`px-2.5 py-1 rounded-full border text-[11px] whitespace-nowrap transition-colors ${
              isLight
                ? 'bg-white hover:bg-slate-200 border-slate-300 text-slate-700'
                : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
            }`}
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <div className={`p-3 border-t pb-16 ${
        isLight ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800'
      }`}>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className={`flex items-center gap-2 border rounded-2xl p-1.5 pl-3 focus-within:border-indigo-500 transition-colors ${
            isLight
              ? 'bg-slate-50 border-slate-300'
              : 'bg-slate-800/90 border-slate-700'
          }`}
        >
          <input
            type="text"
            placeholder="Ask Nexif5 AI Coach about roles, skills, prep..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={isAiTyping}
            className={`flex-1 bg-transparent text-xs placeholder-slate-400 focus:outline-hidden ${
              isLight ? 'text-slate-900' : 'text-white'
            }`}
          />
          <button
            type="submit"
            disabled={!inputText.trim() || isAiTyping}
            className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white transition-all active:scale-95"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
