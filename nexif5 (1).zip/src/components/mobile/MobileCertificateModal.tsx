import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Award,
  Download,
  Share2,
  CheckCircle2,
  ShieldCheck,
  ExternalLink,
  QrCode,
  Check,
  Copy,
  Printer
} from 'lucide-react';

export const MobileCertificateModal: React.FC = () => {
  const {
    isCertificateModalOpen,
    setIsCertificateModalOpen,
    selectedCertificateForView,
    openCertificateVerification,
    theme
  } = useApp();

  const isLight = theme === 'light';
  const cert = selectedCertificateForView;

  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  if (!isCertificateModalOpen || !cert) {
    return null;
  }

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(cert.verificationUrl || `https://nexif5.careers/verify/${cert.certificateId}`);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  const handleDownload = () => {
    setIsDownloading(true);
    setTimeout(() => {
      setIsDownloading(false);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    }, 1200);
  };

  const handleShareLinkedIn = () => {
    const text = encodeURIComponent(
      `Proud to have completed the ${cert.courseTitle} on NEXIF5 (${cert.grade}) with verified skill mastery in ${cert.skill}! Certificate ID: ${cert.certificateId}`
    );
    const url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(cert.verificationUrl)}&summary=${text}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div
        className={`w-full max-w-xl max-h-[94vh] flex flex-col rounded-t-3xl sm:rounded-3xl border shadow-2xl overflow-hidden font-sans transition-all ${
          isLight ? 'bg-slate-50 text-slate-900 border-slate-200' : 'bg-slate-900 text-white border-slate-800'
        }`}
      >
        {/* Top Header */}
        <div
          className={`px-4 py-3 border-b flex items-center justify-between shrink-0 ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-800/80 border-slate-700/80'
          }`}
        >
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-500 flex items-center justify-center font-bold">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-500">
                Official Credential
              </span>
              <h2 className="text-sm font-bold truncate font-display">Verified Certificate</h2>
            </div>
          </div>

          <button
            onClick={() => setIsCertificateModalOpen(false)}
            className={`p-1.5 rounded-full transition-colors shrink-0 ${
              isLight ? 'hover:bg-slate-100 text-slate-500' : 'hover:bg-slate-800 text-slate-400'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
          {/* ======================================================== */}
          {/* THE PRESTIGIOUS CERTIFICATE CANVAS */}
          {/* ======================================================== */}
          <div className="relative rounded-2xl p-1 bg-gradient-to-br from-amber-300 via-amber-500 to-amber-700 shadow-xl">
            <div
              className={`rounded-[14px] p-6 text-center space-y-4 border-4 border-double ${
                isLight
                  ? 'bg-gradient-to-b from-amber-50/70 via-white to-slate-50 border-amber-300/80 text-slate-900'
                  : 'bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 border-amber-500/60 text-white'
              }`}
            >
              {/* Certificate Top Crest & Seal */}
              <div className="space-y-1">
                <div className="inline-flex p-3 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 shadow-md">
                  <Award className="w-8 h-8" />
                </div>
                <p className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-amber-600 dark:text-amber-400">
                  NEXIF5 CAREER EXECUTION PLATFORM
                </p>
                <h1 className="text-xl sm:text-2xl font-black font-display tracking-tight text-slate-900 dark:text-white uppercase">
                  Certificate of Skill Mastery
                </h1>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 italic">
                  In Partnership with {cert.partnerName}
                </p>
              </div>

              {/* Recipient Details */}
              <div className="space-y-1 py-1">
                <p className="text-[11px] text-slate-500 uppercase tracking-widest font-semibold">
                  This is proudly presented to
                </p>
                <h2 className="text-2xl font-black font-display text-indigo-600 dark:text-indigo-400 underline decoration-amber-400/60 decoration-2 underline-offset-4">
                  {cert.learnerName}
                </h2>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto leading-relaxed">
                  for successfully completing all video modules, practical task demonstrations, and achieving{' '}
                  <strong className="text-slate-900 dark:text-white">{cert.grade}</strong> on the capstone evaluation for
                </p>
                <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
                  {cert.courseTitle}
                </h3>
              </div>

              {/* Demonstrated Skills Tags */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
                  Demonstrated Competencies:
                </span>
                <div className="flex flex-wrap justify-center gap-1.5">
                  {cert.skillsDemonstrated.map((skill, sIdx) => (
                    <span
                      key={sIdx}
                      className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500/15 text-amber-800 dark:text-amber-300 border border-amber-500/20"
                    >
                      ✓ {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Signatures & Official Metadata */}
              <div className="pt-4 border-t border-amber-500/20 grid grid-cols-2 gap-4 text-xs items-end">
                <div className="text-left space-y-0.5">
                  <div className="font-serif italic text-sm text-indigo-500 dark:text-indigo-400 border-b border-slate-300 dark:border-slate-700 pb-1">
                    {cert.signatoryName}
                  </div>
                  <p className="font-bold text-[10px] text-slate-900 dark:text-white">
                    {cert.signatoryName}
                  </p>
                  <p className="text-[9px] text-slate-500">{cert.signatoryTitle}</p>
                </div>

                <div className="text-right space-y-0.5">
                  <div className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 dark:text-emerald-400 pb-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>STATUS: VERIFIED</span>
                  </div>
                  <p className="font-mono font-bold text-[10px] text-slate-900 dark:text-white">
                    ID: {cert.certificateId}
                  </p>
                  <p className="text-[9px] text-slate-500">Date: {cert.issueDate}</p>
                </div>
              </div>

              {/* Bottom Verification QR / URL Simulation */}
              <div className="pt-2 flex items-center justify-center gap-2 text-[10px] text-slate-400 font-mono">
                <QrCode className="w-3.5 h-3.5 text-amber-500" />
                <span>Verify online at: {cert.verificationUrl}</span>
              </div>
            </div>
          </div>

          {/* ======================================================== */}
          {/* CERTIFICATE TRANSPARENCY & DISCLAIMER CARD */}
          {/* ======================================================== */}
          <div
            className={`p-3.5 rounded-2xl border space-y-1.5 text-xs ${
              isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-800/60 border-slate-700'
            }`}
          >
            <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white text-[11px]">
              <ShieldCheck className="w-4 h-4 text-indigo-500" />
              <span>NEXIF5 Credential Transparency Guarantee</span>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
              {cert.disclaimer}
            </p>
          </div>

          {/* Quick Certificate Actions */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={handleCopyLink}
              className={`p-3 rounded-2xl border font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 ${
                isLight ? 'bg-white hover:bg-slate-50 border-slate-200' : 'bg-slate-800 hover:bg-slate-700 border-slate-700'
              }`}
            >
              {isCopied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  <span className="text-emerald-500">Link Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Copy Verification Link</span>
                </>
              )}
            </button>

            <button
              onClick={() => {
                setIsCertificateModalOpen(false);
                openCertificateVerification(cert.certificateId);
              }}
              className={`p-3 rounded-2xl border font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 ${
                isLight ? 'bg-white hover:bg-slate-50 border-slate-200' : 'bg-slate-800 hover:bg-slate-700 border-slate-700'
              }`}
            >
              <ExternalLink className="w-3.5 h-3.5 text-amber-500" />
              <span>Verify ID Online</span>
            </button>
          </div>
        </div>

        {/* Modal Sticky Bottom Controls */}
        <div
          className={`px-4 py-3 border-t flex items-center justify-between gap-3 shrink-0 ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-800/90 border-slate-700'
          }`}
        >
          <button
            onClick={handleShareLinkedIn}
            className="px-3.5 py-2.5 rounded-xl border border-indigo-500/30 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-500/10 font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Share Credential</span>
          </button>

          <button
            onClick={handleDownload}
            disabled={isDownloading}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md flex items-center gap-1.5 transition-all active:scale-95"
          >
            {downloadSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-300" />
                <span>Downloaded PDF ✓</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>{isDownloading ? 'Generating PDF...' : 'Download Certificate'}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
