import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AuthModal } from './AuthModal';
import {
  Compass,
  Briefcase,
  Bot,
  Layers,
  User,
  BarChart3,
  Users,
  Calendar,
  GraduationCap,
  Sparkles,
  Building2,
  School,
  Menu,
  X,
  FileText,
  Plus
} from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const {
    currentRole,
    setCurrentRole,
    activeStudentTab,
    setActiveStudentTab,
    activeJobSeekerTab,
    setActiveJobSeekerTab,
    activeRecruiterTab,
    setActiveRecruiterTab,
    activeCollegeTab,
    setActiveCollegeTab,
    applications,
    currentStudent,
    switchToStudentDemo,
    switchToJobSeekerDemo,
    switchToRecruiterDemo,
    switchToCollegeDemo
  } = useApp();

  const [moreMenuOpen, setMoreMenuOpen] = useState(false);

  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signup');

  if (currentRole === 'landing') {
    return (
      <>
        <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-lg px-4 py-2.5 flex items-center justify-between gap-3">
          <button
            onClick={() => {
              switchToStudentDemo('std-1');
              setActiveStudentTab('jobs');
            }}
            className="flex-1 py-2 px-3 rounded-xl border border-slate-200 text-xs font-bold text-slate-800 text-center hover:bg-slate-50 transition-colors"
          >
            Explore Jobs
          </button>
          <button
            onClick={() => {
              setAuthMode('signin');
              setAuthModalOpen(true);
            }}
            className="py-2 px-3 rounded-xl text-xs font-bold text-slate-700 hover:text-slate-900"
          >
            Sign In
          </button>
          <button
            onClick={() => {
              setAuthMode('signup');
              setAuthModalOpen(true);
            }}
            className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold text-center shadow-xs transition-colors"
          >
            Get Started
          </button>
        </div>

        <AuthModal
          isOpen={authModalOpen}
          onClose={() => setAuthModalOpen(false)}
          initialMode={authMode}
        />
      </>
    );
  }

  // Student / Job Seeker Applications Count
  const studentAppsCount = applications.filter(
    a => a.candidateId === currentStudent.id
  ).length;

  return (
    <>
      {/* Mobile Bottom Navigation Bar */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-lg px-1.5 py-1 flex items-center justify-around select-none"
        style={{ paddingBottom: 'max(0.375rem, env(safe-area-inset-bottom))' }}
      >
        {/* STUDENT OR JOB SEEKER BOTTOM NAV */}
        {(currentRole === 'student' || currentRole === 'job_seeker') && (
          <>
            {/* 1. Home */}
            <button
              onClick={() => {
                if (currentRole === 'student') setActiveStudentTab('home');
                else setActiveJobSeekerTab('home');
              }}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors ${
                (currentRole === 'student' ? activeStudentTab === 'home' : activeJobSeekerTab === 'home')
                  ? 'text-indigo-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Compass className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Home</span>
            </button>

            {/* 2. Jobs */}
            <button
              onClick={() => {
                if (currentRole === 'student') setActiveStudentTab('jobs');
                else setActiveJobSeekerTab('jobs');
              }}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors ${
                (currentRole === 'student' ? (activeStudentTab === 'jobs' || activeStudentTab === 'internships') : (activeJobSeekerTab === 'jobs' || activeJobSeekerTab === 'internships'))
                  ? 'text-indigo-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Briefcase className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Jobs</span>
            </button>

            {/* 3. AI Assistant (Featured Center) */}
            <button
              onClick={() => {
                if (currentRole === 'student') setActiveStudentTab('ai');
                else setActiveJobSeekerTab('ai');
              }}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors relative ${
                (currentRole === 'student' ? activeStudentTab === 'ai' : activeJobSeekerTab === 'ai')
                  ? 'text-indigo-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <div className="relative">
                <Bot className="w-5 h-5" />
                <span className="absolute -top-1 -right-1.5 w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
              </div>
              <span className="text-[10px] mt-0.5">Nexif AI</span>
            </button>

            {/* 4. Applications */}
            <button
              onClick={() => {
                if (currentRole === 'student') setActiveStudentTab('applications');
                else setActiveJobSeekerTab('applications');
              }}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors relative ${
                (currentRole === 'student' ? activeStudentTab === 'applications' : activeJobSeekerTab === 'applications')
                  ? 'text-indigo-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <div className="relative">
                <Layers className="w-5 h-5" />
                {studentAppsCount > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-indigo-600 text-white text-[9px] font-bold px-1 rounded-full min-w-[14px] text-center">
                    {studentAppsCount}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5">Applied</span>
            </button>

            {/* 5. Profile */}
            <button
              onClick={() => {
                if (currentRole === 'student') setActiveStudentTab('profile');
                else setActiveJobSeekerTab('profile');
              }}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors ${
                (currentRole === 'student' ? activeStudentTab === 'profile' : activeJobSeekerTab === 'profile')
                  ? 'text-indigo-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <User className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Profile</span>
            </button>

            {/* More Menu Trigger */}
            <button
              onClick={() => setMoreMenuOpen(true)}
              className="px-2 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl text-slate-400 hover:text-slate-700 transition-colors"
              title="More pages"
            >
              <Menu className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">More</span>
            </button>
          </>
        )}

        {/* RECRUITER BOTTOM NAV */}
        {currentRole === 'recruiter' && (
          <>
            {/* 1. Overview */}
            <button
              onClick={() => setActiveRecruiterTab('overview')}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors ${
                activeRecruiterTab === 'overview' ? 'text-emerald-700 font-bold' : 'text-slate-500'
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Overview</span>
            </button>

            {/* 2. Jobs */}
            <button
              onClick={() => setActiveRecruiterTab('jobs')}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors ${
                activeRecruiterTab === 'jobs' ? 'text-emerald-700 font-bold' : 'text-slate-500'
              }`}
            >
              <Briefcase className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Jobs</span>
            </button>

            {/* 3. Candidates (AI Matching) */}
            <button
              onClick={() => setActiveRecruiterTab('candidates')}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors ${
                activeRecruiterTab === 'candidates' || activeRecruiterTab === 'ai_match' ? 'text-emerald-700 font-bold' : 'text-slate-500'
              }`}
            >
              <Bot className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">AI Match</span>
            </button>

            {/* 4. Applications */}
            <button
              onClick={() => setActiveRecruiterTab('applications')}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors ${
                activeRecruiterTab === 'applications' ? 'text-emerald-700 font-bold' : 'text-slate-500'
              }`}
            >
              <Layers className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Applicants</span>
            </button>

            {/* 5. Interviews */}
            <button
              onClick={() => setActiveRecruiterTab('interviews')}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors ${
                activeRecruiterTab === 'interviews' ? 'text-emerald-700 font-bold' : 'text-slate-500'
              }`}
            >
              <Calendar className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Interviews</span>
            </button>

            {/* More Menu */}
            <button
              onClick={() => setMoreMenuOpen(true)}
              className="px-2 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl text-slate-400 hover:text-slate-700"
            >
              <Menu className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">More</span>
            </button>
          </>
        )}

        {/* COLLEGE BOTTOM NAV */}
        {currentRole === 'college' && (
          <>
            {/* 1. Overview */}
            <button
              onClick={() => setActiveCollegeTab('overview')}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors ${
                activeCollegeTab === 'overview' ? 'text-purple-700 font-bold' : 'text-slate-500'
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Overview</span>
            </button>

            {/* 2. Students */}
            <button
              onClick={() => setActiveCollegeTab('students')}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors ${
                activeCollegeTab === 'students' ? 'text-purple-700 font-bold' : 'text-slate-500'
              }`}
            >
              <Users className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Students</span>
            </button>

            {/* 3. Placements */}
            <button
              onClick={() => setActiveCollegeTab('placements')}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors ${
                activeCollegeTab === 'placements' ? 'text-purple-700 font-bold' : 'text-slate-500'
              }`}
            >
              <GraduationCap className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Placements</span>
            </button>

            {/* 4. Skill Gaps */}
            <button
              onClick={() => setActiveCollegeTab('skill_gaps')}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl transition-colors ${
                activeCollegeTab === 'skill_gaps' ? 'text-purple-700 font-bold' : 'text-slate-500'
              }`}
            >
              <Bot className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Skill Gaps</span>
            </button>

            {/* 5. More */}
            <button
              onClick={() => setMoreMenuOpen(true)}
              className="px-2 flex flex-col items-center justify-center py-1.5 min-h-[46px] rounded-xl text-slate-400 hover:text-slate-700"
            >
              <Menu className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">More</span>
            </button>
          </>
        )}
      </nav>

      {/* Slide-over More Drawer for Mobile */}
      {moreMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex flex-col justify-end bg-slate-900/60 backdrop-blur-xs">
          <div
            className="flex-1"
            onClick={() => setMoreMenuOpen(false)}
          />
          <div className="bg-white rounded-t-3xl border-t border-slate-200 p-5 shadow-2xl space-y-4 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
                <span className="font-bold text-slate-900 text-sm">Nexif5 Navigation</span>
              </div>
              <button
                onClick={() => setMoreMenuOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Link Grid depending on Role */}
            <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
              {(currentRole === 'student' || currentRole === 'job_seeker') && (
                <>
                  <button
                    onClick={() => {
                      if (currentRole === 'student') setActiveStudentTab('dashboard');
                      else setActiveJobSeekerTab('dashboard');
                      setMoreMenuOpen(false);
                    }}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 hover:bg-indigo-50 text-left flex items-center gap-2.5"
                  >
                    <BarChart3 className="w-4 h-4 text-indigo-600" />
                    <span>Analytics Dashboard</span>
                  </button>

                  <button
                    onClick={() => {
                      if (currentRole === 'student') setActiveStudentTab('resume');
                      else setActiveJobSeekerTab('resume');
                      setMoreMenuOpen(false);
                    }}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 hover:bg-indigo-50 text-left flex items-center gap-2.5"
                  >
                    <FileText className="w-4 h-4 text-rose-600" />
                    <span>ATS Resume Builder</span>
                  </button>

                  <button
                    onClick={() => {
                      if (currentRole === 'student') setActiveStudentTab('companies');
                      else setActiveJobSeekerTab('companies');
                      setMoreMenuOpen(false);
                    }}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 hover:bg-indigo-50 text-left flex items-center gap-2.5"
                  >
                    <Building2 className="w-4 h-4 text-emerald-600" />
                    <span>Explore Companies</span>
                  </button>

                  <button
                    onClick={() => {
                      if (currentRole === 'student') setActiveStudentTab('internships');
                      else setActiveJobSeekerTab('internships');
                      setMoreMenuOpen(false);
                    }}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 hover:bg-indigo-50 text-left flex items-center gap-2.5"
                  >
                    <GraduationCap className="w-4 h-4 text-purple-600" />
                    <span>Internships & PPO</span>
                  </button>
                </>
              )}

              {currentRole === 'recruiter' && (
                <>
                  <button
                    onClick={() => {
                      setActiveRecruiterTab('team');
                      setMoreMenuOpen(false);
                    }}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 hover:bg-emerald-50 text-left flex items-center gap-2.5"
                  >
                    <Users className="w-4 h-4 text-emerald-600" />
                    <span>Hiring Team</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveRecruiterTab('company');
                      setMoreMenuOpen(false);
                    }}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 hover:bg-emerald-50 text-left flex items-center gap-2.5"
                  >
                    <Building2 className="w-4 h-4 text-blue-600" />
                    <span>Company Profile</span>
                  </button>
                </>
              )}

              {currentRole === 'college' && (
                <>
                  <button
                    onClick={() => {
                      setActiveCollegeTab('ai');
                      setMoreMenuOpen(false);
                    }}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 hover:bg-purple-50 text-left flex items-center gap-2.5"
                  >
                    <Bot className="w-4 h-4 text-purple-600" />
                    <span>AI Placement Advisor</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveCollegeTab('team');
                      setMoreMenuOpen(false);
                    }}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 hover:bg-purple-50 text-left flex items-center gap-2.5"
                  >
                    <Users className="w-4 h-4 text-blue-600" />
                    <span>Placement Cell Team</span>
                  </button>
                </>
              )}
            </div>

            {/* Persona Switcher within Drawer */}
            <div className="pt-2 border-t border-slate-100">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                Switch Role / Demo Persona:
              </span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    switchToStudentDemo('std-1');
                    setMoreMenuOpen(false);
                  }}
                  className="p-2.5 rounded-xl bg-blue-50 text-blue-800 text-xs font-bold text-left flex items-center gap-2"
                >
                  <GraduationCap className="w-4 h-4" /> Student
                </button>
                <button
                  onClick={() => {
                    switchToJobSeekerDemo('std-jobseeker');
                    setMoreMenuOpen(false);
                  }}
                  className="p-2.5 rounded-xl bg-amber-50 text-amber-800 text-xs font-bold text-left flex items-center gap-2"
                >
                  <Briefcase className="w-4 h-4" /> Job Seeker
                </button>
                <button
                  onClick={() => {
                    switchToRecruiterDemo('comp-1');
                    setMoreMenuOpen(false);
                  }}
                  className="p-2.5 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-bold text-left flex items-center gap-2"
                >
                  <Building2 className="w-4 h-4" /> Recruiter
                </button>
                <button
                  onClick={() => {
                    switchToCollegeDemo('clg-1');
                    setMoreMenuOpen(false);
                  }}
                  className="p-2.5 rounded-xl bg-purple-50 text-purple-800 text-xs font-bold text-left flex items-center gap-2"
                >
                  <School className="w-4 h-4" /> College
                </button>
              </div>
            </div>

            {/* Overview / Landing Return */}
            <button
              onClick={() => {
                setCurrentRole('landing');
                setMoreMenuOpen(false);
              }}
              className="w-full py-2.5 rounded-xl bg-slate-900 text-white text-xs font-bold text-center flex items-center justify-center gap-2"
            >
              <Compass className="w-4 h-4" />
              <span>Platform Concept Overview</span>
            </button>
          </div>
        </div>
      )}
    </>
  );
};
