import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, User, Camera, Plus, X, GraduationCap, Award, FolderGit2, Sparkles, Check } from 'lucide-react';

const SUGGESTED_SKILLS = [
  'Python', 'SQL', 'Power BI', 'Excel', 'Data Analysis',
  'Business Analytics', 'React', 'Communication', 'Financial Modeling',
  'Machine Learning', 'Problem Solving', 'Project Management'
];

export const ProfileSetupScreen: React.FC = () => {
  const { setAuthState } = useApp();

  const savedName = sessionStorage.getItem('temp_signup_name') || 'Aarav Patel';
  const [name, setName] = useState(savedName);
  const [avatarUrl, setAvatarUrl] = useState('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80');
  
  // Education fields
  const [education, setEducation] = useState('Undergraduate (B.Tech / B.E / B.Sc)');
  const [course, setCourse] = useState('Computer Science & Engineering');
  const [college, setCollege] = useState('Sri Krishna College of Technology');
  const [gradYear, setGradYear] = useState('2025');

  // Skills
  const [skills, setSkills] = useState<string[]>(['Python', 'SQL', 'Power BI', 'Communication']);
  const [customSkill, setCustomSkill] = useState('');

  // Achievements & Projects
  const [achievement, setAchievement] = useState('1st Place in University Hackathon 2024');
  const [projectTitle, setProjectTitle] = useState('Customer Churn Predictive Model');
  const [certification, setCertification] = useState('Google Data Analytics Professional Certificate');
  const [experience, setExperience] = useState('Data Analytics Intern at FinTech Labs (3 mos)');

  const handleAddSkill = (skill: string) => {
    if (!skills.includes(skill)) {
      setSkills([...skills, skill]);
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setSkills(skills.filter(s => s !== skillToRemove));
  };

  const handleAddCustomSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (customSkill.trim() && !skills.includes(customSkill.trim())) {
      setSkills([...skills, customSkill.trim()]);
      setCustomSkill('');
    }
  };

  const handleContinue = () => {
    // Save to session storage for final user assembly
    sessionStorage.setItem('temp_profile_name', name);
    sessionStorage.setItem('temp_profile_avatar', avatarUrl);
    sessionStorage.setItem('temp_profile_education', education);
    sessionStorage.setItem('temp_profile_course', course);
    sessionStorage.setItem('temp_profile_college', college);
    sessionStorage.setItem('temp_profile_gradYear', gradYear);
    sessionStorage.setItem('temp_profile_skills', JSON.stringify(skills));
    sessionStorage.setItem('temp_profile_achievement', achievement);
    sessionStorage.setItem('temp_profile_project', projectTitle);
    sessionStorage.setItem('temp_profile_certification', certification);
    sessionStorage.setItem('temp_profile_experience', experience);

    setAuthState('career_goal');
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col justify-between px-5 py-6 font-sans">
      {/* Top Header & Progress */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setAuthState('account_type')}
              className="p-2 -ml-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors active:scale-95"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white font-display">
                Let's build your profile
              </h1>
              <p className="text-xs text-slate-400">
                Step 1 of 3 — Profile & Background
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-indigo-400">33%</span>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1.5 bg-slate-800 rounded-full mb-4 overflow-hidden">
          <div className="h-full bg-indigo-500 rounded-full w-1/3 transition-all duration-300" />
        </div>

        {/* Scrollable Form Content */}
        <div className="overflow-y-auto max-h-[66vh] space-y-4 pr-1">
          {/* Profile Photo Avatar Selection */}
          <div className="flex items-center gap-4 p-3.5 bg-slate-800/60 border border-slate-700/80 rounded-2xl">
            <div className="relative">
              <img
                src={avatarUrl}
                alt="Profile"
                className="w-16 h-16 rounded-full object-cover border-2 border-indigo-500 shadow-md"
              />
              <button
                type="button"
                onClick={() => {
                  const avatars = [
                    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
                    'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
                    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
                    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80'
                  ];
                  const currentIndex = avatars.indexOf(avatarUrl);
                  const nextIndex = (currentIndex + 1) % avatars.length;
                  setAvatarUrl(avatars[nextIndex]);
                }}
                className="absolute bottom-0 right-0 p-1.5 rounded-full bg-indigo-600 text-white shadow-md hover:bg-indigo-500 active:scale-95"
                title="Change Photo"
              >
                <Camera className="w-3 h-3" />
              </button>
            </div>
            <div>
              <p className="text-xs font-bold text-white">Profile Photo</p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Tap camera to switch avatar or upload professional photo.
              </p>
            </div>
          </div>

          {/* Full Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Full Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white focus:outline-hidden focus:border-indigo-500"
              required
            />
          </div>

          {/* Education Level */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Education Level
            </label>
            <select
              value={education}
              onChange={(e) => setEducation(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white focus:outline-hidden focus:border-indigo-500"
            >
              <option value="Undergraduate (B.Tech / B.E / B.Sc / BCA)">Undergraduate (B.Tech / B.E / B.Sc / BCA)</option>
              <option value="Postgraduate (M.Tech / MBA / MCA / M.Sc)">Postgraduate (M.Tech / MBA / MCA / M.Sc)</option>
              <option value="Diploma / Polytechnic">Diploma / Polytechnic</option>
              <option value="Experienced Professional">Experienced Working Professional</option>
            </select>
          </div>

          {/* Course & Major */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Course / Major
            </label>
            <input
              type="text"
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              placeholder="e.g. Computer Science & Engineering"
              className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          {/* College / Institution */}
          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                College / Institution
              </label>
              <input
                type="text"
                value={college}
                onChange={(e) => setCollege(e.target.value)}
                placeholder="e.g. Sri Krishna College of Technology"
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white focus:outline-hidden focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Grad Year
              </label>
              <select
                value={gradYear}
                onChange={(e) => setGradYear(e.target.value)}
                className="w-full px-2.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white focus:outline-hidden focus:border-indigo-500"
              >
                <option value="2024">2024</option>
                <option value="2025">2025</option>
                <option value="2026">2026</option>
                <option value="2027">2027</option>
                <option value="2023">2023</option>
              </select>
            </div>
          </div>

          {/* Skills Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Skills (Select or Add)
            </label>
            
            {/* Selected Skills Chips */}
            <div className="flex flex-wrap gap-1.5 mb-2">
              {skills.map((s) => (
                <span
                  key={s}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-600/30 border border-indigo-500/50 text-indigo-200 text-xs font-medium"
                >
                  {s}
                  <button
                    type="button"
                    onClick={() => handleRemoveSkill(s)}
                    className="hover:text-white"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>

            {/* Custom Skill Input */}
            <form onSubmit={handleAddCustomSkill} className="flex gap-2 mb-2">
              <input
                type="text"
                placeholder="Add another skill..."
                value={customSkill}
                onChange={(e) => setCustomSkill(e.target.value)}
                className="flex-1 px-3 py-1.5 bg-slate-800/80 border border-slate-700/80 rounded-lg text-xs text-white focus:outline-hidden focus:border-indigo-500"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg"
              >
                Add
              </button>
            </form>

            {/* Suggested Skills */}
            <div className="flex flex-wrap gap-1">
              {SUGGESTED_SKILLS.filter(s => !skills.includes(s)).slice(0, 6).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => handleAddSkill(s)}
                  className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-400 hover:text-slate-200 border border-slate-700/50 flex items-center gap-1"
                >
                  <Plus className="w-2.5 h-2.5" />
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Key Achievement */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Top Achievement
            </label>
            <input
              type="text"
              value={achievement}
              onChange={(e) => setAchievement(e.target.value)}
              placeholder="e.g. 1st Place in College Hackathon"
              className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          {/* Key Project */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Featured Project
            </label>
            <input
              type="text"
              value={projectTitle}
              onChange={(e) => setProjectTitle(e.target.value)}
              placeholder="e.g. Customer Churn Predictive Analytics Dashboard"
              className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          {/* Key Certification */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Certifications
            </label>
            <input
              type="text"
              value={certification}
              onChange={(e) => setCertification(e.target.value)}
              placeholder="e.g. Google Data Analytics Certificate"
              className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          {/* Experience */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Work Experience / Internship
            </label>
            <input
              type="text"
              value={experience}
              onChange={(e) => setExperience(e.target.value)}
              placeholder="e.g. Intern at FinTech Labs (3 months) or Fresher"
              className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white focus:outline-hidden focus:border-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Sticky Bottom Continue Button */}
      <div className="pt-3">
        <button
          onClick={handleContinue}
          className="w-full py-4 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-base shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
        >
          <span>Continue</span>
        </button>
      </div>
    </div>
  );
};
