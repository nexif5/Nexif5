import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  LayoutDashboard,
  Settings,
  Bell,
  HelpCircle,
  LogOut,
  X,
  FileText,
  Sparkles,
  ChevronRight,
  Sun,
  Moon,
  Globe,
  MessageSquare,
  Users
} from 'lucide-react';
import { SUPPORTED_LANGUAGES } from '../../services/i18n';

interface MobileProfileMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenNotifications: () => void;
}

export const MobileProfileMenuDrawer: React.FC<MobileProfileMenuDrawerProps> = ({
  isOpen,
  onClose,
  onOpenNotifications
}) => {
  const {
    currentStudent,
    currentProfessional,
    currentCompany,
    currentCollege,
    currentMentor,
    setMobileTab,
    setSubView,
    logoutUser,
    currentRole,
    switchToStudentDemo,
    switchToProfessionalDemo,
    switchToRecruiterDemo,
    switchToCollegeDemo,
    switchToMentorDemo,
    switchToAdminDemo,
    theme,
    toggleTheme,
    currentLanguage,
    setAuthState,
    chatConversations,
    connectionRequests
  } = useApp();

  if (!isOpen) return null;

  const unreadMessagesCount = chatConversations.reduce((acc, c) => acc + (c.unreadCount || 0), 0);
  const pendingRequestsCount = connectionRequests.filter(r => r.status === 'pending' && r.receiverId === (
    currentRole === 'recruiter' ? currentCompany.id :
    currentRole === 'college' ? currentCollege.id :
    currentRole === 'mentor' ? currentMentor.id :
    currentRole === 'professional' ? currentProfessional.id :
    currentStudent.id
  )).length;

  const isLight = theme === 'light';
  const currentLangObj = SUPPORTED_LANGUAGES.find(l => l.code === currentLanguage) || SUPPORTED_LANGUAGES[0];

  const currentAvatar =
    currentRole === 'recruiter'
      ? currentCompany.logoUrl
      : currentRole === 'college'
      ? currentCollege.logoUrl
      : currentRole === 'professional' || currentRole === 'job_seeker'
      ? currentProfessional.avatarUrl
      : currentRole === 'mentor'
      ? currentMentor.avatarUrl
      : currentRole === 'admin'
      ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'
      : currentStudent.avatarUrl;

  const currentDisplayName =
    currentRole === 'recruiter'
      ? currentCompany.name
      : currentRole === 'college'
      ? currentCollege.name
      : currentRole === 'professional' || currentRole === 'job_seeker'
      ? currentProfessional.name
      : currentRole === 'mentor'
      ? currentMentor.name
      : currentRole === 'admin'
      ? 'NEXIF5 Admin'
      : currentStudent.name;

  const currentDisplayEmail =
    currentRole === 'recruiter'
      ? 'rajesh.m@abctechnologies.io'
      : currentRole === 'college'
      ? 'ramanathan.placement@rathinam.ac.in'
      : currentRole === 'professional' || currentRole === 'job_seeker'
      ? currentProfessional.email
      : currentRole === 'mentor'
      ? currentMentor.email
      : currentRole === 'admin'
      ? 'admin@nexif5.io'
      : currentStudent.email;

  const roleLabel =
    currentRole === 'recruiter'
      ? 'Recruiter / Company'
      : currentRole === 'college'
      ? 'College / Institution'
      : currentRole === 'professional' || currentRole === 'job_seeker'
      ? 'Working Professional'
      : currentRole === 'mentor'
      ? 'Mentor'
      : currentRole === 'admin'
      ? 'Administrator'
      : 'Student';

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-slate-950/70 backdrop-blur-xs font-sans">
      {/* Tap backdrop to dismiss */}
      <div className="flex-1" onClick={onClose} />

      {/* Bottom Sheet Drawer */}
      <div className={`rounded-t-3xl border-t p-5 space-y-4 shadow-2xl max-h-[85vh] overflow-y-auto transition-colors duration-200 ${
        isLight
          ? 'bg-white border-slate-200 text-slate-900'
          : 'bg-slate-900 border-slate-800 text-white'
      }`}>
        {/* Top Header with Avatar */}
        <div className={`flex items-center justify-between pb-3 border-b ${
          isLight ? 'border-slate-200' : 'border-slate-800'
        }`}>
          <div className="flex items-center gap-3">
            <img
              src={currentAvatar}
              alt={currentDisplayName}
              className="w-12 h-12 rounded-full object-cover border-2 border-indigo-500 shadow-sm"
            />
            <div>
              <h3 className={`font-bold text-base leading-tight font-display ${
                isLight ? 'text-slate-900' : 'text-white'
              }`}>
                {currentDisplayName}
              </h3>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>{currentDisplayEmail}</p>
              <span className="inline-block mt-0.5 px-2 py-0.5 rounded-md bg-indigo-500/15 text-indigo-600 dark:text-indigo-300 text-[10px] font-bold">
                {roleLabel}
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`p-2 rounded-xl transition-colors ${
              isLight ? 'text-slate-500 hover:text-slate-800 bg-slate-100' : 'text-slate-400 hover:text-white bg-slate-800/80'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Settings: Theme & Language Toggle Row */}
        <div className="grid grid-cols-2 gap-2">
          {/* Quick Theme Switch */}
          <button
            onClick={toggleTheme}
            className={`p-3 rounded-2xl border flex items-center justify-between transition-all ${
              isLight
                ? 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-slate-100'
                : 'bg-slate-800/60 border-slate-700 text-slate-200 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-2">
              {isLight ? (
                <Sun className="w-4 h-4 text-amber-500" />
              ) : (
                <Moon className="w-4 h-4 text-indigo-400" />
              )}
              <span className="text-xs font-semibold">
                {isLight ? 'White Mode' : 'Dark Mode'}
              </span>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/15 text-indigo-600 font-bold">
              Toggle
            </span>
          </button>

          {/* Quick Language Switch */}
          <button
            onClick={() => {
              onClose();
              setAuthState('language');
            }}
            className={`p-3 rounded-2xl border flex items-center justify-between transition-all ${
              isLight
                ? 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-slate-100'
                : 'bg-slate-800/60 border-slate-700 text-slate-200 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-indigo-500" />
              <span className="text-xs font-semibold">{currentLangObj.name}</span>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/15 text-indigo-600 font-bold">
              Change
            </span>
          </button>
        </div>

        {/* Menu Items */}
        <div className="space-y-1">
          {/* My Profile */}
          <button
            onClick={() => {
              onClose();
              setSubView(null);
              setMobileTab('profile');
            }}
            className={`w-full p-3 rounded-xl flex items-center justify-between text-xs font-semibold transition-colors ${
              isLight
                ? 'text-slate-800 hover:bg-slate-100'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <User className="w-4 h-4 text-indigo-500" />
              <span>My Profile</span>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-slate-500'}`} />
          </button>

          {/* Professional Network & Connections */}
          <button
            onClick={() => {
              onClose();
              setSubView('network');
            }}
            className={`w-full p-3 rounded-xl flex items-center justify-between text-xs font-semibold transition-colors ${
              isLight
                ? 'text-slate-800 hover:bg-slate-100'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <Users className="w-4 h-4 text-indigo-500" />
              <span>Professional Network & Connect</span>
            </div>
            <div className="flex items-center gap-1.5">
              {pendingRequestsCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[9px] font-bold">
                  {pendingRequestsCount} new
                </span>
              )}
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-slate-500'}`} />
            </div>
          </button>

          {/* Direct Messages & Inquiries */}
          <button
            onClick={() => {
              onClose();
              setSubView('messages');
            }}
            className={`w-full p-3 rounded-xl flex items-center justify-between text-xs font-semibold transition-colors ${
              isLight
                ? 'text-slate-800 hover:bg-slate-100'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <MessageSquare className="w-4 h-4 text-emerald-500" />
              <span>Messages & Inquiries</span>
            </div>
            <div className="flex items-center gap-1.5">
              {unreadMessagesCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-indigo-600 text-white text-[9px] font-bold">
                  {unreadMessagesCount} unread
                </span>
              )}
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-slate-500'}`} />
            </div>
          </button>

          {/* Learning Hub & Document Sharing */}
          <button
            onClick={() => {
              onClose();
              setSubView(null);
              setMobileTab('learn');
            }}
            className={`w-full p-3 rounded-xl flex items-center justify-between text-xs font-semibold transition-colors ${
              isLight
                ? 'text-slate-800 hover:bg-slate-100'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <FileText className="w-4 h-4 text-indigo-500" />
              <span>Learning Hub & Document Sharing</span>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-slate-500'}`} />
          </button>

          {/* AI Career Analysis */}
          <button
            onClick={() => {
              onClose();
              setSubView(null);
              setMobileTab('career');
            }}
            className={`w-full p-3 rounded-xl flex items-center justify-between text-xs font-semibold transition-colors ${
              isLight
                ? 'text-slate-800 hover:bg-slate-100'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <LayoutDashboard className="w-4 h-4 text-blue-500" />
              <span>AI Career Analysis & Roadmaps</span>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-slate-500'}`} />
          </button>

          {/* ATS Resume Builder */}
          <button
            onClick={() => {
              onClose();
              setSubView('resume');
            }}
            className={`w-full p-3 rounded-xl flex items-center justify-between text-xs font-semibold transition-colors ${
              isLight
                ? 'text-slate-800 hover:bg-slate-100'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <FileText className="w-4 h-4 text-emerald-500" />
              <span>ATS Resume Builder</span>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-slate-500'}`} />
          </button>

          {/* Mock Interview */}
          <button
            onClick={() => {
              onClose();
              setSubView('interview_prep');
            }}
            className={`w-full p-3 rounded-xl flex items-center justify-between text-xs font-semibold transition-colors ${
              isLight
                ? 'text-slate-800 hover:bg-slate-100'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <Sparkles className="w-4 h-4 text-purple-500" />
              <span>AI Mock Interview Simulator</span>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-slate-500'}`} />
          </button>

          {/* Notifications */}
          <button
            onClick={() => {
              onClose();
              onOpenNotifications();
            }}
            className={`w-full p-3 rounded-xl flex items-center justify-between text-xs font-semibold transition-colors ${
              isLight
                ? 'text-slate-800 hover:bg-slate-100'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <Bell className="w-4 h-4 text-amber-500" />
              <span>Notifications & Alerts</span>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-slate-500'}`} />
          </button>

          {/* Settings */}
          <button
            onClick={() => {
              onClose();
              setSubView('settings');
            }}
            className={`w-full p-3 rounded-xl flex items-center justify-between text-xs font-semibold transition-colors ${
              isLight
                ? 'text-slate-800 hover:bg-slate-100'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <Settings className={`w-4 h-4 ${isLight ? 'text-slate-600' : 'text-slate-400'}`} />
              <span>Settings & Appearance</span>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-slate-500'}`} />
          </button>

          {/* Help & Support */}
          <button
            onClick={() => {
              onClose();
              setMobileTab('ai');
            }}
            className={`w-full p-3 rounded-xl flex items-center justify-between text-xs font-semibold transition-colors ${
              isLight
                ? 'text-slate-800 hover:bg-slate-100'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <HelpCircle className="w-4 h-4 text-cyan-500" />
              <span>Help & AI Guidance</span>
            </div>
            <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-slate-500'}`} />
          </button>
        </div>

        {/* Role Switcher Grid */}
        <div className={`p-3 rounded-2xl border ${
          isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/60 border-slate-700/80'
        }`}>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            Switch Perspective Role
          </p>
          <div className="grid grid-cols-3 gap-1.5 text-[10px]">
            <button
              onClick={() => {
                switchToStudentDemo('std-1');
                onClose();
              }}
              className="py-1.5 px-2 rounded-lg bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 font-bold border border-blue-500/30 truncate"
            >
              🎓 Student
            </button>
            <button
              onClick={() => {
                switchToProfessionalDemo('pro-1');
                onClose();
              }}
              className="py-1.5 px-2 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 font-bold border border-amber-500/30 truncate"
            >
              💼 Professional
            </button>
            <button
              onClick={() => {
                switchToRecruiterDemo('comp-1');
                onClose();
              }}
              className="py-1.5 px-2 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30 truncate"
            >
              🏢 Recruiter
            </button>
            <button
              onClick={() => {
                switchToCollegeDemo('clg-1');
                onClose();
              }}
              className="py-1.5 px-2 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 font-bold border border-purple-500/30 truncate"
            >
              🏫 College
            </button>
            <button
              onClick={() => {
                switchToMentorDemo('men-1');
                onClose();
              }}
              className="py-1.5 px-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 font-bold border border-cyan-500/30 truncate"
            >
              🎖️ Mentor
            </button>
            <button
              onClick={() => {
                switchToAdminDemo();
                onClose();
              }}
              className="py-1.5 px-2 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-bold border border-rose-500/30 truncate"
            >
              🛡️ Admin
            </button>
          </div>
        </div>

        {/* Log Out */}
        <div className={`pt-2 border-t ${isLight ? 'border-slate-200' : 'border-slate-800'}`}>
          <button
            onClick={() => {
              onClose();
              logoutUser();
            }}
            className="w-full p-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 dark:text-rose-400 flex items-center justify-center gap-2 text-xs font-bold transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Log Out</span>
          </button>
        </div>
      </div>
    </div>
  );
};
