import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  TrendingUp,
  Sparkles,
  Award,
  Briefcase,
  ChevronRight,
  Eye,
  MessageSquare,
  CheckCircle2,
  DollarSign,
  BookOpen,
  ArrowUpRight,
  Play,
  Users,
  UserPlus
} from 'lucide-react';

export const MobileProfessionalDashboard: React.FC = () => {
  const {
    currentProfessional,
    setMobileTab,
    setSubView,
    openCourseLearning,
    certifiedCourses,
    jobs,
    smartRecommendations,
    openUserProfile,
    sendConnectionRequest,
    getConnectionStatusWithUser,
    theme
  } = useApp();

  const isLight = theme === 'light';

  // Matched senior jobs
  const seniorJobs = jobs.filter(j =>
    j.title.toLowerCase().includes('senior') ||
    j.title.toLowerCase().includes('analyst') ||
    j.title.toLowerCase().includes('lead')
  ).slice(0, 3);

  // Recommended upskilling courses
  const recommendedCourses = certifiedCourses.slice(0, 2);

  return (
    <div className={`p-4 space-y-4 pb-24 font-sans ${isLight ? 'text-slate-900' : 'text-white'}`}>
      {/* Professional Profile Header */}
      <div className={`p-4 rounded-2xl border ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <img
              src={currentProfessional.avatarUrl}
              alt={currentProfessional.name}
              className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-500 shadow-md"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold font-display">{currentProfessional.name}</h1>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-300 font-bold">
                  Professional
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {currentProfessional.currentJobTitle} • {currentProfessional.currentCompany}
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {currentProfessional.totalExperienceYears} Yrs Exp • {currentProfessional.location}
              </p>
            </div>
          </div>
        </div>

        {/* Career Growth Score Tile */}
        <div className={`mt-3.5 p-3 rounded-xl border flex items-center justify-between ${
          isLight ? 'bg-amber-50/80 border-amber-200 text-slate-800' : 'bg-amber-950/40 border-amber-500/30 text-white'
        }`}>
          <div className="flex items-center gap-2.5">
            <TrendingUp className="w-5 h-5 text-amber-500" />
            <div>
              <p className="text-xs font-bold">
                Promotion Readiness: {currentProfessional.careerGrowthScore}%
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                Aiming for: <strong>{currentProfessional.careerGoal}</strong>
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-500/20 text-amber-600 dark:text-amber-300 rounded-md">
            Top 10% Tier
          </span>
        </div>
      </div>

      {/* Recruiter Activity & Compensation Benchmark */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Eye className="w-4 h-4 text-blue-500" />
            <span className="text-[10px] text-emerald-500 font-bold">+18% this wk</span>
          </div>
          <p className="text-xl font-black font-display">{currentProfessional.profileViewsCount}</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Recruiter Views</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <DollarSign className="w-4 h-4 text-emerald-500" />
            <span className="text-[10px] text-emerald-500 font-bold">Target</span>
          </div>
          <p className="text-xl font-black font-display">₹{currentProfessional.salaryTargetLPA} LPA</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">CTC Benchmark</p>
        </div>
      </div>

      {/* Priority Skill Gaps & Upskilling */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <h2 className="text-sm font-bold">Priority Skill Gaps for Promotion</h2>
          </div>
          <span className="text-[10px] text-amber-500 font-bold">AI Diagnosis</span>
        </div>

        <div className="space-y-2">
          {currentProfessional.targetSkills.map((sk, i) => (
            <div
              key={i}
              className={`p-2.5 rounded-xl border flex items-center justify-between text-xs ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                <span className="font-semibold">{sk}</span>
              </div>
              <button
                onClick={() => setMobileTab('learn')}
                className="text-[11px] font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-0.5"
              >
                <span>Learn</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Recommended Certified Upskilling Courses */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-indigo-500" />
            <h2 className="text-sm font-bold">Recommended Certified Courses</h2>
          </div>
          <button
            onClick={() => setMobileTab('learn')}
            className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            View All
          </button>
        </div>

        <div className="space-y-2.5">
          {recommendedCourses.map((c) => (
            <div
              key={c.id}
              className={`p-3 rounded-xl border space-y-2 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-xs font-bold line-clamp-1">{c.title}</h3>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    {c.partner} • {c.durationLabel}
                  </p>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-md bg-indigo-500/15 text-indigo-600 dark:text-indigo-300 font-bold shrink-0">
                  {c.level}
                </span>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[10px] text-emerald-500 font-bold">
                  {c.careerReadinessImpact}
                </span>
                <button
                  onClick={() => openCourseLearning(c.id)}
                  className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold flex items-center gap-1"
                >
                  <Play className="w-3 h-3 fill-white" />
                  <span>Start Module</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recommended Industry Connections & Mentors */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-indigo-500" />
            <h2 className="text-sm font-bold">Recommended Industry Connections</h2>
          </div>
          <button
            onClick={() => setSubView('network')}
            className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            Network Hub
          </button>
        </div>

        <div className="space-y-2.5">
          {smartRecommendations.filter(r => r.role === 'mentor' || r.role === 'recruiter' || r.role === 'professional').slice(0, 2).map((rec) => {
            const status = getConnectionStatusWithUser(rec.userId);

            return (
              <div
                key={rec.userId}
                className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800'
                }`}
              >
                <div
                  className="flex items-center gap-2.5 min-w-0 cursor-pointer flex-1"
                  onClick={() => openUserProfile(rec.userId)}
                >
                  <img
                    src={rec.avatarUrl}
                    alt={rec.name}
                    className="w-10 h-10 rounded-full object-cover border border-amber-500/40 shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="font-bold text-xs truncate hover:text-indigo-500">{rec.name}</p>
                    <p className="text-[10px] text-slate-400 truncate">{rec.headline}</p>
                    <span className="text-[9px] px-1.5 py-0.2 rounded font-bold bg-amber-500/10 text-amber-500">
                      {rec.role.toUpperCase()}
                    </span>
                  </div>
                </div>

                <div className="shrink-0">
                  {status === 'connected' ? (
                    <span className="text-[10px] font-bold text-emerald-500">Connected</span>
                  ) : status === 'pending_sent' ? (
                    <span className="text-[10px] text-amber-500 font-semibold">Sent</span>
                  ) : (
                    <button
                      onClick={() => sendConnectionRequest(rec.userId)}
                      className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold flex items-center gap-1 shadow-xs"
                    >
                      <UserPlus className="w-3 h-3" />
                      <span>Connect</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Target Job Openings */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-emerald-500" />
            <h2 className="text-sm font-bold">Executive & Senior Openings</h2>
          </div>
          <button
            onClick={() => setMobileTab('jobs')}
            className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
          >
            Explore
          </button>
        </div>

        <div className="space-y-2">
          {seniorJobs.map((j) => (
            <div
              key={j.id}
              onClick={() => setMobileTab('jobs')}
              className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                isLight ? 'bg-slate-50 hover:bg-slate-100 border-slate-200' : 'bg-slate-900/60 hover:bg-slate-800 border-slate-800'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <img src={j.companyLogoUrl} alt={j.companyName} className="w-9 h-9 rounded-lg object-cover" />
                <div>
                  <h3 className="text-xs font-bold">{j.title}</h3>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    {j.companyName} • {j.salaryDisplay}
                  </p>
                </div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-400" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
