import React from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { SUPPORTED_LANGUAGES } from '../../services/i18n';
import { Sparkles, ArrowRight, ShieldCheck, Zap, Globe, Compass, Sun, Moon } from 'lucide-react';

export const WelcomeScreen: React.FC = () => {
  const { setAuthState, currentLanguage, theme, toggleTheme } = useApp();

  const currentLangObj = SUPPORTED_LANGUAGES.find(l => l.code === currentLanguage) || SUPPORTED_LANGUAGES[0];
  const isLight = theme === 'light';

  return (
    <div className={`min-h-screen flex flex-col justify-between px-6 py-8 relative overflow-hidden font-sans transition-colors duration-300 ${
      isLight
        ? 'bg-gradient-to-b from-slate-50 via-indigo-50/40 to-slate-100 text-slate-900'
        : 'bg-gradient-to-b from-slate-950 via-slate-900 to-indigo-950 text-white'
    }`}>
      {/* Background glowing ambient elements */}
      <div className={`absolute -top-32 -left-32 w-80 h-80 rounded-full blur-3xl pointer-events-none ${
        isLight ? 'bg-indigo-300/30' : 'bg-indigo-600/20'
      }`} />
      <div className={`absolute top-1/2 -right-32 w-80 h-80 rounded-full blur-3xl pointer-events-none ${
        isLight ? 'bg-blue-300/20' : 'bg-blue-600/15'
      }`} />
      <div className={`absolute -bottom-32 left-10 w-80 h-80 rounded-full blur-3xl pointer-events-none ${
        isLight ? 'bg-purple-300/25' : 'bg-purple-600/20'
      }`} />

      {/* Top Bar with Brand, Theme Toggle & Language Switcher */}
      <div className="relative z-10 flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center shadow-lg shadow-indigo-500/25 border border-indigo-400/30">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <span className={`text-xl font-extrabold tracking-tight font-display ${
            isLight ? 'text-slate-900' : 'text-white'
          }`}>
            NEXIF5
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Theme Switcher Toggle Button */}
          <button
            onClick={toggleTheme}
            className={`p-2 rounded-full border backdrop-blur-md transition-all active:scale-95 flex items-center justify-center ${
              isLight
                ? 'bg-white/80 border-slate-200 text-slate-700 shadow-xs hover:bg-white'
                : 'bg-white/10 border-white/15 text-slate-200 hover:bg-white/15'
            }`}
            title={isLight ? 'Switch to Dark Mode' : 'Switch to White Mode'}
            aria-label="Toggle Theme"
          >
            {isLight ? (
              <Moon className="w-4 h-4 text-indigo-600" />
            ) : (
              <Sun className="w-4 h-4 text-amber-400" />
            )}
          </button>

          {/* Language selector pill */}
          <button
            onClick={() => setAuthState('language')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full backdrop-blur-md border text-xs font-semibold transition-all active:scale-95 ${
              isLight
                ? 'bg-white/80 border-slate-200 text-slate-800 shadow-xs hover:bg-white'
                : 'bg-white/10 border-white/15 text-slate-200 hover:bg-white/15'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-indigo-500" />
            <span>{currentLangObj.name} ({currentLangObj.nativeName})</span>
          </button>
        </div>
      </div>

      {/* Hero Visual & Headline */}
      <div className="relative z-10 my-auto py-8 space-y-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-4"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-600 dark:text-indigo-300 text-xs font-semibold">
            <Zap className="w-3.5 h-3.5 text-indigo-500" />
            <span>AI-Powered Career Execution Platform</span>
          </div>

          <h1 className={`text-3xl sm:text-4xl font-extrabold tracking-tight leading-tight font-display ${
            isLight ? 'text-slate-900' : 'text-white'
          }`}>
            From Learning to Opportunity. <br />
            <span className="bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 bg-clip-text text-transparent">
              From Potential to Career.
            </span>
          </h1>

          <p className={`text-xs leading-relaxed max-w-sm mx-auto ${
            isLight ? 'text-slate-600' : 'text-slate-300/90'
          }`}>
            AI identifies skill gaps, recommends personalized learning, provides practical next actions, and connects you with verified career opportunities.
          </p>
        </motion.div>

        {/* Feature Highlights Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="grid grid-cols-3 gap-2.5 pt-2 max-w-xs mx-auto text-left"
        >
          <div className={`rounded-2xl p-3 border transition-colors ${
            isLight
              ? 'bg-white/80 border-slate-200 shadow-xs'
              : 'bg-white/5 border-white/10'
          }`}>
            <div className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-500 flex items-center justify-center mb-2">
              <Zap className="w-4 h-4" />
            </div>
            <p className={`text-[11px] font-bold leading-tight ${isLight ? 'text-slate-900' : 'text-slate-200'}`}>94% AI Match</p>
            <p className={`text-[9px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Target Roles</p>
          </div>

          <div className={`rounded-2xl p-3 border transition-colors ${
            isLight
              ? 'bg-white/80 border-slate-200 shadow-xs'
              : 'bg-white/5 border-white/10'
          }`}>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-500 flex items-center justify-center mb-2">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <p className={`text-[11px] font-bold leading-tight ${isLight ? 'text-slate-900' : 'text-slate-200'}`}>Smart Resume</p>
            <p className={`text-[9px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>ATS Optimized</p>
          </div>

          <div className={`rounded-2xl p-3 border transition-colors ${
            isLight
              ? 'bg-white/80 border-slate-200 shadow-xs'
              : 'bg-white/5 border-white/10'
          }`}>
            <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-500 flex items-center justify-center mb-2">
              <Compass className="w-4 h-4" />
            </div>
            <p className={`text-[11px] font-bold leading-tight ${isLight ? 'text-slate-900' : 'text-slate-200'}`}>Direct Apply</p>
            <p className={`text-[9px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>To Companies</p>
          </div>
        </motion.div>
      </div>

      {/* Bottom CTA Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.25 }}
        className="relative z-10 space-y-3 pb-2"
      >
        <button
          onClick={() => setAuthState('language')}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-base shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
        >
          <span>Get Started</span>
          <ArrowRight className="w-5 h-5" />
        </button>

        <button
          onClick={() => setAuthState('login')}
          className={`w-full py-3.5 px-6 rounded-2xl border font-bold text-sm flex items-center justify-center transition-all active:scale-[0.98] ${
            isLight
              ? 'bg-white border-slate-300 text-slate-800 hover:bg-slate-50 shadow-xs'
              : 'bg-white/10 hover:bg-white/15 border-white/15 text-slate-200 hover:text-white'
          }`}
        >
          Sign In
        </button>

        <p className={`text-center text-[11px] pt-1 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
          Students ↔ Companies ↔ Colleges Ecosystem
        </p>
      </motion.div>
    </div>
  );
};
