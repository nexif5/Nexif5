import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, Sun, Moon, Globe, LogOut, Check, Sparkles, CheckCircle2 } from 'lucide-react';
import { SUPPORTED_LANGUAGES, LanguageCode } from '../../services/i18n';

export const MobileSettingsScreen: React.FC = () => {
  const { setSubView, currentStudent, setAuthState, logoutUser, currentLanguage, setCurrentLanguage, theme, setTheme } = useApp();

  const [emailNotifs, setEmailNotifs] = useState(true);
  const [jobAlerts, setJobAlerts] = useState(true);
  const [interviewReminders, setInterviewReminders] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const isLight = theme === 'light';
  const currentLangObj = SUPPORTED_LANGUAGES.find(l => l.code === currentLanguage) || SUPPORTED_LANGUAGES[0];

  const handleSave = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const quickLanguages: LanguageCode[] = ['en', 'ta', 'hi', 'te', 'ml', 'kn'];

  return (
    <div className={`space-y-5 px-4 pt-4 pb-24 font-sans min-h-screen transition-colors duration-200 ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-white'
    }`}>
      {/* Top Bar */}
      <div className={`flex items-center justify-between pb-3 border-b ${
        isLight ? 'border-slate-200' : 'border-slate-800'
      }`}>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSubView(null)}
            className={`p-2 -ml-1 rounded-xl transition-colors ${
              isLight
                ? 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className={`text-lg font-bold font-display ${isLight ? 'text-slate-900' : 'text-white'}`}>
              Settings
            </h1>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Appearance, language, and preferences
            </p>
          </div>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-300 text-xs flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>Settings saved successfully!</span>
        </div>
      )}

      {/* Appearance / Theme Mode Selector */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <h3 className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
            Appearance & Theme
          </h3>
          <span className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400">
            {theme === 'light' ? 'White / Light Mode' : 'Dark Mode'}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-1">
          {/* Light / White Mode Card */}
          <button
            onClick={() => setTheme('light')}
            className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all ${
              theme === 'light'
                ? 'bg-indigo-50 border-indigo-600 ring-2 ring-indigo-600/20 shadow-xs'
                : isLight
                ? 'bg-slate-50 border-slate-200 hover:border-slate-300'
                : 'bg-slate-900/60 border-slate-700 hover:border-slate-600'
            }`}
          >
            <div className="flex items-center justify-between w-full mb-3">
              <div className="w-8 h-8 rounded-xl bg-amber-500/15 text-amber-600 flex items-center justify-center">
                <Sun className="w-4 h-4" />
              </div>
              {theme === 'light' && (
                <div className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                  <Check className="w-3 h-3" />
                </div>
              )}
            </div>
            <div>
              <p className={`text-xs font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                White Mode
              </p>
              <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Crisp & high contrast
              </p>
            </div>
          </button>

          {/* Dark Mode Card */}
          <button
            onClick={() => setTheme('dark')}
            className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all ${
              theme === 'dark'
                ? 'bg-indigo-950/40 border-indigo-500 ring-2 ring-indigo-500/30'
                : isLight
                ? 'bg-slate-50 border-slate-200 hover:border-slate-300'
                : 'bg-slate-900/60 border-slate-700 hover:border-slate-600'
            }`}
          >
            <div className="flex items-center justify-between w-full mb-3">
              <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                <Moon className="w-4 h-4" />
              </div>
              {theme === 'dark' && (
                <div className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                  <Check className="w-3 h-3" />
                </div>
              )}
            </div>
            <div>
              <p className={`text-xs font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                Dark Mode
              </p>
              <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Eye-friendly in dim light
              </p>
            </div>
          </button>
        </div>
      </div>

      {/* Language Section */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <div>
            <h3 className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Language / மொழி
            </h3>
            <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
              Selected: <span className="font-bold text-indigo-600 dark:text-indigo-400">{currentLangObj.name} ({currentLangObj.nativeName})</span>
            </p>
          </div>
          <button
            onClick={() => setAuthState('language')}
            className="px-3 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-bold transition-all shadow-xs hover:bg-indigo-500"
          >
            All Languages
          </button>
        </div>

        {/* Quick Language Chips */}
        <div className="grid grid-cols-3 gap-2 pt-1">
          {quickLanguages.map((code) => {
            const lang = SUPPORTED_LANGUAGES.find(l => l.code === code);
            if (!lang) return null;
            const isSelected = currentLanguage === code;
            return (
              <button
                key={code}
                onClick={() => setCurrentLanguage(code)}
                className={`py-2 px-2.5 rounded-xl border text-center transition-all ${
                  isSelected
                    ? 'bg-indigo-600 text-white border-indigo-600 font-bold shadow-xs'
                    : isLight
                    ? 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
                    : 'bg-slate-900/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="text-[11px] font-bold leading-tight">{lang.name}</div>
                <div className="text-[9px] opacity-80 mt-0.5">{lang.nativeName}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Account Profile Info */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <h3 className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
          Account Profile
        </h3>

        <div>
          <label className={`block text-xs mb-1 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>Full Name</label>
          <input
            type="text"
            defaultValue={currentStudent.name}
            className={`w-full px-3.5 py-2 rounded-xl text-xs border ${
              isLight
                ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white'
                : 'bg-slate-900/80 border-slate-700 text-white'
            }`}
          />
        </div>

        <div>
          <label className={`block text-xs mb-1 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>Email</label>
          <input
            type="email"
            defaultValue={currentStudent.email}
            disabled
            className={`w-full px-3.5 py-2 rounded-xl text-xs border ${
              isLight
                ? 'bg-slate-100 border-slate-200 text-slate-500'
                : 'bg-slate-900/40 border-slate-800 text-slate-400'
            }`}
          />
        </div>
      </div>

      {/* Notifications Preferences */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <h3 className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
          Notifications & Alerts
        </h3>

        <div className="flex items-center justify-between">
          <div>
            <p className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>Job Matches Alert</p>
            <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Get notified when 90%+ match jobs appear</p>
          </div>
          <input
            type="checkbox"
            checked={jobAlerts}
            onChange={(e) => setJobAlerts(e.target.checked)}
            className="w-4 h-4 rounded text-indigo-600 accent-indigo-600"
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <p className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>Interview Reminders</p>
            <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Preparation alerts and interview reminders</p>
          </div>
          <input
            type="checkbox"
            checked={interviewReminders}
            onChange={(e) => setInterviewReminders(e.target.checked)}
            className="w-4 h-4 rounded text-indigo-600 accent-indigo-600"
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <p className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>Email Digest</p>
            <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Weekly career opportunities summary</p>
          </div>
          <input
            type="checkbox"
            checked={emailNotifs}
            onChange={(e) => setEmailNotifs(e.target.checked)}
            className="w-4 h-4 rounded text-indigo-600 accent-indigo-600"
          />
        </div>
      </div>

      {/* Save Button */}
      <button
        onClick={handleSave}
        className="w-full py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/25 transition-all active:scale-[0.98]"
      >
        Save Preferences
      </button>

      {/* Logout Action */}
      <div className="pt-2">
        <button
          onClick={logoutUser}
          className="w-full py-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 dark:text-rose-400 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          <span>Log Out from Nexif5</span>
        </button>
      </div>
    </div>
  );
};
