import React from 'react';
import { useApp } from '../../context/AppContext';
import { calculateJobMatch } from '../../services/aiEngine';
import {
  ArrowLeft,
  Bookmark,
  MapPin,
  Building2,
  Briefcase,
  Zap,
  CheckCircle2,
  ShieldCheck,
  Check,
  BookOpen,
  ArrowRight,
  AlertTriangle
} from 'lucide-react';

export const MobileJobDetailsModal: React.FC = () => {
  const {
    selectedJobForDetails,
    setSelectedJobForDetails,
    setSelectedJobForApply,
    currentStudent,
    savedJobIds,
    toggleSaveJob,
    applications,
    setMobileTab,
    sharedResources,
    setSelectedResourceForDetail,
    theme
  } = useApp();

  if (!selectedJobForDetails) return null;

  const isLight = theme === 'light';
  const job = selectedJobForDetails;
  const isSaved = savedJobIds.includes(job.id);
  const isApplied = applications.some(
    a => a.jobId === job.id && a.candidateId === currentStudent.id
  );

  const match = calculateJobMatch(currentStudent, job);
  const studentSkillNames = currentStudent.skills.map(s => s.name.toLowerCase());

  // Check for related shared learning resource
  const relatedResource = sharedResources.find(r =>
    job.requiredSkills.some(rs => rs.toLowerCase().includes(r.skill.toLowerCase()))
  );

  return (
    <div className={`fixed inset-0 z-50 flex flex-col font-sans overflow-hidden transition-colors duration-200 ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-white'
    }`}>
      {/* Top Mobile App Bar: Back, Title, Save */}
      <div className={`sticky top-0 z-10 backdrop-blur-md border-b px-4 py-3 flex items-center justify-between shadow-xs ${
        isLight ? 'bg-white/95 border-slate-200' : 'bg-slate-900/95 border-slate-800'
      }`}>
        <button
          onClick={() => setSelectedJobForDetails(null)}
          className={`p-2 -ml-1 rounded-xl transition-colors active:scale-95 flex items-center gap-1 text-xs font-semibold ${
            isLight ? 'bg-slate-100 text-slate-700 hover:text-slate-900' : 'bg-slate-800 text-slate-300 hover:text-white'
          }`}
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <span className="text-xs font-bold max-w-[200px] truncate text-center">
          {job.title}
        </span>

        <button
          onClick={() => toggleSaveJob(job.id)}
          className={`p-2 rounded-xl border transition-colors active:scale-95 ${
            isSaved
              ? 'bg-indigo-600/20 border-indigo-500 text-indigo-600 dark:text-indigo-400'
              : isLight
              ? 'bg-slate-100 border-slate-200 text-slate-500 hover:text-slate-900'
              : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
          }`}
        >
          <Bookmark className="w-4 h-4" />
        </button>
      </div>

      {/* Main Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 pb-28">
        {/* Company Header */}
        <div className={`flex items-start gap-3.5 p-4 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <img
            src={job.companyLogoUrl}
            alt={job.companyName}
            className={`w-14 h-14 rounded-2xl object-cover border shrink-0 ${
              isLight ? 'border-slate-200' : 'border-slate-700'
            }`}
          />
          <div className="space-y-1">
            <h1 className="text-lg font-bold leading-tight font-display">
              {job.title}
            </h1>
            <p className="text-xs font-semibold flex items-center gap-1.5">
              <span>{job.companyName}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
              <span className="text-emerald-500 font-medium">Verified Opportunity</span>
            </p>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 pt-0.5">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" />
                {job.location}
              </span>
              <span>•</span>
              <span className="capitalize">{job.workMode}</span>
            </div>
          </div>
        </div>

        {/* Quick Highlights Key-Value Pills */}
        <div className="grid grid-cols-3 gap-2">
          <div className={`p-3 rounded-xl border text-center ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-800/50 border-slate-800'
          }`}>
            <span className="text-[10px] text-slate-400 block uppercase font-semibold">Salary</span>
            <span className="text-xs font-bold text-emerald-500 mt-0.5 block">{job.salaryDisplay || job.salaryRange}</span>
          </div>

          <div className={`p-3 rounded-xl border text-center ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-800/50 border-slate-800'
          }`}>
            <span className="text-[10px] text-slate-400 block uppercase font-semibold">Type</span>
            <span className="text-xs font-bold mt-0.5 block capitalize">{job.type}</span>
          </div>

          <div className={`p-3 rounded-xl border text-center ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-800/50 border-slate-800'
          }`}>
            <span className="text-[10px] text-slate-400 block uppercase font-semibold">Experience</span>
            <span className="text-xs font-bold mt-0.5 block">{job.experienceRequired || 'Freshers (0 Yrs)'}</span>
          </div>
        </div>

        {/* Why this Matches You (Prompt Section 19: AI Opportunity Matching) */}
        <div className={`p-4 rounded-2xl border space-y-3 ${
          isLight
            ? 'bg-indigo-50/80 border-indigo-200 text-slate-900'
            : 'bg-indigo-950/40 border-indigo-500/30 text-white'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-indigo-600/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                <Zap className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold">Why This Matches You</h3>
            </div>
            <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-extrabold">
              {match.overallScore}% AI Match
            </span>
          </div>

          <div className="space-y-2">
            {match.whyItMatches.map((reason, idx) => (
              <div key={idx} className="flex items-start gap-2 text-xs leading-relaxed">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                <span>{reason}</span>
              </div>
            ))}
          </div>

          {/* Missing Skills & Recommended Action */}
          {match.missingSkills.length > 0 && (
            <div className="pt-2 border-t border-indigo-500/20 space-y-1.5 text-xs">
              <div className="flex items-center gap-1.5 font-bold text-amber-600 dark:text-amber-400">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Skill to improve before applying: {match.missingSkills.join(', ')}</span>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-300">
                Recommended Action: {match.nextBestAction}
              </p>
            </div>
          )}
        </div>

        {/* Connected Learning Resource CTA if available */}
        {relatedResource && (
          <div className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 ${
            isLight ? 'bg-purple-50/80 border-purple-200 text-slate-900' : 'bg-purple-950/30 border-purple-500/30 text-white'
          }`}>
            <div className="space-y-0.5">
              <p className="text-[10px] font-bold text-purple-600 dark:text-purple-400 uppercase tracking-wider flex items-center gap-1">
                <BookOpen className="w-3 h-3" />
                <span>Recommended Prep Material</span>
              </p>
              <p className="text-xs font-bold truncate max-w-[220px]">
                {relatedResource.title}
              </p>
            </div>
            <button
              onClick={() => {
                setSelectedJobForDetails(null);
                setSelectedResourceForDetail(relatedResource);
              }}
              className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shrink-0 flex items-center gap-1"
            >
              <span>Read Notes</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        )}

        {/* Job Description */}
        <div className="space-y-2">
          <h3 className="text-sm font-bold">Job Description</h3>
          <p className={`text-xs leading-relaxed whitespace-pre-line p-3.5 rounded-2xl border ${
            isLight ? 'bg-white border-slate-200 text-slate-700' : 'bg-slate-800/40 border-slate-800 text-slate-300'
          }`}>
            {job.description}
          </p>
        </div>

        {/* Key Responsibilities */}
        {job.responsibilities && job.responsibilities.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-sm font-bold">Key Responsibilities</h3>
            <div className={`space-y-1.5 p-3.5 rounded-2xl border ${
              isLight ? 'bg-white border-slate-200 text-slate-700' : 'bg-slate-800/40 border-slate-800 text-slate-300'
            }`}>
              {job.responsibilities.map((resp, idx) => (
                <div key={idx} className="flex items-start gap-2 text-xs leading-relaxed">
                  <span className="text-indigo-500 font-bold">•</span>
                  <span>{resp}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Required Skills & Fit Analysis */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-bold">Required Skills & Fit</h3>
          <div className="flex flex-wrap gap-1.5">
            {job.requiredSkills.map(skill => {
              const hasSkill = studentSkillNames.some(s => s.includes(skill.toLowerCase()) || skill.toLowerCase().includes(s));
              return (
                <span
                  key={skill}
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold border ${
                    hasSkill
                      ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-600 dark:text-emerald-300'
                      : isLight
                      ? 'bg-slate-100 border-slate-200 text-slate-600'
                      : 'bg-slate-800 border-slate-700 text-slate-300'
                  }`}
                >
                  {hasSkill && <Check className="w-3 h-3 text-emerald-500" />}
                  <span>{skill}</span>
                </span>
              );
            })}
          </div>
        </div>

        {/* Company Overview */}
        <div className={`p-4 rounded-2xl border space-y-1.5 ${
          isLight ? 'bg-white border-slate-200' : 'bg-slate-800/40 border-slate-800'
        }`}>
          <h3 className="text-xs font-bold text-slate-400">About {job.companyName}</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Leading organization hiring verified talent through the Nexif5 Career Execution Network.
          </p>
        </div>
      </div>

      {/* Sticky Bottom Apply Action Bar */}
      <div className={`sticky bottom-0 left-0 right-0 p-4 border-t shadow-2xl flex items-center gap-3 backdrop-blur-md ${
        isLight ? 'bg-white/95 border-slate-200' : 'bg-slate-900/95 border-slate-800'
      }`}>
        <div className="space-y-0.5">
          <p className="text-[10px] text-slate-400 uppercase font-semibold">Compensation</p>
          <p className="text-sm font-extrabold text-emerald-500">{job.salaryDisplay || job.salaryRange}</p>
        </div>

        <button
          onClick={() => {
            if (isApplied) {
              setSelectedJobForDetails(null);
              setMobileTab('applications');
            } else {
              setSelectedJobForDetails(null);
              setSelectedJobForApply(job);
            }
          }}
          disabled={isApplied}
          className={`flex-1 py-3 px-4 rounded-2xl font-bold text-xs text-center transition-all shadow-md active:scale-98 flex items-center justify-center gap-2 ${
            isApplied
              ? 'bg-emerald-600 text-white cursor-default'
              : 'bg-indigo-600 hover:bg-indigo-700 text-white'
          }`}
        >
          {isApplied ? (
            <>
              <Check className="w-4 h-4" />
              <span>Applied via Nexif5</span>
            </>
          ) : (
            <>
              <span>Apply with AI Resume</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
