export type UserRole = 
  | 'student' 
  | 'professional' 
  | 'recruiter' 
  | 'college' 
  | 'mentor' 
  | 'admin' 
  | 'job_seeker' 
  | 'landing';

export type CandidateType = 'student' | 'job_seeker' | 'professional';

export type CompanyRole = 'company_admin' | 'hr_manager' | 'recruiter';
export type CollegeRole = 'dean_placement' | 'placement_officer' | 'dept_coordinator';

// Mentorship models
export interface MentorshipSession {
  id: string;
  mentorId: string;
  menteeId: string;
  menteeName: string;
  menteeAvatar?: string;
  menteeGoal: string;
  date: string;
  time: string;
  type: '1:1 Mentoring' | 'Mock Interview' | 'Resume Review' | 'Career Guidance';
  status: 'upcoming' | 'completed' | 'cancelled';
  notes?: string;
  feedback?: string;
  rating?: number; // 1-5
  scorecard?: {
    technicalDepth: number;
    communication: number;
    problemSolving: number;
    domainKnowledge: number;
    recommendation: string;
  };
}

export interface MentorProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatarUrl: string;
  location: string;
  jobTitle: string;
  company: string;
  experienceYears: number;
  domains: string[]; // e.g. ['Software Engineering', 'System Design', 'Cloud Architecture']
  bio: string;
  availabilityHoursPerWeek: number;
  mentorshipTypes: ('1:1 Mentoring' | 'Mock Interview' | 'Resume Review' | 'Career Guidance')[];
  linkedInUrl?: string;
  portfolioUrl?: string;
  totalMenteesCount: number;
  averageRating: number;
  sessionsCompletedCount: number;
  sessions: MentorshipSession[];
}

export interface WorkingProfessionalProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatarUrl: string;
  location: string;
  currentJobTitle: string;
  currentCompany: string;
  totalExperienceYears: number;
  industry: string;
  workMode: WorkModeType;
  skills: SkillItem[];
  targetSkills: string[];
  careerGoal: string;
  targetJobRole: string;
  preferredIndustry: string;
  preferredLocation: string;
  jobTypePreference: WorkPreferenceType;
  salaryCurrentLPA: number;
  salaryTargetLPA: number;
  pastRoles: {
    id: string;
    title: string;
    company: string;
    duration: string;
    keyAchievements: string[];
  }[];
  projects: Project[];
  certifications: string[];
  resumeName: string;
  careerGrowthScore: number; // 0-100
  profileViewsCount: number;
  recruiterInquiriesCount: number;
}

export interface AdminUserRecord {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: 'active' | 'pending' | 'suspended';
  joinedDate: string;
  organizationOrCollege?: string;
  lastActive: string;
}

export type ApplicationStatus = 
  | 'applied'
  | 'under_review'
  | 'shortlisted'
  | 'interview'
  | 'selected'
  | 'rejected';

export type WorkPreferenceType = 'full_time' | 'internship' | 'part_time' | 'contract';
export type WorkModeType = 'remote' | 'hybrid' | 'on_site';
export type LocationScopeType = 'nearby' | 'specific_city' | 'anywhere_in_india' | 'abroad' | 'remote';

export type StudentCandidate = StudentProfile;
export type CompanyRecruiter = CompanyTeamMember;
export type CollegeStaff = CollegePlacementMember;

export interface SkillItem {
  id: string;
  name: string;
  category: 'technical' | 'analytics' | 'tools' | 'soft' | 'domain';
  level: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  verified?: boolean;
}

export interface Achievement {
  id: string;
  title: string;
  issuer: string;
  date: string;
  description: string;
  credentialUrl?: string;
  category: 'hackathon' | 'competition' | 'academic' | 'leadership' | 'certification';
}

export interface Project {
  id: string;
  title: string;
  description: string;
  technologies: string[];
  liveUrl?: string;
  githubUrl?: string;
  startDate: string;
  endDate: string;
  role?: string;
}

export interface Experience {
  id: string;
  role: string;
  company: string;
  location: string;
  startDate: string;
  endDate: string;
  isCurrent: boolean;
  description: string;
}

export interface Education {
  degree: string;
  course: string;
  institution: string;
  yearOfPassing: number;
  currentYear: string; // e.g. "Final Year (4th Year)", "3rd Year", "2024 Graduate"
  cgpaOrPercentage: string;
}

export interface StudentProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatarUrl: string;
  bio?: string;
  userType?: CandidateType; // 'student' | 'job_seeker'
  workExperienceYears?: number; // e.g. 0 for fresher, 2 for experienced
  currentDesignation?: string; // e.g. "Junior Business Analyst"
  education: Education;
  collegeId?: string; // Optional: user does not have to join a college
  collegeName?: string;
  department?: string;
  careerGoal: string; // e.g., "Business Analyst", "Full Stack Developer", "Data Scientist"
  targetIndustry?: string;
  preferredJobRoles: string[];
  salaryPreferenceMinLPA: number;
  salaryPreferenceMaxLPA: number;
  locationPreferenceType: LocationScopeType;
  preferredCities: string[];
  workPreference: WorkModeType;
  jobTypePreference: WorkPreferenceType;
  skills: SkillItem[];
  achievements: Achievement[]; // NOTE: Use "Achievements", NOT "Skill Passport"
  projects: Project[];
  experiences: Experience[];
  experience?: any[];
  languages: string[];
  resumeName: string;
  resumeUpdatedDate: string;
  careerReadinessScore: number; // 0-100 deterministic
  isPlacementEligible?: boolean;
  createdAt: string;
}

export interface CompanyOrganization {
  id: string;
  name: string;
  logoUrl: string;
  industry: string;
  headquarters: string;
  locations: string[];
  website: string;
  description: string;
  employeeCount: string;
  foundedYear: number;
  verified: boolean;
  activeJobsCount: number;
  totalHiresCount: number;
  teamMembers?: CompanyTeamMember[];
  recruiters?: CompanyTeamMember[];
}

export interface CompanyTeamMember {
  id: string;
  name: string;
  email: string;
  role: CompanyRole | string;
  avatarUrl?: string;
  department?: string;
  companyId?: string;
  activeJobsPosted?: number;
}

export interface CollegeOrganization {
  id: string;
  name: string;
  logoUrl: string;
  location: string;
  state: string;
  type: string; // "Autonomous University", "Affiliated College", "National Institute"
  nirfRank?: string;
  establishedYear: number;
  departments: string[];
  totalStudents: number;
  registeredStudentsCount: number;
  placementOfficers?: CollegePlacementMember[];
  placementStaff?: CollegePlacementMember[];
}

export interface CollegePlacementMember {
  id: string;
  name: string;
  email: string;
  role: CollegeRole | string;
  avatarUrl?: string;
  department?: string;
  collegeId?: string;
}

export interface JobOpportunity {
  id: string;
  companyId: string;
  companyName: string;
  companyLogoUrl: string;
  title: string;
  type: 'job' | 'internship' | 'hackathon' | 'career_event';
  workMode: WorkModeType;
  location: string;
  departmentCategory: string; // "Analytics", "Software Engineering", "Finance", "Marketing"
  salaryMinLPA: number;
  salaryMaxLPA: number;
  salaryDisplay: string;
  stipendPerMonth?: number;
  experienceRequired: string; // "Fresher (0 years)", "0-1 Years", "1-2 Years"
  qualificationRequired: string[]; // ["B.Com", "B.Tech", "BCA", "B.Sc", "MBA"]
  requiredSkills: string[];
  preferredSkills: string[];
  description: string;
  responsibilities: string[];
  perks: string[];
  applicationDeadline: string;
  postedDate: string;
  isOpen: boolean;
  vacancies: number;
  applicantsCount: number;
  targetCollegeIds?: string[]; // Empty if open to all Nexif5 students
}

export interface JobApplication {
  id: string;
  candidateId: string;
  candidateName: string;
  candidateEmail: string;
  candidatePhone: string;
  candidateEducation: string;
  candidateCourse: string;
  candidateCollegeName?: string;
  candidateAvatarUrl: string;
  candidateCareerGoal: string;
  candidateSkills: string[];
  candidateReadinessScore: number;
  candidateType?: CandidateType; // 'student' | 'job_seeker'
  jobId: string;
  jobTitle: string;
  jobType: 'job' | 'internship';
  companyId: string;
  companyName: string;
  companyLogoUrl: string;
  applicationDate: string;
  applicationSource: 'Applied through Nexif5' | 'College Campus Drive' | 'Nexif5' | string;
  status: ApplicationStatus;
  matchScore: number; // 0-100
  matchBreakdown: {
    skillsMatch: number;
    qualificationMatch: number;
    careerGoalMatch: number;
    preferenceMatch: number;
  };
  matchReasons: string[];
  resumeUsed: string;
  coverNote?: string;
  recruiterNotes?: string;
  scheduledInterview?: ScheduledInterview;
  rejectionFeedback?: {
    provided: boolean;
    reasonCategory?: 'skill_gap' | 'qualification' | 'experience' | 'culture_fit' | 'position_filled';
    comment?: string;
    suggestedSkillsToLearn?: string[];
  };
  timeline: {
    status: ApplicationStatus;
    date: string;
    note?: string;
  }[];
}

export interface ScheduledInterview {
  id: string;
  applicationId: string;
  candidateId: string;
  candidateName: string;
  jobTitle: string;
  companyName: string;
  date: string;
  time: string;
  roundType: 'HR Discussion' | 'Technical Round 1' | 'Analytics Case Study' | 'Final Leadership';
  interviewMode: 'Virtual Video Call' | 'In-Person (Office)' | 'College Campus';
  meetingLink?: string;
  interviewerName: string;
  status: 'upcoming' | 'completed' | 'cancelled';
  feedback?: string;
}

export interface AIMatchResult {
  jobId: string;
  studentId: string;
  overallScore: number;
  skillsMatch: number;
  qualificationMatch: number;
  careerGoalMatch: number;
  preferenceMatch: number;
  matchedSkills: string[];
  missingSkills: string[];
  whyItMatches: string[];
  nextBestAction: string;
}

export interface AICareerAnalysis {
  careerGoal: string;
  careerReadinessScore: number; // e.g. 78
  readinessLevel: 'High Potential' | 'Job Ready' | 'Needs Skill Building' | 'Exploring';
  skillGaps: {
    skill: string;
    currentLevel: string;
    requiredLevel: string;
    status: 'Strong' | 'Intermediate' | 'Needs Improvement';
    actionItem: string;
  }[];
  nextBestAction: string;
  recommendedRoleTitles: string[];
  marketDemand: 'High' | 'Very High' | 'Moderate';
  estimatedSalaryRange: string;
}

export interface NotificationItem {
  id: string;
  recipientType: 'student' | 'recruiter' | 'college' | 'professional' | 'mentor' | 'admin';
  recipientId: string;
  title: string;
  message: string;
  type: 'job_match' | 'application_update' | 'interview_scheduled' | 'shortlisted' | 'new_applicant' | 'campus_drive' | 'system';
  date: string;
  read: boolean;
  actionLink?: string;
}

export interface CollegeSkillMetric {
  skillName: string;
  category: string;
  readyCount: number;
  needTrainingCount: number;
  totalAssessed: number;
  growthMoM: string;
}

export interface CollegeDepartmentStat {
  department: string;
  totalStudents: number;
  registeredCount: number;
  shortlistedCount: number;
  selectedCount: number;
  placementRate: number;
  avgSalaryLPA: number;
  highestSalaryLPA: number;
}

export type ResourceCategory =
  | 'Skill Learning'
  | 'Interview Prep'
  | 'Exam Preparation'
  | 'Career Guide'
  | 'Project Resources'
  | 'Templates';

export type ResourceFileType = 'pdf' | 'doc' | 'notes' | 'presentation' | 'template' | 'sheet';

export interface SharedResource {
  id: string;
  title: string;
  description: string;
  fileType: ResourceFileType;
  fileSize: string;
  fileName?: string;
  category: ResourceCategory;
  subject: string;
  skill: string;
  careerRelevance: string;
  tags: string[];
  uploaderId: string;
  uploaderName: string;
  uploaderRole: string;
  uploaderAvatar?: string;
  uploadDate: string;
  viewsCount: number;
  savesCount: number;
  helpfulCount: number;
  downloadsCount: number;
  visibility: 'community' | 'private';
  previewSnippet: string;
  contentOutline?: string[];
  aiRelevanceReason?: string;
  practicalTaskTitle?: string;
  downloadUrl?: string;
}

export interface SkillProgressItem {
  skill: string;
  category: string;
  currentLevel: string;
  targetLevel: string;
  whyItMatters: string;
  progressPercent: number; // 0-100
  nextActionTitle: string;
  nextActionDescription: string;
  howToDemonstrate: string;
  careerReadinessImpact: string;
  isTaskCompleted: boolean;
  relatedResourceId?: string;
}

export interface LessonPracticeTask {
  id: string;
  title: string;
  description: string;
  instructions: string[];
  starterTemplate?: string;
  solutionGuide?: string;
  isCompleted: boolean;
  userSubmission?: string;
  submittedAt?: string;
}

export interface VideoLesson {
  id: string;
  moduleNumber: number;
  title: string;
  description: string;
  durationMinutes: number;
  videoDurationFormatted: string; // e.g. "12:45"
  skillDeveloped: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  isCompleted: boolean;
  videoThumbnail?: string;
  videoSourceLabel: string;
  relatedResourceId?: string;
  practiceTask?: LessonPracticeTask;
}

export interface CourseAssessmentQuestion {
  id: string;
  type: 'mcq' | 'scenario' | 'short_answer' | 'practical';
  question: string;
  scenarioContext?: string;
  options?: string[];
  correctAnswerIndex?: number;
  correctAnswerText?: string;
  explanation: string;
  skillFocus: string;
}

export interface CourseAssessment {
  id: string;
  title: string;
  description: string;
  passingScorePercent: number; // e.g. 80
  totalQuestions: number;
  estimatedMinutes: number;
  questions: CourseAssessmentQuestion[];
  userScorePercent?: number;
  userPassed?: boolean;
  completedAt?: string;
  strengths?: string[];
  weakAreas?: string[];
  skillLevelAwarded?: string;
  recommendedNextAction?: string;
}

export interface CourseCertificate {
  certificateId: string; // e.g. "NXF-PBI-2026-00124"
  courseId: string;
  courseTitle: string;
  skill: string;
  learnerName: string;
  learnerId: string;
  issuerName: string;
  partnerName: string;
  certificateType: 'completion' | 'partner_verified';
  disclaimer: string;
  issueDate: string;
  assessmentScore: number;
  grade: string; // e.g. "Distinction (86%)"
  verificationStatus: 'verified' | 'pending';
  verificationUrl: string;
  qrCodeDataUrl?: string;
  skillsDemonstrated: string[];
  signatoryName: string;
  signatoryTitle: string;
}

export interface CertifiedCourse {
  id: string;
  title: string;
  skill: string;
  targetCareer: string;
  provider: string; // e.g. "NEXIF5 Academy"
  partner: string; // e.g. "Microsoft Learn Partner Curriculum"
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  durationHours: number;
  durationLabel: string; // e.g. "12 Hours • 8 Modules"
  progressPercent: number;
  enrolled: boolean;
  modulesCount: number;
  videoLessons: VideoLesson[];
  practiceActivitiesCount: number;
  assessment: CourseAssessment;
  certificate?: CourseCertificate;
  isCertificateEligible: boolean;
  isCertificateEarned: boolean;
  whyAiRecommended: string;
  careerReadinessImpact: string; // e.g. "+8% Career Readiness"
  badgeColor?: string;
}

// ==========================================
// CONNECT & PROFESSIONAL MESSAGING TYPES
// ==========================================

export type ConnectionStatus = 'none' | 'pending_sent' | 'pending_received' | 'connected';

export interface ConnectionRequest {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  senderAvatar: string;
  senderHeadline: string;
  receiverId: string;
  receiverRole: UserRole;
  note?: string;
  createdAt: string;
  status: 'pending' | 'accepted' | 'declined' | 'cancelled';
  sharedSkillsCount?: number;
}

export interface UserConnection {
  id: string;
  peerId: string;
  peerName: string;
  peerRole: UserRole;
  peerAvatar: string;
  peerHeadline: string;
  peerCompanyOrSchool: string;
  location?: string;
  connectedAt: string;
  isFollowing?: boolean;
  sharedSkills?: string[];
  mutualConnectionsCount?: number;
}

export interface SmartConnectionRecommendation {
  userId: string;
  name: string;
  role: UserRole;
  avatarUrl: string;
  headline: string;
  organization: string;
  location: string;
  sharedSkills: string[];
  whyAiRecommended: string;
  connectionStatus: ConnectionStatus;
  isFollowing?: boolean;
  targetRole?: string;
  experienceYears?: number;
  openToMentoring?: boolean;
  isActivelyHiring?: boolean;
}

export type MessageAttachmentType = 'resume' | 'certificate' | 'job' | 'project';

export interface MessageAttachment {
  type: MessageAttachmentType;
  title: string;
  subtitle?: string;
  itemId?: string;
  badge?: string;
  linkText?: string;
}

export interface DirectChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderRole: UserRole;
  receiverId: string;
  content: string;
  timestamp: string;
  isRead: boolean;
  status?: 'sent' | 'delivered' | 'read';
  attachment?: MessageAttachment;
}

export interface ChatConversation {
  id: string;
  peerId: string;
  peerName: string;
  peerAvatar: string;
  peerRole: UserRole;
  peerHeadline: string;
  peerOrganization: string;
  lastMessage: string;
  lastMessageTimestamp: string;
  unreadCount: number;
  isOnline?: boolean;
  isConnected: boolean;
}

export interface QuickMessageTemplate {
  id: string;
  title: string;
  category: 'career_advice' | 'internship' | 'mentorship' | 'job_inquiry' | 'project_collab';
  targetRoleText: string;
  content: string;
}

