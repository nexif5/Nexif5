import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  CalendarCheck,
  Video,
  Clock,
  User,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Building,
  Briefcase
} from 'lucide-react';

export const RecruiterInterviews: React.FC = () => {
  const { currentCompany, applications, setActiveRecruiterTab } = useApp();

  const companyInterviews = applications
    .filter(a => a.companyId === currentCompany.id && a.status === 'interview' && a.scheduledInterview);

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
            <CalendarCheck className="w-4 h-4" />
            <span>INTERVIEW COORDINATION & VIDEO CALLS</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 font-display">
            Scheduled Interviews ({companyInterviews.length})
          </h1>
          <p className="text-xs text-slate-500">
            Real-time evaluation rounds, meeting URLs, and interviewer assignments
          </p>
        </div>
      </div>

      {companyInterviews.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {companyInterviews.map((app) => (
            <div
              key={app.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={app.candidateAvatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                      alt={app.candidateName}
                      className="w-10 h-10 rounded-xl object-cover border border-slate-200"
                    />
                    <div>
                      <strong className="text-slate-900 font-bold text-sm block">{app.candidateName}</strong>
                      <span className="text-[11px] text-slate-500">{app.jobTitle}</span>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 text-[10px] font-bold border border-blue-200">
                    {app.matchScore}% Match
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between text-slate-700">
                    <span className="font-semibold">{app.scheduledInterview?.roundType}</span>
                    <span className="text-[10px] text-slate-400">Virtual</span>
                  </div>
                  <div className="text-[11px] text-slate-600 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{app.scheduledInterview?.date} • {app.scheduledInterview?.time}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    <span>Interviewer: {app.scheduledInterview?.interviewerName}</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                <a
                  href={app.scheduledInterview?.meetingLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                >
                  <Video className="w-3.5 h-3.5" />
                  <span>Join Video Call</span>
                </a>
                <button
                  onClick={() => setActiveRecruiterTab('applications')}
                  className="px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl font-semibold text-xs transition-colors"
                >
                  Candidate Record
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-12 text-center text-xs text-slate-500 bg-white rounded-2xl border border-slate-200 space-y-2">
          <CalendarCheck className="w-10 h-10 mx-auto text-slate-300 stroke-1" />
          <h3 className="text-sm font-bold text-slate-700">No active interviews scheduled</h3>
          <p>Shortlist candidates from your applications pipeline to schedule technical rounds.</p>
        </div>
      )}
    </div>
  );
};
