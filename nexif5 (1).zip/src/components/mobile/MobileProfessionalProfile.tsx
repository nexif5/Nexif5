import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Briefcase,
  Building2,
  MapPin,
  Award,
  FileText,
  DollarSign,
  TrendingUp,
  CheckCircle2,
  ChevronRight,
  ShieldCheck,
  Sparkles
} from 'lucide-react';

export const MobileProfessionalProfile: React.FC = () => {
  const { currentProfessional, setMobileTab, setSubView, theme } = useApp();
  const isLight = theme === 'light';

  return (
    <div className={`p-4 space-y-4 pb-24 font-sans ${isLight ? 'text-slate-900' : 'text-white'}`}>
      {/* Header Profile Card */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-start gap-3.5">
          <img
            src={currentProfessional.avatarUrl}
            alt={currentProfessional.name}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-amber-500 shadow-md"
          />
          <div className="space-y-0.5">
            <h1 className="text-base font-bold font-display">{currentProfessional.name}</h1>
            <p className="text-xs text-amber-600 dark:text-amber-400 font-semibold">
              {currentProfessional.currentJobTitle}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5" />
              <span>{currentProfessional.currentCompany}</span>
            </p>
            <p className="text-[10px] text-slate-400 flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              <span>{currentProfessional.location} • {currentProfessional.workMode}</span>
            </p>
          </div>
        </div>

        {/* Promotion Benchmark Badge */}
        <div className={`p-3 rounded-xl border flex items-center justify-between ${
          isLight ? 'bg-amber-50/80 border-amber-200 text-slate-800' : 'bg-amber-950/40 border-amber-500/30 text-white'
        }`}>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-amber-500" />
            <div>
              <p className="text-xs font-bold">Career Growth Score: {currentProfessional.careerGrowthScore}%</p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                Targeting: {currentProfessional.targetJobRole}
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-600 dark:text-amber-300">
            Active
          </span>
        </div>
      </div>

      {/* Experience & Past Roles */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center gap-2">
          <Briefcase className="w-4 h-4 text-amber-500" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Work Experience ({currentProfessional.totalExperienceYears} Yrs)
          </h2>
        </div>

        <div className="space-y-3">
          {currentProfessional.pastRoles.map((role) => (
            <div key={role.id} className="space-y-1 border-l-2 border-amber-500/50 pl-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-white dark:text-white">{role.title}</h3>
                <span className="text-[10px] text-slate-400">{role.duration}</span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">{role.company}</p>
              <ul className="text-[11px] text-slate-400 list-disc list-inside space-y-0.5 pt-1">
                {role.keyAchievements.map((ach, idx) => (
                  <li key={idx} className="line-clamp-2">{ach}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Skills & Verified Levels */}
      <div className={`p-4 rounded-2xl border space-y-2.5 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Skills & Proficiency
          </h2>
          <span className="text-[10px] text-amber-500 font-bold">{currentProfessional.skills.length} Skills</span>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {currentProfessional.skills.map((s) => (
            <span
              key={s.id}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 text-xs font-medium border border-slate-700 text-slate-200"
            >
              <span>{s.name}</span>
              <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 capitalize">
                {s.level}
              </span>
            </span>
          ))}
        </div>
      </div>

      {/* Certifications */}
      <div className={`p-4 rounded-2xl border space-y-2.5 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center gap-2">
          <Award className="w-4 h-4 text-indigo-500" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Certifications & Accreditations
          </h2>
        </div>

        <div className="space-y-1.5">
          {currentProfessional.certifications.map((c, idx) => (
            <div key={idx} className="p-2 rounded-xl bg-slate-800/50 border border-slate-700/60 flex items-center gap-2 text-xs">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="text-slate-200 font-medium">{c}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Resume Document */}
      <div className={`p-4 rounded-2xl border flex items-center justify-between ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center gap-2.5">
          <FileText className="w-5 h-5 text-emerald-500" />
          <div>
            <p className="text-xs font-bold">{currentProfessional.resumeName}</p>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">ATS Optimized • Verified</p>
          </div>
        </div>
        <button
          onClick={() => setSubView('resume')}
          className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold"
        >
          View / Edit
        </button>
      </div>
    </div>
  );
};
