import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserRole,
  StudentProfile,
  CompanyOrganization,
  CollegeOrganization,
  JobOpportunity,
  JobApplication,
  ScheduledInterview,
  NotificationItem,
  ApplicationStatus,
  SkillItem,
  Achievement,
  Project,
  SharedResource,
  SkillProgressItem,
  CertifiedCourse,
  VideoLesson,
  CourseAssessment,
  CourseCertificate,
  WorkingProfessionalProfile,
  MentorProfile,
  MentorshipSession,
  AdminUserRecord,
  ConnectionRequest,
  UserConnection,
  SmartConnectionRecommendation,
  DirectChatMessage,
  ChatConversation,
  MessageAttachment,
  QuickMessageTemplate,
  ConnectionStatus
} from '../types';
import {
  MOCK_STUDENTS,
  MOCK_COMPANIES,
  MOCK_COLLEGES,
  MOCK_JOBS,
  MOCK_APPLICATIONS,
  MOCK_NOTIFICATIONS,
  MOCK_SHARED_RESOURCES,
  MOCK_SKILL_PROGRESS,
  MOCK_CERTIFIED_COURSES,
  MOCK_PROFESSIONALS,
  MOCK_MENTORS,
  MOCK_ADMIN_USERS,
  MOCK_CONNECTION_REQUESTS,
  MOCK_USER_CONNECTIONS,
  MOCK_SMART_RECOMMENDATIONS,
  MOCK_CHAT_CONVERSATIONS,
  MOCK_CHAT_MESSAGES,
  MOCK_MESSAGE_TEMPLATES
} from '../data/mockData';
import { calculateJobMatch, handleStudentAIQuery } from '../services/aiEngine';
import { LanguageCode, t as translateFn, SUPPORTED_LANGUAGES } from '../services/i18n';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}

export type ThemeMode = 'dark' | 'light';

export type AuthState =
  | 'welcome'
  | 'language'
  | 'signup'
  | 'login'
  | 'account_type'
  | 'profile_setup'
  | 'career_goal'
  | 'preferences'
  | 'professional_onboarding'
  | 'recruiter_onboarding'
  | 'college_onboarding'
  | 'mentor_onboarding'
  | 'admin_login'
  | 'authenticated';

export type MobileTab = 'home' | 'learn' | 'career' | 'jobs' | 'ai' | 'applications' | 'profile';

export type LearnSubTab = 'recommendations' | 'certifications' | 'shared' | 'tasks' | 'saved' | 'my_resources';


export type SubView =
  | 'dashboard'
  | 'resume'
  | 'interview_prep'
  | 'settings'
  | 'notifications'
  | 'help'
  | 'companies'
  | 'profile_edit'
  | 'network'
  | 'messages'
  | 'view_profile'
  | null;

interface AppContextType {
  // Theme (Dark Mode & White / Light Mode)
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  toggleTheme: () => void;

  // Localization
  currentLanguage: LanguageCode;
  setCurrentLanguage: (lang: LanguageCode) => void;
  t: (key: string) => string;

  // Mobile Auth & Flow State
  authState: AuthState;
  setAuthState: (state: AuthState) => void;
  mobileTab: MobileTab;
  setMobileTab: (tab: MobileTab) => void;
  subView: SubView;
  setSubView: (view: SubView) => void;

  // User & Organization Data
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  currentStudent: StudentProfile;
  setCurrentStudent: (student: StudentProfile) => void;
  currentCompany: CompanyOrganization;
  setCurrentCompany: (company: CompanyOrganization) => void;
  currentCollege: CollegeOrganization;
  setCurrentCollege: (college: CollegeOrganization) => void;

  // Selected for modals
  selectedJobForDetails: JobOpportunity | null;
  setSelectedJobForDetails: (job: JobOpportunity | null) => void;
  selectedJobForApply: JobOpportunity | null;
  setSelectedJobForApply: (job: JobOpportunity | null) => void;
  isProfileMenuOpen: boolean;
  setIsProfileMenuOpen: (open: boolean) => void;

  // Search & Filters
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  savedJobIds: string[];
  toggleSaveJob: (jobId: string) => void;

  // Data Stores
  students: StudentProfile[];
  companies: CompanyOrganization[];
  colleges: CollegeOrganization[];
  jobs: JobOpportunity[];
  applications: JobApplication[];
  notifications: NotificationItem[];
  
  // Document and Learning Resource Sharing
  sharedResources: SharedResource[];
  savedResourceIds: string[];
  toggleSaveResource: (resourceId: string) => void;
  markResourceHelpful: (resourceId: string) => void;
  uploadResource: (newResource: Omit<SharedResource, 'id' | 'viewsCount' | 'savesCount' | 'helpfulCount' | 'downloadsCount' | 'uploadDate'>) => SharedResource;
  deleteResource: (resourceId: string) => void;
  updateResource: (id: string, updates: Partial<SharedResource>) => void;
  selectedResourceForDetail: SharedResource | null;
  setSelectedResourceForDetail: (r: SharedResource | null) => void;
  isUploadResourceModalOpen: boolean;
  setIsUploadResourceModalOpen: (open: boolean) => void;

  // AI Skill Gaps, Practical Action Tasks & Progress
  skillProgressList: SkillProgressItem[];
  completeSkillTask: (skillName: string) => void;
  learnSubTab: LearnSubTab;
  setLearnSubTab: (tab: LearnSubTab) => void;

  // Certified Courses, Video Lessons, Assessments & Certificates
  certifiedCourses: CertifiedCourse[];
  selectedCourseForLearning: CertifiedCourse | null;
  setSelectedCourseForLearning: (course: CertifiedCourse | null) => void;
  activeVideoLessonId: string | null;
  setActiveVideoLessonId: (id: string | null) => void;
  isCourseVideoModalOpen: boolean;
  setIsCourseVideoModalOpen: (open: boolean) => void;
  selectedCourseForAssessment: CertifiedCourse | null;
  setSelectedCourseForAssessment: (course: CertifiedCourse | null) => void;
  isAssessmentModalOpen: boolean;
  setIsAssessmentModalOpen: (open: boolean) => void;
  selectedCertificateForView: CourseCertificate | null;
  setSelectedCertificateForView: (cert: CourseCertificate | null) => void;
  isCertificateModalOpen: boolean;
  setIsCertificateModalOpen: (open: boolean) => void;
  isVerificationModalOpen: boolean;
  setIsVerificationModalOpen: (open: boolean) => void;
  verificationQueryId: string;
  setVerificationQueryId: (id: string) => void;

  openCourseLearning: (courseId: string, lessonId?: string) => void;
  openCourseAssessment: (courseId: string) => void;
  openCertificateView: (courseIdOrCertId: string) => void;
  openCertificateVerification: (certId?: string) => void;
  completeVideoLesson: (courseId: string, lessonId: string) => void;
  submitLessonPracticeTask: (courseId: string, lessonId: string, submissionText: string) => void;
  submitCourseAssessment: (courseId: string, answers: Record<string, string | number>) => { scorePercent: number; passed: boolean; certificate?: CourseCertificate };
  verifyCertificateById: (certId: string) => CourseCertificate | null;

  // AI Chat & Coach

  chatMessages: ChatMessage[];
  sendChatMessage: (text: string) => void;
  clearChat: () => void;
  isAiTyping: boolean;

  // Actions
  createNewUser: (userData: Partial<StudentProfile>, role: UserRole) => StudentProfile;
  loginUser: (email: string) => boolean;
  logOut: () => void;
  logoutUser: () => void;
  applyForJob: (jobId: string, resumeNameOrCoverNote?: string, coverNote?: string) => { success: boolean; message: string; application?: JobApplication };
  updateApplicationStatus: (
    applicationId: string,
    newStatus: ApplicationStatus,
    options?: {
      note?: string;
      interview?: Partial<ScheduledInterview>;
      rejectionFeedback?: {
        provided: boolean;
        reasonCategory?: 'skill_gap' | 'qualification' | 'experience' | 'culture_fit' | 'position_filled';
        comment?: string;
        suggestedSkillsToLearn?: string[];
      };
    }
  ) => void;
  postNewJob: (jobData: Omit<JobOpportunity, 'id' | 'companyId' | 'companyName' | 'companyLogoUrl' | 'postedDate' | 'applicantsCount'>) => JobOpportunity;
  updateStudentProfile: (updated: Partial<StudentProfile>) => void;
  addStudentSkill: (skill: Omit<SkillItem, 'id'>) => void;
  removeStudentSkill: (skillId: string) => void;
  addStudentAchievement: (achievement: Omit<Achievement, 'id'>) => void;
  addStudentProject: (project: Omit<Project, 'id'>) => void;
  markNotificationRead: (notifId: string) => void;
  markAllNotificationsRead: () => void;
  markAllNotificationsAsRead: () => void;
  addNotification: (notif: Omit<NotificationItem, 'id' | 'date' | 'read'>) => void;

  // Working Professional Data
  professionals: WorkingProfessionalProfile[];
  currentProfessional: WorkingProfessionalProfile;
  setCurrentProfessional: (p: WorkingProfessionalProfile) => void;
  updateProfessionalProfile: (updated: Partial<WorkingProfessionalProfile>) => void;

  // Mentor Data
  mentors: MentorProfile[];
  currentMentor: MentorProfile;
  setCurrentMentor: (m: MentorProfile) => void;
  updateMentorProfile: (updated: Partial<MentorProfile>) => void;
  addMentorshipSession: (session: Omit<MentorshipSession, 'id'>) => void;

  // Admin Data
  adminUsers: AdminUserRecord[];
  toggleAdminUserStatus: (userId: string) => void;

  // Role Tab States
  activeRecruiterTab: string;
  setActiveRecruiterTab: (tab: any) => void;
  activeCollegeTab: string;
  setActiveCollegeTab: (tab: any) => void;
  activeProfessionalTab: string;
  setActiveProfessionalTab: (tab: any) => void;
  activeMentorTab: string;
  setActiveMentorTab: (tab: any) => void;
  activeAdminTab: string;
  setActiveAdminTab: (tab: any) => void;
  activeStudentTab?: string;
  setActiveStudentTab?: (tab: any) => void;
  activeJobSeekerTab?: string;
  setActiveJobSeekerTab?: (tab: any) => void;

  // Quick Role Switching
  switchToRole: (role: UserRole) => void;
  switchToStudentDemo: (id?: string) => void;
  switchToJobSeekerDemo: (id?: string) => void;
  switchToProfessionalDemo: (id?: string) => void;
  switchToRecruiterDemo: (companyId?: string) => void;
  switchToCollegeDemo: (collegeId?: string) => void;
  switchToMentorDemo: (mentorId?: string) => void;
  switchToAdminDemo: () => void;

  // Network & Connect System
  connectionRequests: ConnectionRequest[];
  userConnections: UserConnection[];
  smartRecommendations: SmartConnectionRecommendation[];
  sendConnectionRequest: (targetUserId: string, note?: string) => { success: boolean; message: string };
  acceptConnectionRequest: (requestId: string) => void;
  declineConnectionRequest: (requestId: string) => void;
  cancelConnectionRequest: (requestId: string) => void;
  removeConnection: (connectionId: string) => void;
  toggleFollowUser: (targetUserId: string) => void;
  getConnectionStatusWithUser: (targetUserId: string) => ConnectionStatus;

  // Professional Messaging
  chatConversations: ChatConversation[];
  directChatMessages: Record<string, DirectChatMessage[]>;
  activeConversationId: string | null;
  setActiveConversationId: (id: string | null) => void;
  sendMessage: (conversationId: string, content: string, attachment?: MessageAttachment) => void;
  startOrOpenConversation: (peerId: string) => string;
  markConversationRead: (conversationId: string) => void;
  quickTemplates: QuickMessageTemplate[];

  // Profile Viewer
  viewingProfileUserId: string | null;
  setViewingProfileUserId: (userId: string | null) => void;
  openUserProfile: (userId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY_PREFIX = 'nexif5_mobile_';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'theme');
    return (saved as ThemeMode) || 'dark';
  });

  const setTheme = (newTheme: ThemeMode) => {
    setThemeState(newTheme);
    localStorage.setItem(STORAGE_KEY_PREFIX + 'theme', newTheme);
  };

  const toggleTheme = () => {
    setThemeState((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      localStorage.setItem(STORAGE_KEY_PREFIX + 'theme', next);
      return next;
    });
  };

  const [currentLanguage, setCurrentLanguageState] = useState<LanguageCode>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'language');
    return (saved as LanguageCode) || 'en';
  });

  const setCurrentLanguage = (lang: LanguageCode) => {
    setCurrentLanguageState(lang);
    localStorage.setItem(STORAGE_KEY_PREFIX + 'language', lang);
  };

  const [authState, setAuthState] = useState<AuthState>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'auth_state');
    return (saved as AuthState) || 'welcome';
  });

  const [mobileTab, setMobileTab] = useState<MobileTab>('home');
  const [subView, setSubView] = useState<SubView>(null);
  const [currentRole, setCurrentRole] = useState<UserRole>('student');

  const [students, setStudents] = useState<StudentProfile[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'students');
    return saved ? JSON.parse(saved) : MOCK_STUDENTS;
  });

  const [companies, setCompanies] = useState<CompanyOrganization[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'companies');
    return saved ? JSON.parse(saved) : MOCK_COMPANIES;
  });

  const [colleges, setColleges] = useState<CollegeOrganization[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'colleges');
    return saved ? JSON.parse(saved) : MOCK_COLLEGES;
  });

  const [jobs, setJobs] = useState<JobOpportunity[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'jobs');
    return saved ? JSON.parse(saved) : MOCK_JOBS;
  });

  const [applications, setApplications] = useState<JobApplication[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'applications');
    return saved ? JSON.parse(saved) : MOCK_APPLICATIONS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'notifications');
    return saved ? JSON.parse(saved) : MOCK_NOTIFICATIONS;
  });

  const [savedJobIds, setSavedJobIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'saved_jobs');
    return saved ? JSON.parse(saved) : ['job-1', 'job-3'];
  });

  // Shared Learning Resources Store
  const [sharedResources, setSharedResources] = useState<SharedResource[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'shared_resources');
    return saved ? JSON.parse(saved) : MOCK_SHARED_RESOURCES;
  });

  // Saved / Bookmarked Resource IDs
  const [savedResourceIds, setSavedResourceIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'saved_resources_ids');
    return saved ? JSON.parse(saved) : ['res-1', 'res-4'];
  });

  const [selectedResourceForDetail, setSelectedResourceForDetail] = useState<SharedResource | null>(null);
  const [isUploadResourceModalOpen, setIsUploadResourceModalOpen] = useState<boolean>(false);
  const [learnSubTab, setLearnSubTab] = useState<LearnSubTab>('recommendations');

  // Skill Progress & Action Tasks Store
  const [skillProgressList, setSkillProgressList] = useState<SkillProgressItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'skill_progress');
    return saved ? JSON.parse(saved) : MOCK_SKILL_PROGRESS;
  });

  // Certified Courses & Verification Store
  const [certifiedCourses, setCertifiedCourses] = useState<CertifiedCourse[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'certified_courses');
    return saved ? JSON.parse(saved) : MOCK_CERTIFIED_COURSES;
  });

  const [selectedCourseForLearning, setSelectedCourseForLearning] = useState<CertifiedCourse | null>(null);
  const [activeVideoLessonId, setActiveVideoLessonId] = useState<string | null>(null);
  const [isCourseVideoModalOpen, setIsCourseVideoModalOpen] = useState<boolean>(false);
  const [selectedCourseForAssessment, setSelectedCourseForAssessment] = useState<CertifiedCourse | null>(null);
  const [isAssessmentModalOpen, setIsAssessmentModalOpen] = useState<boolean>(false);
  const [selectedCertificateForView, setSelectedCertificateForView] = useState<CourseCertificate | null>(null);
  const [isCertificateModalOpen, setIsCertificateModalOpen] = useState<boolean>(false);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState<boolean>(false);
  const [verificationQueryId, setVerificationQueryId] = useState<string>('');


  // Current logged in user ID
  const [currentStudentId, setCurrentStudentId] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'user_id');
    return saved || 'std-1';
  });

  const [currentCompanyId, setCurrentCompanyId] = useState<string>('comp-1');
  const [currentCollegeId, setCurrentCollegeId] = useState<string>('clg-1');

  // Working Professional State
  const [professionals, setProfessionals] = useState<WorkingProfessionalProfile[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'professionals');
    return saved ? JSON.parse(saved) : MOCK_PROFESSIONALS;
  });
  const [currentProfessionalId, setCurrentProfessionalId] = useState<string>('pro-1');

  // Mentor State
  const [mentors, setMentors] = useState<MentorProfile[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'mentors');
    return saved ? JSON.parse(saved) : MOCK_MENTORS;
  });
  const [currentMentorId, setCurrentMentorId] = useState<string>('men-1');

  // Admin Users State
  const [adminUsers, setAdminUsers] = useState<AdminUserRecord[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'admin_users');
    return saved ? JSON.parse(saved) : MOCK_ADMIN_USERS;
  });

  // Role Tab navigation states
  const [activeRecruiterTab, setActiveRecruiterTab] = useState<string>('overview');
  const [activeCollegeTab, setActiveCollegeTab] = useState<string>('dashboard');
  const [activeProfessionalTab, setActiveProfessionalTab] = useState<string>('overview');
  const [activeMentorTab, setActiveMentorTab] = useState<string>('workspace');
  const [activeAdminTab, setActiveAdminTab] = useState<string>('overview');
  const [activeStudentTab, setActiveStudentTab] = useState<string>('home');
  const [activeJobSeekerTab, setActiveJobSeekerTab] = useState<string>('overview');

  const currentStudent = students.find(s => s.id === currentStudentId) || students[0];
  const currentCompany = companies.find(c => c.id === currentCompanyId) || companies[0];
  const currentCollege = colleges.find(c => c.id === currentCollegeId) || colleges[0];
  const currentProfessional = professionals.find(p => p.id === currentProfessionalId) || professionals[0];
  const currentMentor = mentors.find(m => m.id === currentMentorId) || mentors[0];

  const updateProfessionalProfile = (updates: Partial<WorkingProfessionalProfile>) => {
    setProfessionals(prev => prev.map(p => p.id === currentProfessional.id ? { ...p, ...updates } : p));
  };

  const updateMentorProfile = (updates: Partial<MentorProfile>) => {
    setMentors(prev => prev.map(m => m.id === currentMentor.id ? { ...m, ...updates } : m));
  };

  const addMentorshipSession = (session: Omit<MentorshipSession, 'id'>) => {
    const newSession: MentorshipSession = {
      ...session,
      id: `ms-${Date.now()}`
    };
    setMentors(prev => prev.map(m => {
      if (m.id === currentMentor.id) {
        return {
          ...m,
          sessions: [newSession, ...m.sessions],
          totalMenteesCount: m.totalMenteesCount + 1
        };
      }
      return m;
    }));
  };

  const toggleAdminUserStatus = (userId: string) => {
    setAdminUsers(prev => prev.map(u => {
      if (u.id === userId) {
        return { ...u, status: u.status === 'active' ? 'suspended' : 'active' };
      }
      return u;
    }));
  };

  const switchToRole = (role: UserRole) => {
    setCurrentRole(role);
    setAuthState('authenticated');
    setSubView(null);
  };

  const switchToStudentDemo = (id = 'std-1') => {
    setCurrentRole('student');
    setCurrentStudentId(id);
    setMobileTab('home');
    setAuthState('authenticated');
    setSubView(null);
  };

  const switchToJobSeekerDemo = (id = 'std-jobseeker') => {
    setCurrentRole('job_seeker');
    setCurrentStudentId(id);
    setCurrentProfessionalId('pro-1');
    setMobileTab('home');
    setAuthState('authenticated');
    setSubView(null);
  };

  const switchToProfessionalDemo = (id = 'pro-1') => {
    setCurrentRole('professional');
    setCurrentProfessionalId(id);
    setAuthState('authenticated');
    setSubView(null);
  };

  const switchToRecruiterDemo = (companyId = 'comp-1') => {
    setCurrentRole('recruiter');
    setCurrentCompanyId(companyId);
    setActiveRecruiterTab('overview');
    setAuthState('authenticated');
    setSubView(null);
  };

  const switchToCollegeDemo = (collegeId = 'clg-1') => {
    setCurrentRole('college');
    setCurrentCollegeId(collegeId);
    setActiveCollegeTab('dashboard');
    setAuthState('authenticated');
    setSubView(null);
  };

  const switchToMentorDemo = (mentorId = 'men-1') => {
    setCurrentRole('mentor');
    setCurrentMentorId(mentorId);
    setActiveMentorTab('workspace');
    setAuthState('authenticated');
    setSubView(null);
  };

  const switchToAdminDemo = () => {
    setCurrentRole('admin');
    setActiveAdminTab('overview');
    setAuthState('authenticated');
    setSubView(null);
  };

  // ==========================================
  // NETWORK & CONNECT STATE & METHODS
  // ==========================================
  const [connectionRequests, setConnectionRequests] = useState<ConnectionRequest[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'connection_requests');
    return saved ? JSON.parse(saved) : MOCK_CONNECTION_REQUESTS;
  });

  const [userConnections, setUserConnections] = useState<UserConnection[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'user_connections');
    return saved ? JSON.parse(saved) : MOCK_USER_CONNECTIONS;
  });

  const [smartRecommendations, setSmartRecommendations] = useState<SmartConnectionRecommendation[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'smart_recommendations');
    return saved ? JSON.parse(saved) : MOCK_SMART_RECOMMENDATIONS;
  });

  // Professional Direct Messaging State
  const [chatConversations, setChatConversations] = useState<ChatConversation[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'chat_conversations');
    return saved ? JSON.parse(saved) : MOCK_CHAT_CONVERSATIONS;
  });

  const [directChatMessages, setDirectChatMessages] = useState<Record<string, DirectChatMessage[]>>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'direct_chat_messages');
    return saved ? JSON.parse(saved) : MOCK_CHAT_MESSAGES;
  });

  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [viewingProfileUserId, setViewingProfileUserId] = useState<string | null>(null);
  const quickTemplates = MOCK_MESSAGE_TEMPLATES;

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'connection_requests', JSON.stringify(connectionRequests));
  }, [connectionRequests]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'user_connections', JSON.stringify(userConnections));
  }, [userConnections]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'chat_conversations', JSON.stringify(chatConversations));
  }, [chatConversations]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'direct_chat_messages', JSON.stringify(directChatMessages));
  }, [directChatMessages]);

  const getCurrentUserInfo = () => {
    if (currentRole === 'recruiter') {
      return { id: currentCompany.id, name: currentCompany.name, role: 'recruiter' as UserRole, avatar: currentCompany.logoUrl, headline: 'Hiring Lead @ ' + currentCompany.name };
    }
    if (currentRole === 'college') {
      return { id: currentCollege.id, name: currentCollege.name, role: 'college' as UserRole, avatar: currentCollege.logoUrl, headline: 'Placement & Industry Director @ ' + currentCollege.name };
    }
    if (currentRole === 'mentor') {
      return { id: currentMentor.id, name: currentMentor.name, role: 'mentor' as UserRole, avatar: currentMentor.avatarUrl, headline: currentMentor.jobTitle + ' @ ' + currentMentor.company };
    }
    if (currentRole === 'professional' || currentRole === 'job_seeker') {
      return { id: currentProfessional.id, name: currentProfessional.name, role: 'professional' as UserRole, avatar: currentProfessional.avatarUrl, headline: currentProfessional.currentJobTitle + ' @ ' + currentProfessional.currentCompany };
    }
    return { id: currentStudent.id, name: currentStudent.name, role: 'student' as UserRole, avatar: currentStudent.avatarUrl, headline: 'Student • ' + currentStudent.education.degree };
  };

  const getConnectionStatusWithUser = (targetUserId: string): ConnectionStatus => {
    const isConn = userConnections.some(c => c.peerId === targetUserId);
    if (isConn) return 'connected';

    const sentReq = connectionRequests.find(r => r.receiverId === targetUserId && r.status === 'pending');
    if (sentReq) return 'pending_sent';

    const recReq = connectionRequests.find(r => r.senderId === targetUserId && r.status === 'pending');
    if (recReq) return 'pending_received';

    return 'none';
  };

  const sendConnectionRequest = (targetUserId: string, note?: string) => {
    const current = getCurrentUserInfo();
    if (current.id === targetUserId) {
      return { success: false, message: 'You cannot connect with your own profile.' };
    }

    const currentStatus = getConnectionStatusWithUser(targetUserId);
    if (currentStatus === 'connected') {
      return { success: false, message: 'You are already connected with this user.' };
    }
    if (currentStatus === 'pending_sent') {
      return { success: false, message: 'A connection request has already been sent.' };
    }

    const rec = smartRecommendations.find(r => r.userId === targetUserId);
    const mentorMatch = mentors.find(m => m.id === targetUserId);
    const proMatch = professionals.find(p => p.id === targetUserId);
    const studentMatch = students.find(s => s.id === targetUserId);
    const companyMatch = companies.find(c => c.id === targetUserId);

    const targetName = rec?.name || mentorMatch?.name || proMatch?.name || studentMatch?.name || companyMatch?.name || 'Professional';
    const targetRole = rec?.role || (mentorMatch ? 'mentor' : proMatch ? 'professional' : studentMatch ? 'student' : companyMatch ? 'recruiter' : 'professional');

    const newReq: ConnectionRequest = {
      id: `req-${Date.now()}`,
      senderId: current.id,
      senderName: current.name,
      senderRole: current.role,
      senderAvatar: current.avatar,
      senderHeadline: current.headline,
      receiverId: targetUserId,
      receiverRole: targetRole as UserRole,
      note: note || `Hi ${targetName}, I would like to connect with you professionally on NEXIF5.`,
      createdAt: 'Just now',
      status: 'pending',
      sharedSkillsCount: 3
    };

    setConnectionRequests(prev => [newReq, ...prev]);

    setSmartRecommendations(prev =>
      prev.map(r => r.userId === targetUserId ? { ...r, connectionStatus: 'pending_sent' } : r)
    );

    addNotification({
      recipientType: current.role === 'admin' ? 'admin' : current.role === 'mentor' ? 'mentor' : current.role === 'professional' ? 'professional' : current.role === 'recruiter' ? 'recruiter' : current.role === 'college' ? 'college' : 'student',
      recipientId: current.id,
      title: 'Connection Request Sent',
      message: `Your professional connection request was sent to ${targetName}.`,
      type: 'system'
    });

    return { success: true, message: `Connection request sent to ${targetName}!` };
  };

  const acceptConnectionRequest = (requestId: string) => {
    const req = connectionRequests.find(r => r.id === requestId);
    if (!req) return;

    setConnectionRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: 'accepted' as const } : r));

    const newConn: UserConnection = {
      id: `conn-${Date.now()}`,
      peerId: req.senderId,
      peerName: req.senderName,
      peerRole: req.senderRole,
      peerAvatar: req.senderAvatar,
      peerHeadline: req.senderHeadline,
      peerCompanyOrSchool: req.senderHeadline,
      connectedAt: 'Just now',
      isFollowing: true,
      sharedSkills: ['Career Development', 'Professional Alignment'],
      mutualConnectionsCount: 1
    };

    setUserConnections(prev => [newConn, ...prev.filter(c => c.peerId !== req.senderId)]);

    setSmartRecommendations(prev =>
      prev.map(r => r.userId === req.senderId ? { ...r, connectionStatus: 'connected' } : r)
    );

    const current = getCurrentUserInfo();
    addNotification({
      recipientType: current.role === 'admin' ? 'admin' : current.role === 'mentor' ? 'mentor' : current.role === 'professional' ? 'professional' : current.role === 'recruiter' ? 'recruiter' : current.role === 'college' ? 'college' : 'student',
      recipientId: current.id,
      title: 'Connection Accepted',
      message: `You are now connected with ${req.senderName}. You can start direct messaging anytime!`,
      type: 'system'
    });
  };

  const declineConnectionRequest = (requestId: string) => {
    const req = connectionRequests.find(r => r.id === requestId);
    setConnectionRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: 'declined' as const } : r));
    if (req) {
      setSmartRecommendations(prev =>
        prev.map(r => r.userId === req.senderId ? { ...r, connectionStatus: 'none' } : r)
      );
    }
  };

  const cancelConnectionRequest = (requestId: string) => {
    const req = connectionRequests.find(r => r.id === requestId);
    setConnectionRequests(prev => prev.filter(r => r.id !== requestId));
    if (req) {
      setSmartRecommendations(prev =>
        prev.map(r => r.userId === req.receiverId ? { ...r, connectionStatus: 'none' } : r)
      );
    }
  };

  const removeConnection = (connectionId: string) => {
    const conn = userConnections.find(c => c.id === connectionId);
    setUserConnections(prev => prev.filter(c => c.id !== connectionId));
    if (conn) {
      setSmartRecommendations(prev =>
        prev.map(r => r.userId === conn.peerId ? { ...r, connectionStatus: 'none' } : r)
      );
    }
  };

  const toggleFollowUser = (targetUserId: string) => {
    setSmartRecommendations(prev =>
      prev.map(r => r.userId === targetUserId ? { ...r, isFollowing: !r.isFollowing } : r)
    );
    setUserConnections(prev =>
      prev.map(c => c.peerId === targetUserId ? { ...c, isFollowing: !c.isFollowing } : c)
    );
  };

  const startOrOpenConversation = (peerId: string): string => {
    const existing = chatConversations.find(c => c.peerId === peerId);
    if (existing) {
      setActiveConversationId(existing.id);
      setSubView('messages');
      return existing.id;
    }

    const rec = smartRecommendations.find(r => r.userId === peerId);
    const mentorMatch = mentors.find(m => m.id === peerId);
    const proMatch = professionals.find(p => p.id === peerId);
    const studentMatch = students.find(s => s.id === peerId);
    const companyMatch = companies.find(c => c.id === peerId);

    const peerName = rec?.name || mentorMatch?.name || proMatch?.name || studentMatch?.name || companyMatch?.name || 'Professional Contact';
    const peerRole = (rec?.role || (mentorMatch ? 'mentor' : proMatch ? 'professional' : studentMatch ? 'student' : companyMatch ? 'recruiter' : 'professional')) as UserRole;
    const peerAvatar = rec?.avatarUrl || mentorMatch?.avatarUrl || proMatch?.avatarUrl || studentMatch?.avatarUrl || companyMatch?.logoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150';
    const peerHeadline = rec?.headline || mentorMatch?.jobTitle || proMatch?.currentJobTitle || studentMatch?.careerGoal || 'NEXIF5 Member';
    const peerOrg = rec?.organization || mentorMatch?.company || proMatch?.currentCompany || studentMatch?.education.institution || '';

    const newConvId = `conv-${Date.now()}`;
    const newConv: ChatConversation = {
      id: newConvId,
      peerId,
      peerName,
      peerAvatar,
      peerRole,
      peerHeadline,
      peerOrganization: peerOrg,
      lastMessage: 'Conversation started.',
      lastMessageTimestamp: 'Just now',
      unreadCount: 0,
      isOnline: true,
      isConnected: userConnections.some(c => c.peerId === peerId)
    };

    setChatConversations(prev => [newConv, ...prev]);
    setDirectChatMessages(prev => ({
      ...prev,
      [newConvId]: []
    }));

    setActiveConversationId(newConvId);
    setSubView('messages');
    return newConvId;
  };

  const sendMessage = (conversationId: string, content: string, attachment?: MessageAttachment) => {
    if (!content.trim() && !attachment) return;
    const current = getCurrentUserInfo();
    const conv = chatConversations.find(c => c.id === conversationId);

    const newMsg: DirectChatMessage = {
      id: `m-${Date.now()}`,
      conversationId,
      senderId: current.id,
      senderName: current.name,
      senderAvatar: current.avatar,
      senderRole: current.role,
      receiverId: conv?.peerId || '',
      content: content.trim(),
      timestamp: 'Just now',
      isRead: true,
      status: 'sent',
      attachment
    };

    setDirectChatMessages(prev => ({
      ...prev,
      [conversationId]: [...(prev[conversationId] || []), newMsg]
    }));

    setChatConversations(prev =>
      prev.map(c =>
        c.id === conversationId
          ? {
              ...c,
              lastMessage: attachment ? `[Attachment: ${attachment.title}] ${content}` : content,
              lastMessageTimestamp: 'Just now'
            }
          : c
      )
    );
  };

  const markConversationRead = (conversationId: string) => {
    setChatConversations(prev =>
      prev.map(c => c.id === conversationId ? { ...c, unreadCount: 0 } : c)
    );
    setDirectChatMessages(prev => {
      const msgs = prev[conversationId];
      if (!msgs) return prev;
      return {
        ...prev,
        [conversationId]: msgs.map(m => ({ ...m, isRead: true, status: 'read' as const }))
      };
    });
  };

  const openUserProfile = (userId: string) => {
    setViewingProfileUserId(userId);
    setSubView('view_profile');
  };

  // Active Modals & Search
  const [selectedJobForDetails, setSelectedJobForDetails] = useState<JobOpportunity | null>(null);
  const [selectedJobForApply, setSelectedJobForApply] = useState<JobOpportunity | null>(null);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Persist important keys
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'language', currentLanguage);
  }, [currentLanguage]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'auth_state', authState);
  }, [authState]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'user_id', currentStudentId);
  }, [currentStudentId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'saved_jobs', JSON.stringify(savedJobIds));
  }, [savedJobIds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'jobs', JSON.stringify(jobs));
  }, [jobs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'applications', JSON.stringify(applications));
  }, [applications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'shared_resources', JSON.stringify(sharedResources));
  }, [sharedResources]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'saved_resources_ids', JSON.stringify(savedResourceIds));
  }, [savedResourceIds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'skill_progress', JSON.stringify(skillProgressList));
  }, [skillProgressList]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'certified_courses', JSON.stringify(certifiedCourses));
  }, [certifiedCourses]);


  // Document Sharing Actions
  const toggleSaveResource = (resourceId: string) => {
    const isSaved = savedResourceIds.includes(resourceId);
    if (isSaved) {
      setSavedResourceIds(prev => prev.filter(id => id !== resourceId));
      setSharedResources(prev =>
        prev.map(r => (r.id === resourceId ? { ...r, savesCount: Math.max(0, r.savesCount - 1) } : r))
      );
    } else {
      setSavedResourceIds(prev => [...prev, resourceId]);
      setSharedResources(prev =>
        prev.map(r => (r.id === resourceId ? { ...r, savesCount: r.savesCount + 1 } : r))
      );
    }
  };

  const markResourceHelpful = (resourceId: string) => {
    setSharedResources(prev =>
      prev.map(r => (r.id === resourceId ? { ...r, helpfulCount: r.helpfulCount + 1 } : r))
    );
  };

  const uploadResource = (
    newResourceData: Omit<SharedResource, 'id' | 'viewsCount' | 'savesCount' | 'helpfulCount' | 'downloadsCount' | 'uploadDate'>
  ): SharedResource => {
    const newId = `res-${Date.now()}`;
    const fullResource: SharedResource = {
      ...newResourceData,
      id: newId,
      viewsCount: 1,
      savesCount: 0,
      helpfulCount: 0,
      downloadsCount: 0,
      uploadDate: 'Just now',
      uploaderId: currentStudent.id,
      uploaderName: currentStudent.name,
      uploaderRole: `${currentStudent.education.degree} Student`,
      uploaderAvatar: currentStudent.avatarUrl
    };

    setSharedResources(prev => [fullResource, ...prev]);

    // Automatically notify user
    addNotification({
      recipientType: 'student',
      recipientId: currentStudent.id,
      title: 'Resource Published to NEXIF5',
      message: `"${fullResource.title}" is now available in the Learning Hub for the student community!`,
      type: 'system',
      actionLink: newId
    });

    return fullResource;
  };

  const deleteResource = (resourceId: string) => {
    setSharedResources(prev => prev.filter(r => r.id !== resourceId));
    setSavedResourceIds(prev => prev.filter(id => id !== resourceId));
  };

  const updateResource = (id: string, updates: Partial<SharedResource>) => {
    setSharedResources(prev =>
      prev.map(r => (r.id === id ? { ...r, ...updates } : r))
    );
  };

  // Skill Progress & Practical Action Task Completion
  const completeSkillTask = (skillName: string) => {
    setSkillProgressList(prev =>
      prev.map(item => {
        if (item.skill.toLowerCase() === skillName.toLowerCase()) {
          const newProgress = Math.min(100, item.progressPercent + 25);
          return {
            ...item,
            isTaskCompleted: true,
            progressPercent: newProgress,
            currentLevel: newProgress >= 80 ? 'Advanced' : 'Working Proficiency'
          };
        }
        return item;
      })
    );

    // Boost student career readiness score deterministically
    const updatedScore = Math.min(98, currentStudent.careerReadinessScore + 6);
    updateStudentProfile({
      careerReadinessScore: updatedScore
    });

    addNotification({
      recipientType: 'student',
      recipientId: currentStudent.id,
      title: 'Practical Task Completed!',
      message: `Great job! Your demonstration of ${skillName} increased progress. Career Readiness updated to ${updatedScore}%.`,
      type: 'system'
    });
  };

  // Certified Courses & Learning Journey Actions
  const openCourseLearning = (courseId: string, lessonId?: string) => {
    const course = certifiedCourses.find(c => c.id === courseId) || certifiedCourses[0];
    setSelectedCourseForLearning(course);
    if (lessonId) {
      setActiveVideoLessonId(lessonId);
    } else {
      const uncompleted = course.videoLessons.find(l => !l.isCompleted);
      setActiveVideoLessonId(uncompleted ? uncompleted.id : course.videoLessons[0]?.id || null);
    }
    setIsCourseVideoModalOpen(true);
  };

  const openCourseAssessment = (courseId: string) => {
    const course = certifiedCourses.find(c => c.id === courseId) || certifiedCourses[0];
    setSelectedCourseForAssessment(course);
    setIsAssessmentModalOpen(true);
  };

  const openCertificateView = (courseIdOrCertId: string) => {
    let foundCert: CourseCertificate | null = null;
    for (const c of certifiedCourses) {
      if (c.certificate && (c.certificate.certificateId === courseIdOrCertId || c.id === courseIdOrCertId)) {
        foundCert = c.certificate;
        break;
      }
    }
    if (!foundCert) {
      for (const c of MOCK_CERTIFIED_COURSES) {
        if (c.certificate && (c.certificate.certificateId === courseIdOrCertId || c.id === courseIdOrCertId)) {
          foundCert = c.certificate;
          break;
        }
      }
    }
    if (foundCert) {
      setSelectedCertificateForView(foundCert);
      setIsCertificateModalOpen(true);
    }
  };

  const openCertificateVerification = (certId?: string) => {
    setVerificationQueryId(certId || '');
    setIsVerificationModalOpen(true);
  };

  const completeVideoLesson = (courseId: string, lessonId: string) => {
    setCertifiedCourses(prev =>
      prev.map(course => {
        if (course.id !== courseId) return course;
        const updatedLessons = course.videoLessons.map(l =>
          l.id === lessonId ? { ...l, isCompleted: true } : l
        );
        const completedCount = updatedLessons.filter(l => l.isCompleted).length;
        const newProgress = Math.round((completedCount / updatedLessons.length) * 100);

        return {
          ...course,
          videoLessons: updatedLessons,
          progressPercent: newProgress,
          isCertificateEligible: newProgress >= 80
        };
      })
    );
  };

  const submitLessonPracticeTask = (courseId: string, lessonId: string, submissionText: string) => {
    setCertifiedCourses(prev =>
      prev.map(course => {
        if (course.id !== courseId) return course;
        const updatedLessons = course.videoLessons.map(l => {
          if (l.id === lessonId) {
            return {
              ...l,
              isCompleted: true,
              practiceTask: l.practiceTask
                ? {
                    ...l.practiceTask,
                    isCompleted: true,
                    userSubmission: submissionText,
                    submittedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
                  }
                : undefined
            };
          }
          return l;
        });

        const completedCount = updatedLessons.filter(l => l.isCompleted).length;
        const newProgress = Math.round((completedCount / updatedLessons.length) * 100);

        return {
          ...course,
          videoLessons: updatedLessons,
          progressPercent: newProgress,
          isCertificateEligible: newProgress >= 80
        };
      })
    );

    addNotification({
      recipientType: 'student',
      recipientId: currentStudent.id,
      title: 'Practice Task Submitted & Verified!',
      message: `Your practical exercise was evaluated and recorded by AI Coach. Video module completed!`,
      type: 'system'
    });
  };

  const submitCourseAssessment = (courseId: string, answers: Record<string, string | number>) => {
    const course = certifiedCourses.find(c => c.id === courseId);
    if (!course) return { scorePercent: 0, passed: false };

    let correctCount = 0;
    const questions = course.assessment.questions;
    questions.forEach(q => {
      const userAnswer = answers[q.id];
      if (q.correctAnswerIndex !== undefined && userAnswer === q.correctAnswerIndex) {
        correctCount++;
      } else if (q.correctAnswerText && String(userAnswer).trim().toLowerCase() === q.correctAnswerText.trim().toLowerCase()) {
        correctCount++;
      }
    });

    const scorePercent = Math.round((correctCount / questions.length) * 100);
    const passed = scorePercent >= course.assessment.passingScorePercent;

    let cert: CourseCertificate | undefined = course.certificate;
    if (passed) {
      const certId = course.certificate?.certificateId || `NXF-${course.skill.substring(0, 3).toUpperCase()}-2026-00${Math.floor(100 + Math.random() * 900)}`;
      cert = {
        certificateId: certId,
        courseId: course.id,
        courseTitle: course.title,
        skill: course.skill,
        learnerName: currentStudent.name,
        learnerId: currentStudent.id,
        issuerName: 'NEXIF5 Career Execution Platform',
        partnerName: course.partner,
        certificateType: 'completion',
        disclaimer: `NEXIF5 Skill Mastery Completion Certificate. Validates 100% course progression, interactive video lessons, practical task demonstrations, and passing score of ${scorePercent}% on the capstone examination.`,
        issueDate: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
        assessmentScore: scorePercent,
        grade: scorePercent >= 90 ? `Distinction (${scorePercent}%)` : `First Class (${scorePercent}%)`,
        verificationStatus: 'verified',
        verificationUrl: `https://nexif5.careers/verify/${certId}`,
        skillsDemonstrated: course.certificate?.skillsDemonstrated || [
          `${course.skill} Practical Demonstration`,
          'Capstone Project Execution',
          'Analytical Problem Solving'
        ],
        signatoryName: 'Dr. Ramesh Sundaram',
        signatoryTitle: 'Head of Industry Academics, NEXIF5'
      };

      // Boost student score deterministically
      const updatedScore = Math.min(98, currentStudent.careerReadinessScore + 8);
      updateStudentProfile({
        careerReadinessScore: updatedScore
      });

      // Mark student skill as verified
      const existingSkill = currentStudent.skills.find(s => s.name.toLowerCase().includes(course.skill.toLowerCase()));
      if (existingSkill) {
        updateStudentProfile({
          skills: currentStudent.skills.map(s =>
            s.id === existingSkill.id ? { ...s, verified: true, level: 'advanced' } : s
          )
        });
      }

      // Add achievement
      addStudentAchievement({
        title: `${course.title} — Verified`,
        issuer: `${course.provider} (${course.partner})`,
        date: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
        description: `Passed capstone assessment with ${scorePercent}% score. Certificate ID: ${certId}`,
        category: 'certification'
      });

      addNotification({
        recipientType: 'student',
        recipientId: currentStudent.id,
        title: '🎉 Certificate Earned!',
        message: `Congratulations! You scored ${scorePercent}% in ${course.title}. Verifiable Certificate #${certId} has been awarded.`,
        type: 'system',
        actionLink: certId
      });
    }

    setCertifiedCourses(prev =>
      prev.map(c => {
        if (c.id !== courseId) return c;
        return {
          ...c,
          progressPercent: passed ? 100 : c.progressPercent,
          isCertificateEarned: passed || c.isCertificateEarned,
          isCertificateEligible: true,
          certificate: cert,
          assessment: {
            ...c.assessment,
            userScorePercent: scorePercent,
            userPassed: passed,
            completedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
          }
        };
      })
    );

    return { scorePercent, passed, certificate: cert };
  };

  const verifyCertificateById = (certId: string): CourseCertificate | null => {
    const cleanId = certId.trim().toUpperCase();
    for (const c of certifiedCourses) {
      if (c.certificate && c.certificate.certificateId.toUpperCase() === cleanId) {
        return c.certificate;
      }
    }
    for (const c of MOCK_CERTIFIED_COURSES) {
      if (c.certificate && c.certificate.certificateId.toUpperCase() === cleanId) {
        return c.certificate;
      }
    }
    return null;
  };


  const toggleSaveJob = (jobId: string) => {
    setSavedJobIds(prev =>
      prev.includes(jobId) ? prev.filter(id => id !== jobId) : [...prev, jobId]
    );
  };

  const createNewUser = (userData: Partial<StudentProfile>, role: UserRole): StudentProfile => {
    const newId = `user-${Date.now()}`;
    const newStudent: StudentProfile = {
      id: newId,
      name: userData.name || 'Nexif5 User',
      email: userData.email || 'user@nexif5.com',
      phone: userData.phone || '+91 98765 43210',
      avatarUrl: userData.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      bio: userData.bio || 'Aspiring professional building an AI-optimized career roadmap on Nexif5.',
      collegeId: userData.collegeId,
      collegeName: userData.collegeName || 'Sri Krishna College of Technology',
      userType: role === 'job_seeker' ? 'job_seeker' : 'student',
      currentDesignation: userData.currentDesignation || 'Business Analyst Candidate',
      careerGoal: userData.careerGoal || 'Business Analyst',
      careerReadinessScore: 88,
      education: userData.education || {
        degree: 'B.Tech',
        course: 'Computer Science & Engineering',
        institution: userData.collegeName || 'Sri Krishna College of Technology',
        yearOfPassing: 2025,
        currentYear: 'Final Year (4th Year)',
        cgpaOrPercentage: '8.7 CGPA'
      },
      preferredJobRoles: userData.preferredJobRoles || [userData.careerGoal || 'Business Analyst'],
      salaryPreferenceMinLPA: 5,
      salaryPreferenceMaxLPA: 8,
      locationPreferenceType: 'anywhere_in_india',
      preferredCities: ['Coimbatore', 'Bengaluru', 'Remote'],
      workPreference: 'hybrid',
      jobTypePreference: 'full_time',
      skills: userData.skills && userData.skills.length > 0 ? userData.skills : [
        { id: 'sk-1', name: 'Python', category: 'technical', level: 'intermediate', verified: true },
        { id: 'sk-2', name: 'SQL', category: 'technical', level: 'advanced', verified: true },
        { id: 'sk-3', name: 'Power BI', category: 'analytics', level: 'intermediate', verified: true },
        { id: 'sk-4', name: 'Communication', category: 'soft', level: 'expert', verified: true }
      ],
      achievements: userData.achievements || [
        { id: 'ach-1', title: 'Nexif5 Verified Profile', issuer: 'Nexif5 Career Engine', date: 'Jul 2025', description: 'Certified candidate profile', category: 'certification' }
      ],
      projects: userData.projects || [
        {
          id: 'proj-1',
          title: 'Customer Churn Predictive Analytics Dashboard',
          description: 'Engineered end-to-end churn model and Power BI visual dashboards for retail banking analytics.',
          technologies: ['Python', 'SQL', 'Power BI'],
          startDate: 'Jan 2024',
          endDate: 'Apr 2024',
          role: 'Lead Analyst'
        }
      ],
      experiences: userData.experiences || [],
      languages: userData.languages || ['English', 'Tamil'],
      resumeName: userData.resumeName || `${(userData.name || 'Nexif5_User').replace(/\s+/g, '_')}_ATS_Resume.pdf`,
      resumeUpdatedDate: 'Just now',
      createdAt: new Date().toISOString()
    };

    setStudents(prev => [newStudent, ...prev]);
    setCurrentStudentId(newId);
    setCurrentRole(role);
    setAuthState('authenticated');
    setMobileTab('home');

    addNotification({
      recipientType: 'student',
      recipientId: newId,
      title: 'Welcome to Nexif5!',
      message: `Your profile is ready. Start exploring AI-matched career opportunities!`,
      type: 'system'
    });

    return newStudent;
  };

  const loginUser = (email: string): boolean => {
    const lower = email.toLowerCase().trim();

    // Check admin
    if (lower === 'admin@nexif5.io' || lower.startsWith('admin')) {
      setCurrentRole('admin');
      setActiveAdminTab('overview');
      setAuthState('authenticated');
      return true;
    }

    // Check mentor
    const mentorMatch = mentors.find(m => m.email.toLowerCase() === lower);
    if (mentorMatch || lower.includes('mentor') || lower === 'ananya.sen@example.com') {
      setCurrentMentorId(mentorMatch?.id || 'men-1');
      setCurrentRole('mentor');
      setActiveMentorTab('workspace');
      setAuthState('authenticated');
      return true;
    }

    // Check working professional
    const proMatch = professionals.find(p => p.email.toLowerCase() === lower);
    if (proMatch || lower.includes('rahul.verma') || lower.includes('sneha.kapoor')) {
      setCurrentProfessionalId(proMatch?.id || 'pro-1');
      setCurrentRole('professional');
      setActiveProfessionalTab('overview');
      setAuthState('authenticated');
      return true;
    }

    // Check recruiter / company
    const compMatch = companies.find(c => c.teamMembers?.some(m => m.email.toLowerCase() === lower));
    if (compMatch || lower.includes('recruiter') || lower.includes('abctechnologies') || lower.includes('finedgeanalytics')) {
      setCurrentCompanyId(compMatch?.id || 'comp-1');
      setCurrentRole('recruiter');
      setActiveRecruiterTab('overview');
      setAuthState('authenticated');
      return true;
    }

    // Check college / institution
    const collegeMatch = colleges.find(c => c.placementOfficers?.some(p => p.email.toLowerCase() === lower));
    if (collegeMatch || lower.includes('placement') || lower.includes('rathinam') || lower.includes('psg')) {
      setCurrentCollegeId(collegeMatch?.id || 'clg-1');
      setCurrentRole('college');
      setActiveCollegeTab('dashboard');
      setAuthState('authenticated');
      return true;
    }

    // Check student
    const match = students.find(s => s.email.toLowerCase() === lower);
    if (match) {
      setCurrentStudentId(match.id);
      if (match.userType === 'job_seeker') {
        setCurrentRole('professional');
        setActiveProfessionalTab('overview');
      } else {
        setCurrentRole('student');
        setMobileTab('home');
      }
    } else {
      setCurrentStudentId('std-1');
      setCurrentRole('student');
      setMobileTab('home');
    }

    setAuthState('authenticated');
    return true;
  };

  const logOut = () => {
    setAuthState('welcome');
    setMobileTab('home');
    setSubView(null);
    setIsProfileMenuOpen(false);
    setSelectedJobForDetails(null);
    setSelectedJobForApply(null);
  };

  const logoutUser = () => {
    logOut();
  };

  // AI Chat Coach state
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init',
      sender: 'ai',
      text: `Hello ${currentStudent.name.split(' ')[0]}! I'm your Nexif5 Career Intelligence Coach. How can I help with your job search, interview preparation, or skill gaps today?`,
      timestamp: 'Just now'
    }
  ]);
  const [isAiTyping, setIsAiTyping] = useState(false);

  const sendChatMessage = (text: string) => {
    if (!text.trim()) return;
    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: 'Just now'
    };
    setChatMessages(prev => [...prev, userMsg]);
    setIsAiTyping(true);

    setTimeout(() => {
      const aiResponse = handleStudentAIQuery(text, currentStudent, jobs, applications);
      let responseText = aiResponse.answer;
      if (aiResponse.recommendations && aiResponse.recommendations.length > 0) {
        responseText += '\n\n' + aiResponse.recommendations.map(r => `• **${r.title}** at **${r.company}** (${r.score}% Match) — ${r.salary}`).join('\n');
      }
      const aiMsg: ChatMessage = {
        id: `msg-ai-${Date.now()}`,
        sender: 'ai',
        text: responseText,
        timestamp: 'Just now'
      };
      setChatMessages(prev => [...prev, aiMsg]);
      setIsAiTyping(false);
    }, 600);
  };

  const clearChat = () => {
    setChatMessages([]);
  };

  const applyForJob = (jobId: string, resumeNameOrCoverNote?: string, coverNote?: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (!job) return { success: false, message: 'Job not found.' };

    const existing = applications.find(
      a => a.jobId === jobId && a.candidateId === currentStudent.id
    );
    if (existing) {
      return { success: false, message: 'You have already applied for this opportunity.' };
    }

    const match = calculateJobMatch(currentStudent, job);
    const newAppId = `app-${Date.now()}`;
    const today = new Date().toISOString().split('T')[0];

    const actualResume = (resumeNameOrCoverNote && resumeNameOrCoverNote.endsWith('.pdf'))
      ? resumeNameOrCoverNote
      : currentStudent.resumeName;
    const actualCoverNote = coverNote || (resumeNameOrCoverNote && !resumeNameOrCoverNote.endsWith('.pdf') ? resumeNameOrCoverNote : undefined);

    const newApplication: JobApplication = {
      id: newAppId,
      candidateId: currentStudent.id,
      candidateName: currentStudent.name,
      candidateEmail: currentStudent.email,
      candidatePhone: currentStudent.phone,
      candidateEducation: currentStudent.education.degree,
      candidateCourse: currentStudent.education.course,
      candidateCollegeName: currentStudent.collegeName,
      candidateAvatarUrl: currentStudent.avatarUrl,
      candidateCareerGoal: currentStudent.careerGoal,
      candidateSkills: currentStudent.skills.map(s => s.name),
      candidateReadinessScore: currentStudent.careerReadinessScore,
      candidateType: currentRole === 'job_seeker' ? 'job_seeker' : 'student',
      jobId: job.id,
      jobTitle: job.title,
      jobType: job.type === 'internship' ? 'internship' : 'job',
      companyId: job.companyId,
      companyName: job.companyName,
      companyLogoUrl: job.companyLogoUrl,
      applicationDate: today,
      applicationSource: 'Applied through Nexif5 Mobile',
      status: 'applied',
      matchScore: match.overallScore,
      matchBreakdown: {
        skillsMatch: match.skillsMatch,
        qualificationMatch: match.qualificationMatch,
        careerGoalMatch: match.careerGoalMatch,
        preferenceMatch: match.preferenceMatch
      },
      matchReasons: match.whyItMatches,
      resumeUsed: actualResume,
      coverNote: actualCoverNote,
      timeline: [
        {
          status: 'applied',
          date: today,
          note: `Applied through Nexif5 Mobile (AI Match: ${match.overallScore}%)`
        }
      ]
    };

    setApplications(prev => [newApplication, ...prev]);
    setJobs(prev => prev.map(j => j.id === jobId ? { ...j, applicantsCount: j.applicantsCount + 1 } : j));

    addNotification({
      recipientType: 'student',
      recipientId: currentStudent.id,
      title: `Application Delivered — ${job.companyName}`,
      message: `Your application for '${job.title}' was delivered with a ${match.overallScore}% AI Match score.`,
      type: 'application_update',
      actionLink: newAppId
    });

    return { success: true, message: 'Application submitted successfully!', application: newApplication };
  };

  const updateApplicationStatus = (
    applicationId: string,
    newStatus: ApplicationStatus,
    options?: {
      note?: string;
      interview?: Partial<ScheduledInterview>;
      rejectionFeedback?: {
        provided: boolean;
        reasonCategory?: 'skill_gap' | 'qualification' | 'experience' | 'culture_fit' | 'position_filled';
        comment?: string;
        suggestedSkillsToLearn?: string[];
      };
    }
  ) => {
    const today = new Date().toISOString().split('T')[0];
    setApplications(prev =>
      prev.map(app => {
        if (app.id !== applicationId) return app;
        const timelineItem = {
          status: newStatus,
          date: today,
          note: options?.note || `Application status updated to ${newStatus}`
        };
        return {
          ...app,
          status: newStatus,
          interview: options?.interview ? { ...(app.interview || {}), ...options.interview } as ScheduledInterview : app.interview,
          rejectionFeedback: options?.rejectionFeedback || app.rejectionFeedback,
          timeline: [...app.timeline, timelineItem]
        };
      })
    );
  };

  const postNewJob = (jobData: Omit<JobOpportunity, 'id' | 'companyId' | 'companyName' | 'companyLogoUrl' | 'postedDate' | 'applicantsCount'>) => {
    const newId = `job-${Date.now()}`;
    const newJob: JobOpportunity = {
      ...jobData,
      id: newId,
      companyId: currentCompany.id,
      companyName: currentCompany.name,
      companyLogoUrl: currentCompany.logoUrl,
      postedDate: 'Today',
      applicantsCount: 0
    };
    setJobs(prev => [newJob, ...prev]);
    return newJob;
  };

  const updateStudentProfile = (updated: Partial<StudentProfile>) => {
    setStudents(prev =>
      prev.map(s => (s.id === currentStudent.id ? { ...s, ...updated } : s))
    );
  };

  const addStudentSkill = (skill: Omit<SkillItem, 'id'>) => {
    const newSkill: SkillItem = { ...skill, id: `sk-${Date.now()}` };
    updateStudentProfile({ skills: [...currentStudent.skills, newSkill] });
  };

  const removeStudentSkill = (skillId: string) => {
    updateStudentProfile({ skills: currentStudent.skills.filter(s => s.id !== skillId) });
  };

  const addStudentAchievement = (achievement: Omit<Achievement, 'id'>) => {
    const newAch: Achievement = { ...achievement, id: `ach-${Date.now()}` };
    updateStudentProfile({ achievements: [...currentStudent.achievements, newAch] });
  };

  const addStudentProject = (project: Omit<Project, 'id'>) => {
    const newProj: Project = { ...project, id: `proj-${Date.now()}` };
    updateStudentProfile({ projects: [...currentStudent.projects, newProj] });
  };

  const markNotificationRead = (notifId: string) => {
    setNotifications(prev =>
      prev.map(n => (n.id === notifId ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const addNotification = (notif: Omit<NotificationItem, 'id' | 'date' | 'read'>) => {
    const newNotif: NotificationItem = {
      ...notif,
      id: `notif-${Date.now()}`,
      date: 'Just now',
      read: false
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const t = (key: string) => {
    return translateFn(key, currentLanguage);
  };

  return (
    <AppContext.Provider
      value={{
        theme,
        setTheme,
        toggleTheme,
        currentLanguage,
        setCurrentLanguage,
        t,
        authState,
        setAuthState,
        mobileTab,
        setMobileTab,
        subView,
        setSubView,
        currentRole,
        setCurrentRole,
        currentStudent,
        setCurrentStudent: (s) => setCurrentStudentId(s.id),
        currentCompany,
        setCurrentCompany: (c) => setCurrentCompanyId(c.id),
        currentCollege,
        setCurrentCollege: (c) => setCurrentCollegeId(c.id),
        selectedJobForDetails,
        setSelectedJobForDetails,
        selectedJobForApply,
        setSelectedJobForApply,
        isProfileMenuOpen,
        setIsProfileMenuOpen,
        searchQuery,
        setSearchQuery,
        savedJobIds,
        toggleSaveJob,
        students,
        companies,
        colleges,
        jobs,
        applications,
        notifications,
        // Document & Learning Resource Sharing
        sharedResources,
        savedResourceIds,
        toggleSaveResource,
        markResourceHelpful,
        uploadResource,
        deleteResource,
        updateResource,
        selectedResourceForDetail,
        setSelectedResourceForDetail,
        isUploadResourceModalOpen,
        setIsUploadResourceModalOpen,
        // Skill Progress & Action Tasks
        skillProgressList,
        completeSkillTask,
        learnSubTab,
        setLearnSubTab,
        // Certified Courses, Video Lessons, Assessments & Certificates
        certifiedCourses,
        selectedCourseForLearning,
        setSelectedCourseForLearning,
        activeVideoLessonId,
        setActiveVideoLessonId,
        isCourseVideoModalOpen,
        setIsCourseVideoModalOpen,
        selectedCourseForAssessment,
        setSelectedCourseForAssessment,
        isAssessmentModalOpen,
        setIsAssessmentModalOpen,
        selectedCertificateForView,
        setSelectedCertificateForView,
        isCertificateModalOpen,
        setIsCertificateModalOpen,
        isVerificationModalOpen,
        setIsVerificationModalOpen,
        verificationQueryId,
        setVerificationQueryId,
        openCourseLearning,
        openCourseAssessment,
        openCertificateView,
        openCertificateVerification,
        completeVideoLesson,
        submitLessonPracticeTask,
        submitCourseAssessment,
        verifyCertificateById,
        chatMessages,

        sendChatMessage,
        clearChat,
        isAiTyping,
        createNewUser,
        loginUser,
        logOut,
        logoutUser,
        applyForJob,
        updateApplicationStatus,
        postNewJob,
        updateStudentProfile,
        addStudentSkill,
        removeStudentSkill,
        addStudentAchievement,
        addStudentProject,
        markNotificationRead,
        markAllNotificationsRead,
        markAllNotificationsAsRead: markAllNotificationsRead,
        addNotification,

        // Working Professional Data
        professionals,
        currentProfessional,
        setCurrentProfessional: (p) => setCurrentProfessionalId(p.id),
        updateProfessionalProfile,

        // Mentor Data
        mentors,
        currentMentor,
        setCurrentMentor: (m) => setCurrentMentorId(m.id),
        updateMentorProfile,
        addMentorshipSession,

        // Admin Data
        adminUsers,
        toggleAdminUserStatus,

        // Role Tab States
        activeRecruiterTab,
        setActiveRecruiterTab,
        activeCollegeTab,
        setActiveCollegeTab,
        activeProfessionalTab,
        setActiveProfessionalTab,
        activeMentorTab,
        setActiveMentorTab,
        activeAdminTab,
        setActiveAdminTab,
        activeStudentTab,
        setActiveStudentTab,
        activeJobSeekerTab,
        setActiveJobSeekerTab,

        // Role Switchers
        switchToRole,
        switchToStudentDemo,
        switchToJobSeekerDemo,
        switchToProfessionalDemo,
        switchToRecruiterDemo,
        switchToCollegeDemo,
        switchToMentorDemo,
        switchToAdminDemo,

        // Network & Connect System
        connectionRequests,
        userConnections,
        smartRecommendations,
        sendConnectionRequest,
        acceptConnectionRequest,
        declineConnectionRequest,
        cancelConnectionRequest,
        removeConnection,
        toggleFollowUser,
        getConnectionStatusWithUser,

        // Professional Messaging
        chatConversations,
        directChatMessages,
        activeConversationId,
        setActiveConversationId,
        sendMessage,
        startOrOpenConversation,
        markConversationRead,
        quickTemplates,

        // Profile Viewer
        viewingProfileUserId,
        setViewingProfileUserId,
        openUserProfile
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
