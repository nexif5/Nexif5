import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import { ArrowLeft, Sparkles, MapPin, DollarSign, Briefcase, Building, Laptop, Check } from 'lucide-react';

const POPULAR_ROLES = [
  'Business Analyst',
  'Data Analyst',
  'Software Engineer',
  'Frontend Developer',
  'Product Associate',
  'AI / ML Engineer',
  'Finance Associate',
  'Marketing Specialist'
];

const LOCATIONS = [
  'Nearby (Within 50 km)',
  'Coimbatore',
  'Bangalore',
  'Chennai',
  'Hyderabad',
  'Mumbai',
  'Remote',
  'Abroad'
];

const SALARY_RANGES = [
  '₹3–6 LPA',
  '₹5–8 LPA',
  '₹8–12 LPA',
  '₹12–18 LPA',
  '₹18+ LPA'
];

export const PreferencesScreen: React.FC = () => {
  const { setAuthState, createNewUser } = useApp();

  const [preferredRole, setPreferredRole] = useState('Business Analyst');
  const [preferredLocation, setPreferredLocation] = useState('Coimbatore');
  const [expectedSalary, setExpectedSalary] = useState('₹5–8 LPA');
  const [workType, setWorkType] = useState<'full_time' | 'internship' | 'part_time'>('full_time');
  const [experienceLevel, setExperienceLevel] = useState('Fresher (0-1 Years)');
  const [workMode, setWorkMode] = useState<'remote' | 'hybrid' | 'on_site'>('hybrid');

  const handleFinish = () => {
    // Gather all temporary state
    const name = sessionStorage.getItem('temp_profile_name') || sessionStorage.getItem('temp_signup_name') || 'Aarav Patel';
    const email = sessionStorage.getItem('temp_signup_email') || 'aarav.patel@skct.edu.in';
    const role = (sessionStorage.getItem('temp_selected_role') as UserRole) || 'student';
    const avatar = sessionStorage.getItem('temp_profile_avatar') || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80';
    const education = sessionStorage.getItem('temp_profile_education') || 'B.Tech';
    const course = sessionStorage.getItem('temp_profile_course') || 'Computer Science & Engineering';
    const college = sessionStorage.getItem('temp_profile_college') || 'Sri Krishna College of Technology';
    const gradYear = parseInt(sessionStorage.getItem('temp_profile_gradYear') || '2025', 10);
    const rawSkills = sessionStorage.getItem('temp_profile_skills');
    const skillsList: string[] = rawSkills ? JSON.parse(rawSkills) : ['Python', 'SQL', 'Power BI', 'Communication'];
    const careerGoal = sessionStorage.getItem('temp_career_goal') || 'Find a Job';

    const salaryNum = expectedSalary.includes('5–8') ? 7 : expectedSalary.includes('3–6') ? 5 : expectedSalary.includes('8–12') ? 10 : 15;

    // Create user in AppContext
    createNewUser(
      {
        name,
        email,
        avatarUrl: avatar,
        collegeName: college,
        currentDesignation: `${preferredRole} Aspirant`,
        careerGoal: preferredRole,
        education: {
          degree: education.includes('Undergraduate') ? 'B.Tech' : 'Master Degree',
          course,
          institution: college,
          yearOfPassing: gradYear,
          currentYear: 'Final Year (4th Year)',
          cgpaOrPercentage: '8.7 CGPA'
        },
        skills: skillsList.map((sk, idx) => ({
          id: `sk-${idx + 1}`,
          name: sk,
          category: idx === 0 ? 'technical' : idx === 1 ? 'technical' : idx === 2 ? 'analytics' : 'soft',
          level: 'intermediate',
          verified: true
        })),
        preferredJobRoles: [preferredRole],
        salaryPreferenceMinLPA: salaryNum - 2 > 0 ? salaryNum - 2 : 3,
        salaryPreferenceMaxLPA: salaryNum + 3,
        locationPreferenceType: 'specific_city',
        preferredCities: [preferredLocation, 'Bengaluru', 'Remote'],
        workPreference: workMode,
        jobTypePreference: workType
      },
      role
    );
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col justify-between px-5 py-6 font-sans">
      {/* Top Header & Progress */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setAuthState('career_goal')}
              className="p-2 -ml-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors active:scale-95"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white font-display">
                What opportunities are you looking for?
              </h1>
              <p className="text-xs text-slate-400">
                Step 3 of 3 — Career Preferences
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-indigo-400">100%</span>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1.5 bg-slate-800 rounded-full mb-4 overflow-hidden">
          <div className="h-full bg-emerald-500 rounded-full w-full transition-all duration-300" />
        </div>

        {/* Scrollable Form Content */}
        <div className="overflow-y-auto max-h-[66vh] space-y-4 pr-1">
          {/* Preferred Role */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Preferred Target Role
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              {POPULAR_ROLES.map((role) => (
                <button
                  key={role}
                  type="button"
                  onClick={() => setPreferredRole(role)}
                  className={`p-2.5 rounded-xl text-left text-xs font-medium border transition-all ${
                    preferredRole === role
                      ? 'bg-indigo-600/30 border-indigo-500 text-white font-bold'
                      : 'bg-slate-800/70 border-slate-700/80 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {role}
                </button>
              ))}
            </div>
          </div>

          {/* Location */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Preferred Location
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              {LOCATIONS.map((loc) => (
                <button
                  key={loc}
                  type="button"
                  onClick={() => setPreferredLocation(loc)}
                  className={`p-2.5 rounded-xl text-left text-xs font-medium border transition-all ${
                    preferredLocation === loc
                      ? 'bg-indigo-600/30 border-indigo-500 text-white font-bold'
                      : 'bg-slate-800/70 border-slate-700/80 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  📍 {loc}
                </button>
              ))}
            </div>
          </div>

          {/* Expected Salary */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Expected Salary Range
            </label>
            <div className="flex flex-wrap gap-1.5">
              {SALARY_RANGES.map((sal) => (
                <button
                  key={sal}
                  type="button"
                  onClick={() => setExpectedSalary(sal)}
                  className={`px-3 py-2 rounded-xl text-xs font-medium border transition-all ${
                    expectedSalary === sal
                      ? 'bg-indigo-600/30 border-indigo-500 text-white font-bold'
                      : 'bg-slate-800/70 border-slate-700/80 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {sal}
                </button>
              ))}
            </div>
          </div>

          {/* Work Type (Full-time / Internship / Part-time) */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Work Type
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setWorkType('full_time')}
                className={`p-2.5 rounded-xl text-center text-xs font-medium border transition-all ${
                  workType === 'full_time'
                    ? 'bg-indigo-600/30 border-indigo-500 text-white font-bold'
                    : 'bg-slate-800/70 border-slate-700/80 text-slate-300'
                }`}
              >
                Full-time
              </button>
              <button
                type="button"
                onClick={() => setWorkType('internship')}
                className={`p-2.5 rounded-xl text-center text-xs font-medium border transition-all ${
                  workType === 'internship'
                    ? 'bg-indigo-600/30 border-indigo-500 text-white font-bold'
                    : 'bg-slate-800/70 border-slate-700/80 text-slate-300'
                }`}
              >
                Internship
              </button>
              <button
                type="button"
                onClick={() => setWorkType('part_time')}
                className={`p-2.5 rounded-xl text-center text-xs font-medium border transition-all ${
                  workType === 'part_time'
                    ? 'bg-indigo-600/30 border-indigo-500 text-white font-bold'
                    : 'bg-slate-800/70 border-slate-700/80 text-slate-300'
                }`}
              >
                Part-time
              </button>
            </div>
          </div>

          {/* Experience Level */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Experience Level
            </label>
            <select
              value={experienceLevel}
              onChange={(e) => setExperienceLevel(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white focus:outline-hidden focus:border-indigo-500"
            >
              <option value="Fresher (0-1 Years)">Fresher / Entry-Level (0–1 Years)</option>
              <option value="1-3 Years">1–3 Years Experience</option>
              <option value="3-5 Years">3–5 Years Experience</option>
              <option value="5+ Years">5+ Years Senior Professional</option>
            </select>
          </div>

          {/* Work Mode: Remote / Hybrid / On-site */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Work Mode Preference
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setWorkMode('hybrid')}
                className={`p-2.5 rounded-xl text-center text-xs font-medium border transition-all ${
                  workMode === 'hybrid'
                    ? 'bg-indigo-600/30 border-indigo-500 text-white font-bold'
                    : 'bg-slate-800/70 border-slate-700/80 text-slate-300'
                }`}
              >
                Hybrid
              </button>
              <button
                type="button"
                onClick={() => setWorkMode('remote')}
                className={`p-2.5 rounded-xl text-center text-xs font-medium border transition-all ${
                  workMode === 'remote'
                    ? 'bg-indigo-600/30 border-indigo-500 text-white font-bold'
                    : 'bg-slate-800/70 border-slate-700/80 text-slate-300'
                }`}
              >
                Remote
              </button>
              <button
                type="button"
                onClick={() => setWorkMode('on_site')}
                className={`p-2.5 rounded-xl text-center text-xs font-medium border transition-all ${
                  workMode === 'on_site'
                    ? 'bg-indigo-600/30 border-indigo-500 text-white font-bold'
                    : 'bg-slate-800/70 border-slate-700/80 text-slate-300'
                }`}
              >
                On-site
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Bottom Finish Button */}
      <div className="pt-3">
        <button
          onClick={handleFinish}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-indigo-600 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white font-bold text-base shadow-xl shadow-indigo-600/25 flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
        >
          <Sparkles className="w-5 h-5 text-amber-300" />
          <span>Finish & Open Nexif5</span>
        </button>
      </div>
    </div>
  );
};
