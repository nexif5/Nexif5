import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { StudentProfile, UserRole } from '../../types';
import {
  Sparkles,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  User,
  GraduationCap,
  Target,
  Briefcase,
  Layers,
  MapPin,
  Clock,
  Award,
  Zap,
  BookOpen,
  Plus,
  Trash2,
  Search,
  Check
} from 'lucide-react';

interface CareerOnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialRole?: UserRole;
  userEmail?: string;
  initialName?: string;
}

const POPULAR_GOALS = [
  'Find a Job',
  'Find an Internship',
  'Get My First Job',
  'Switch Career',
  'Build Skills',
  'Prepare for Placement',
  'Explore Career Options'
];

const POPULAR_ROLES = [
  'Business Analyst',
  'Data Analyst',
  'Software Engineer',
  'Frontend Developer',
  'Full Stack Developer',
  'Marketing Specialist',
  'Finance Associate',
  'HR Specialist',
  'Product Manager',
  'AI / ML Engineer',
  'DevOps Engineer',
  'Quality Assurance Engineer'
];

const POPULAR_SKILLS = [
  'Python',
  'SQL',
  'Excel / Sheets',
  'Power BI',
  'Tableau',
  'JavaScript',
  'React',
  'Java',
  'Financial Analysis',
  'Market Research',
  'Communication',
  'Problem Solving',
  'Git / GitHub',
  'Data Visualization'
];

const LOCATION_OPTIONS = [
  'Nearby (Within 50 km)',
  'Bangalore',
  'Coimbatore',
  'Chennai',
  'Hyderabad',
  'Mumbai',
  'Delhi NCR',
  'Anywhere in India',
  'Remote',
  'Abroad'
];

const WORK_PREFERENCES = [
  { id: 'full_time', label: 'Full-time', type: 'type' },
  { id: 'part_time', label: 'Part-time', type: 'type' },
  { id: 'internship', label: 'Internship', type: 'type' },
  { id: 'remote', label: 'Remote', type: 'mode' },
  { id: 'hybrid', label: 'Hybrid', type: 'mode' },
  { id: 'on_site', label: 'On-site', type: 'mode' }
];

export const CareerOnboardingModal: React.FC<CareerOnboardingModalProps> = ({
  isOpen,
  onClose,
  initialRole = 'student',
  userEmail = 'user@nexif5.com',
  initialName = ''
}) => {
  const { createNewUser, updateStudentProfile, setActiveStudentTab, setActiveJobSeekerTab } = useApp();

  const [step, setStep] = useState(1);

  // Step 1: Profile
  const [firstName, setFirstName] = useState(initialName.split(' ')[0] || '');
  const [lastName, setLastName] = useState(initialName.split(' ').slice(1).join(' ') || '');
  const [avatarUrl, setAvatarUrl] = useState('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80');
  const [currentStatus, setCurrentStatus] = useState<'Final Year Student' | 'Pre-final Year' | 'Fresh Graduate' | 'Experienced Working Professional'>('Final Year Student');
  const [degree, setDegree] = useState('B.Tech');
  const [course, setCourse] = useState('Computer Science & Engineering');
  const [collegeName, setCollegeName] = useState('Sri Krishna College of Technology');
  const [gradYear, setGradYear] = useState(2025);

  // Step 2: Career Goal
  const [selectedGoals, setSelectedGoals] = useState<string[]>(['Find a Job', 'Build Skills']);

  // Step 3: Target Role
  const [targetRoleSearch, setTargetRoleSearch] = useState('');
  const [selectedRoles, setSelectedRoles] = useState<string[]>(['Business Analyst', 'Data Analyst']);

  // Step 4: Skills & Achievements
  const [skillsList, setSkillsList] = useState<string[]>(['Excel / Sheets', 'Power BI', 'SQL', 'Problem Solving']);
  const [newSkillInput, setNewSkillInput] = useState('');
  const [achievementsList, setAchievementsList] = useState<string[]>([
    'Completed Advanced Business Intelligence Capstone',
    'Certified SQL & Data Querying Professional'
  ]);
  const [newAchievementInput, setNewAchievementInput] = useState('');

  // Step 5: Location
  const [selectedLocations, setSelectedLocations] = useState<string[]>(['Bangalore', 'Coimbatore', 'Remote']);

  // Step 6: Work Preference
  const [workTypes, setWorkTypes] = useState<string[]>(['full_time', 'internship']);
  const [workModes, setWorkModes] = useState<string[]>(['hybrid', 'remote']);

  if (!isOpen) return null;

  const toggleGoal = (goal: string) => {
    if (selectedGoals.includes(goal)) {
      if (selectedGoals.length > 1) {
        setSelectedGoals(selectedGoals.filter(g => g !== goal));
      }
    } else {
      setSelectedGoals([...selectedGoals, goal]);
    }
  };

  const toggleRole = (role: string) => {
    if (selectedRoles.includes(role)) {
      if (selectedRoles.length > 1) {
        setSelectedRoles(selectedRoles.filter(r => r !== role));
      }
    } else {
      setSelectedRoles([...selectedRoles, role]);
    }
  };

  const toggleLocation = (loc: string) => {
    if (selectedLocations.includes(loc)) {
      if (selectedLocations.length > 1) {
        setSelectedLocations(selectedLocations.filter(l => l !== loc));
      }
    } else {
      setSelectedLocations([...selectedLocations, loc]);
    }
  };

  const toggleWorkPref = (id: string, type: 'type' | 'mode') => {
    if (type === 'type') {
      if (workTypes.includes(id)) {
        if (workTypes.length > 1) setWorkTypes(workTypes.filter(t => t !== id));
      } else {
        setWorkTypes([...workTypes, id]);
      }
    } else {
      if (workModes.includes(id)) {
        if (workModes.length > 1) setWorkModes(workModes.filter(m => m !== id));
      } else {
        setWorkModes([...workModes, id]);
      }
    }
  };

  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (newSkillInput.trim() && !skillsList.includes(newSkillInput.trim())) {
      setSkillsList([...skillsList, newSkillInput.trim()]);
      setNewSkillInput('');
    }
  };

  const handleAddAchievement = (e: React.FormEvent) => {
    e.preventDefault();
    if (newAchievementInput.trim()) {
      setAchievementsList([...achievementsList, newAchievementInput.trim()]);
      setNewAchievementInput('');
    }
  };

  const handleFinishOnboarding = () => {
    const fullName = `${firstName.trim()} ${lastName.trim()}`.trim() || 'Aadhi Kesavan';
    
    // Construct real profile object
    const createdProfile: Partial<StudentProfile> = {
      name: fullName,
      email: userEmail,
      avatarUrl,
      currentDesignation: `${selectedRoles[0] || 'Business Analyst'} Aspirant | ${course}`,
      careerGoal: selectedGoals[0] || 'Find a Job',
      careerReadinessScore: 78,
      collegeName: collegeName.trim() || undefined,
      education: {
        degree,
        course,
        institution: collegeName.trim() || 'Autonomous Engineering College',
        yearOfPassing: gradYear,
        currentYear: 'Final Year',
        cgpaOrPercentage: '8.4 CGPA'
      },
      skills: skillsList.map((sk, idx) => ({
        id: `sk-${idx}-${Date.now()}`,
        name: sk,
        level: idx < 2 ? 'proficient' : 'intermediate',
        verified: true,
        source: 'ai_assessment'
      })),
      achievements: achievementsList.map((ach, idx) => ({
        id: `ach-${idx}-${Date.now()}`,
        title: ach,
        issuer: 'Verified Credential',
        date: 'Recent',
        type: 'certification'
      })),
      preferredJobRoles: selectedRoles,
      preferredCities: selectedLocations,
      jobTypePreference: workTypes.includes('full_time') ? 'full_time' : 'internship',
      workPreference: workModes.includes('hybrid') ? 'hybrid' : (workModes[0] as any) || 'remote',
      salaryPreferenceMinLPA: 5,
      salaryPreferenceMaxLPA: 9,
      locationPreferenceType: 'anywhere_in_india'
    };

    createNewUser(createdProfile, initialRole === 'job_seeker' ? 'job_seeker' : 'student');
    if (initialRole === 'job_seeker') {
      setActiveJobSeekerTab('home');
    } else {
      setActiveStudentTab('home');
    }
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden z-10 my-6 flex flex-col max-h-[90vh]"
        >
          {/* Top Progress Bar */}
          <div className="p-5 sm:p-6 pb-4 border-b border-slate-100 bg-slate-50/50">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-xs">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-sm sm:text-base font-display">
                    Nexif5 Career Onboarding
                  </h3>
                  <p className="text-[11px] text-slate-500 font-medium">
                    Step {step} of 7 — {step === 1 && "Profile"}
                    {step === 2 && "Career Goal"}
                    {step === 3 && "Target Role"}
                    {step === 4 && "Skills & Achievements"}
                    {step === 5 && "Location Preference"}
                    {step === 6 && "Work Preference"}
                    {step === 7 && "Career Readiness"}
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full border border-indigo-100">
                  {Math.round((step / 7) * 100)}% Complete
                </span>
              </div>
            </div>

            {/* Stepper Dots */}
            <div className="grid grid-cols-7 gap-1.5 pt-1">
              {[1, 2, 3, 4, 5, 6, 7].map((s) => (
                <div
                  key={s}
                  className={`h-1.5 rounded-full transition-all ${
                    s <= step ? 'bg-indigo-600' : 'bg-slate-200'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Step Body */}
          <div className="p-6 sm:p-8 overflow-y-auto flex-1 space-y-6">
            {/* STEP 1: PROFILE */}
            {step === 1 && (
              <div className="space-y-5">
                <div className="space-y-1">
                  <h2 className="text-xl font-extrabold text-slate-900 font-display">
                    Let's build your profile
                  </h2>
                  <p className="text-xs text-slate-500">
                    Provide your fundamental details so Nexif5 AI can match you with the right opportunities.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">First Name</label>
                    <input
                      type="text"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      placeholder="e.g. Aadhi"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Last Name</label>
                    <input
                      type="text"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      placeholder="e.g. Kesavan"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1.5">Current Status</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {[
                      'Final Year Student',
                      'Pre-final Year',
                      'Fresh Graduate',
                      'Experienced Working Professional'
                    ].map((status) => (
                      <button
                        key={status}
                        type="button"
                        onClick={() => setCurrentStatus(status as any)}
                        className={`p-3 rounded-xl border text-left text-xs font-medium transition-all flex items-center justify-between ${
                          currentStatus === status
                            ? 'border-indigo-600 bg-indigo-50/70 text-indigo-900 font-bold'
                            : 'border-slate-200 hover:border-slate-300 text-slate-700'
                        }`}
                      >
                        <span>{status}</span>
                        {currentStatus === status && <Check className="w-4 h-4 text-indigo-600" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Degree / Qualification</label>
                    <input
                      type="text"
                      value={degree}
                      onChange={(e) => setDegree(e.target.value)}
                      placeholder="e.g. B.Tech / B.E / B.Sc / MBA"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Course / Major</label>
                    <input
                      type="text"
                      value={course}
                      onChange={(e) => setCourse(e.target.value)}
                      placeholder="e.g. Computer Science / Business"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-hidden"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="sm:col-span-2">
                    <label className="text-xs font-bold text-slate-700 block mb-1">College / University</label>
                    <input
                      type="text"
                      value={collegeName}
                      onChange={(e) => setCollegeName(e.target.value)}
                      placeholder="e.g. Sri Krishna College of Technology"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Graduation Year</label>
                    <input
                      type="number"
                      value={gradYear}
                      onChange={(e) => setGradYear(parseInt(e.target.value) || 2025)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-hidden"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* STEP 2: CAREER GOAL */}
            {step === 2 && (
              <div className="space-y-5">
                <div className="space-y-1">
                  <h2 className="text-xl font-extrabold text-slate-900 font-display">
                    What are you trying to achieve?
                  </h2>
                  <p className="text-xs text-slate-500">
                    Select your primary career intentions (multiple selections allowed).
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {POPULAR_GOALS.map((goal) => {
                    const isSelected = selectedGoals.includes(goal);
                    return (
                      <button
                        key={goal}
                        type="button"
                        onClick={() => toggleGoal(goal)}
                        className={`p-4 rounded-2xl border text-left transition-all flex items-center justify-between group ${
                          isSelected
                            ? 'border-indigo-600 bg-indigo-50/80 text-indigo-950 font-bold shadow-xs'
                            : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                              isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            <Target className="w-4 h-4" />
                          </div>
                          <span className="text-xs font-bold">{goal}</span>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-indigo-600" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 3: TARGET ROLE */}
            {step === 3 && (
              <div className="space-y-5">
                <div className="space-y-1">
                  <h2 className="text-xl font-extrabold text-slate-900 font-display">
                    What roles are you interested in?
                  </h2>
                  <p className="text-xs text-slate-500">
                    Search and pick the professional roles you want to pursue.
                  </p>
                </div>

                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={targetRoleSearch}
                    onChange={(e) => setTargetRoleSearch(e.target.value)}
                    placeholder="Search roles (e.g. Business Analyst, Data Analyst, Software...)"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-hidden"
                  />
                </div>

                <div className="flex flex-wrap gap-2">
                  {POPULAR_ROLES.filter(r => r.toLowerCase().includes(targetRoleSearch.toLowerCase())).map((role) => {
                    const isSelected = selectedRoles.includes(role);
                    return (
                      <button
                        key={role}
                        type="button"
                        onClick={() => toggleRole(role)}
                        className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all flex items-center gap-2 ${
                          isSelected
                            ? 'bg-indigo-600 border-indigo-600 text-white shadow-xs'
                            : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                        }`}
                      >
                        <span>{role}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 4: SKILLS & ACHIEVEMENTS */}
            {step === 4 && (
              <div className="space-y-6">
                <div className="space-y-1">
                  <h2 className="text-xl font-extrabold text-slate-900 font-display">
                    What skills do you have?
                  </h2>
                  <p className="text-xs text-slate-500">
                    Add your technical skills, tools, and verifiable achievements.
                  </p>
                </div>

                {/* Skills Section */}
                <div className="space-y-3">
                  <label className="text-xs font-bold text-slate-800 block uppercase tracking-wider">
                    Skills & Tools ({skillsList.length})
                  </label>

                  <div className="flex flex-wrap gap-2">
                    {skillsList.map((skill) => (
                      <span
                        key={skill}
                        className="px-3 py-1.5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs font-semibold flex items-center gap-2"
                      >
                        <span>{skill}</span>
                        <button
                          type="button"
                          onClick={() => setSkillsList(skillsList.filter(s => s !== skill))}
                          className="text-indigo-400 hover:text-indigo-700"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>

                  <form onSubmit={handleAddSkill} className="flex gap-2">
                    <input
                      type="text"
                      value={newSkillInput}
                      onChange={(e) => setNewSkillInput(e.target.value)}
                      placeholder="Add custom skill (e.g. Docker, TypeScript...)"
                      className="flex-1 px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:border-indigo-500 outline-hidden"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition-all flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add</span>
                    </button>
                  </form>

                  <div className="pt-1">
                    <p className="text-[11px] text-slate-400 mb-1.5 font-medium">Quick suggestions:</p>
                    <div className="flex flex-wrap gap-1.5">
                      {POPULAR_SKILLS.filter(s => !skillsList.includes(s)).slice(0, 8).map((sk) => (
                        <button
                          key={sk}
                          type="button"
                          onClick={() => setSkillsList([...skillsList, sk])}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium transition-colors"
                        >
                          + {sk}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Achievements Section */}
                <div className="space-y-3 pt-2 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-800 block uppercase tracking-wider flex items-center gap-1.5">
                      <Award className="w-4 h-4 text-amber-500" />
                      <span>Achievements & Certifications</span>
                    </label>
                    <span className="text-[11px] text-slate-400 font-medium">
                      (No 'Skill Passport' — standard verified achievements)
                    </span>
                  </div>

                  <div className="space-y-2">
                    {achievementsList.map((ach, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl bg-amber-50/50 border border-amber-200/80 text-xs flex items-center justify-between text-amber-950 font-medium"
                      >
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0" />
                          <span>{ach}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setAchievementsList(achievementsList.filter((_, i) => i !== idx))}
                          className="text-slate-400 hover:text-red-600"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>

                  <form onSubmit={handleAddAchievement} className="flex gap-2">
                    <input
                      type="text"
                      value={newAchievementInput}
                      onChange={(e) => setNewAchievementInput(e.target.value)}
                      placeholder="Add an achievement (e.g. 1st Place College Hackathon, AWS Certified...)"
                      className="flex-1 px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:border-indigo-500 outline-hidden"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 transition-all flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add</span>
                    </button>
                  </form>
                </div>
              </div>
            )}

            {/* STEP 5: LOCATION */}
            {step === 5 && (
              <div className="space-y-5">
                <div className="space-y-1">
                  <h2 className="text-xl font-extrabold text-slate-900 font-display">
                    Where do you want to work?
                  </h2>
                  <p className="text-xs text-slate-500">
                    Select your location preferences (multiple selections allowed).
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {LOCATION_OPTIONS.map((loc) => {
                    const isSelected = selectedLocations.includes(loc);
                    return (
                      <button
                        key={loc}
                        type="button"
                        onClick={() => toggleLocation(loc)}
                        className={`p-3.5 rounded-2xl border text-left transition-all flex items-center justify-between ${
                          isSelected
                            ? 'border-indigo-600 bg-indigo-50/80 text-indigo-950 font-bold shadow-xs'
                            : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <MapPin className={`w-4 h-4 ${isSelected ? 'text-indigo-600' : 'text-slate-400'}`} />
                          <span className="text-xs font-semibold">{loc}</span>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-indigo-600" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 6: WORK PREFERENCE */}
            {step === 6 && (
              <div className="space-y-6">
                <div className="space-y-1">
                  <h2 className="text-xl font-extrabold text-slate-900 font-display">
                    Work Preferences
                  </h2>
                  <p className="text-xs text-slate-500">
                    Specify employment type and working style preferences.
                  </p>
                </div>

                {/* Employment Type */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-800 block uppercase tracking-wider">
                    Employment Type
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {WORK_PREFERENCES.filter(p => p.type === 'type').map((p) => {
                      const isSelected = workTypes.includes(p.id);
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => toggleWorkPref(p.id, 'type')}
                          className={`p-3 rounded-xl border text-center text-xs font-bold transition-all ${
                            isSelected
                              ? 'border-indigo-600 bg-indigo-600 text-white shadow-xs'
                              : 'border-slate-200 text-slate-700 bg-white hover:border-slate-300'
                          }`}
                        >
                          {p.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Work Mode */}
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <label className="text-xs font-bold text-slate-800 block uppercase tracking-wider">
                    Work Arrangement
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {WORK_PREFERENCES.filter(p => p.type === 'mode').map((p) => {
                      const isSelected = workModes.includes(p.id);
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => toggleWorkPref(p.id, 'mode')}
                          className={`p-3 rounded-xl border text-center text-xs font-bold transition-all ${
                            isSelected
                              ? 'border-indigo-600 bg-indigo-600 text-white shadow-xs'
                              : 'border-slate-200 text-slate-700 bg-white hover:border-slate-300'
                          }`}
                        >
                          {p.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* STEP 7: CAREER READINESS */}
            {step === 7 && (
              <div className="space-y-6">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>AI Career Engine Initialized</span>
                  </div>
                  <h2 className="text-xl font-extrabold text-slate-900 font-display">
                    Your Nexif5 Career Starting Point
                  </h2>
                  <p className="text-xs text-slate-500">
                    Here is your calculated readiness profile and recommended immediate actions.
                  </p>
                </div>

                {/* Readiness Score Card */}
                <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950 text-white space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                        Calculated Career Readiness
                      </span>
                      <h3 className="text-2xl font-black font-display text-white">78 / 100</h3>
                    </div>
                    <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold">
                      Strong Foundation
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/10 text-center">
                    <div className="p-2 rounded-xl bg-white/5">
                      <span className="text-[10px] text-slate-400 block">Profile Completion</span>
                      <span className="text-sm font-bold text-white">85%</span>
                    </div>
                    <div className="p-2 rounded-xl bg-white/5">
                      <span className="text-[10px] text-slate-400 block">Skills Matched</span>
                      <span className="text-sm font-bold text-white">{skillsList.length}</span>
                    </div>
                    <div className="p-2 rounded-xl bg-white/5">
                      <span className="text-[10px] text-slate-400 block">Target Roles</span>
                      <span className="text-sm font-bold text-white">{selectedRoles.length}</span>
                    </div>
                  </div>
                </div>

                {/* Actionable Next Steps */}
                <div className="space-y-2.5">
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                    Recommended Next Actions
                  </span>

                  <div className="space-y-2">
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                        <span className="text-slate-800 font-medium">Complete your smart resume layout</span>
                      </div>
                      <span className="text-[11px] font-bold text-indigo-600">+10% Readiness</span>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                        <span className="text-slate-800 font-medium">Add 2 portfolio projects in {selectedRoles[0]}</span>
                      </div>
                      <span className="text-[11px] font-bold text-indigo-600">+8% Readiness</span>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                        <span className="text-slate-800 font-medium">Apply to your first 5 matching opportunities</span>
                      </div>
                      <span className="text-[11px] font-bold text-indigo-600">Immediate Match</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer Controls */}
          <div className="p-4 sm:p-6 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep(step - 1)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 transition-colors flex items-center gap-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
            ) : (
              <div />
            )}

            {step < 7 ? (
              <button
                type="button"
                onClick={() => setStep(step + 1)}
                className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-600/20 transition-all flex items-center gap-2"
              >
                <span>Continue</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleFinishOnboarding}
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition-all flex items-center gap-2"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Go to Nexif5 Home</span>
              </button>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
