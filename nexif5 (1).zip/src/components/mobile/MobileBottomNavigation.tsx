import React from 'react';
import { useApp, MobileTab } from '../../context/AppContext';
import {
  Home,
  BookOpen,
  TrendingUp,
  Briefcase,
  User,
  Sparkles,
  Users,
  Layers,
  Building2,
  School,
  Award,
  CalendarCheck,
  ShieldCheck,
  Activity,
  Server
} from 'lucide-react';

export const MobileBottomNavigation: React.FC = () => {
  const {
    mobileTab,
    setMobileTab,
    setSubView,
    currentRole,
    theme
  } = useApp();

  const isLight = theme === 'light';

  // Role-specific bottom navigation tabs
  const getNavItems = () => {
    if (currentRole === 'recruiter') {
      return [
        { id: 'home' as MobileTab, label: 'Overview', icon: <Building2 className="w-5 h-5" /> },
        { id: 'jobs' as MobileTab, label: 'Requisitions', icon: <Briefcase className="w-5 h-5" /> },
        { id: 'career' as MobileTab, label: 'AI Matches', icon: <Sparkles className="w-5 h-5" />, isAiHighlight: true },
        { id: 'applications' as MobileTab, label: 'Pipeline', icon: <Layers className="w-5 h-5" /> },
        { id: 'profile' as MobileTab, label: 'Company', icon: <Users className="w-5 h-5" /> }
      ];
    }

    if (currentRole === 'college') {
      return [
        { id: 'home' as MobileTab, label: 'Placement Hub', icon: <School className="w-5 h-5" /> },
        { id: 'career' as MobileTab, label: 'Skill Gaps', icon: <Sparkles className="w-5 h-5" />, isAiHighlight: true },
        { id: 'jobs' as MobileTab, label: 'Drives', icon: <Briefcase className="w-5 h-5" /> },
        { id: 'applications' as MobileTab, label: 'Students', icon: <Users className="w-5 h-5" /> },
        { id: 'profile' as MobileTab, label: 'College', icon: <Award className="w-5 h-5" /> }
      ];
    }

    if (currentRole === 'mentor') {
      return [
        { id: 'home' as MobileTab, label: 'Workspace', icon: <Award className="w-5 h-5" /> },
        { id: 'career' as MobileTab, label: 'Sessions', icon: <CalendarCheck className="w-5 h-5" /> },
        { id: 'learn' as MobileTab, label: 'Mentees', icon: <Users className="w-5 h-5" />, isAiHighlight: true },
        { id: 'jobs' as MobileTab, label: 'Guidance', icon: <Sparkles className="w-5 h-5" /> },
        { id: 'profile' as MobileTab, label: 'Mentor', icon: <User className="w-5 h-5" /> }
      ];
    }

    if (currentRole === 'admin') {
      return [
        { id: 'home' as MobileTab, label: 'Control', icon: <ShieldCheck className="w-5 h-5" /> },
        { id: 'learn' as MobileTab, label: 'Users', icon: <Users className="w-5 h-5" /> },
        { id: 'career' as MobileTab, label: 'Platform', icon: <Server className="w-5 h-5" /> },
        { id: 'jobs' as MobileTab, label: 'Jobs', icon: <Briefcase className="w-5 h-5" /> },
        { id: 'profile' as MobileTab, label: 'Security', icon: <Activity className="w-5 h-5" /> }
      ];
    }

    if (currentRole === 'professional' || currentRole === 'job_seeker') {
      return [
        { id: 'home' as MobileTab, label: 'Overview', icon: <Home className="w-5 h-5" /> },
        { id: 'learn' as MobileTab, label: 'Upskill', icon: <BookOpen className="w-5 h-5" />, isAiHighlight: true },
        { id: 'career' as MobileTab, label: 'Growth', icon: <TrendingUp className="w-5 h-5" /> },
        { id: 'jobs' as MobileTab, label: 'Jobs', icon: <Briefcase className="w-5 h-5" /> },
        { id: 'profile' as MobileTab, label: 'Profile', icon: <User className="w-5 h-5" /> }
      ];
    }

    // Default Student
    return [
      { id: 'home' as MobileTab, label: 'Home', icon: <Home className="w-5 h-5" /> },
      { id: 'learn' as MobileTab, label: 'Learn', icon: <BookOpen className="w-5 h-5" />, isAiHighlight: true },
      { id: 'career' as MobileTab, label: 'Career', icon: <TrendingUp className="w-5 h-5" /> },
      { id: 'jobs' as MobileTab, label: 'Opportunities', icon: <Briefcase className="w-5 h-5" /> },
      { id: 'profile' as MobileTab, label: 'Profile', icon: <User className="w-5 h-5" /> }
    ];
  };

  const navItems = getNavItems();

  return (
    <nav
      aria-label="Mobile Navigation"
      className={`fixed bottom-0 left-0 right-0 z-40 backdrop-blur-md px-1.5 py-1 flex items-center justify-around shadow-2xl select-none transition-colors duration-200 border-t ${
        isLight
          ? 'bg-white/95 border-slate-200 text-slate-600'
          : 'bg-slate-900/95 border-slate-800 text-slate-400'
      }`}
      style={{ paddingBottom: 'max(0.375rem, env(safe-area-inset-bottom))' }}
    >
      {navItems.map((item) => {
        const isActive = mobileTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => {
              setSubView(null);
              setMobileTab(item.id);
            }}
            className={`flex-1 flex flex-col items-center justify-center py-1.5 min-h-[48px] rounded-xl transition-all relative ${
              isActive
                ? isLight
                  ? 'text-indigo-600 font-bold scale-105'
                  : 'text-indigo-400 font-bold scale-105'
                : isLight
                ? 'text-slate-500 hover:text-slate-900'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="relative">
              {item.icon}
              {item.isAiHighlight && (
                <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
              )}
            </div>
            <span className="text-[10px] mt-1 tracking-tight">
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
