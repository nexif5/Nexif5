import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  School,
  Users,
  Award,
  TrendingUp,
  Building2,
  Sparkles,
  BarChart3,
  Download,
  CheckCircle2,
  FileSpreadsheet,
  ChevronRight
} from 'lucide-react';

export const MobileCollegeDashboard: React.FC = () => {
  const { currentCollege, students, theme } = useApp();
  const isLight = theme === 'light';

  const [selectedDept, setSelectedDept] = useState('All Departments');

  const departments = [
    { name: 'Commerce & Analytics', total: 420, placed: 350, readiness: 86 },
    { name: 'Computer Science & Eng', total: 480, placed: 440, readiness: 92 },
    { name: 'Management (BBA)', total: 260, placed: 205, readiness: 79 },
    { name: 'Information Tech', total: 260, placed: 230, readiness: 88 }
  ];

  const topSkillGaps = [
    { skill: 'Power BI DAX', department: 'Commerce & Analytics', affectedStudents: 142, urgency: 'High' },
    { skill: 'Financial Modeling', department: 'Finance & Commerce', affectedStudents: 98, urgency: 'High' },
    { skill: 'System Design & Docker', department: 'Computer Science', affectedStudents: 110, urgency: 'Medium' }
  ];

  return (
    <div className={`p-4 space-y-4 pb-24 font-sans ${isLight ? 'text-slate-900' : 'text-white'}`}>
      {/* College Institutional Header */}
      <div className={`p-4 rounded-2xl border ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <img
              src={currentCollege.logoUrl}
              alt={currentCollege.name}
              className="w-14 h-14 rounded-2xl object-cover border border-purple-500/40 shadow-md"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold font-display">{currentCollege.name}</h1>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-600 dark:text-purple-300 font-bold">
                  NAAC A++
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {currentCollege.type} • {currentCollege.location}
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Director of Placements: <strong>Dr. K. Ramanathan</strong>
              </p>
            </div>
          </div>
        </div>

        {/* Quick Report Download */}
        <div className="mt-3.5 pt-3 border-t border-slate-700/50 flex items-center justify-between">
          <span className="text-xs text-slate-400">Placement Cohort 2025</span>
          <button
            onClick={() => alert('Exporting NAAC/NIRF Placement Readiness Report as PDF...')}
            className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Analytics</span>
          </button>
        </div>
      </div>

      {/* 4 Key Institutional Placement Metrics */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Users className="w-4 h-4 text-purple-500" />
            <span className="text-[10px] text-purple-400 font-bold">2025 Batch</span>
          </div>
          <p className="text-xl font-black font-display">1,420</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Registered Students</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <TrendingUp className="w-4 h-4 text-emerald-500" />
            <span className="text-[10px] text-emerald-500 font-bold">Target 90%</span>
          </div>
          <p className="text-xl font-black font-display">86%</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Placement Rate</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Award className="w-4 h-4 text-amber-500" />
            <span className="text-[10px] text-amber-500 font-bold">Avg</span>
          </div>
          <p className="text-xl font-black font-display">82/100</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Readiness Score</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Building2 className="w-4 h-4 text-blue-500" />
            <span className="text-[10px] text-blue-400 font-bold">Active</span>
          </div>
          <p className="text-xl font-black font-display">18</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Recruiter Drives</p>
        </div>
      </div>

      {/* AI Batch Skill Gap Analysis */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-500" />
            <h2 className="text-sm font-bold">AI Batch Skill Gap Diagnostics</h2>
          </div>
          <span className="text-[10px] text-purple-400 font-bold">Curriculum Intervention</span>
        </div>

        <div className="space-y-2">
          {topSkillGaps.map((gap, idx) => (
            <div
              key={idx}
              className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              <div>
                <h3 className="font-bold text-white dark:text-white">{gap.skill}</h3>
                <p className="text-[10px] text-slate-400">
                  {gap.department} • <strong>{gap.affectedStudents} students need training</strong>
                </p>
              </div>

              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                gap.urgency === 'High' ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'
              }`}>
                {gap.urgency} Priority
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Department-wise Breakdown */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-purple-500" />
            <h2 className="text-sm font-bold">Department Placement Breakdown</h2>
          </div>
        </div>

        <div className="space-y-2.5">
          {departments.map((dept, idx) => (
            <div
              key={idx}
              className={`p-3 rounded-xl border space-y-1.5 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold">{dept.name}</span>
                <span className="text-purple-400 font-bold">{dept.placed}/{dept.total} Placed</span>
              </div>

              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-purple-500 rounded-full"
                  style={{ width: `${(dept.placed / dept.total) * 100}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-0.5">
                <span>Placement: {Math.round((dept.placed / dept.total) * 100)}%</span>
                <span>Avg Readiness: {dept.readiness}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Active Campus Drives with Top Recruiters */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-500" />
            <h2 className="text-sm font-bold">Active Campus Drives</h2>
          </div>
          <span className="text-[10px] text-emerald-400 font-bold">Verified Partners</span>
        </div>

        <div className="space-y-2 text-xs">
          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700 flex items-center justify-between">
            <div>
              <p className="font-bold">ABC Technologies</p>
              <p className="text-[10px] text-slate-400">12 Vacancies • Software Engineer & Analyst</p>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
              Round 1 Active
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700 flex items-center justify-between">
            <div>
              <p className="font-bold">FinEdge Analytics</p>
              <p className="text-[10px] text-slate-400">8 Vacancies • Financial Analyst</p>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-bold">
              Shortlisting
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
