import {
  StudentProfile,
  JobOpportunity,
  AIMatchResult,
  AICareerAnalysis,
  JobApplication
} from '../types';

/**
 * Calculates a transparent, deterministic match between a student and a job opportunity
 */
export function calculateJobMatch(student: StudentProfile, job: JobOpportunity): AIMatchResult {
  // 1. Skills match (weight 40%)
  const studentSkillNames = student.skills.map(s => s.name.toLowerCase());
  const requiredSkills = job.requiredSkills.map(s => s.toLowerCase());
  const preferredSkills = (job.preferredSkills || []).map(s => s.toLowerCase());

  let matchedRequired = 0;
  const matchedSkillsList: string[] = [];
  const missingSkillsList: string[] = [];

  job.requiredSkills.forEach(req => {
    const isMatched = studentSkillNames.some(s => 
      s.includes(req.toLowerCase()) || req.toLowerCase().includes(s)
    );
    if (isMatched) {
      matchedRequired++;
      matchedSkillsList.push(req);
    } else {
      missingSkillsList.push(req);
    }
  });

  const skillsMatch = requiredSkills.length > 0 
    ? Math.min(100, Math.round((matchedRequired / requiredSkills.length) * 100))
    : 80;

  // 2. Qualification match (weight 25%)
  const studentDeg = (student.education.degree + ' ' + student.education.course).toLowerCase();
  let qualMatch = 60;
  if (job.qualificationRequired && job.qualificationRequired.length > 0) {
    const qualFound = job.qualificationRequired.some(q => 
      studentDeg.includes(q.toLowerCase()) || (student.education.degree.toLowerCase().includes(q.toLowerCase()))
    );
    qualMatch = qualFound ? 98 : 70;
  }

  // 3. Career Goal match (weight 20%)
  const goal = (student.careerGoal || '').toLowerCase();
  const title = job.title.toLowerCase();
  const isGoalAligned = title.includes(goal) || goal.includes(title) || 
    (student.preferredJobRoles || []).some(r => title.includes(r.toLowerCase()));
  const careerGoalMatch = isGoalAligned ? 95 : 65;

  // 4. Preference match (weight 15%)
  let prefMatch = 70;
  if (job.workMode === student.workPreference || student.workPreference === 'hybrid') {
    prefMatch += 15;
  }
  if (student.locationPreferenceType === 'remote' && job.workMode === 'remote') {
    prefMatch += 15;
  } else if (student.preferredCities.some(c => job.location.toLowerCase().includes(c.toLowerCase()))) {
    prefMatch += 15;
  }
  const preferenceMatch = Math.min(100, prefMatch);

  // Overall Score (Weighted combination)
  const overallScore = Math.round(
    skillsMatch * 0.40 +
    qualMatch * 0.25 +
    careerGoalMatch * 0.20 +
    preferenceMatch * 0.15
  );

  // Generate transparent explanations
  const whyItMatches: string[] = [];
  if (matchedSkillsList.length > 0) {
    whyItMatches.push(`Matched core competencies: ${matchedSkillsList.join(', ')}.`);
  }
  if (qualMatch >= 90) {
    whyItMatches.push(`Your academic degree (${student.education.degree}) meets the recruiter's eligible qualifications.`);
  }
  if (careerGoalMatch >= 85) {
    whyItMatches.push(`Directly fulfills your stated career ambition of becoming a ${student.careerGoal}.`);
  }
  if (job.salaryMinLPA >= student.salaryPreferenceMinLPA) {
    whyItMatches.push(`Compensation of ${job.salaryDisplay} aligns with your expected ₹${student.salaryPreferenceMinLPA}-${student.salaryPreferenceMaxLPA} LPA target.`);
  }
  if (student.achievements && student.achievements.length > 0) {
    whyItMatches.push(`Verified achievements like '${student.achievements[0].title}' strengthen profile ranking.`);
  }

  // Next best action
  let nextBestAction = 'Review required project portfolio and submit your verified resume.';
  if (missingSkillsList.length > 0) {
    nextBestAction = `Build one mini-project demonstrating ${missingSkillsList[0]} to close the gap from ${overallScore}% to 98%.`;
  }

  return {
    jobId: job.id,
    studentId: student.id,
    overallScore,
    skillsMatch,
    qualificationMatch: qualMatch,
    careerGoalMatch,
    preferenceMatch,
    matchedSkills: matchedSkillsList,
    missingSkills: missingSkillsList,
    whyItMatches,
    nextBestAction
  };
}

/**
 * Runs deep AI Career Analysis on a Student Profile
 */
export function analyzeCareerReadiness(student: StudentProfile): AICareerAnalysis {
  const goal = student.careerGoal || 'Business Analyst';
  
  // Standard benchmark skill profiles based on career goal
  const benchmarkSkillsMap: Record<string, { skill: string; level: string; priority: string }[]> = {
    'Business Analyst': [
      { skill: 'Excel (Advanced)', level: 'advanced', priority: 'Must have' },
      { skill: 'SQL', level: 'intermediate', priority: 'Must have' },
      { skill: 'Power BI', level: 'intermediate', priority: 'Must have' },
      { skill: 'Business Analysis', level: 'advanced', priority: 'Must have' },
      { skill: 'Tableau', level: 'intermediate', priority: 'Good to have' },
      { skill: 'Financial Modeling', level: 'intermediate', priority: 'Good to have' }
    ],
    'Full Stack Engineer': [
      { skill: 'React / Next.js', level: 'advanced', priority: 'Must have' },
      { skill: 'TypeScript', level: 'advanced', priority: 'Must have' },
      { skill: 'Node.js & Express', level: 'intermediate', priority: 'Must have' },
      { skill: 'PostgreSQL', level: 'intermediate', priority: 'Must have' },
      { skill: 'Docker & AWS Basics', level: 'intermediate', priority: 'Good to have' }
    ],
    'Data Scientist': [
      { skill: 'Python', level: 'advanced', priority: 'Must have' },
      { skill: 'SQL', level: 'advanced', priority: 'Must have' },
      { skill: 'Pandas & Scikit-Learn', level: 'advanced', priority: 'Must have' },
      { skill: 'Power BI', level: 'intermediate', priority: 'Good to have' },
      { skill: 'Deep Learning (PyTorch)', level: 'intermediate', priority: 'Good to have' }
    ],
    'Financial Analyst': [
      { skill: 'Financial Modeling', level: 'advanced', priority: 'Must have' },
      { skill: 'Excel (Advanced)', level: 'advanced', priority: 'Must have' },
      { skill: 'Corporate Valuation (DCF)', level: 'advanced', priority: 'Must have' },
      { skill: 'Power BI', level: 'intermediate', priority: 'Good to have' },
      { skill: 'SQL Basics', level: 'beginner', priority: 'Good to have' }
    ]
  };

  const benchmarks = benchmarkSkillsMap[goal] || benchmarkSkillsMap['Business Analyst'];
  const studentSkillMap = new Map(student.skills.map(s => [s.name.toLowerCase(), s.level]));

  const skillGaps = benchmarks.map(b => {
    const studentLevel = studentSkillMap.get(b.skill.toLowerCase());
    let status: 'Strong' | 'Intermediate' | 'Needs Improvement' = 'Needs Improvement';
    let currentLevel = 'Not Added';
    let actionItem = `Take a guided module on ${b.skill} and add a practical project to your resume.`;

    if (studentLevel) {
      currentLevel = studentLevel.charAt(0).toUpperCase() + studentLevel.slice(1);
      if (studentLevel === 'advanced' || studentLevel === 'expert') {
        status = 'Strong';
        actionItem = `High competency verified. Showcase in case study interviews.`;
      } else if (studentLevel === 'intermediate') {
        status = b.level === 'advanced' ? 'Intermediate' : 'Strong';
        actionItem = `Practice advanced scenario problem solving in ${b.skill}.`;
      } else {
        status = 'Needs Improvement';
        actionItem = `Complete one dedicated project using ${b.skill} to reach intermediate proficiency.`;
      }
    }

    return {
      skill: b.skill,
      currentLevel,
      requiredLevel: b.level.charAt(0).toUpperCase() + b.level.slice(1),
      status,
      actionItem
    };
  });

  // Calculate readiness score
  const strongCount = skillGaps.filter(s => s.status === 'Strong').length;
  const interCount = skillGaps.filter(s => s.status === 'Intermediate').length;
  const score = Math.min(96, Math.max(55, Math.round((strongCount * 18) + (interCount * 12) + (student.achievements.length * 5) + (student.projects.length * 6) + 15)));

  let readinessLevel: 'High Potential' | 'Job Ready' | 'Needs Skill Building' | 'Exploring' = 'Job Ready';
  if (score >= 85) readinessLevel = 'High Potential';
  else if (score >= 70) readinessLevel = 'Job Ready';
  else readinessLevel = 'Needs Skill Building';

  const needsImprovementItem = skillGaps.find(s => s.status === 'Needs Improvement');
  const nextBestAction = needsImprovementItem
    ? `Complete one ${needsImprovementItem.skill} portfolio project and add it to your resume to increase readiness from ${score}/100 to 88/100.`
    : `Apply to active top-matched Business Analyst openings at ABC Technologies and FinEdge.`;

  return {
    careerGoal: goal,
    careerReadinessScore: score,
    readinessLevel,
    skillGaps,
    nextBestAction,
    recommendedRoleTitles: [
      goal,
      `Associate ${goal}`,
      `Junior Data & ${goal}`,
      'Operations Analyst'
    ],
    marketDemand: 'Very High',
    estimatedSalaryRange: '₹6.5 - 10.5 LPA for 2025 Freshers'
  };
}

/**
 * Handles Student AI chat questions
 */
export function handleStudentAIQuery(
  query: string,
  student: StudentProfile,
  jobs: JobOpportunity[],
  applications: JobApplication[]
): { answer: string; recommendations?: any[]; suggestedActions?: string[] } {
  const q = query.toLowerCase();

  if (q.includes('next') || q.includes('what should i do') || q.includes('action') || q.includes('learn') || q.includes('resource') || q.includes('power bi')) {
    return {
      answer: `Here is your **Next AI Recommended Action**:\n\n1. **Priority Skill Gap**: Power BI & Financial Modelling\n2. **Recommended Resource**: *"Power BI Beginner Notes & DAX Formulas.pdf"* (Shared by Senior Consultant Sneha Kulkarni in the Learning Hub)\n3. **Practical Action**: Complete the practical task *"Build a 3-KPI Sales Dashboard with Date Slicers"*.\n4. **Career Outcome**: Advancing this skill boosts your Career Readiness from **${student.careerReadinessScore}/100** to **86/100** and elevates your shortlisting probability for active openings at ABC Tech and FinEdge.`,
      suggestedActions: [
        'Open Learning Hub and study Power BI notes',
        'Show my full skill gap analysis',
        'Find Business Analyst jobs for me'
      ]
    };
  }

  if (q.includes('business analyst') || q.includes('find jobs') || q.includes('search jobs')) {
    const matchedJobs = jobs
      .filter(j => j.type === 'job' && j.isOpen)
      .map(j => ({ job: j, match: calculateJobMatch(student, j) }))
      .sort((a, b) => b.match.overallScore - a.match.overallScore)
      .slice(0, 3);

    return {
      answer: `Here are the top active **Business Analyst** opportunities currently matching your profile, ranked by our deterministic AI Match Engine:`,
      recommendations: matchedJobs.map(m => ({
        id: m.job.id,
        title: m.job.title,
        company: m.job.companyName,
        salary: m.job.salaryDisplay,
        location: m.job.location,
        score: m.match.overallScore,
        why: m.match.whyItMatches[0]
      })),
      suggestedActions: [
        'Apply to ABC Technologies (94% Match)',
        'Review FinEdge Analytics Job Description',
        'What skills am I missing for this role?'
      ]
    };
  }

  if (q.includes('missing') || q.includes('skills') || q.includes('skill gap')) {
    const analysis = analyzeCareerReadiness(student);
    const gaps = analysis.skillGaps.filter(g => g.status !== 'Strong');
    const gapsList = gaps.map(g => `• **${g.skill}**: Current level: ${g.currentLevel} (Required: ${g.requiredLevel}) — *${g.actionItem}*`).join('\n');

    return {
      answer: `Based on an analysis of current recruiter requirements for **${student.careerGoal}** positions in 2025:\n\n**Your Current Career Readiness**: ${analysis.careerReadinessScore}/100\n\n**Identified Skill Gaps**:\n${gapsList}\n\n**Next Best Action**:\n${analysis.nextBestAction}`,
      suggestedActions: [
        'Open Power BI Certified Course',
        'How do I practice SQL for case studies?',
        'Find Business Analyst internships'
      ]
    };
  }

  if (q.includes('certificate') || q.includes('certified') || q.includes('course') || q.includes('video') || q.includes('exam') || q.includes('assessment') || q.includes('learning')) {
    return {
      answer: `Here is your **AI Certified Career Learning Pathway** tailored for **${student.careerGoal}**:\n\n1. 🏆 **Power BI Data Analyst Certified Professional** (Microsoft Learn Curriculum Alignment)\n   • 8 Modules with structured video lessons, retail sales dashboard task, and capstone exam.\n   • Status: **75% completed** (Exam Ready / Certificate Eligible).\n\n2. 📊 **Financial Modelling & Valuation Certified Analyst** (CFI Syllabus Alignment)\n   • 6 Modules with 3-statement forecast models and DCF valuation case studies.\n   • Status: In Progress (35%).\n\n3. ⚡ **Advanced Excel for Business & Financial Analytics**\n   • Validated Master level (Score: 94% Distinction). Certificate ID: **NXF-EXC-2026-00892**.\n\n4. 💾 **SQL & Relational Analytics Certified Professional**\n   • 6 Modules covering multi-table JOINs and window functions.\n\n*Every completed course awards a tamper-evident certificate that boosts your Career Readiness Score and verifies competencies for employers.*`,
      suggestedActions: [
        'Take Power BI AI Assessment',
        'Launch Financial Modelling Course',
        'Verify Certificate ID online',
        'What skills am I missing?'
      ]
    };
  }


  if (q.includes('internship') || q.includes('intern')) {
    const internships = jobs.filter(j => j.type === 'internship' && j.isOpen);
    return {
      answer: `Found **${internships.length} high-impact internship opportunities** with Pre-Placement Offer (PPO) conversion tracks:`,
      recommendations: internships.map(j => ({
        id: j.id,
        title: j.title,
        company: j.companyName,
        salary: j.salaryDisplay,
        location: j.location,
        score: calculateJobMatch(student, j).overallScore,
        why: 'Offers direct mentorship and PPO evaluation for final year students.'
      })),
      suggestedActions: [
        'Apply for ABC Technologies Summer Intern',
        'Apply for FinEdge Product & Analytics Intern'
      ]
    };
  }

  if (q.includes('improve resume') || q.includes('resume')) {
    return {
      answer: `Here are 3 concrete, high-impact improvements to boost your **${student.careerGoal}** resume response rate:\n\n1. **Quantify Project Outcomes**: In your *OmniChannel Retail Sales Analyzer* project, specify exact metrics (e.g., *"Reduced query run-time by 35% and identified ₹12 Lakhs margin leakage"*).\n2. **Front-load Verified Tools**: Move **Excel DAX, SQL, and Power BI** directly into your header skills matrix.\n3. **Highlight Key Achievement**: Place your *Winner — National FinTech Business Case Challenge 2024* right below your education section.`,
      suggestedActions: [
        'Update resume details in Profile',
        'Test my interview readiness',
        'Find jobs for my updated profile'
      ]
    };
  }

  if (q.includes('interview') || q.includes('prepare')) {
    return {
      answer: `Preparing for your **Associate Business Analyst Case Study Round** at ABC Technologies:\n\n**Key Areas Recruiters Test**:\n1. **SQL Data Extraction**: Writing ` + "`GROUP BY`" + `, ` + "`HAVING`" + `, and window functions ` + "`ROW_NUMBER() OVER()`" + `.\n2. **Business Metrics**: Calculating CAC, LTV, Gross Margin, and Cohort Churn.\n3. **Root Cause Analysis**: Walk through the "5 Whys" framework for sudden drop-offs in product sales.\n\n*Tip: Always state your underlying assumptions clearly before calculating numbers.*`,
      suggestedActions: [
        'Practice SQL interview questions',
        'Review ABC Technologies company profile',
        'View my upcoming interview details'
      ]
    };
  }

  if (q.includes('shortlist') || q.includes('why am i not') || q.includes('rejection')) {
    const rejectedApp = applications.find(a => a.status === 'rejected');
    if (rejectedApp && rejectedApp.rejectionFeedback?.provided) {
      return {
        answer: `From your previous application to **${rejectedApp.companyName}**, the recruiter shared constructive feedback:\n\n💬 *"${rejectedApp.rejectionFeedback.comment}"*\n\n**AI Actionable Recommendation**:\n• Master intermediate SQL subqueries and complete 1 Power BI dashboard with DAX calculations.\n• Re-applying with this portfolio will elevate your match score from 62% to 92%.`,
        suggestedActions: [
          'What projects can I build for SQL?',
          'Find other jobs matching my current skills',
          'Explore internships with training tracks'
        ]
      };
    } else {
      return {
        answer: `Recruiters prioritize verified project artifacts and specific tool overlap. To ensure consistent shortlisting:\n\n1. Keep your **Career Readiness Score** above 80.\n2. Include live GitHub / dashboard links on all listed projects.\n3. Apply to roles with 85%+ AI Match Scores where your degree and core skills directly align.`,
        suggestedActions: [
          'View my Career Readiness analysis',
          'Search for 90%+ match jobs'
        ]
      };
    }
  }

  // General helpful AI response
  return {
    answer: `I am your **Nexif5 AI Career Coach**. I analyze real recruiter criteria, skill gap benchmarks, and live market trends to guide your journey from career goal to hiring.\n\nYou are currently tracking toward **${student.careerGoal}** with a Career Readiness score of **${student.careerReadinessScore}/100**.\n\nHow would you like me to help you right now?`,
    suggestedActions: [
      'Find Business Analyst jobs for me',
      'What skills am I missing?',
      'Improve my resume',
      'Prepare me for this interview'
    ]
  };
}

/**
 * Recruiter AI Query Handler for assistant UI
 */
export function handleRecruiterAIQuery(
  query: string,
  students: StudentProfile[],
  jobs: JobOpportunity[]
): {
  summary: string;
  rankedCandidates: {
    name: string;
    education: string;
    course?: string;
    college?: string;
    matchScore: number;
    highlight: string;
  }[];
  suggestedFilters: string[];
} {
  const result = handleRecruiterTalentSearch(query, students);
  return {
    summary: result.summary,
    rankedCandidates: result.candidates.map(c => ({
      name: c.student.name,
      education: c.student.education.degree,
      course: c.student.education.course,
      college: c.student.collegeName,
      matchScore: c.matchScore,
      highlight: c.matchReasons[0] || 'Matches core qualifications'
    })),
    suggestedFilters: [
      'Filter 90%+ Match Candidates',
      'Filter candidates with verified SQL',
      'Export Shortlist to CSV'
    ]
  };
}

/**
 * Example: "Find B.Com freshers with Excel, SQL and Power BI"
 */
export function handleRecruiterTalentSearch(
  query: string,
  students: StudentProfile[]
): {
  parsedQuery: { role?: string; degree?: string; skills: string[] };
  candidates: {
    student: StudentProfile;
    matchScore: number;
    matchReasons: string[];
    skillsBreakdown: { skill: string; matched: boolean }[];
  }[];
  summary: string;
} {
  const q = query.toLowerCase();
  
  // Extract keywords
  const targetSkills = ['excel', 'sql', 'power bi', 'python', 'financial modeling', 'react', 'typescript', 'figma'];
  const matchedSkillsFilter = targetSkills.filter(s => q.includes(s));
  const isBCom = q.includes('b.com') || q.includes('bcom') || q.includes('commerce');
  const isBTech = q.includes('b.tech') || q.includes('btech') || q.includes('engineering') || q.includes('cse');
  const isFresher = q.includes('fresher') || q.includes('2025') || q.includes('final year');

  const candidatesRanked = students.map(student => {
    let score = 70;
    const reasons: string[] = [];
    const studentSkillNames = student.skills.map(s => s.name.toLowerCase());

    // Check degree
    const deg = (student.education.degree + ' ' + student.education.course).toLowerCase();
    if (isBCom && (deg.includes('b.com') || deg.includes('commerce'))) {
      score += 15;
      reasons.push(`B.Com degree background from ${student.collegeName || 'Accredited Institution'}`);
    } else if (isBTech && (deg.includes('b.tech') || deg.includes('computer science') || deg.includes('it'))) {
      score += 15;
      reasons.push(`B.Tech engineering background with ${student.education.cgpaOrPercentage}`);
    }

    // Check skills
    const skillsBreakdown: { skill: string; matched: boolean }[] = [];
    (matchedSkillsFilter.length > 0 ? matchedSkillsFilter : ['excel', 'sql', 'power bi']).forEach(skill => {
      const hasSkill = studentSkillNames.some(s => s.includes(skill));
      skillsBreakdown.push({ skill: skill.toUpperCase(), matched: hasSkill });
      if (hasSkill) {
        score += 8;
      }
    });

    if (skillsBreakdown.filter(s => s.matched).length === skillsBreakdown.length) {
      reasons.push(`Possesses all requested skills: ${skillsBreakdown.map(s => s.skill).join(', ')}.`);
    } else {
      const matched = skillsBreakdown.filter(s => s.matched).map(s => s.skill);
      if (matched.length > 0) {
        reasons.push(`Matched skills: ${matched.join(', ')}.`);
      }
    }

    if (student.achievements.length > 0) {
      score += 5;
      reasons.push(`Verified achievement: ${student.achievements[0].title}`);
    }

    const finalScore = Math.min(98, Math.max(50, score));

    return {
      student,
      matchScore: finalScore,
      matchReasons: reasons,
      skillsBreakdown
    };
  });

  // Sort descending by match score
  candidatesRanked.sort((a, b) => b.matchScore - a.matchScore);

  return {
    parsedQuery: {
      role: q.includes('analyst') ? 'Business Analyst' : undefined,
      degree: isBCom ? 'B.Com' : (isBTech ? 'B.Tech' : undefined),
      skills: matchedSkillsFilter.map(s => s.toUpperCase())
    },
    candidates: candidatesRanked.slice(0, 6),
    summary: `Found **${candidatesRanked.filter(c => c.matchScore >= 80).length} verified candidate profiles** matching your search criteria. Candidate ratings are calculated transparently based on academic credentials, verified skills, and project portfolios.`
  };
}

/**
 * Handles College AI Placement queries
 */
export function handleCollegeAIQuery(
  query: string,
  collegeOrStudents: any,
  studentsParam?: any,
  jobsParam?: any
): { answer: string; chartData?: any[]; actionRecommendations?: string[]; actions?: string[] } {
  const q = query.toLowerCase();
  const students: StudentProfile[] = Array.isArray(collegeOrStudents) ? collegeOrStudents : (studentsParam || []);

  if (q.includes('business analyst') || q.includes('b.com')) {
    const bcomStudents = students.filter(s => 
      (s.education.degree.toLowerCase().includes('b.com') || s.department?.includes('Commerce')) &&
      s.skills.some(sk => sk.name.toLowerCase().includes('sql') || sk.name.toLowerCase().includes('excel'))
    );

    return {
      answer: `Found **${bcomStudents.length} B.Com students** with strong foundational qualifications for **Business Analyst** roles:\n\n• **Aarav Sharma** (94% Match, 78/100 Readiness) — Has Excel Advanced, Power BI, SQL & National Case Challenge Winner.\n• **Ritu Agarwal** (92% Match, 88/100 Readiness) — Advanced Excel, SQL, and Financial Ratio Analysis.\n• **Arvind Swaminathan** (72/100 Readiness) — Ready for introductory analyst and audit roles after SQL refresher.`,
      actions: [
        'Schedule on-campus mock case study interviews',
        'Notify candidates about ABC Technologies drive',
        'Organize weekend SQL certification cohort'
      ]
    };
  }

  if (q.includes('missing') || q.includes('skill gap') || q.includes('skills')) {
    return {
      answer: `**College-Wide Skill Gap Intelligence Report**:\n\n1. **SQL Database Querying**: **115 out of 180 assessed students** need training in multi-table JOINs and window functions. This is currently the #1 reason for recruiter screening drops.\n2. **Power BI / BI Visualization**: **90 students** require intermediate DAX training.\n3. **Excel Advanced Modeling**: Strong baseline (**160 ready**, only 20 need training).\n\n💡 *Actionable College Recommendation: Launching a 2-week practical SQL bootcamp will elevate college placement eligibility by an estimated 24%.*`,
      actions: [
        'Export Skill Gap Batch List for Faculty Coordinators',
        'Schedule 10-hour SQL Hackathon with Industry Mentors'
      ]
    };
  }

  if (q.includes('highest placement') || q.includes('department')) {
    return {
      answer: `**Department Placement Performance Ranking**:\n\n1. 🥇 **Data Analytics & AI**: **94.0% Placement Rate** (Avg: ₹8.6 LPA, Max: ₹16.0 LPA)\n2. 🥈 **Computer Science & Engineering**: **91.2% Placement Rate** (Avg: ₹7.8 LPA, Max: ₹18.5 LPA)\n3. 🥉 **Commerce & Computer Applications**: **84.6% Placement Rate** (Avg: ₹6.4 LPA, Max: ₹12.0 LPA)\n4. 🏅 **Management Studies (MBA)**: **81.5% Placement Rate** (Avg: ₹7.2 LPA, Max: ₹14.0 LPA)\n5. **Commerce & Finance**: **78.4% Placement Rate** (Avg: ₹5.8 LPA, Max: ₹10.5 LPA)`,
      actions: [
        'View full Department-wise Placement Analytics',
        'Generate AI Placement Accreditation Report'
      ]
    };
  }

  if (q.includes('selected') || q.includes('month') || q.includes('hiring')) {
    return {
      answer: `A total of **24 students have been selected** across campus drives and Nexif5 direct company connections this placement cycle.\n\n**Top Hiring Partners**:\n• **TCS Innovate Labs**: 12 Hires (Avg ₹7.5 - 8.5 LPA)\n• **ABC Technologies**: 6 Hires (Avg ₹6.5 - 8.5 LPA)\n• **FinEdge Analytics**: 4 Hires (Avg ₹7.0 - 9.5 LPA)\n• **Zenith Health AI**: 2 Hires (Avg ₹8.0 LPA)`,
      actions: [
        'View all placement offer records',
        'Send congratulations email to placed students'
      ]
    };
  }

  return {
    answer: `I am the **Nexif5 College AI Assistant**. I query authorized college placement data to provide actionable intelligence on student readiness, department placement rates, corporate hiring trends, and curriculum skill gaps.\n\nHow can I assist your placement cell today?`,
    actions: [
      'Which B.Com students are suitable for Business Analyst jobs?',
      'What skills are missing among our students?',
      'Which department has the highest placement rate?',
      'How many students were selected this month?'
    ]
  };
}
