import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, Briefcase, GraduationCap, Sparkles, BookOpen, Shuffle, Compass, Check } from 'lucide-react';

interface GoalOption {
  id: string;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
}

export const CareerGoalScreen: React.FC = () => {
  const { setAuthState } = useApp();
  const [selectedGoal, setSelectedGoal] = useState<string>('Find a Job');

  const goals: GoalOption[] = [
    {
      id: 'Find a Job',
      title: 'Find a Job',
      subtitle: 'Discover full-time roles matching my skill set.',
      icon: <Briefcase className="w-5 h-5 text-indigo-400" />
    },
    {
      id: 'Find an Internship',
      title: 'Find an Internship',
      subtitle: 'Gain hands-on industry experience and PPO opportunities.',
      icon: <GraduationCap className="w-5 h-5 text-blue-400" />
    },
    {
      id: 'Get My First Job',
      title: 'Get My First Job',
      subtitle: 'Fast-track entry-level openings for fresh graduates.',
      icon: <Sparkles className="w-5 h-5 text-emerald-400" />
    },
    {
      id: 'Prepare for Placement',
      title: 'Prepare for Placement',
      subtitle: 'Placement mock tests, aptitude, and interview preparation.',
      icon: <GraduationCap className="w-5 h-5 text-purple-400" />
    },
    {
      id: 'Improve My Skills',
      title: 'Improve My Skills',
      subtitle: 'Targeted skill gap analytics and verified assessments.',
      icon: <BookOpen className="w-5 h-5 text-amber-400" />
    },
    {
      id: 'Switch Career',
      title: 'Switch Career',
      subtitle: 'Transition smoothly to high-demand tech & business domains.',
      icon: <Shuffle className="w-5 h-5 text-rose-400" />
    },
    {
      id: 'Explore Careers',
      title: 'Explore Careers',
      subtitle: 'Learn about role expectations, roadmaps, and salary bands.',
      icon: <Compass className="w-5 h-5 text-cyan-400" />
    }
  ];

  const handleContinue = () => {
    sessionStorage.setItem('temp_career_goal', selectedGoal);
    setAuthState('preferences');
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col justify-between px-5 py-6 font-sans">
      {/* Top Header & Progress */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setAuthState('profile_setup')}
              className="p-2 -ml-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors active:scale-95"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white font-display">
                What do you want to achieve?
              </h1>
              <p className="text-xs text-slate-400">
                Step 2 of 3 — Primary Objective
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-indigo-400">66%</span>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1.5 bg-slate-800 rounded-full mb-4 overflow-hidden">
          <div className="h-full bg-indigo-500 rounded-full w-2/3 transition-all duration-300" />
        </div>

        {/* Goals List */}
        <div className="overflow-y-auto max-h-[66vh] space-y-2.5 pr-1">
          {goals.map((g) => {
            const isSelected = selectedGoal === g.id;
            return (
              <motion.button
                key={g.id}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedGoal(g.id)}
                className={`w-full p-3.5 rounded-2xl text-left border flex items-center justify-between transition-all ${
                  isSelected
                    ? 'bg-indigo-600/20 border-indigo-500 shadow-md shadow-indigo-500/10'
                    : 'bg-slate-800/60 border-slate-800 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    isSelected ? 'bg-indigo-600/30' : 'bg-slate-700/50'
                  }`}>
                    {g.icon}
                  </div>
                  <div>
                    <span className="font-bold text-white text-sm block">
                      {g.title}
                    </span>
                    <span className="text-xs text-slate-400 mt-0.5 block">
                      {g.subtitle}
                    </span>
                  </div>
                </div>

                <div className="shrink-0 ml-2">
                  {isSelected ? (
                    <div className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  ) : (
                    <div className="w-5 h-5 rounded-full border border-slate-600" />
                  )}
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Sticky Bottom Continue Button */}
      <div className="pt-3">
        <button
          onClick={handleContinue}
          className="w-full py-4 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-base shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
        >
          <span>Continue</span>
        </button>
      </div>
    </div>
  );
};
