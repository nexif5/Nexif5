import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Award,
  Building2,
  MapPin,
  Clock,
  Star,
  CheckCircle2,
  Globe,
  Share2,
  ShieldCheck
} from 'lucide-react';

export const MobileMentorProfile: React.FC = () => {
  const { currentMentor, theme } = useApp();
  const isLight = theme === 'light';

  return (
    <div className={`p-4 space-y-4 pb-24 font-sans ${isLight ? 'text-slate-900' : 'text-white'}`}>
      {/* Mentor Identity Card */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-start gap-3.5">
          <img
            src={currentMentor.avatarUrl}
            alt={currentMentor.name}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-cyan-500 shadow-md"
          />
          <div className="space-y-0.5">
            <div className="flex items-center gap-1.5">
              <h1 className="text-base font-bold font-display">{currentMentor.name}</h1>
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
            </div>
            <p className="text-xs text-cyan-600 dark:text-cyan-400 font-semibold">
              {currentMentor.jobTitle}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5" />
              <span>{currentMentor.company}</span>
            </p>
            <p className="text-[10px] text-slate-400 flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              <span>{currentMentor.location} • {currentMentor.experienceYears} Yrs Exp</span>
            </p>
          </div>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          {currentMentor.bio}
        </p>

        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-700/60 text-xs">
          <div>
            <span className="text-slate-500 dark:text-slate-400 text-[10px] block">Availability</span>
            <span className="font-bold">{currentMentor.availabilityHoursPerWeek} Hours / Week</span>
          </div>
          <div>
            <span className="text-slate-500 dark:text-slate-400 text-[10px] block">Mentees Mentored</span>
            <span className="font-bold">{currentMentor.totalMenteesCount} Mentees</span>
          </div>
        </div>
      </div>

      {/* Expertise Domains */}
      <div className={`p-4 rounded-2xl border space-y-2.5 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
          Areas of Mentorship Expertise
        </h2>
        <div className="flex flex-wrap gap-1.5">
          {currentMentor.domains.map((d, idx) => (
            <span
              key={idx}
              className="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-xs font-medium text-cyan-300"
            >
              ✦ {d}
            </span>
          ))}
        </div>
      </div>

      {/* Offerings */}
      <div className={`p-4 rounded-2xl border space-y-2.5 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
          Active Mentorship Formats
        </h2>
        <div className="space-y-1.5">
          {currentMentor.mentorshipTypes.map((type, idx) => (
            <div key={idx} className="p-2.5 rounded-xl bg-slate-800/50 border border-slate-700/60 flex items-center justify-between text-xs">
              <span className="font-semibold text-white">{type}</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
