import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, Briefcase, Building2, MapPin, Sparkles, Check, Plus, X, Award, FileText } from 'lucide-react';
import { WorkModeType, WorkPreferenceType } from '../../types';

export const ProfessionalOnboardingScreen: React.FC = () => {
  const { setAuthState, setCurrentRole, updateProfessionalProfile, currentProfessional } = useApp();

  const [name, setName] = useState('Rahul Verma');
  const [avatarUrl, setAvatarUrl] = useState('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80');
  const [location, setLocation] = useState('Bengaluru, Karnataka');
  const [currentJobTitle, setCurrentJobTitle] = useState('Associate Business Analyst');
  const [currentCompany, setCurrentCompany] = useState('Finlytics Advisory Corp');
  const [experienceYears, setExperienceYears] = useState(2.5);
  const [industry, setIndustry] = useState('FinTech & Analytics Consulting');
  const [workMode, setWorkMode] = useState<WorkModeType>('hybrid');

  // Skills
  const [skills, setSkills] = useState<string[]>(['Excel (Advanced)', 'SQL', 'Power BI', 'Financial Modeling']);
  const [newSkill, setNewSkill] = useState('');
  const [targetSkills, setTargetSkills] = useState<string[]>(['Strategic Forecasting', 'Python Automation', 'Tableau Server']);

  // Career Goals
  const [careerGoal, setCareerGoal] = useState('Senior Business Analyst');
  const [targetJobRole, setTargetJobRole] = useState('Lead Product Analyst / Strategy Lead');
  const [preferredIndustry, setPreferredIndustry] = useState('FinTech, SaaS, Investment Banking');
  const [preferredLocation, setPreferredLocation] = useState('Bengaluru / Remote');
  const [salaryCurrentLPA, setSalaryCurrentLPA] = useState(8.5);
  const [salaryTargetLPA, setSalaryTargetLPA] = useState(14.5);
  const [resumeName, setResumeName] = useState('Rahul_Verma_Senior_Analyst_2026.pdf');

  const [step, setStep] = useState<1 | 2 | 3>(1);

  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()]);
      setNewSkill('');
    }
  };

  const handleFinish = () => {
    updateProfessionalProfile({
      name,
      avatarUrl,
      location,
      currentJobTitle,
      currentCompany,
      totalExperienceYears: experienceYears,
      industry,
      workMode,
      targetSkills,
      careerGoal,
      targetJobRole,
      preferredIndustry,
      preferredLocation,
      salaryCurrentLPA,
      salaryTargetLPA,
      resumeName
    });

    setCurrentRole('professional');
    setAuthState('authenticated');
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col justify-between px-5 py-6 font-sans">
      {/* Top Header */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (step > 1) setStep((step - 1) as any);
                else setAuthState('account_type');
              }}
              className="p-2 -ml-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors active:scale-95"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white font-display">
                Professional Onboarding
              </h1>
              <p className="text-xs text-slate-400">
                Step {step} of 3 — {step === 1 ? 'Current Role' : step === 2 ? 'Skills & Upskilling' : 'Target Career Goals'}
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-amber-400">{step === 1 ? '33%' : step === 2 ? '66%' : '100%'}</span>
        </div>

        {/* Progress bar */}
        <div className="w-full h-1.5 bg-slate-800 rounded-full mb-4 overflow-hidden">
          <div
            className="h-full bg-amber-500 rounded-full transition-all duration-300"
            style={{ width: `${(step / 3) * 100}%` }}
          />
        </div>

        {/* Step 1: Personal & Current Professional Details */}
        {step === 1 && (
          <div className="space-y-3.5 max-h-[68vh] overflow-y-auto pr-1">
            <div className="flex items-center gap-3.5 p-3.5 bg-slate-800/60 border border-slate-700/80 rounded-2xl">
              <img
                src={avatarUrl}
                alt={name}
                className="w-14 h-14 rounded-full object-cover border-2 border-amber-500"
              />
              <div>
                <p className="text-xs font-bold text-white">Professional Profile</p>
                <p className="text-[11px] text-slate-400">Verified credentials & career benchmarks</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Current Job Title</label>
                <input
                  type="text"
                  value={currentJobTitle}
                  onChange={(e) => setCurrentJobTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                  placeholder="e.g. Associate Business Analyst"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Current Company</label>
                <input
                  type="text"
                  value={currentCompany}
                  onChange={(e) => setCurrentCompany(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                  placeholder="e.g. Finlytics Advisory"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Total Experience (Years)</label>
                <input
                  type="number"
                  step="0.5"
                  value={experienceYears}
                  onChange={(e) => setExperienceYears(parseFloat(e.target.value) || 0)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Current Work Mode</label>
                <select
                  value={workMode}
                  onChange={(e) => setWorkMode(e.target.value as WorkModeType)}
                  className="w-full px-3 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                >
                  <option value="remote">Remote</option>
                  <option value="hybrid">Hybrid</option>
                  <option value="on_site">On-site</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Location / Base City</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
              />
            </div>
          </div>
        )}

        {/* Step 2: Skills & Target Upskilling */}
        {step === 2 && (
          <div className="space-y-4 max-h-[68vh] overflow-y-auto pr-1">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Current Verified Skills
              </label>
              <div className="flex flex-wrap gap-1.5 mb-2.5">
                {skills.map((s) => (
                  <span
                    key={s}
                    className="inline-flex items-center gap-1 px-3 py-1 bg-amber-500/15 border border-amber-500/30 text-amber-300 rounded-lg text-xs font-medium"
                  >
                    <span>{s}</span>
                    <button
                      type="button"
                      onClick={() => setSkills(skills.filter(x => x !== s))}
                      className="hover:text-white"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>

              <form onSubmit={handleAddSkill} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Add skill (e.g. Python, DAX, SQL)"
                  value={newSkill}
                  onChange={(e) => setNewSkill(e.target.value)}
                  className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white"
                />
                <button
                  type="submit"
                  className="px-3 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold"
                >
                  Add
                </button>
              </form>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Target Upskilling Focus (Skills to develop)
              </label>
              <div className="space-y-2">
                {targetSkills.map((ts, idx) => (
                  <div key={idx} className="p-2.5 bg-slate-800/70 border border-slate-700 rounded-xl flex items-center justify-between text-xs">
                    <span className="font-semibold text-white">{ts}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">
                      Target Gap
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-3 bg-slate-800/60 border border-slate-700/80 rounded-xl text-xs text-slate-300 space-y-1">
              <div className="flex items-center gap-1.5 text-amber-400 font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI Recommendation Engine</span>
              </div>
              <p className="text-[11px] text-slate-400">
                NEXIF5 AI will tailor certified courses and case projects directly towards your targeted promotion track.
              </p>
            </div>
          </div>
        )}

        {/* Step 3: Target Career Role & Compensation Benchmark */}
        {step === 3 && (
          <div className="space-y-3.5 max-h-[68vh] overflow-y-auto pr-1">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Next Career Milestone / Goal
              </label>
              <input
                type="text"
                value={careerGoal}
                onChange={(e) => setCareerGoal(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                placeholder="e.g. Senior Business Analyst"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Target Job Roles
              </label>
              <input
                type="text"
                value={targetJobRole}
                onChange={(e) => setTargetJobRole(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                placeholder="e.g. Lead Product Analyst / Strategy Lead"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Current CTC (LPA)</label>
                <input
                  type="number"
                  step="0.5"
                  value={salaryCurrentLPA}
                  onChange={(e) => setSalaryCurrentLPA(parseFloat(e.target.value) || 0)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Expected CTC (LPA)</label>
                <input
                  type="number"
                  step="0.5"
                  value={salaryTargetLPA}
                  onChange={(e) => setSalaryTargetLPA(parseFloat(e.target.value) || 0)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Preferred Industry
              </label>
              <input
                type="text"
                value={preferredIndustry}
                onChange={(e) => setPreferredIndustry(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
              />
            </div>

            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center gap-2.5">
              <FileText className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <p className="text-xs font-bold text-emerald-300">Resume Attached</p>
                <p className="text-[11px] text-slate-300">{resumeName}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Button */}
      <div className="pt-4">
        {step < 3 ? (
          <button
            onClick={() => setStep((step + 1) as any)}
            className="w-full py-3.5 px-6 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-sm shadow-lg shadow-amber-600/30 flex items-center justify-center transition-all active:scale-[0.98]"
          >
            Continue
          </button>
        ) : (
          <button
            onClick={handleFinish}
            className="w-full py-3.5 px-6 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-sm shadow-lg shadow-amber-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
          >
            <Check className="w-4 h-4" />
            <span>Complete Setup & Enter Workspace</span>
          </button>
        )}
      </div>
    </div>
  );
};
