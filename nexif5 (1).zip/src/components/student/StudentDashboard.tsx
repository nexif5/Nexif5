import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { analyzeCareerReadiness, calculateJobMatch } from '../../services/aiEngine';
import { JobDetailModal } from '../common/JobDetailModal';
import { JobOpportunity } from '../../types';
import {
  Target,
  TrendingUp,
  Sparkles,
  Layers,
  CalendarCheck,
  FileText,
  Zap,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Video,
  Building,
  MapPin,
  Bot
} from 'lucide-react';
import { ResponsiveContainer, RadialBarChart, RadialBar, PolarAngleAxis } from 'recharts';

export const StudentDashboard: React.FC = () => {
  const {
    currentStudent,
    jobs,
    applications,
    setActiveStudentTab
  } = useApp();

  const [selectedJob, setSelectedJob] = useState<JobOpportunity | null>(null);
  const careerAnalysis = analyzeCareerReadiness(currentStudent);

  // Application counts
  const studentApps = applications.filter(a => a.candidateId === currentStudent.id);
  const appliedCount = studentApps.filter(a => a.status === 'applied' || a.status === 'under_review').length;
  const shortlistedCount = studentApps.filter(a => a.status === 'shortlisted').length;
  const interviewCount = studentApps.filter(a => a.status === 'interview').length;
  const selectedCount = studentApps.filter(a => a.status === 'selected').length;

  // Upcoming interviews
  const upcomingInterviews = studentApps
    .filter(a => a.status === 'interview' && a.scheduledInterview)
    .map(a => a.scheduledInterview!);

  // Radial chart data
  const readinessChartData = [
    {
      name: 'Readiness',
      value: careerAnalysis.careerReadinessScore,
      fill: '#4f46e5'
    }
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Header Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
            <Target className="w-4 h-4" />
            <span>PERSONAL CAREER CONTROL CENTER</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 font-display">
            Career Readiness & Execution Dashboard
          </h1>
          <p className="text-xs text-slate-500">
            Real-time analytics and next best actions for {currentStudent.name}
          </p>
        </div>

        <button
          onClick={() => setActiveStudentTab('ai')}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs hover:shadow transition-all flex items-center gap-2 w-fit"
        >
          <Bot className="w-4 h-4" />
          <span>Ask Nexif5 AI Assistant</span>
        </button>
      </div>

      {/* 4 Core High-Level Metric Tiles */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* 1. Target Goal Tile */}
        <div className="bg-white p-3.5 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <span className="p-1.5 sm:p-2 bg-blue-50 text-blue-600 rounded-xl">
              <Target className="w-4 h-4 sm:w-5 sm:h-5" />
            </span>
            <span className="text-[9px] sm:text-[10px] font-bold text-blue-600 bg-blue-50 px-1.5 sm:px-2 py-0.5 rounded-full">
              Goal
            </span>
          </div>
          <div className="mt-3 sm:mt-4">
            <span className="text-[10px] sm:text-xs text-slate-500 font-medium block">Career Ambition</span>
            <h3 className="text-sm sm:text-base lg:text-lg font-bold text-slate-900 font-display mt-0.5 truncate">
              {currentStudent.careerGoal}
            </h3>
            <p className="text-[10px] sm:text-[11px] text-slate-500 mt-1 truncate">
              Target: ₹{currentStudent.salaryPreferenceMinLPA}-{currentStudent.salaryPreferenceMaxLPA} LPA
            </p>
          </div>
        </div>

        {/* 2. Readiness Score Tile */}
        <div className="bg-white p-3.5 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <span className="p-1.5 sm:p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5" />
            </span>
            <span className="text-[9px] sm:text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 sm:px-2 py-0.5 rounded-full">
              {careerAnalysis.readinessLevel}
            </span>
          </div>
          <div className="mt-3 sm:mt-4">
            <span className="text-[10px] sm:text-xs text-slate-500 font-medium block">AI Readiness</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-xl sm:text-2xl font-black text-indigo-600 font-display">
                {careerAnalysis.careerReadinessScore}
              </span>
              <span className="text-[10px] sm:text-xs font-semibold text-slate-400">/ 100</span>
            </div>
            <p className="text-[10px] sm:text-[11px] text-slate-500 mt-1">
              +14 pts verified
            </p>
          </div>
        </div>

        {/* 3. Application Pipeline Tile */}
        <div className="bg-white p-3.5 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <span className="p-1.5 sm:p-2 bg-purple-50 text-purple-600 rounded-xl">
              <Layers className="w-4 h-4 sm:w-5 sm:h-5" />
            </span>
            <button
              onClick={() => setActiveStudentTab('applications')}
              className="text-[9px] sm:text-[10px] font-bold text-purple-600 hover:text-purple-800"
            >
              Funnel →
            </button>
          </div>
          <div className="mt-3 sm:mt-4">
            <span className="text-[10px] sm:text-xs text-slate-500 font-medium block">Applications</span>
            <div className="flex items-center gap-2 mt-1 text-xs">
              <div>
                <strong className="text-slate-900 font-bold text-sm sm:text-base block">{appliedCount}</strong>
                <span className="text-[9px] text-slate-400">Applied</span>
              </div>
              <div className="w-px h-5 bg-slate-200" />
              <div>
                <strong className="text-emerald-600 font-bold text-sm sm:text-base block">{shortlistedCount}</strong>
                <span className="text-[9px] text-slate-400">Shortlisted</span>
              </div>
              <div className="w-px h-5 bg-slate-200" />
              <div>
                <strong className="text-blue-600 font-bold text-sm sm:text-base block">{interviewCount}</strong>
                <span className="text-[9px] text-slate-400">Interview</span>
              </div>
            </div>
          </div>
        </div>

        {/* 4. Resume & ATS Score Tile */}
        <div className="bg-white p-3.5 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <span className="p-1.5 sm:p-2 bg-rose-50 text-rose-600 rounded-xl">
              <FileText className="w-4 h-4 sm:w-5 sm:h-5" />
            </span>
            <span className="text-[9px] sm:text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 sm:px-2 py-0.5 rounded-full">
              ATS 88%
            </span>
          </div>
          <div className="mt-3 sm:mt-4">
            <span className="text-[10px] sm:text-xs text-slate-500 font-medium block">Active Resume</span>
            <p className="text-xs font-bold text-slate-900 truncate mt-0.5">
              {currentStudent.resumeName}
            </p>
            <p className="text-[10px] sm:text-[11px] text-emerald-600 font-semibold mt-1">
              88% ATS Score
            </p>
          </div>
        </div>
      </div>

      {/* Next Best Action Guided Execution Hero Card */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-2xl p-6 shadow-md relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold border border-indigo-400/30">
              <Zap className="w-3.5 h-3.5" />
              <span>RECOMMENDED NEXT BEST ACTION</span>
            </div>
            <h3 className="text-lg sm:text-xl font-bold font-display">
              {careerAnalysis.nextBestAction}
            </h3>
            <p className="text-xs text-slate-300">
              Completing this specific action directly addresses the top recruiter screening filter for Associate Business Analyst openings.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveStudentTab('ai')}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-sm transition-all"
            >
              Start AI Practice
            </button>
            <button
              onClick={() => setActiveStudentTab('profile')}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all"
            >
              Update Profile
            </button>
          </div>
        </div>
      </div>

      {/* Two Column Layout: Upcoming Interviews & Skill Diagnostics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 spans): Skill Gap Diagnostic Table */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-base font-display">
                Skill Gap Analysis & Corporate Benchmarks
              </h3>
              <p className="text-xs text-slate-500">
                Detailed breakdown for target role: <strong>{currentStudent.careerGoal}</strong>
              </p>
            </div>

            <button
              onClick={() => setActiveStudentTab('profile')}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
            >
              + Add Skills
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {careerAnalysis.skillGaps.map((item, idx) => (
              <div key={idx} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{item.skill}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      item.status === 'Strong'
                        ? 'bg-emerald-100 text-emerald-800'
                        : item.status === 'Intermediate'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {item.status}
                    </span>
                  </div>
                  <p className="text-slate-500 text-[11px]">{item.actionItem}</p>
                </div>

                <div className="flex items-center gap-4 text-[11px] text-slate-600 shrink-0">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Your Level</span>
                    <strong className="text-slate-800">{item.currentLevel}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Required</span>
                    <strong className="text-indigo-600">{item.requiredLevel}</strong>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column (1 span): Upcoming Interviews & Applications Snapshot */}
        <div className="space-y-6">
          {/* Upcoming Interview Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm font-display flex items-center gap-2">
                <CalendarCheck className="w-4 h-4 text-blue-600" />
                <span>Upcoming Interviews</span>
              </h3>
              <span className="text-[11px] font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                {upcomingInterviews.length} Scheduled
              </span>
            </div>

            {upcomingInterviews.length > 0 ? (
              <div className="space-y-3">
                {upcomingInterviews.map((int) => (
                  <div key={int.id} className="p-3.5 rounded-xl bg-blue-50/50 border border-blue-100 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <strong className="text-slate-900 font-bold">{int.jobTitle}</strong>
                      <span className="text-[10px] font-bold text-blue-700 bg-white px-2 py-0.5 rounded-full border border-blue-200">
                        {int.roundType}
                      </span>
                    </div>
                    <p className="text-slate-600 font-medium">{int.companyName}</p>
                    <div className="flex items-center gap-3 text-[11px] text-slate-500 pt-1">
                      <span className="flex items-center gap-1 font-semibold text-slate-700">
                        <Clock className="w-3 h-3 text-slate-400" /> {int.date} at {int.time}
                      </span>
                    </div>

                    <a
                      href={int.meetingLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-[11px] flex items-center justify-center gap-1.5 transition-colors block text-center"
                    >
                      <Video className="w-3.5 h-3.5" />
                      <span>Join Video Interview</span>
                    </a>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-slate-100">
                <CalendarCheck className="w-8 h-8 mx-auto text-slate-300 mb-1" />
                <p>No interviews scheduled at this moment.</p>
              </div>
            )}
          </div>

          {/* Quick Application Tracker Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm font-display flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-600" />
                <span>Recent Submissions</span>
              </h3>
              <button
                onClick={() => setActiveStudentTab('applications')}
                className="text-xs font-bold text-purple-600 hover:text-purple-800"
              >
                View All
              </button>
            </div>

            <div className="space-y-2">
              {studentApps.slice(0, 3).map((app) => (
                <div
                  key={app.id}
                  onClick={() => setActiveStudentTab('applications')}
                  className="p-3 rounded-xl border border-slate-100 hover:border-slate-300 hover:bg-slate-50 cursor-pointer transition-all flex items-center justify-between text-xs"
                >
                  <div className="min-w-0 pr-2">
                    <p className="font-bold text-slate-900 truncate">{app.jobTitle}</p>
                    <p className="text-[11px] text-slate-500 truncate">{app.companyName}</p>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold capitalize shrink-0 ${
                    app.status === 'selected' ? 'bg-emerald-100 text-emerald-800' :
                    app.status === 'interview' ? 'bg-blue-100 text-blue-800' :
                    app.status === 'shortlisted' ? 'bg-purple-100 text-purple-800' :
                    app.status === 'rejected' ? 'bg-rose-100 text-rose-800' :
                    'bg-slate-100 text-slate-700'
                  }`}>
                    {app.status.replace('_', ' ')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {selectedJob && (
        <JobDetailModal
          job={selectedJob}
          onClose={() => setSelectedJob(null)}
        />
      )}
    </div>
  );
};
