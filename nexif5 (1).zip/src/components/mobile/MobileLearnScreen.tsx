import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { ResourceCategory, SharedResource, SkillProgressItem, CertifiedCourse } from '../../types';
import {
  Sparkles,
  Search,
  BookOpen,
  Upload,
  Bookmark,
  ThumbsUp,
  FileText,
  CheckCircle2,
  TrendingUp,
  Filter,
  Eye,
  ArrowRight,
  User,
  Clock,
  Layers,
  Check,
  ShieldCheck,
  ExternalLink,
  Trash2,
  Award,
  Play,
  Video,
  ChevronRight,
  HelpCircle
} from 'lucide-react';

export const MobileLearnScreen: React.FC = () => {
  const {
    currentStudent,
    sharedResources,
    savedResourceIds,
    toggleSaveResource,
    setSelectedResourceForDetail,
    setIsUploadResourceModalOpen,
    skillProgressList,
    completeSkillTask,
    learnSubTab,
    setLearnSubTab,
    deleteResource,
    certifiedCourses,
    openCourseLearning,
    openCourseAssessment,
    openCertificateView,
    openCertificateVerification,
    theme
  } = useApp();

  const isLight = theme === 'light';
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSkillFilter, setSelectedSkillFilter] = useState<string>('all');
  const [courseFilter, setCourseFilter] = useState<'all' | 'in_progress' | 'earned'>('all');

  const categories: { id: string; label: string }[] = [
    { id: 'all', label: 'All Categories' },
    { id: 'Skill Learning', label: 'Skill Learning' },
    { id: 'Interview Prep', label: 'Interview Prep' },
    { id: 'Exam Preparation', label: 'Exam Prep' },
    { id: 'Career Guide', label: 'Career Guides' },
    { id: 'Templates', label: 'Templates' },
    { id: 'Project Resources', label: 'Projects' }
  ];

  const skillFilters = ['all', 'Power BI', 'Financial Modeling', 'SQL', 'Excel', 'Business Analysis'];

  // AI-recommended resources for this student
  const aiRecommendedResources = useMemo(() => {
    return sharedResources.filter(r =>
      r.skill.toLowerCase().includes('power bi') ||
      r.skill.toLowerCase().includes('financial model') ||
      r.skill.toLowerCase().includes('sql') ||
      r.careerRelevance.toLowerCase().includes('business') ||
      r.careerRelevance.toLowerCase().includes('finance')
    );
  }, [sharedResources]);

  // Saved resources
  const savedResources = useMemo(() => {
    return sharedResources.filter(r => savedResourceIds.includes(r.id));
  }, [sharedResources, savedResourceIds]);

  // User's own uploaded resources
  const myResources = useMemo(() => {
    return sharedResources.filter(r => r.uploaderId === currentStudent.id);
  }, [sharedResources, currentStudent.id]);

  // Filtered certified courses
  const filteredCourses = useMemo(() => {
    return certifiedCourses.filter(c => {
      if (courseFilter === 'in_progress') return c.progressPercent > 0 && !c.isCertificateEarned;
      if (courseFilter === 'earned') return c.isCertificateEarned;
      return true;
    });
  }, [certifiedCourses, courseFilter]);

  // Filtered resources for the "Shared Resources" community tab
  const filteredSharedResources = useMemo(() => {
    return sharedResources.filter(r => {
      const matchesSearch =
        searchQuery === '' ||
        r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.skill.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesCat =
        selectedCategory === 'all' || r.category === selectedCategory;

      const matchesSkill =
        selectedSkillFilter === 'all' ||
        r.skill.toLowerCase().includes(selectedSkillFilter.toLowerCase());

      return matchesSearch && matchesCat && matchesSkill;
    });
  }, [sharedResources, searchQuery, selectedCategory, selectedSkillFilter]);

  return (
    <div className={`space-y-4 px-4 pt-4 pb-24 font-sans min-h-screen transition-colors duration-200 ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-white'
    }`}>
      {/* 1. Header with Tagline */}
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-600 dark:text-indigo-400 text-[11px] font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI LEARNING & CERTIFICATION HUB</span>
          </div>
          <h1 className={`text-2xl font-bold tracking-tight font-display mt-1 ${
            isLight ? 'text-slate-900' : 'text-white'
          }`}>
            From Learning to Opportunity
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            AI skill analysis, video courses, practical verification, and verifiable certificates.
          </p>
        </div>

        {/* Upload Resource Button */}
        <button
          onClick={() => setIsUploadResourceModalOpen(true)}
          className="shrink-0 px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md flex items-center gap-1.5 active:scale-95 transition-all mt-1"
          title="Share an educational document"
        >
          <Upload className="w-3.5 h-3.5" />
          <span>Upload</span>
        </button>
      </div>

      {/* 2. Sub-Navigation Tabs */}
      <div className={`flex items-center gap-1.5 p-1 rounded-2xl border overflow-x-auto no-scrollbar ${
        isLight ? 'bg-slate-200/80 border-slate-300' : 'bg-slate-800/80 border-slate-700'
      }`}>
        <button
          onClick={() => setLearnSubTab('recommendations')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            learnSubTab === 'recommendations'
              ? 'bg-indigo-600 text-white shadow-sm'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>AI Recommendations</span>
        </button>

        <button
          onClick={() => setLearnSubTab('certifications')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            learnSubTab === 'certifications'
              ? 'bg-indigo-600 text-white shadow-sm'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Award className="w-3.5 h-3.5 text-amber-400" />
          <span>Certified Learning</span>
          <span className="text-[10px] opacity-75">({certifiedCourses.length})</span>
        </button>

        <button
          onClick={() => setLearnSubTab('shared')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            learnSubTab === 'shared'
              ? 'bg-indigo-600 text-white shadow-sm'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Shared Resources</span>
          <span className="text-[10px] opacity-75">({sharedResources.length})</span>
        </button>

        <button
          onClick={() => setLearnSubTab('tasks')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            learnSubTab === 'tasks'
              ? 'bg-indigo-600 text-white shadow-sm'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Skill Progress</span>
        </button>

        <button
          onClick={() => setLearnSubTab('saved')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            learnSubTab === 'saved'
              ? 'bg-indigo-600 text-white shadow-sm'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" />
          <span>Saved ({savedResources.length})</span>
        </button>

        <button
          onClick={() => setLearnSubTab('my_resources')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            learnSubTab === 'my_resources'
              ? 'bg-indigo-600 text-white shadow-sm'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span>My Uploads ({myResources.length})</span>
        </button>
      </div>

      {/* ============================================================== */}
      {/* VIEW 1: AI RECOMMENDATIONS (Personalized Learning Journey) */}
      {/* ============================================================== */}
      {learnSubTab === 'recommendations' && (
        <div className="space-y-4">
          {/* AI Guidance Callout Banner */}
          <div className={`p-4 rounded-2xl border space-y-2.5 ${
            isLight
              ? 'bg-gradient-to-br from-indigo-50 to-blue-50/70 border-indigo-200 text-slate-800'
              : 'bg-gradient-to-br from-indigo-950/60 to-slate-900 border-indigo-500/30 text-white'
          }`}>
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI Skill-Gap Diagnostics</span>
              </span>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                Goal: {currentStudent.careerGoal}
              </span>
            </div>
            <p className="text-xs leading-relaxed">
              Based on your goal of becoming a <strong>{currentStudent.careerGoal}</strong>, NEXIF5 AI identified a priority skill gap in <strong>Power BI</strong> and <strong>Financial Modelling</strong>.
              Follow the recommended learning path: video lessons, practical task submission, and AI capstone exams to earn verifiable credentials.
            </p>

            <div className="pt-2 flex items-center justify-between border-t border-indigo-500/20 text-xs">
              <span className="text-slate-500 dark:text-slate-400">Career Readiness</span>
              <span className="font-extrabold text-indigo-600 dark:text-indigo-400">{currentStudent.careerReadinessScore}/100</span>
            </div>
          </div>

          {/* Core Learning Journey Pipeline Banner */}
          <div className={`p-3.5 rounded-2xl border text-xs space-y-2 ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-800/80 border-slate-700'
          }`}>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
              Core Career Execution Journey
            </span>
            <div className="flex items-center gap-1 text-[11px] overflow-x-auto no-scrollbar py-1 text-slate-600 dark:text-slate-300">
              <span className="px-2 py-1 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold whitespace-nowrap">Goal</span>
              <span>→</span>
              <span className="px-2 py-1 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold whitespace-nowrap">Skill Gap</span>
              <span>→</span>
              <span className="px-2 py-1 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold whitespace-nowrap">Course</span>
              <span>→</span>
              <span className="px-2 py-1 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold whitespace-nowrap">Video</span>
              <span>→</span>
              <span className="px-2 py-1 rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400 font-bold whitespace-nowrap">Practice</span>
              <span>→</span>
              <span className="px-2 py-1 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold whitespace-nowrap">Exam</span>
              <span>→</span>
              <span className="px-2 py-1 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-bold whitespace-nowrap">Certificate</span>
            </div>
          </div>

          {/* AI Recommended Certified Courses Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-500" />
                <span>Recommended Certified Courses ({certifiedCourses.length})</span>
              </h3>
              <button
                onClick={() => setLearnSubTab('certifications')}
                className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                View All
              </button>
            </div>

            <div className="space-y-3">
              {certifiedCourses.slice(0, 3).map((course) => (
                <CertifiedCourseCard
                  key={course.id}
                  course={course}
                  onOpenLearning={() => openCourseLearning(course.id)}
                  onOpenAssessment={() => openCourseAssessment(course.id)}
                  onOpenCertificate={() => openCertificateView(course.id)}
                  isLight={isLight}
                />
              ))}
            </div>
          </div>

          {/* Recommended Resources List */}
          <div className="space-y-3 pt-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-indigo-500" />
              <span>Personalized Study Notes & Cheat Sheets ({aiRecommendedResources.length})</span>
            </h3>

            {aiRecommendedResources.map((resource) => (
              <ResourceCard
                key={resource.id}
                resource={resource}
                isSaved={savedResourceIds.includes(resource.id)}
                onToggleSave={() => toggleSaveResource(resource.id)}
                onClick={() => setSelectedResourceForDetail(resource)}
                isLight={isLight}
              />
            ))}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* VIEW 2: CERTIFIED LEARNING (Dedicated Courses, Videos, Exams & Certs) */}
      {/* ============================================================== */}
      {learnSubTab === 'certifications' && (
        <div className="space-y-4">
          {/* Top Banner & Quick Verification Launcher */}
          <div className={`p-4 rounded-2xl border space-y-3 ${
            isLight
              ? 'bg-gradient-to-br from-amber-50 via-white to-indigo-50/50 border-amber-200 text-slate-900'
              : 'bg-gradient-to-br from-amber-950/40 via-slate-900 to-indigo-950/40 border-amber-500/30 text-white'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-500 flex items-center justify-center font-bold">
                  <Award className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold font-display">Certified Learning Curriculum</h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Industry-aligned courses • Interactive video lessons • Verified capstones
                  </p>
                </div>
              </div>

              <button
                onClick={() => openCertificateVerification()}
                className="px-2.5 py-1.5 rounded-xl border border-amber-500/40 text-[11px] font-bold text-amber-600 dark:text-amber-400 hover:bg-amber-500/10 flex items-center gap-1 transition-all"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Verify ID</span>
              </button>
            </div>

            <div className="p-2.5 rounded-xl bg-white/70 dark:bg-slate-900/60 border border-slate-200/60 dark:border-slate-800 text-xs space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white text-[11px]">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-500" />
                <span>NEXIF5 Credential Transparency Guarantee:</span>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                NEXIF5 completion certificates confirm verified practical tasks and passing score on comprehensive capstone exams. For statutory external certification, connect third-party credentials.
              </p>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="flex items-center gap-1.5 text-xs">
            <button
              onClick={() => setCourseFilter('all')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                courseFilter === 'all'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : isLight
                  ? 'bg-white text-slate-600 border border-slate-200'
                  : 'bg-slate-800 text-slate-300 border border-slate-700'
              }`}
            >
              All Courses ({certifiedCourses.length})
            </button>
            <button
              onClick={() => setCourseFilter('in_progress')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                courseFilter === 'in_progress'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : isLight
                  ? 'bg-white text-slate-600 border border-slate-200'
                  : 'bg-slate-800 text-slate-300 border border-slate-700'
              }`}
            >
              In Progress
            </button>
            <button
              onClick={() => setCourseFilter('earned')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                courseFilter === 'earned'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : isLight
                  ? 'bg-white text-slate-600 border border-slate-200'
                  : 'bg-slate-800 text-slate-300 border border-slate-700'
              }`}
            >
              Earned Certificates
            </button>
          </div>

          {/* Course Cards List */}
          <div className="space-y-3">
            {filteredCourses.map((course) => (
              <CertifiedCourseCard
                key={course.id}
                course={course}
                onOpenLearning={() => openCourseLearning(course.id)}
                onOpenAssessment={() => openCourseAssessment(course.id)}
                onOpenCertificate={() => openCertificateView(course.id)}
                isLight={isLight}
              />
            ))}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* VIEW 3: SHARED RESOURCES (Community Educational Documents) */}
      {/* ============================================================== */}
      {learnSubTab === 'shared' && (
        <div className="space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search study notes, cheat sheets, interview guides..."
              className={`w-full pl-10 pr-4 py-2.5 rounded-2xl border text-xs outline-hidden transition-all ${
                isLight
                  ? 'bg-white border-slate-200 focus:border-indigo-500'
                  : 'bg-slate-800 border-slate-700 text-white focus:border-indigo-400'
              }`}
            />
          </div>

          {/* Category Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : isLight
                    ? 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                    : 'bg-slate-800 border border-slate-700 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Filtered Resources List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>{filteredSharedResources.length} Documents Available</span>
              <span>Community Verified</span>
            </div>

            {filteredSharedResources.map((resource) => (
              <ResourceCard
                key={resource.id}
                resource={resource}
                isSaved={savedResourceIds.includes(resource.id)}
                onToggleSave={() => toggleSaveResource(resource.id)}
                onClick={() => setSelectedResourceForDetail(resource)}
                isLight={isLight}
              />
            ))}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* VIEW 4: SKILL PROGRESS & ACTION TASKS */}
      {/* ============================================================== */}
      {learnSubTab === 'tasks' && (
        <div className="space-y-4">
          <div className={`p-4 rounded-2xl border space-y-1.5 ${
            isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-800/60 border-slate-700'
          }`}>
            <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4" />
              <span>Skill Progress & Practical Action Cycle</span>
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Recommendation → Action → Completion → Progress.
              Complete practical mini-tasks to verify competencies and advance your career readiness.
            </p>
          </div>

          <div className="space-y-3">
            {skillProgressList.map((item, idx) => (
              <SkillProgressCard
                key={idx}
                item={item}
                onComplete={() => completeSkillTask(item.skill)}
                onOpenResource={(resId) => {
                  const targetRes = sharedResources.find(r => r.id === resId);
                  if (targetRes) setSelectedResourceForDetail(targetRes);
                  else setLearnSubTab('shared');
                }}
                isLight={isLight}
              />
            ))}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* VIEW 5: SAVED RESOURCES */}
      {/* ============================================================== */}
      {learnSubTab === 'saved' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 pb-1">
            <span className="font-bold uppercase tracking-wider">Saved Learning Library</span>
            <span>{savedResources.length} items</span>
          </div>

          {savedResources.length === 0 ? (
            <div className={`p-8 rounded-2xl border text-center space-y-3 ${
              isLight ? 'bg-white border-slate-200' : 'bg-slate-800/40 border-slate-700'
            }`}>
              <Bookmark className="w-10 h-10 text-slate-400 mx-auto" />
              <p className="text-xs font-bold text-slate-400">
                You haven't saved any educational documents yet.
              </p>
              <button
                onClick={() => setLearnSubTab('shared')}
                className="px-3.5 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
              >
                Explore Community Resources
              </button>
            </div>
          ) : (
            savedResources.map((resource) => (
              <ResourceCard
                key={resource.id}
                resource={resource}
                isSaved={true}
                onToggleSave={() => toggleSaveResource(resource.id)}
                onClick={() => setSelectedResourceForDetail(resource)}
                isLight={isLight}
              />
            ))
          )}
        </div>
      )}

      {/* ============================================================== */}
      {/* VIEW 6: MY UPLOADED RESOURCES */}
      {/* ============================================================== */}
      {learnSubTab === 'my_resources' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 pb-1">
            <span className="font-bold uppercase tracking-wider">My Shared Knowledge</span>
            <span>{myResources.length} uploaded</span>
          </div>

          {myResources.length === 0 ? (
            <div className={`p-8 rounded-2xl border text-center space-y-3 ${
              isLight ? 'bg-white border-slate-200' : 'bg-slate-800/40 border-slate-700'
            }`}>
              <Upload className="w-10 h-10 text-slate-400 mx-auto" />
              <p className="text-xs font-bold text-slate-400">
                You haven't uploaded any study materials yet.
              </p>
              <button
                onClick={() => setIsUploadResourceModalOpen(true)}
                className="px-3.5 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
              >
                Upload First Document
              </button>
            </div>
          ) : (
            myResources.map((resource) => (
              <div
                key={resource.id}
                className={`p-4 rounded-2xl border space-y-2.5 ${
                  isLight ? 'bg-white border-slate-200' : 'bg-slate-800/80 border-slate-700/80'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-500">
                      {resource.category} • {resource.fileType.toUpperCase()}
                    </span>
                    <h4 className="text-sm font-bold">{resource.title}</h4>
                  </div>
                  <button
                    onClick={() => deleteResource(resource.id)}
                    className="p-1 rounded-lg text-slate-400 hover:text-rose-500 transition-colors"
                    title="Delete resource"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100 dark:border-slate-800 text-slate-400">
                  <span>{resource.viewsCount} views • {resource.helpfulCount} helpful</span>
                  <button
                    onClick={() => setSelectedResourceForDetail(resource)}
                    className="text-xs font-bold text-indigo-500 flex items-center gap-1"
                  >
                    <span>Open Preview</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

// -------------------------------------------------------------
// Component: Certified Course Card
// -------------------------------------------------------------
interface CertifiedCourseCardProps {
  course: CertifiedCourse;
  onOpenLearning: () => void;
  onOpenAssessment: () => void;
  onOpenCertificate: () => void;
  isLight: boolean;
}

const CertifiedCourseCard: React.FC<CertifiedCourseCardProps> = ({
  course,
  onOpenLearning,
  onOpenAssessment,
  onOpenCertificate,
  isLight
}) => {
  return (
    <div
      className={`p-4 rounded-2xl border space-y-3 transition-all hover:border-indigo-400 ${
        isLight
          ? 'bg-white border-slate-200 shadow-xs hover:shadow-md'
          : 'bg-slate-800/80 border-slate-700/80'
      }`}
    >
      {/* Header Info */}
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-2 py-0.5 rounded-md bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 text-[10px] font-extrabold uppercase tracking-wider">
              {course.skill}
            </span>
            <span className="text-[10px] text-slate-400 font-medium">
              {course.durationLabel}
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
              {course.level}
            </span>
          </div>

          <h4 className="text-sm font-bold font-display mt-1.5">{course.title}</h4>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
            Provider: <strong>{course.provider}</strong> • {course.partner}
          </p>
        </div>

        {/* Status Badge */}
        <div className="shrink-0 text-right">
          {course.isCertificateEarned ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] font-extrabold uppercase tracking-wider border border-emerald-500/30">
              <Award className="w-3.5 h-3.5" />
              <span>Earned ✓</span>
            </span>
          ) : course.progressPercent >= 80 ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 text-[10px] font-extrabold uppercase tracking-wider border border-amber-500/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Exam Ready</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 text-[10px] font-extrabold uppercase tracking-wider">
              <span>{course.progressPercent}% Done</span>
            </span>
          )}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span>{course.videoLessons.filter(l => l.isCompleted).length} of {course.videoLessons.length} Modules Finished</span>
          <span className="font-bold text-slate-900 dark:text-white">{course.progressPercent}%</span>
        </div>
        <div className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              course.isCertificateEarned
                ? 'bg-emerald-500'
                : course.progressPercent >= 70
                ? 'bg-amber-500'
                : 'bg-indigo-500'
            }`}
            style={{ width: `${course.progressPercent}%` }}
          />
        </div>
      </div>

      {/* AI Recommendation Reason */}
      <div className={`p-2.5 rounded-xl text-xs leading-relaxed ${
        isLight ? 'bg-slate-50 text-slate-700' : 'bg-slate-900/60 text-slate-300'
      }`}>
        <span className="font-bold text-indigo-600 dark:text-indigo-400">AI Diagnostic: </span>
        {course.whyAiRecommended}
      </div>

      {/* Action Buttons Toolbar */}
      <div className="flex items-center justify-between pt-1 gap-2 flex-wrap">
        <button
          onClick={onOpenLearning}
          className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs active:scale-95 transition-all flex items-center gap-1.5"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>{course.progressPercent > 0 ? 'Continue Video Learning' : 'Start Video Lessons'}</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenAssessment}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all active:scale-95 flex items-center gap-1 ${
              isLight ? 'hover:bg-slate-100 border-slate-300 text-slate-700' : 'hover:bg-slate-700 border-slate-600 text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
            <span>AI Assessment</span>
          </button>

          {course.isCertificateEarned && (
            <button
              onClick={onOpenCertificate}
              className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-xs active:scale-95 transition-all flex items-center gap-1"
            >
              <Award className="w-3.5 h-3.5" />
              <span>Certificate</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

// -------------------------------------------------------------
// Component: Shared Resource Card Item
// -------------------------------------------------------------
interface ResourceCardProps {
  resource: SharedResource;
  isSaved: boolean;
  onToggleSave: () => void;
  onClick: () => void;
  isLight: boolean;
}

const ResourceCard: React.FC<ResourceCardProps> = ({
  resource,
  isSaved,
  onToggleSave,
  onClick,
  isLight
}) => {
  return (
    <div
      className={`p-4 rounded-2xl border space-y-3 transition-all hover:border-indigo-400 cursor-pointer ${
        isLight
          ? 'bg-white border-slate-200 hover:shadow-md'
          : 'bg-slate-800/80 border-slate-700/80 hover:bg-slate-800'
      }`}
      onClick={onClick}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="px-2 py-0.5 rounded-md bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 text-[10px] font-bold uppercase tracking-wider">
            {resource.category}
          </span>
          <span className="text-[10px] text-slate-400 font-medium">
            {resource.fileType.toUpperCase()} • {resource.fileSize}
          </span>
          {resource.aiRelevanceReason && (
            <span className="px-2 py-0.5 rounded-md bg-purple-500/15 text-purple-600 dark:text-purple-400 text-[10px] font-bold flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" />
              <span>AI Recommended</span>
            </span>
          )}
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleSave();
          }}
          className={`p-1.5 rounded-xl border transition-colors ${
            isSaved
              ? 'bg-indigo-600 border-indigo-600 text-white'
              : isLight
              ? 'bg-slate-100 border-slate-200 text-slate-500 hover:text-slate-900'
              : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
          }`}
          title={isSaved ? 'Saved to library' : 'Save resource'}
        >
          <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-current' : ''}`} />
        </button>
      </div>

      <div className="space-y-1">
        <h4 className="text-sm font-bold font-display leading-snug hover:text-indigo-500 transition-colors">
          {resource.title}
        </h4>
        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
          {resource.description}
        </p>
      </div>

      <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
          <span className="font-semibold text-indigo-600 dark:text-indigo-400 text-[11px]">
            {resource.skill}
          </span>
          <span>•</span>
          <span className="text-[11px] truncate max-w-[130px]">{resource.uploaderName}</span>
        </div>

        <div className="flex items-center gap-2.5 text-slate-400 text-[11px]">
          <span className="flex items-center gap-1">
            <ThumbsUp className="w-3 h-3 text-indigo-400" />
            <span>{resource.helpfulCount}</span>
          </span>
          <span className="flex items-center gap-1">
            <Eye className="w-3 h-3" />
            <span>{resource.viewsCount}</span>
          </span>
        </div>
      </div>
    </div>
  );
};

// -------------------------------------------------------------
// Component: Skill Progress & Action Task Card
// -------------------------------------------------------------
interface SkillProgressCardProps {
  item: SkillProgressItem;
  onComplete: () => void;
  onOpenResource: (resId?: string) => void;
  isLight: boolean;
}

const SkillProgressCard: React.FC<SkillProgressCardProps> = ({
  item,
  onComplete,
  onOpenResource,
  isLight
}) => {
  return (
    <div className={`p-4 rounded-2xl border space-y-3 ${
      isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
    }`}>
      <div className="flex items-start justify-between gap-2">
        <div>
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            {item.category}
          </span>
          <h4 className="text-sm font-bold font-display">{item.skill}</h4>
        </div>

        <div className="text-right">
          <span className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-bold ${
            item.progressPercent >= 70
              ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
              : 'bg-indigo-500/15 text-indigo-600 dark:text-indigo-400'
          }`}>
            {item.currentLevel} ({item.progressPercent}%)
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">
            Target: {item.targetLevel}
          </span>
        </div>
      </div>

      <div className="space-y-1">
        <div className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              item.progressPercent >= 70 ? 'bg-emerald-500' : 'bg-indigo-500'
            }`}
            style={{ width: `${item.progressPercent}%` }}
          />
        </div>
      </div>

      <div className={`p-2.5 rounded-xl text-xs leading-relaxed ${
        isLight ? 'bg-slate-50 text-slate-700' : 'bg-slate-900/60 text-slate-300'
      }`}>
        <span className="font-bold text-slate-900 dark:text-white">Why it matters: </span>
        {item.whyItMatters}
      </div>

      <div className={`p-3 rounded-xl border space-y-2 text-xs ${
        item.isTaskCompleted
          ? isLight
            ? 'bg-emerald-50/70 border-emerald-200'
            : 'bg-emerald-950/20 border-emerald-500/30'
          : isLight
          ? 'bg-indigo-50/70 border-indigo-200'
          : 'bg-indigo-950/30 border-indigo-500/30'
      }`}>
        <div className="flex items-start justify-between gap-2">
          <div className="space-y-0.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              {item.isTaskCompleted ? 'Verified Task' : 'Next Action Task'}
            </span>
            <p className="font-bold text-slate-900 dark:text-white">
              {item.nextActionTitle}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {item.nextActionDescription}
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between pt-1 gap-2 border-t border-slate-200 dark:border-slate-800">
          {item.relatedResourceId ? (
            <button
              onClick={() => onOpenResource(item.relatedResourceId)}
              className="text-[11px] text-indigo-600 dark:text-indigo-400 font-bold hover:underline flex items-center gap-1"
            >
              <span>Read Recommended Notes</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          ) : (
            <span className="text-[10px] text-slate-400">Impact: {item.careerReadinessImpact}</span>
          )}

          {!item.isTaskCompleted ? (
            <button
              onClick={onComplete}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs active:scale-95 transition-all flex items-center gap-1 shrink-0"
            >
              <span>Complete Task</span>
              <Check className="w-3.5 h-3.5" />
            </button>
          ) : (
            <span className="text-[11px] font-bold text-emerald-500 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Completed ✓</span>
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
