import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { JobOpportunity } from '../../types';
import {
  X,
  Briefcase,
  Sparkles,
  Plus,
  ArrowRight,
  CheckCircle2,
  DollarSign,
  MapPin
} from 'lucide-react';

interface RecruiterJobPostModalProps {
  onClose: () => void;
  onCreated?: () => void;
}

export const RecruiterJobPostModal: React.FC<RecruiterJobPostModalProps> = ({ onClose, onCreated }) => {
  const { postNewJob, currentCompany } = useApp();

  const [title, setTitle] = useState('');
  const [type, setType] = useState<'job' | 'internship'>('job');
  const [description, setDescription] = useState('');
  const [requiredSkills, setRequiredSkills] = useState('');
  const [qualifications, setQualifications] = useState('B.Com, B.Tech, BBA, BCA');
  const [experience, setExperience] = useState('Fresher / 0-1 Years');
  const [salaryDisplay, setSalaryDisplay] = useState('₹6.5 - 8.5 LPA');
  const [salaryMin, setSalaryMin] = useState(6.5);
  const [salaryMax, setSalaryMax] = useState(8.5);
  const [location, setLocation] = useState('Bengaluru, Karnataka');
  const [workMode, setWorkMode] = useState<'remote' | 'on_site' | 'hybrid'>('hybrid');
  const [deadline, setDeadline] = useState('2025-03-31');
  const [vacancies, setVacancies] = useState(4);
  const [perks, setPerks] = useState('Health Insurance, Mentorship, Performance Bonus, Flexible Hours');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !requiredSkills.trim()) return;

    postNewJob({
      title: title.trim(),
      type,
      description: description.trim() || `Exciting opening for ${title} at ${currentCompany.name}. Looking for motivated candidates with strong foundational skills.`,
      requiredSkills: requiredSkills.split(',').map(s => s.trim()).filter(Boolean),
      qualificationRequired: qualifications.split(',').map(s => s.trim()).filter(Boolean),
      experienceRequired: experience,
      salaryDisplay,
      salaryMinLPA: Number(salaryMin),
      salaryMaxLPA: Number(salaryMax),
      location,
      workMode,
      applicationDeadline: deadline,
      vacanciesCount: Number(vacancies),
      responsibilities: [
        'Collaborate with cross-functional teams on core deliverables',
        'Analyze data and present actionable insights to stakeholders',
        'Build and maintain documentation and project artifacts'
      ],
      perks: perks.split(',').map(s => s.trim()).filter(Boolean),
      isOpen: true
    });

    if (onCreated) onCreated();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Create New Job Requisition</h3>
              <p className="text-xs text-slate-500">Posting under {currentCompany.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Position Title *</label>
              <input
                type="text"
                placeholder="e.g. Associate Business Analyst, Data Scientist"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Opportunity Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none font-medium"
              >
                <option value="job">Full-Time Job</option>
                <option value="internship">Internship / PPO Track</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">
                Required Competencies (Comma separated) *
              </label>
              <input
                type="text"
                placeholder="e.g. SQL, Excel, Power BI, Business Analysis"
                value={requiredSkills}
                onChange={(e) => setRequiredSkills(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Nexif5 AI uses these exact competencies to calculate transparent candidate match scores.
              </span>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Eligible Degrees</label>
              <input
                type="text"
                value={qualifications}
                onChange={(e) => setQualifications(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Experience Level</label>
              <input
                type="text"
                value={experience}
                onChange={(e) => setExperience(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Salary Display Label</label>
              <input
                type="text"
                value={salaryDisplay}
                onChange={(e) => setSalaryDisplay(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Location & Work Mode</label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-2/3 p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                />
                <select
                  value={workMode}
                  onChange={(e) => setWorkMode(e.target.value as any)}
                  className="w-1/3 p-2.5 rounded-xl border border-slate-200 focus:outline-none font-medium"
                >
                  <option value="hybrid">Hybrid</option>
                  <option value="remote">Remote</option>
                  <option value="on_site">On-Site</option>
                </select>
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Job Description & Responsibilities</label>
              <textarea
                rows={3}
                placeholder="Outline the day-to-day responsibilities, problem statements, and team dynamic..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Application Deadline</label>
              <input
                type="date"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Number of Openings</label>
              <input
                type="number"
                value={vacancies}
                onChange={(e) => setVacancies(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                min={1}
              />
            </div>
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-900 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Publish Requisition</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
