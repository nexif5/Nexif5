import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  ShieldCheck,
  Search,
  CheckCircle2,
  AlertCircle,
  Award,
  Calendar,
  User,
  BookOpen,
  ArrowRight
} from 'lucide-react';

export const MobileCertificateVerificationModal: React.FC = () => {
  const {
    isVerificationModalOpen,
    setIsVerificationModalOpen,
    verificationQueryId,
    verifyCertificateById,
    openCertificateView,
    theme
  } = useApp();

  const isLight = theme === 'light';

  const [inputCertId, setInputCertId] = useState<string>('NXF-PBI-2026-00124');
  const [searchedCert, setSearchedCert] = useState<any | null>(null);
  const [hasSearched, setHasSearched] = useState<boolean>(false);

  useEffect(() => {
    if (verificationQueryId) {
      setInputCertId(verificationQueryId);
      const res = verifyCertificateById(verificationQueryId);
      setSearchedCert(res);
      setHasSearched(true);
    } else {
      // Default to Power BI sample
      const res = verifyCertificateById('NXF-PBI-2026-00124');
      setSearchedCert(res);
      setHasSearched(true);
    }
  }, [verificationQueryId]);

  if (!isVerificationModalOpen) {
    return null;
  }

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputCertId.trim()) return;
    const res = verifyCertificateById(inputCertId.trim());
    setSearchedCert(res);
    setHasSearched(true);
  };

  const sampleCertIds = [
    { id: 'NXF-PBI-2026-00124', label: 'Power BI' },
    { id: 'NXF-EXC-2026-00892', label: 'Excel' },
    { id: 'NXF-FIN-2026-00341', label: 'Financial Modeling' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className={`w-full max-w-xl max-h-[92vh] flex flex-col rounded-t-3xl sm:rounded-3xl border shadow-2xl overflow-hidden font-sans transition-all ${
          isLight ? 'bg-slate-50 text-slate-900 border-slate-200' : 'bg-slate-900 text-white border-slate-800'
        }`}
      >
        {/* Top Header */}
        <div
          className={`px-4 py-3.5 border-b flex items-center justify-between shrink-0 ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-800/80 border-slate-700/80'
          }`}
        >
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-500 flex items-center justify-center font-bold">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-500">
                Verification Portal
              </span>
              <h2 className="text-sm font-bold font-display">Verify NEXIF5 Certificate</h2>
            </div>
          </div>

          <button
            onClick={() => setIsVerificationModalOpen(false)}
            className={`p-1.5 rounded-full transition-colors shrink-0 ${
              isLight ? 'hover:bg-slate-100 text-slate-500' : 'hover:bg-slate-800 text-slate-400'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
          {/* Search Form */}
          <form onSubmit={handleSearch} className="space-y-2">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              Enter Certificate ID or Verification Code:
            </label>
            <div className="flex items-center gap-2">
              <div
                className={`flex-1 flex items-center gap-2 px-3 py-2.5 rounded-xl border text-xs ${
                  isLight ? 'bg-white border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              >
                <Search className="w-4 h-4 text-slate-400 shrink-0" />
                <input
                  type="text"
                  value={inputCertId}
                  onChange={(e) => setInputCertId(e.target.value)}
                  placeholder="e.g. NXF-PBI-2026-00124"
                  className="w-full bg-transparent outline-hidden font-mono font-bold uppercase"
                />
              </div>

              <button
                type="submit"
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all active:scale-95 shrink-0"
              >
                Verify
              </button>
            </div>

            {/* Quick Preset Buttons */}
            <div className="flex items-center gap-1.5 flex-wrap pt-1 text-[11px]">
              <span className="text-slate-400 text-[10px]">Test Presets:</span>
              {sampleCertIds.map(sample => (
                <button
                  key={sample.id}
                  type="button"
                  onClick={() => {
                    setInputCertId(sample.id);
                    const res = verifyCertificateById(sample.id);
                    setSearchedCert(res);
                    setHasSearched(true);
                  }}
                  className={`px-2 py-0.5 rounded-md font-mono text-[10px] border transition-all ${
                    inputCertId === sample.id
                      ? 'bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 border-indigo-400 font-bold'
                      : isLight
                      ? 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {sample.label}
                </button>
              ))}
            </div>
          </form>

          {/* Verification Result Card */}
          {hasSearched && (
            <div>
              {searchedCert ? (
                <div
                  className={`p-4 rounded-2xl border space-y-3 shadow-md ${
                    isLight
                      ? 'bg-gradient-to-br from-emerald-50 via-white to-slate-50 border-emerald-300 text-slate-900'
                      : 'bg-gradient-to-br from-emerald-950/40 via-slate-900 to-indigo-950/30 border-emerald-500/40 text-white'
                  }`}
                >
                  {/* Verified Header Badge */}
                  <div className="flex items-center justify-between pb-2 border-b border-emerald-500/20">
                    <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-extrabold text-xs">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>AUTHENTIC & VERIFIED</span>
                    </div>
                    <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-700 dark:text-emerald-300">
                      ID: {searchedCert.certificateId}
                    </span>
                  </div>

                  {/* Details Grid */}
                  <div className="space-y-2 text-xs">
                    <div className="flex items-start justify-between">
                      <span className="text-slate-400 text-[11px]">Certificate Holder</span>
                      <span className="font-bold text-slate-900 dark:text-white flex items-center gap-1">
                        <User className="w-3.5 h-3.5 text-indigo-500" />
                        <span>{searchedCert.learnerName}</span>
                      </span>
                    </div>

                    <div className="flex items-start justify-between">
                      <span className="text-slate-400 text-[11px]">Course Title</span>
                      <span className="font-bold text-right text-slate-900 dark:text-white max-w-[220px]">
                        {searchedCert.courseTitle}
                      </span>
                    </div>

                    <div className="flex items-start justify-between">
                      <span className="text-slate-400 text-[11px]">Certified Skill</span>
                      <span className="font-bold text-indigo-600 dark:text-indigo-400">
                        {searchedCert.skill}
                      </span>
                    </div>

                    <div className="flex items-start justify-between">
                      <span className="text-slate-400 text-[11px]">Assessment Grade</span>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">
                        {searchedCert.grade}
                      </span>
                    </div>

                    <div className="flex items-start justify-between">
                      <span className="text-slate-400 text-[11px]">Issuing Platform</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {searchedCert.issuerName}
                      </span>
                    </div>

                    <div className="flex items-start justify-between">
                      <span className="text-slate-400 text-[11px]">Curriculum Partner</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {searchedCert.partnerName}
                      </span>
                    </div>

                    <div className="flex items-start justify-between">
                      <span className="text-slate-400 text-[11px]">Issue Date</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {searchedCert.issueDate}
                      </span>
                    </div>
                  </div>

                  {/* Demonstrated Skills List */}
                  {searchedCert.skillsDemonstrated && (
                    <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        Verified Competencies:
                      </span>
                      <div className="flex flex-wrap gap-1">
                        {searchedCert.skillsDemonstrated.map((s: string, idx: number) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 rounded-md text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium"
                          >
                            ✓ {s}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* View Full Certificate Button */}
                  <div className="pt-2">
                    <button
                      onClick={() => {
                        setIsVerificationModalOpen(false);
                        openCertificateView(searchedCert.certificateId);
                      }}
                      className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all active:scale-98 flex items-center justify-center gap-1.5"
                    >
                      <Award className="w-4 h-4" />
                      <span>View Official Digital Certificate</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ) : (
                <div
                  className={`p-6 rounded-2xl border text-center space-y-2 ${
                    isLight ? 'bg-white border-slate-200' : 'bg-slate-800/60 border-slate-700'
                  }`}
                >
                  <AlertCircle className="w-8 h-8 text-amber-500 mx-auto" />
                  <h4 className="font-bold text-xs text-slate-900 dark:text-white">
                    No Record Found for "{inputCertId}"
                  </h4>
                  <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
                    Please ensure the ID is typed correctly, or test with one of the available sample IDs above.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Sticky Bottom Controls */}
        <div
          className={`px-4 py-3 border-t flex items-center justify-between shrink-0 ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-800/90 border-slate-700'
          }`}
        >
          <span className="text-[10px] text-slate-400">
            NEXIF5 Cryptographic Verification Service
          </span>

          <button
            onClick={() => setIsVerificationModalOpen(false)}
            className="px-3.5 py-1.5 rounded-xl border text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
