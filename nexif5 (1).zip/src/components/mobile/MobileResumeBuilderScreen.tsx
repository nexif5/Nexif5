import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, Download, Sparkles, CheckCircle2, ShieldCheck, Copy, Check } from 'lucide-react';

export const MobileResumeBuilderScreen: React.FC = () => {
  const { setSubView, currentStudent } = useApp();
  const [downloaded, setDownloaded] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleDownload = () => {
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 2500);
  };

  const handleCopy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-4 px-4 pt-4 pb-20 font-sans bg-slate-900 text-white min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSubView(null)}
            className="p-2 -ml-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-lg font-bold text-white font-display">ATS Resume Builder</h1>
            <p className="text-xs text-slate-400">AI-formatted for applicant tracking systems</p>
          </div>
        </div>
      </div>

      {/* ATS Score Card */}
      <div className="p-4 rounded-2xl bg-slate-800/80 border border-emerald-500/40 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-extrabold text-base font-display">
            92%
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">ATS Compatibility Score</h3>
            <p className="text-[11px] text-emerald-400 font-medium">Standard structure & keyword dense</p>
          </div>
        </div>
        <div className="shrink-0 flex items-center gap-1 text-[11px] text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Verified</span>
        </div>
      </div>

      {/* Resume Document Paper View (Mobile Styled) */}
      <div className="p-5 rounded-2xl bg-white text-slate-900 shadow-xl space-y-4 text-xs font-sans">
        {/* Resume Header */}
        <div className="border-b border-slate-300 pb-3 text-center space-y-1">
          <h2 className="text-base font-extrabold tracking-tight text-slate-900 uppercase">
            {currentStudent.name}
          </h2>
          <p className="text-[11px] text-slate-600 font-medium">
            {currentStudent.email} | +91 98765 43210 | Coimbatore, India
          </p>
          <p className="text-[11px] text-indigo-700 font-semibold">
            {currentStudent.headline || 'Business Analyst Candidate'}
          </p>
        </div>

        {/* Summary */}
        <div className="space-y-1">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-0.5">
            Professional Summary
          </h3>
          <p className="text-[11px] text-slate-700 leading-relaxed">
            Analytical and detail-oriented candidate with deep expertise in Python, SQL, and Power BI. Proven ability to translate complex datasets into business intelligence and actionable executive insights.
          </p>
        </div>

        {/* Education */}
        <div className="space-y-1">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-0.5">
            Education
          </h3>
          <div className="flex justify-between font-bold text-slate-900 text-[11px]">
            <span>{currentStudent.education.institution}</span>
            <span>{currentStudent.education.yearOfPassing}</span>
          </div>
          <p className="text-[11px] text-slate-700">
            {currentStudent.education.degree} in {currentStudent.education.course} • {currentStudent.education.cgpaOrPercentage}
          </p>
        </div>

        {/* Skills */}
        <div className="space-y-1">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-0.5">
            Core Competencies & Skills
          </h3>
          <p className="text-[11px] text-slate-700 leading-normal">
            <b>Technical:</b> {currentStudent.skills.map(s => s.name).join(', ')}
          </p>
          <p className="text-[11px] text-slate-700 leading-normal">
            <b>Methodologies:</b> Data Cleansing, Predictive Modeling, KPI Dashboards, Agile
          </p>
        </div>

        {/* Key Projects */}
        <div className="space-y-1">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-0.5">
            Key Projects
          </h3>
          <p className="text-[11px] font-bold text-slate-900">
            Customer Churn & Sentiment Analytics Platform
          </p>
          <ul className="list-disc pl-4 text-[10px] text-slate-700 space-y-0.5">
            <li>Engineered ETL pipeline processing 100k+ customer records using Python and PostgreSQL.</li>
            <li>Constructed interactive Power BI dashboards boosting business team visibility by 40%.</li>
          </ul>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-2 pt-2">
        <button
          onClick={handleDownload}
          className="w-full py-4 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
        >
          {downloaded ? (
            <>
              <Check className="w-4 h-4" />
              <span>Resume Downloaded!</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4" />
              <span>Download ATS-Formatted PDF</span>
            </>
          )}
        </button>

        <button
          onClick={handleCopy}
          className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs flex items-center justify-center gap-2 transition-colors"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400">Copied to Clipboard</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy Plain Text Content</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
