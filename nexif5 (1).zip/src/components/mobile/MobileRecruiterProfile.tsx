import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Building2,
  Mail,
  Phone,
  Globe,
  MapPin,
  Briefcase,
  Users,
  CheckCircle2,
  ShieldCheck,
  Plus
} from 'lucide-react';

export const MobileRecruiterProfile: React.FC = () => {
  const { currentCompany, jobs, theme } = useApp();
  const isLight = theme === 'light';

  const companyJobs = jobs.filter(j => j.companyId === currentCompany.id || !j.companyId);

  return (
    <div className={`p-4 space-y-4 pb-24 font-sans ${isLight ? 'text-slate-900' : 'text-white'}`}>
      {/* Company Header Card */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-start gap-3.5">
          <img
            src={currentCompany.logoUrl}
            alt={currentCompany.name}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-500 shadow-md"
          />
          <div className="space-y-0.5">
            <div className="flex items-center gap-1.5">
              <h1 className="text-base font-bold font-display">{currentCompany.name}</h1>
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
            </div>
            <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
              {currentCompany.industry}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>{currentCompany.headquarters}</span>
            </p>
          </div>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          {currentCompany.description}
        </p>

        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-700/60 text-xs">
          <div>
            <span className="text-slate-500 dark:text-slate-400 text-[10px] block">Company Size</span>
            <span className="font-bold">{currentCompany.employeeCount}</span>
          </div>
          <div>
            <span className="text-slate-500 dark:text-slate-400 text-[10px] block">Active Postings</span>
            <span className="font-bold">{companyJobs.length} Requisitions</span>
          </div>
        </div>
      </div>

      {/* Recruiter Authorized Contact */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center gap-2">
          <Briefcase className="w-4 h-4 text-emerald-500" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Recruiter Account Details
          </h2>
        </div>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/50 border border-slate-700/60">
            <span className="text-slate-400">Lead Recruiter</span>
            <span className="font-bold">Rajesh Menon</span>
          </div>
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/50 border border-slate-700/60">
            <span className="text-slate-400">Work Email</span>
            <span className="font-bold">rajesh.m@abctechnologies.io</span>
          </div>
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/50 border border-slate-700/60">
            <span className="text-slate-400">Title / Department</span>
            <span className="font-bold">Head of Talent Acquisition</span>
          </div>
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/50 border border-slate-700/60">
            <span className="text-slate-400">Hiring Scope</span>
            <span className="font-bold">Pan-India & Hybrid</span>
          </div>
        </div>
      </div>

      {/* Verified Hiring Locations */}
      <div className={`p-4 rounded-2xl border space-y-2.5 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
          Target Hiring Locations
        </h2>
        <div className="flex flex-wrap gap-1.5">
          {currentCompany.locations.map((loc, idx) => (
            <span
              key={idx}
              className="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-xs font-medium text-slate-300"
            >
              📍 {loc}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
