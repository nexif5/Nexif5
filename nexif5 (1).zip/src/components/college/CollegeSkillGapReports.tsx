import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  School,
  ArrowRight,
  BookOpen,
  Layers
} from 'lucide-react';

export const CollegeSkillGapReports: React.FC = () => {
  const { currentCollege, setActiveCollegeTab } = useApp();

  const departmentHeatmap = [
    {
      department: 'Commerce & Accounting (B.Com)',
      demandScore: 92,
      criticalGapSkill: 'SQL (Multi-Table Queries)',
      studentReadiness: '62%',
      recruiterDemand: 'High (84% of BA roles require SQL)',
      recommendedAction: 'Mandate 15-hour practical SQL lab on financial transaction querying.'
    },
    {
      department: 'Business Administration (BBA)',
      demandScore: 86,
      criticalGapSkill: 'Power BI & DAX Visualizations',
      studentReadiness: '54%',
      recruiterDemand: 'High (76% of Analyst roles require Power BI)',
      recommendedAction: 'Introduce live case study dashboard assignments in semester 5.'
    },
    {
      department: 'Computer Science (B.Tech)',
      demandScore: 94,
      criticalGapSkill: 'Cloud Deployment & Docker Containers',
      studentReadiness: '71%',
      recruiterDemand: 'Very High (90% of Backend/SDE roles)',
      recommendedAction: 'Add hands-on containerization module to Systems Lab.'
    },
    {
      department: 'Computer Applications (BCA)',
      demandScore: 88,
      criticalGapSkill: 'API Development & Postman Testing',
      studentReadiness: '66%',
      recruiterDemand: 'High (82% of Junior Dev roles)',
      recommendedAction: 'Conduct hackathon focused on RESTful microservice architectures.'
    }
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-purple-600 mb-1">
          <Sparkles className="w-4 h-4" />
          <span>REAL-TIME CURRICULUM & RECRUITER ALIGNMENT</span>
        </div>
        <h1 className="text-2xl font-bold text-slate-900 font-display">
          Departmental Skill Gap Diagnostics
        </h1>
        <p className="text-xs text-slate-500">
          Comparing {currentCollege.name} student competencies against 1,400+ live 2025 recruiter requisitions
        </p>
      </div>

      {/* Heatmap & Gap Cards */}
      <div className="space-y-4">
        {departmentHeatmap.map((item, idx) => (
          <div
            key={idx}
            className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-purple-50 text-purple-700 font-bold text-sm">
                  <School className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">{item.department}</h3>
                  <span className="text-xs text-slate-500">Recruiter Demand Index: <strong>{item.demandScore}/100</strong></span>
                </div>
              </div>

              <div className="flex items-center gap-3 text-xs">
                <span className="text-slate-500">Cohort Readiness:</span>
                <span className="px-3 py-1 bg-amber-50 text-amber-800 font-bold rounded-full border border-amber-200">
                  {item.studentReadiness} Match
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-rose-50/50 border border-rose-100 space-y-1.5">
                <div className="flex items-center gap-1.5 text-rose-700 font-bold">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Primary Competency Deficit</span>
                </div>
                <strong className="text-slate-900 text-sm block">{item.criticalGapSkill}</strong>
                <p className="text-slate-600 text-[11px]">{item.recruiterDemand}</p>
              </div>

              <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-100 space-y-1.5">
                <div className="flex items-center gap-1.5 text-emerald-800 font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Recommended Academic Intervention</span>
                </div>
                <p className="text-slate-800 leading-relaxed text-xs">
                  {item.recommendedAction}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* AI Curriculum Advisor Prompt Callout */}
      <div className="bg-gradient-to-r from-purple-900 to-indigo-900 text-white rounded-2xl p-6 shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h3 className="text-base font-bold font-display">Need custom training module blueprints?</h3>
          <p className="text-xs text-purple-200">
            Ask Nexif5 AI to generate syllabus outlines and practice datasets tailored to active company hiring drives.
          </p>
        </div>

        <button
          onClick={() => setActiveCollegeTab('ai_advisor')}
          className="px-5 py-2.5 bg-white text-purple-900 hover:bg-purple-50 rounded-xl font-bold text-xs shadow-xs transition-colors shrink-0 flex items-center gap-2"
        >
          <span>Ask AI Placement Advisor</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
