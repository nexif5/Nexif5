import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { JobOpportunity } from '../../types';
import { RecruiterJobPostModal } from './RecruiterJobPostModal';
import { JobDetailModal } from '../common/JobDetailModal';
import {
  Briefcase,
  Plus,
  Search,
  MapPin,
  Users,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Eye,
  SlidersHorizontal
} from 'lucide-react';

export const RecruiterJobs: React.FC = () => {
  const { currentCompany, jobs, setActiveRecruiterTab } = useApp();
  const [showPostModal, setShowPostModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedJob, setSelectedJob] = useState<JobOpportunity | null>(null);

  const companyJobs = jobs.filter(j => j.companyId === currentCompany.id);
  const filteredJobs = companyJobs.filter(j =>
    j.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    j.requiredSkills.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
            <Briefcase className="w-4 h-4" />
            <span>JOB REQUISITION MANAGEMENT</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 font-display">
            Active Job & Internship Postings ({companyJobs.length})
          </h1>
          <p className="text-xs text-slate-500">
            Requisitions created under {currentCompany.name}
          </p>
        </div>

        <button
          onClick={() => setShowPostModal(true)}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs shadow-xs hover:shadow transition-all flex items-center gap-2 w-fit"
        >
          <Plus className="w-4 h-4" />
          <span>Post New Job Requisition</span>
        </button>
      </div>

      {/* Filter & Search */}
      <div className="flex items-center justify-between gap-3">
        <div className="relative max-w-md w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Filter requisitions by title or required skill..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
          />
        </div>
      </div>

      {/* Jobs Table / Cards */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-semibold text-[10px] tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Position Title</th>
                <th className="py-3.5 px-4">Type & Mode</th>
                <th className="py-3.5 px-4">Compensation</th>
                <th className="py-3.5 px-4">Applicants</th>
                <th className="py-3.5 px-4">Deadline</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredJobs.map((job) => (
                <tr key={job.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-4 px-4">
                    <div className="space-y-0.5">
                      <strong className="text-slate-900 font-bold text-xs block">{job.title}</strong>
                      <span className="text-[11px] text-slate-400">ID: {job.id}</span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="space-y-0.5">
                      <span className="capitalize font-semibold text-slate-800 block">{job.type}</span>
                      <span className="text-[11px] text-slate-500 capitalize">{job.workMode}</span>
                    </div>
                  </td>
                  <td className="py-4 px-4 font-bold text-emerald-700">
                    {job.salaryDisplay}
                  </td>
                  <td className="py-4 px-4">
                    <span className="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 font-bold text-xs">
                      {job.applicantsCount} Candidates
                    </span>
                  </td>
                  <td className="py-4 px-4 text-slate-500">
                    {job.applicationDeadline}
                  </td>
                  <td className="py-4 px-4">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-semibold text-[11px] border border-emerald-200 flex items-center gap-1 w-fit">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Active
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => setSelectedJob(job)}
                        className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600"
                        title="View Requisition Details"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setActiveRecruiterTab('applications')}
                        className="px-2.5 py-1 bg-slate-900 hover:bg-indigo-600 text-white rounded-lg font-bold text-[11px] transition-colors"
                      >
                        Review Applicants
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showPostModal && (
        <RecruiterJobPostModal
          onClose={() => setShowPostModal(false)}
        />
      )}

      {selectedJob && (
        <JobDetailModal
          job={selectedJob}
          onClose={() => setSelectedJob(null)}
        />
      )}
    </div>
  );
};
