import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, CheckCircle2, FileText, Sparkles, Send, ShieldCheck, X } from 'lucide-react';

export const MobileApplicationFlowModal: React.FC = () => {
  const {
    selectedJobForApply,
    setSelectedJobForApply,
    currentStudent,
    applyForJob,
    setMobileTab
  } = useApp();

  const [step, setStep] = useState<'review' | 'success'>('review');
  const [coverNote, setCoverNote] = useState(
    `I am excited to apply for the ${selectedJobForApply?.title || 'role'} at ${selectedJobForApply?.companyName || 'your company'}. My background in ${currentStudent.education.course} and proven skills in ${currentStudent.skills.slice(0, 3).map(s => s.name).join(', ')} make me a strong candidate.`
  );
  const [selectedResume, setSelectedResume] = useState('Aarav_Patel_ATS_Resume_2025.pdf');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!selectedJobForApply) return null;

  const job = selectedJobForApply;

  const handleConfirmApply = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      applyForJob(job.id, coverNote);
      setIsSubmitting(false);
      setStep('success');
    }, 600);
  };

  const handleClose = () => {
    setSelectedJobForApply(null);
    setStep('review');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/95 backdrop-blur-md text-white flex flex-col justify-between p-4 font-sans overflow-y-auto">
      {step === 'review' ? (
        <div className="space-y-4 max-w-md mx-auto w-full">
          {/* Top Bar */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <button
              onClick={handleClose}
              className="p-2 -ml-2 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <h2 className="text-sm font-bold text-white">Apply to {job.companyName}</h2>
            <div className="w-5" />
          </div>

          {/* Job Card Header */}
          <div className="p-3.5 rounded-2xl bg-slate-800 border border-slate-700 flex items-center gap-3">
            <img
              src={job.companyLogoUrl}
              alt={job.companyName}
              className="w-12 h-12 rounded-xl object-cover border border-slate-700"
            />
            <div>
              <h3 className="font-bold text-white text-sm">{job.title}</h3>
              <p className="text-xs text-slate-400">{job.companyName} • {job.location}</p>
              <p className="text-xs text-emerald-400 font-semibold mt-0.5">{job.salaryRange}</p>
            </div>
          </div>

          {/* Resume Selection */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-300">
              Selected ATS Resume
            </label>
            <div className="p-3 rounded-xl bg-slate-800/80 border border-indigo-500/50 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <FileText className="w-5 h-5 text-indigo-400" />
                <div>
                  <p className="text-xs font-bold text-white">{selectedResume}</p>
                  <p className="text-[10px] text-emerald-400">92% ATS Score • Tailored for {job.title}</p>
                </div>
              </div>
              <span className="text-xs text-indigo-400 font-semibold">Active</span>
            </div>
          </div>

          {/* Note to Recruiter / Cover Letter */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-300">
              Note to Hiring Team (Optional)
            </label>
            <textarea
              rows={4}
              value={coverNote}
              onChange={(e) => setCoverNote(e.target.value)}
              className="w-full p-3 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          {/* Candidate Profile Details Snapshot */}
          <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-800 text-xs text-slate-300 space-y-1.5">
            <div className="flex justify-between">
              <span className="text-slate-400">Applicant:</span>
              <span className="font-semibold text-white">{currentStudent.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Email:</span>
              <span className="font-semibold text-white">{currentStudent.email}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">College:</span>
              <span className="font-semibold text-white">{currentStudent.education.institution}</span>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              onClick={handleConfirmApply}
              disabled={isSubmitting}
              className="w-full py-4 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
            >
              {isSubmitting ? (
                <span>Submitting Application...</span>
              ) : (
                <>
                  <span>Submit Application</span>
                  <Send className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      ) : (
        /* Success Screen */
        <div className="my-auto max-w-sm mx-auto text-center space-y-5 p-4">
          <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-white font-display">
              Application Submitted!
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Your profile and ATS resume were securely dispatched to <b>{job.companyName}</b> for <b>{job.title}</b>.
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 text-left text-xs space-y-1">
            <p className="text-slate-400 font-medium">Application Status:</p>
            <p className="text-emerald-400 font-bold">Under Review by Hiring Team</p>
          </div>

          <div className="space-y-2 pt-2">
            <button
              onClick={() => {
                handleClose();
                setMobileTab('applications');
              }}
              className="w-full py-3.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition-all"
            >
              View in Applications Tracker
            </button>

            <button
              onClick={handleClose}
              className="w-full py-3 px-4 rounded-xl bg-slate-800 text-slate-300 font-semibold text-xs hover:bg-slate-700 transition-colors"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
