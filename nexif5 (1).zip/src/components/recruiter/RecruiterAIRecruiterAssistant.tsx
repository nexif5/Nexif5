import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { handleRecruiterAIQuery } from '../../services/aiEngine';
import { StudentCandidate } from '../../types';
import {
  Bot,
  Sparkles,
  Send,
  Search,
  CheckCircle2,
  Users,
  Award,
  CalendarCheck,
  Building,
  School,
  ArrowRight,
  ShieldCheck,
  Lightbulb
} from 'lucide-react';

export const RecruiterAIRecruiterAssistant: React.FC = () => {
  const { students, jobs, currentCompany, setActiveRecruiterTab } = useApp();

  const [query, setQuery] = useState('');
  const [selectedCandidate, setSelectedCandidate] = useState<StudentCandidate | null>(null);

  const defaultPromptSuggestions = [
    'Find B.Com freshers with Excel, SQL and Power BI',
    'Show candidates with 85%+ readiness for Business Analyst',
    'Find students with national competition achievements',
    'Show top ranked candidates across partner colleges'
  ];

  const [chatHistory, setChatHistory] = useState<{
    id: string;
    sender: 'user' | 'ai';
    text: string;
    candidates?: any[];
    actions?: string[];
  }[]>([
    {
      id: 'r-init',
      sender: 'ai',
      text: `Hello **${currentCompany.name} Talent Team**! I am your **Nexif5 Recruiter AI Talent Search Engine**.\n\nYou can query in natural language to discover, match, and rank verified student candidates across both independent sign-ups and affiliated colleges.\n\n*Human-in-the-loop guarantee: AI computes match scores and evidence highlights; all shortlisting, interviewing, and offer decisions remain entirely in recruiter control.*`,
      actions: [
        'Find B.Com freshers with Excel, SQL and Power BI',
        'Show candidates with 85%+ readiness for Business Analyst'
      ]
    }
  ]);

  const handleRunQuery = (textToSend?: string) => {
    const q = textToSend || query;
    if (!q.trim()) return;

    setChatHistory(prev => [
      ...prev,
      { id: `user-${Date.now()}`, sender: 'user', text: q }
    ]);
    if (!textToSend) setQuery('');

    setTimeout(() => {
      const result = handleRecruiterAIQuery(q, students, jobs);
      setChatHistory(prev => [
        ...prev,
        {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: result.summary,
          candidates: result.rankedCandidates,
          actions: result.suggestedFilters
        }
      ]);
    }, 400);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
          <Bot className="w-4 h-4" />
          <span>NATURAL LANGUAGE TALENT SOURCING</span>
        </div>
        <h1 className="text-2xl font-bold text-slate-900 font-display">
          AI Candidate Sourcing & Semantic Match
        </h1>
        <p className="text-xs text-slate-500">
          Scan verified achievements, academic records, and technical portfolios using plain language criteria
        </p>
      </div>

      {/* Suggested Chips */}
      <div className="flex flex-wrap gap-2">
        {defaultPromptSuggestions.map((sug, i) => (
          <button
            key={i}
            onClick={() => handleRunQuery(sug)}
            className="px-3 py-1.5 rounded-xl bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-xs font-semibold text-slate-700 hover:text-indigo-700 transition-all shadow-2xs flex items-center gap-1.5"
          >
            <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
            <span>{sug}</span>
          </button>
        ))}
      </div>

      {/* Chat / Results Window */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col h-[650px] overflow-hidden">
        {/* Messages */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-5">
          {chatHistory.map((item) => (
            <div
              key={item.id}
              className={`flex gap-3 text-xs leading-relaxed ${
                item.sender === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {item.sender === 'ai' && (
                <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0 shadow-xs mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`p-4 rounded-2xl max-w-2xl space-y-3 ${
                  item.sender === 'user'
                    ? 'bg-indigo-600 text-white rounded-tr-none'
                    : 'bg-slate-50 border border-slate-200 text-slate-800 rounded-tl-none'
                }`}
              >
                <div className="whitespace-pre-line space-y-2">
                  {item.text}
                </div>

                {/* Candidate Match Ranking Cards */}
                {item.candidates && item.candidates.length > 0 && (
                  <div className="space-y-2.5 pt-2 border-t border-slate-200/80">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Ranked Matching Candidate Profiles ({item.candidates.length}):
                    </span>

                    {item.candidates.map((cand, idx) => (
                      <div
                        key={idx}
                        className="bg-white p-3.5 rounded-xl border border-slate-200 hover:border-indigo-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                      >
                        <div className="flex items-start gap-3">
                          <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-700 font-bold flex items-center justify-center shrink-0 text-[11px]">
                            #{idx + 1}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <strong className="text-slate-900 font-bold text-sm">{cand.name}</strong>
                              <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200">
                                {cand.matchScore}% Match
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500">
                              {cand.education} {cand.course ? `• ${cand.course}` : ''} ({cand.college || 'Independent Candidate'})
                            </p>
                            <p className="text-[11px] text-slate-700 pt-1 font-medium">
                              💡 <em>{cand.highlight}</em>
                            </p>
                          </div>
                        </div>

                        <button
                          onClick={() => setActiveRecruiterTab('applications')}
                          className="px-3 py-1.5 bg-slate-900 hover:bg-indigo-600 text-white rounded-lg font-bold text-[11px] shrink-0 transition-colors"
                        >
                          View in Pipeline
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Action Suggestions */}
                {item.actions && item.actions.length > 0 && (
                  <div className="pt-2 border-t border-slate-200/80 space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      Refine Query Criteria:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {item.actions.map((act, i) => (
                        <button
                          key={i}
                          onClick={() => handleRunQuery(act)}
                          className="px-2.5 py-1 rounded-lg bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-[11px] text-slate-700 transition-colors"
                        >
                          {act}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Query Input */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleRunQuery();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="e.g. Find B.Com freshers with Excel, SQL and Power BI..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1 p-3 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
            />
            <button
              type="submit"
              disabled={!query.trim()}
              className="p-3 bg-slate-900 hover:bg-indigo-600 text-white rounded-xl shadow-xs transition-colors disabled:opacity-40"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
