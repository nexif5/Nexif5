import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { JobOpportunity } from '../../types';
import { calculateJobMatch } from '../../services/aiEngine';
import { JobDetailModal } from '../common/JobDetailModal';
import { JobApplyModal } from '../common/JobApplyModal';
import {
  Search,
  Filter,
  MapPin,
  Building2,
  Briefcase,
  Sparkles,
  GraduationCap,
  DollarSign,
  CheckCircle2,
  Send,
  X,
  SlidersHorizontal,
  RotateCcw
} from 'lucide-react';

interface StudentJobSearchProps {
  initialType?: 'job' | 'internship' | 'all';
}

export const StudentJobSearch: React.FC<StudentJobSearchProps> = ({ initialType = 'all' }) => {
  const { currentStudent, jobs, applications } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<'all' | 'job' | 'internship'>(initialType);
  const [selectedWorkMode, setSelectedWorkMode] = useState<string>('all');
  const [selectedLocation, setSelectedLocation] = useState<string>('all');
  const [fresherOnly, setFresherOnly] = useState(false);
  const [highMatchOnly, setHighMatchOnly] = useState(false);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const [detailJob, setDetailJob] = useState<JobOpportunity | null>(null);
  const [applyJob, setApplyJob] = useState<JobOpportunity | null>(null);

  // Compute matched jobs with scores
  const matchedJobs = useMemo(() => {
    return jobs
      .filter(j => j.isOpen)
      .map(job => ({
        job,
        match: calculateJobMatch(currentStudent, job)
      }));
  }, [jobs, currentStudent]);

  // Filter jobs
  const filteredJobs = useMemo(() => {
    return matchedJobs.filter(({ job, match }) => {
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = job.title.toLowerCase().includes(q);
        const matchesCompany = job.companyName.toLowerCase().includes(q);
        const matchesSkill = job.requiredSkills.some(s => s.toLowerCase().includes(q));
        const matchesLocation = job.location.toLowerCase().includes(q);
        if (!matchesTitle && !matchesCompany && !matchesSkill && !matchesLocation) return false;
      }

      // Type
      if (selectedType !== 'all' && job.type !== selectedType) return false;

      // Work Mode
      if (selectedWorkMode !== 'all' && job.workMode !== selectedWorkMode) return false;

      // Location
      if (selectedLocation !== 'all' && !job.location.toLowerCase().includes(selectedLocation.toLowerCase())) return false;

      // Fresher
      if (fresherOnly && !job.experienceRequired.toLowerCase().includes('fresher') && !job.experienceRequired.includes('0-1')) return false;

      // High Match
      if (highMatchOnly && match.overallScore < 85) return false;

      return true;
    }).sort((a, b) => b.match.overallScore - a.match.overallScore);
  }, [matchedJobs, searchQuery, selectedType, selectedWorkMode, selectedLocation, fresherOnly, highMatchOnly]);

  const uniqueLocations = Array.from(new Set(jobs.map(j => j.location.split(',')[0].trim())));

  const activeFiltersCount = (selectedType !== 'all' ? 1 : 0) +
    (selectedWorkMode !== 'all' ? 1 : 0) +
    (selectedLocation !== 'all' ? 1 : 0) +
    (fresherOnly ? 1 : 0) +
    (highMatchOnly ? 1 : 0);

  const handleResetFilters = () => {
    setSelectedType('all');
    setSelectedWorkMode('all');
    setSelectedLocation('all');
    setFresherOnly(false);
    setHighMatchOnly(false);
    setSearchQuery('');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
          <Briefcase className="w-4 h-4" />
          <span>REAL-TIME OPPORTUNITY EXPLORER</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 font-display">
          {selectedType === 'internship' ? 'Explore Internships & PPO Tracks' : 'Verified Career Opportunities'}
        </h1>
        <p className="text-xs text-slate-500">
          Ranked in real-time by Nexif5 AI against your profile, verified skills, and academic goals
        </p>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white p-3 sm:p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by role, company, skill (SQL, Excel, React), or city..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-8 py-2.5 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50/50"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Mobile Filter Button */}
          <button
            onClick={() => setMobileFilterOpen(true)}
            className="sm:hidden px-3 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-700 text-xs font-bold flex items-center gap-1.5 shrink-0 relative active:bg-slate-100"
          >
            <SlidersHorizontal className="w-4 h-4 text-indigo-600" />
            <span>Filters</span>
            {activeFiltersCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-indigo-600 text-white text-[10px] font-black flex items-center justify-center">
                {activeFiltersCount}
              </span>
            )}
          </button>

          {/* Desktop Select Dropdowns */}
          <div className="hidden sm:flex items-center gap-2">
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value as any)}
              className="px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 focus:outline-none bg-white"
            >
              <option value="all">All Opportunities</option>
              <option value="job">Full-Time Jobs</option>
              <option value="internship">Internships</option>
            </select>

            <select
              value={selectedWorkMode}
              onChange={(e) => setSelectedWorkMode(e.target.value)}
              className="px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 focus:outline-none bg-white"
            >
              <option value="all">Any Work Mode</option>
              <option value="hybrid">Hybrid</option>
              <option value="remote">Remote</option>
              <option value="on_site">On-Site</option>
            </select>
          </div>
        </div>

        {/* Filter Quick Pills (Desktop + Tablet) */}
        <div className="hidden sm:flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100 text-xs">
          <span className="text-[11px] text-slate-400 font-medium mr-1">Quick Filters:</span>

          <button
            onClick={() => setHighMatchOnly(!highMatchOnly)}
            className={`px-3 py-1 rounded-full font-bold transition-all flex items-center gap-1.5 ${
              highMatchOnly
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Sparkles className="w-3 h-3" />
            <span>85%+ AI Match</span>
          </button>

          <button
            onClick={() => setFresherOnly(!fresherOnly)}
            className={`px-3 py-1 rounded-full font-bold transition-all ${
              fresherOnly
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <span>Freshers / 2025 Batch</span>
          </button>

          {uniqueLocations.map((loc) => (
            <button
              key={loc}
              onClick={() => setSelectedLocation(selectedLocation === loc ? 'all' : loc)}
              className={`px-3 py-1 rounded-full font-semibold transition-all ${
                selectedLocation === loc
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {loc}
            </button>
          ))}

          {activeFiltersCount > 0 && (
            <button
              onClick={handleResetFilters}
              className="text-[11px] text-rose-600 hover:text-rose-800 font-semibold ml-auto flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-slate-500 px-1">
        <span>
          Showing <strong>{filteredJobs.length}</strong> matching positions
        </span>
        <span className="text-[11px] hidden sm:inline">Ranked by AI Match Score</span>
      </div>

      {/* Job Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
        {filteredJobs.map(({ job, match }) => {
          const alreadyApplied = applications.find(
            a => a.jobId === job.id && a.candidateId === currentStudent.id
          );

          return (
            <div
              key={job.id}
              className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                {/* Top Company Logo & Match Score */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={job.companyLogoUrl}
                      alt={job.companyName}
                      className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl object-cover border border-slate-200 shrink-0"
                    />
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-tight">{job.title}</h3>
                      <p className="text-xs font-semibold text-indigo-600 mt-0.5">{job.companyName}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end shrink-0">
                    <span className="px-2.5 py-1 rounded-lg bg-indigo-600 text-white font-bold text-xs shadow-xs">
                      {match.overallScore}%
                    </span>
                    <span className="text-[9px] text-slate-400 mt-0.5">Match</span>
                  </div>
                </div>

                {/* Meta details */}
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 pt-1">
                  <span className="flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-md">
                    <MapPin className="w-3 h-3 text-slate-400" /> {job.location.split(',')[0]}
                  </span>
                  <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                    {job.salaryDisplay}
                  </span>
                  <span className="capitalize bg-slate-100 px-2 py-0.5 rounded-md text-slate-600 text-[11px]">
                    {job.workMode.replace('_', ' ')}
                  </span>
                </div>

                {/* Match Reason Banner */}
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-[11px] text-slate-700 space-y-0.5">
                  <span className="font-semibold text-slate-900 block">Why this matches you:</span>
                  <p className="text-slate-600 line-clamp-2 leading-relaxed">{match.whyItMatches[0]}</p>
                </div>

                {/* Skills Chips */}
                <div className="flex flex-wrap gap-1 pt-1">
                  {job.requiredSkills.slice(0, 3).map((sk, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-semibold"
                    >
                      {sk}
                    </span>
                  ))}
                  {job.requiredSkills.length > 3 && (
                    <span className="px-1.5 py-0.5 rounded-md bg-slate-50 text-slate-400 text-[10px]">
                      +{job.requiredSkills.length - 3}
                    </span>
                  )}
                </div>
              </div>

              {/* Actions Footer */}
              <div className="pt-3.5 mt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => setDetailJob(job)}
                  className="text-xs font-semibold text-slate-700 hover:text-slate-900 py-2 px-3 rounded-xl hover:bg-slate-100 transition-colors min-h-[40px] flex items-center"
                >
                  View Details
                </button>

                {alreadyApplied ? (
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-3.5 py-2 rounded-xl border border-emerald-200 flex items-center gap-1 min-h-[40px]">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Applied
                  </span>
                ) : (
                  <button
                    onClick={() => setApplyJob(job)}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow transition-all flex items-center gap-1.5 min-h-[40px] active:scale-95"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Apply Now</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Mobile Filter Bottom Sheet Modal */}
      {mobileFilterOpen && (
        <div className="sm:hidden fixed inset-0 z-50 flex flex-col justify-end bg-slate-900/60 backdrop-blur-xs">
          <div className="flex-1" onClick={() => setMobileFilterOpen(false)} />
          <div className="bg-white rounded-t-3xl border-t border-slate-200 p-5 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-base">Filter Opportunities</h3>
              </div>
              <button
                onClick={() => setMobileFilterOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Opportunity Type */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-800">Opportunity Type</label>
              <div className="grid grid-cols-3 gap-2">
                {(['all', 'job', 'internship'] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setSelectedType(t)}
                    className={`py-2 rounded-xl text-xs font-semibold capitalize border ${
                      selectedType === t
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    {t === 'all' ? 'All' : t === 'job' ? 'Full-Time' : 'Internship'}
                  </button>
                ))}
              </div>
            </div>

            {/* Work Mode */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-800">Work Mode</label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'all', label: 'Any Mode' },
                  { id: 'hybrid', label: 'Hybrid' },
                  { id: 'remote', label: 'Remote' },
                  { id: 'on_site', label: 'On-Site' }
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setSelectedWorkMode(m.id)}
                    className={`py-2 rounded-xl text-xs font-semibold border ${
                      selectedWorkMode === m.id
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Toggles */}
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <label
                onClick={() => setHighMatchOnly(!highMatchOnly)}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs font-semibold text-slate-800">85%+ High AI Match Only</span>
                </div>
                <input
                  type="checkbox"
                  checked={highMatchOnly}
                  onChange={() => {}}
                  className="w-4 h-4 accent-indigo-600"
                />
              </label>

              <label
                onClick={() => setFresherOnly(!fresherOnly)}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-blue-600" />
                  <span className="text-xs font-semibold text-slate-800">Freshers / 2025 Eligible</span>
                </div>
                <input
                  type="checkbox"
                  checked={fresherOnly}
                  onChange={() => {}}
                  className="w-4 h-4 accent-blue-600"
                />
              </label>
            </div>

            {/* Locations */}
            <div className="space-y-1.5 pt-2 border-t border-slate-100">
              <label className="text-xs font-bold text-slate-800">Locations</label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setSelectedLocation('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${
                    selectedLocation === 'all'
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  All Locations
                </button>
                {uniqueLocations.map((loc) => (
                  <button
                    key={loc}
                    onClick={() => setSelectedLocation(loc)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${
                      selectedLocation === loc
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    {loc}
                  </button>
                ))}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-slate-100 flex items-center gap-3">
              <button
                onClick={handleResetFilters}
                className="flex-1 py-3 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50"
              >
                Reset All
              </button>
              <button
                onClick={() => setMobileFilterOpen(false)}
                className="flex-1 py-3 rounded-xl bg-indigo-600 text-white text-xs font-bold shadow-md hover:bg-indigo-700"
              >
                Show Results ({filteredJobs.length})
              </button>
            </div>
          </div>
        </div>
      )}

      {detailJob && (
        <JobDetailModal
          job={detailJob}
          onClose={() => setDetailJob(null)}
        />
      )}

      {applyJob && (
        <JobApplyModal
          job={applyJob}
          onClose={() => setApplyJob(null)}
        />
      )}
    </div>
  );
};

