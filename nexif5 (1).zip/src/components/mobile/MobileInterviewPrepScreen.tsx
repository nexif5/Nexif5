import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, Sparkles, Send, CheckCircle2, ChevronRight, RefreshCw, Award } from 'lucide-react';

const MOCK_QUESTIONS = [
  {
    id: 1,
    role: 'Business Analyst',
    question: 'How do you handle ambiguous requirements from business stakeholders when designing a new feature?',
    sampleAnswer: 'I start by scheduling structured discovery workshops, identifying core business goals and constraints. Next, I create wireframes and user stories with clear acceptance criteria, then validate iteratively with stakeholders to resolve ambiguity early.'
  },
  {
    id: 2,
    role: 'Data Analyst',
    question: 'Explain the difference between WHERE and HAVING clauses in SQL, with a real-world use case.',
    sampleAnswer: 'WHERE filters individual rows before any aggregation takes place, whereas HAVING filters aggregated groups created by GROUP BY (such as filtering departments where AVG(salary) > 50,000).'
  },
  {
    id: 3,
    role: 'Business Analyst',
    question: 'Describe a project where you used data visualization to persuade decision-makers to take action.',
    sampleAnswer: 'In my churn analytics project, I built a waterfall chart showing where users dropped off in the onboarding funnel. This highlighted a 35% friction point at payment, prompting the team to simplify checkout and recover 18% conversions.'
  }
];

export const MobileInterviewPrepScreen: React.FC = () => {
  const { setSubView, currentStudent } = useApp();
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [feedback, setFeedback] = useState<{ score: number; strengths: string; improvements: string } | null>(null);
  const [isEvaluating, setIsEvaluating] = useState(false);

  const q = MOCK_QUESTIONS[currentQIndex];

  const handleEvaluate = () => {
    if (!userAnswer.trim()) return;
    setIsEvaluating(true);
    setTimeout(() => {
      setIsEvaluating(false);
      setFeedback({
        score: 88,
        strengths: 'Clear structured reasoning, effective mention of iterative validation and measurable outcomes.',
        improvements: 'Consider adding a metric example (e.g. % reduced rework) to make your response even more impactful.'
      });
    }, 800);
  };

  const handleNextQuestion = () => {
    setFeedback(null);
    setUserAnswer('');
    setCurrentQIndex((currentQIndex + 1) % MOCK_QUESTIONS.length);
  };

  return (
    <div className="space-y-4 px-4 pt-4 pb-20 font-sans bg-slate-900 text-white min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSubView(null)}
            className="p-2 -ml-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-lg font-bold text-white font-display">Mock Interview Prep</h1>
            <p className="text-xs text-slate-400">Target Role: {q.role}</p>
          </div>
        </div>
        <span className="text-xs text-indigo-400 font-bold">
          Q{currentQIndex + 1} of {MOCK_QUESTIONS.length}
        </span>
      </div>

      {/* Question Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/60 to-slate-800 border border-indigo-500/40 space-y-2">
        <div className="flex items-center gap-2">
          <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 text-[10px] font-bold uppercase">
            Behavioral / Technical
          </span>
        </div>
        <h2 className="text-sm font-bold text-white leading-snug">
          "{q.question}"
        </h2>
      </div>

      {/* Answer Box */}
      <div className="space-y-2">
        <label className="block text-xs font-semibold text-slate-300">
          Your Answer
        </label>
        <textarea
          rows={5}
          value={userAnswer}
          onChange={(e) => setUserAnswer(e.target.value)}
          placeholder="Type your response here using the STAR method (Situation, Task, Action, Result)..."
          className="w-full p-3.5 bg-slate-800/90 border border-slate-700 rounded-2xl text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-indigo-500 leading-relaxed"
        />

        <div className="flex gap-2">
          <button
            onClick={handleEvaluate}
            disabled={!userAnswer.trim() || isEvaluating}
            className="flex-1 py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs shadow-lg flex items-center justify-center gap-1.5 transition-all"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>{isEvaluating ? 'Evaluating Response...' : 'Evaluate Answer with AI'}</span>
          </button>
        </div>
      </div>

      {/* AI Feedback Card */}
      {feedback && (
        <div className="p-4 rounded-2xl bg-slate-800/80 border border-emerald-500/40 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
              <Award className="w-4 h-4" />
              <span>AI Evaluation Feedback</span>
            </h3>
            <span className="text-sm font-extrabold text-emerald-400">{feedback.score}/100</span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="p-2.5 rounded-xl bg-emerald-950/30 border border-emerald-800/40">
              <p className="text-[10px] font-bold text-emerald-300 uppercase">Strengths</p>
              <p className="text-slate-200 mt-0.5 leading-relaxed">{feedback.strengths}</p>
            </div>

            <div className="p-2.5 rounded-xl bg-amber-950/30 border border-amber-800/40">
              <p className="text-[10px] font-bold text-amber-300 uppercase">Suggested Improvements</p>
              <p className="text-slate-200 mt-0.5 leading-relaxed">{feedback.improvements}</p>
            </div>
          </div>

          {/* Model Answer */}
          <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase">Model Exemplar Answer</p>
            <p className="text-xs text-slate-300 leading-relaxed italic">{q.sampleAnswer}</p>
          </div>

          <button
            onClick={handleNextQuestion}
            className="w-full py-3 rounded-xl bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
          >
            <span>Next Practice Question</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
