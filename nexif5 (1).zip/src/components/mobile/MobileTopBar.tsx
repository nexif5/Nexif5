import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  Search,
  Bell,
  Sun,
  Moon,
  Bot,
  MessageSquare,
  Users
} from 'lucide-react';

interface MobileTopBarProps {
  onOpenNotifications: () => void;
  onOpenProfileMenu: () => void;
  onOpenSearch: () => void;
}

export const MobileTopBar: React.FC<MobileTopBarProps> = ({
  onOpenNotifications,
  onOpenProfileMenu,
  onOpenSearch
}) => {
  const {
    currentStudent,
    currentProfessional,
    currentCompany,
    currentCollege,
    currentMentor,
    currentRole,
    notifications,
    theme,
    toggleTheme,
    setMobileTab,
    mobileTab,
    setSubView,
    chatConversations,
    connectionRequests
  } = useApp();

  const unreadCount = notifications.filter(n => !n.read).length;
  const unreadMessagesCount = chatConversations.reduce((acc, c) => acc + (c.unreadCount || 0), 0);
  const pendingRequestsCount = connectionRequests.filter(r => r.status === 'pending' && r.receiverId === (
    currentRole === 'recruiter' ? currentCompany.id :
    currentRole === 'college' ? currentCollege.id :
    currentRole === 'mentor' ? currentMentor.id :
    currentRole === 'professional' ? currentProfessional.id :
    currentStudent.id
  )).length;
  const isLight = theme === 'light';

  const currentAvatar =
    currentRole === 'recruiter'
      ? currentCompany.logoUrl
      : currentRole === 'college'
      ? currentCollege.logoUrl
      : currentRole === 'professional' || currentRole === 'job_seeker'
      ? currentProfessional.avatarUrl
      : currentRole === 'mentor'
      ? currentMentor.avatarUrl
      : currentRole === 'admin'
      ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'
      : currentStudent.avatarUrl;

  const currentDisplayName =
    currentRole === 'recruiter'
      ? currentCompany.name
      : currentRole === 'college'
      ? currentCollege.name
      : currentRole === 'professional' || currentRole === 'job_seeker'
      ? currentProfessional.name
      : currentRole === 'mentor'
      ? currentMentor.name
      : currentRole === 'admin'
      ? 'Admin Central'
      : currentStudent.name;

  return (
    <header className={`sticky top-0 z-40 backdrop-blur-md px-3.5 py-2 flex items-center justify-between shadow-xs transition-colors duration-200 border-b ${
      isLight
        ? 'bg-white/95 border-slate-200 text-slate-900'
        : 'bg-slate-900/95 border-slate-800/80 text-white'
    }`}>
      {/* Brand Logo */}
      <div
        onClick={() => setMobileTab('home')}
        className="flex items-center gap-1.5 cursor-pointer select-none"
      >
        <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center shadow-md shadow-indigo-500/20 border border-indigo-400/30">
          <Sparkles className="w-3.5 h-3.5 text-white" />
        </div>
        <div>
          <span className={`text-sm font-extrabold tracking-tight font-display block leading-none ${
            isLight ? 'text-slate-900' : 'text-white'
          }`}>
            NEXIF5
          </span>
        </div>
      </div>

      {/* Right Controls: AI Coach Fast Launch, Theme Toggle, Notification Bell, Profile Avatar */}
      <div className="flex items-center gap-1.5">
        {/* Fast AI Coach Launcher Button (Only for Learners/Professionals) */}
        {(currentRole === 'student' || currentRole === 'professional' || currentRole === 'job_seeker') && (
          <button
            onClick={() => setMobileTab('ai')}
            className={`px-2 py-1 rounded-xl transition-all active:scale-95 flex items-center gap-1 text-xs font-bold border ${
              mobileTab === 'ai'
                ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm'
                : isLight
                ? 'bg-indigo-50 hover:bg-indigo-100 text-indigo-600 border-indigo-200'
                : 'bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-300 border-indigo-500/40'
            }`}
            title="Ask Nexif5 AI Coach"
          >
            <Bot className="w-3.5 h-3.5" />
            <span className="text-[10px]">AI Coach</span>
          </button>
        )}

        {/* Network & Connections Hub Button */}
        <button
          onClick={() => setSubView('network')}
          className={`p-1.5 rounded-xl transition-colors relative active:scale-95 ${
            isLight
              ? 'text-slate-600 hover:text-indigo-600 hover:bg-slate-100'
              : 'text-slate-300 hover:text-indigo-400 hover:bg-slate-800'
          }`}
          aria-label="Professional Network"
          title="Professional Network"
        >
          <Users className="w-4 h-4" />
          {pendingRequestsCount > 0 && (
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
          )}
        </button>

        {/* Professional Direct Messages Button */}
        <button
          onClick={() => setSubView('messages')}
          className={`p-1.5 rounded-xl transition-colors relative active:scale-95 ${
            isLight
              ? 'text-slate-600 hover:text-indigo-600 hover:bg-slate-100'
              : 'text-slate-300 hover:text-indigo-400 hover:bg-slate-800'
          }`}
          aria-label="Messages"
          title="Professional Messages"
        >
          <MessageSquare className="w-4 h-4" />
          {unreadMessagesCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 min-w-[14px] h-[14px] px-0.5 rounded-full bg-rose-500 text-white text-[8px] font-bold flex items-center justify-center">
              {unreadMessagesCount}
            </span>
          )}
        </button>

        {/* Theme Quick Toggle Button */}
        <button
          onClick={toggleTheme}
          className={`p-1.5 rounded-xl transition-all active:scale-95 ${
            isLight
              ? 'text-slate-600 hover:text-indigo-600 hover:bg-slate-100'
              : 'text-slate-300 hover:text-amber-400 hover:bg-slate-800'
          }`}
          aria-label={isLight ? 'Switch to Dark Mode' : 'Switch to White Mode'}
          title={isLight ? 'Dark Mode' : 'White Mode'}
        >
          {isLight ? (
            <Moon className="w-4 h-4" />
          ) : (
            <Sun className="w-4 h-4 text-amber-400" />
          )}
        </button>

        {/* Notification Bell */}
        <button
          onClick={onOpenNotifications}
          className={`p-1.5 rounded-xl transition-colors relative active:scale-95 ${
            isLight
              ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              : 'text-slate-300 hover:text-white hover:bg-slate-800'
          }`}
          aria-label="Notifications"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
          )}
        </button>

        {/* Profile Avatar */}
        <button
          onClick={onOpenProfileMenu}
          className="p-0.5 rounded-full ring-2 ring-indigo-500/50 hover:ring-indigo-400 transition-all active:scale-95 ml-0.5"
          aria-label="Profile Menu"
          title={currentDisplayName}
        >
          <img
            src={currentAvatar}
            alt={currentDisplayName}
            className="w-7 h-7 rounded-full object-cover"
          />
        </button>
      </div>
    </header>
  );
};

