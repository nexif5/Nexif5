import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeft,
  UserPlus,
  MessageSquare,
  Bookmark,
  Share2,
  Check,
  Clock,
  Building2,
  GraduationCap,
  Award,
  Briefcase,
  Sparkles,
  MapPin,
  Mail,
  Phone,
  ShieldCheck,
  Globe,
  ExternalLink,
  Star,
  CalendarCheck,
  FileText,
  Lock,
  ChevronRight
} from 'lucide-react';
import { UserRole } from '../../types';

export const MobileUserProfileViewScreen: React.FC = () => {
  const {
    theme,
    setSubView,
    viewingProfileUserId,
    smartRecommendations,
    userConnections,
    connectionRequests,
    sendConnectionRequest,
    acceptConnectionRequest,
    cancelConnectionRequest,
    removeConnection,
    toggleFollowUser,
    startOrOpenConversation,
    getConnectionStatusWithUser,
    students,
    professionals,
    mentors,
    companies,
    colleges,
    jobs
  } = useApp();

  const isLight = theme === 'light';
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const targetId = viewingProfileUserId || 'men-1';

  // Search across all models for target profile
  const recMatch = smartRecommendations.find(r => r.userId === targetId);
  const mentorMatch = mentors.find(m => m.id === targetId);
  const proMatch = professionals.find(p => p.id === targetId);
  const studentMatch = students.find(s => s.id === targetId);
  const companyMatch = companies.find(c => c.id === targetId);
  const collegeMatch = colleges.find(c => c.id === targetId);

  // Determine user role
  const role: UserRole =
    recMatch?.role ||
    (mentorMatch ? 'mentor' : proMatch ? 'professional' : studentMatch ? 'student' : companyMatch ? 'recruiter' : collegeMatch ? 'college' : 'professional');

  const name =
    recMatch?.name ||
    mentorMatch?.name ||
    proMatch?.name ||
    studentMatch?.name ||
    companyMatch?.name ||
    collegeMatch?.name ||
    'Professional Profile';

  const avatar =
    recMatch?.avatarUrl ||
    mentorMatch?.avatarUrl ||
    proMatch?.avatarUrl ||
    studentMatch?.avatarUrl ||
    companyMatch?.logoUrl ||
    collegeMatch?.logoUrl ||
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200';

  const headline =
    recMatch?.headline ||
    mentorMatch?.jobTitle + ' @ ' + mentorMatch?.company ||
    proMatch?.currentJobTitle + ' @ ' + proMatch?.currentCompany ||
    studentMatch?.careerGoal ||
    companyMatch?.tagline ||
    collegeMatch?.name ||
    'NEXIF5 Member';

  const location =
    recMatch?.location ||
    mentorMatch?.location ||
    proMatch?.location ||
    (studentMatch ? 'New Delhi, India' : '') ||
    companyMatch?.location ||
    collegeMatch?.location ||
    'India';

  const organization =
    recMatch?.organization ||
    mentorMatch?.company ||
    proMatch?.currentCompany ||
    studentMatch?.education.institution ||
    companyMatch?.name ||
    collegeMatch?.name ||
    '';

  const connectionStatus = getConnectionStatusWithUser(targetId);
  const isFollowing = recMatch?.isFollowing || userConnections.find(c => c.peerId === targetId)?.isFollowing;

  // Company open jobs
  const companyJobs = (companyMatch || recMatch?.role === 'recruiter')
    ? jobs.filter(j => j.companyId === companyMatch?.id || j.companyName.toLowerCase().includes(name.toLowerCase()))
    : [];

  const getRoleBadge = (r: UserRole) => {
    switch (r) {
      case 'student':
        return { label: 'Student', color: 'bg-indigo-500/15 text-indigo-500 border-indigo-500/30', icon: <GraduationCap className="w-3.5 h-3.5" /> };
      case 'professional':
      case 'job_seeker':
        return { label: 'Working Professional', color: 'bg-amber-500/15 text-amber-500 border-amber-500/30', icon: <Briefcase className="w-3.5 h-3.5" /> };
      case 'recruiter':
        return { label: 'Recruiter & Company', color: 'bg-emerald-500/15 text-emerald-500 border-emerald-500/30', icon: <Building2 className="w-3.5 h-3.5" /> };
      case 'mentor':
        return { label: 'Industry Mentor', color: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30', icon: <Award className="w-3.5 h-3.5" /> };
      case 'college':
        return { label: 'College / Institution', color: 'bg-purple-500/15 text-purple-400 border-purple-500/30', icon: <Building2 className="w-3.5 h-3.5" /> };
      default:
        return { label: 'NEXIF5 Member', color: 'bg-slate-500/15 text-slate-400 border-slate-500/30', icon: <ShieldCheck className="w-3.5 h-3.5" /> };
    }
  };

  const badge = getRoleBadge(role);

  return (
    <div className={`min-h-screen pb-24 ${isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-slate-100'}`}>
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-indigo-600 text-white font-medium text-xs shadow-xl flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Bar */}
      <div className={`sticky top-0 z-30 px-4 py-3 backdrop-blur-md border-b flex items-center justify-between ${
        isLight ? 'bg-white/95 border-slate-200' : 'bg-slate-900/95 border-slate-800'
      }`}>
        <button
          onClick={() => setSubView('network')}
          className={`p-2 rounded-xl transition-colors ${
            isLight ? 'text-slate-600 hover:bg-slate-100' : 'text-slate-400 hover:bg-slate-800'
          }`}
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <span className="text-xs font-bold font-display">Professional Profile</span>

        <button
          onClick={() => {
            toggleFollowUser(targetId);
            showToast(isFollowing ? `Unfollowed ${name}` : `Following ${name}`);
          }}
          className={`p-2 rounded-xl border transition-colors ${
            isFollowing
              ? 'bg-indigo-500/15 text-indigo-500 border-indigo-500/30'
              : isLight
              ? 'text-slate-500 hover:bg-slate-100 border-slate-200'
              : 'text-slate-400 hover:bg-slate-800 border-slate-700'
          }`}
          title={isFollowing ? 'Following' : 'Follow'}
        >
          <Bookmark className="w-4 h-4" fill={isFollowing ? 'currentColor' : 'none'} />
        </button>
      </div>

      {/* Profile Cover & Avatar Card */}
      <div className="px-4 pt-4">
        <div className={`rounded-3xl border overflow-hidden ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-800'
        }`}>
          {/* Cover Header */}
          <div className="h-28 bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 relative p-4 flex justify-end">
            <span className="px-2.5 py-1 rounded-full bg-black/30 backdrop-blur-md text-white text-[10px] font-bold flex items-center gap-1 border border-white/20 self-start">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>Verified Account</span>
            </span>
          </div>

          {/* User Details */}
          <div className="px-5 pb-5 pt-0 relative">
            <div className="-mt-12 flex items-end justify-between mb-3">
              <img
                src={avatar}
                alt={name}
                className="w-24 h-24 rounded-full object-cover border-4 border-white dark:border-slate-800 shadow-md"
              />
              <span className={`px-2.5 py-1 rounded-xl text-xs font-bold border flex items-center gap-1.5 ${badge.color}`}>
                {badge.icon}
                <span>{badge.label}</span>
              </span>
            </div>

            <h1 className="text-xl font-bold font-display leading-tight">{name}</h1>
            <p className={`text-xs mt-1 leading-snug font-medium ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
              {headline}
            </p>

            <div className="mt-2 flex items-center gap-3 text-[11px] text-slate-400 flex-wrap">
              {organization && (
                <span className="flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5" />
                  {organization}
                </span>
              )}
              {location && (
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" />
                  {location}
                </span>
              )}
            </div>

            {/* Quick Action Buttons Row */}
            <div className="mt-4 pt-4 border-t flex items-center gap-2 border-slate-200 dark:border-slate-700/60">
              {connectionStatus === 'connected' ? (
                <div className="flex-1 flex items-center justify-center gap-1 py-2 px-3 rounded-xl bg-emerald-500/10 text-emerald-500 font-bold text-xs border border-emerald-500/20">
                  <Check className="w-4 h-4" />
                  <span>Connected</span>
                </div>
              ) : connectionStatus === 'pending_sent' ? (
                <button
                  onClick={() => {
                    const req = connectionRequests.find(r => r.receiverId === targetId && r.status === 'pending');
                    if (req) cancelConnectionRequest(req.id);
                    showToast('Invitation cancelled.');
                  }}
                  className={`flex-1 py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1 ${
                    isLight ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-amber-950/40 text-amber-400 border-amber-900/50'
                  }`}
                >
                  <Clock className="w-4 h-4" />
                  <span>Request Sent (Cancel)</span>
                </button>
              ) : connectionStatus === 'pending_received' ? (
                <button
                  onClick={() => {
                    const req = connectionRequests.find(r => r.senderId === targetId && r.status === 'pending');
                    if (req) acceptConnectionRequest(req.id);
                    showToast(`Connected with ${name}!`);
                  }}
                  className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-xs"
                >
                  <Check className="w-4 h-4" />
                  <span>Accept Request</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    const res = sendConnectionRequest(targetId);
                    showToast(res.message);
                  }}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-transform active:scale-95"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Connect</span>
                </button>
              )}

              <button
                onClick={() => startOrOpenConversation(targetId)}
                className="flex-1 py-2.5 px-3 rounded-xl bg-indigo-500/15 hover:bg-indigo-500/25 text-indigo-600 dark:text-indigo-400 font-bold text-xs flex items-center justify-center gap-1.5 border border-indigo-500/30 transition-transform active:scale-95"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Message</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* AI Relevance Card (Why Recommended) */}
      {recMatch && (
        <div className="px-4 pt-3">
          <div className={`p-4 rounded-2xl border flex items-start gap-3 ${
            isLight
              ? 'bg-gradient-to-r from-indigo-50 to-purple-50/50 border-indigo-100 text-indigo-950'
              : 'bg-gradient-to-r from-indigo-950/40 to-purple-950/20 border-indigo-900/50 text-indigo-200'
          }`}>
            <Sparkles className="w-5 h-5 text-indigo-500 shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed">
              <p className="font-bold text-indigo-600 dark:text-indigo-400">NEXIF5 AI Connection Analysis</p>
              <p className="mt-1">{recMatch.whyAiRecommended}</p>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* ROLE-SPECIFIC DETAILED SECTIONS */}
      {/* ------------------------------------------------------------------ */}
      <div className="px-4 pt-4 space-y-4">
        {/* 1. MENTOR SPECIFIC SECTION */}
        {role === 'mentor' && mentorMatch && (
          <>
            <div className={`p-4 rounded-2xl border space-y-3 ${
              isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-800'
            }`}>
              <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-500 flex items-center gap-1.5">
                <Award className="w-4 h-4" />
                <span>Mentorship & Expertise</span>
              </h2>

              <p className={`text-xs leading-relaxed ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                {mentorMatch.bio}
              </p>

              <div>
                <p className={`text-[11px] font-bold mb-1.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  Domains of Guidance:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {mentorMatch.domains.map((dom, i) => (
                    <span key={i} className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
                      {dom}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-2 border-t grid grid-cols-3 gap-2 text-center border-slate-200 dark:border-slate-700/60">
                <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                  <p className="text-base font-bold text-indigo-500">{mentorMatch.experienceYears}+</p>
                  <p className="text-[10px] text-slate-400">Yrs Experience</p>
                </div>
                <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                  <p className="text-base font-bold text-emerald-500">{mentorMatch.totalMenteesCount}</p>
                  <p className="text-[10px] text-slate-400">Mentees Guided</p>
                </div>
                <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                  <p className="text-base font-bold text-amber-500">{mentorMatch.averageRating} ★</p>
                  <p className="text-[10px] text-slate-400">Rating</p>
                </div>
              </div>
            </div>

            <div className={`p-4 rounded-2xl border space-y-2.5 ${
              isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-800'
            }`}>
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <CalendarCheck className="w-4 h-4 text-indigo-500" />
                <span>Mentorship Formats Offered</span>
              </h2>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {mentorMatch.mentorshipTypes.map((type, i) => (
                  <div key={i} className={`p-2.5 rounded-xl border flex items-center gap-2 ${
                    isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-700'
                  }`}>
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                    <span className="font-semibold text-[11px]">{type}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* 2. RECRUITER / COMPANY SECTION */}
        {(role === 'recruiter' || companyMatch) && (
          <>
            <div className={`p-4 rounded-2xl border space-y-3 ${
              isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-800'
            }`}>
              <h2 className="text-xs font-bold uppercase tracking-wider text-emerald-500 flex items-center gap-1.5">
                <Building2 className="w-4 h-4" />
                <span>Hiring & Company Overview</span>
              </h2>

              <p className={`text-xs leading-relaxed ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                {companyMatch?.description || 'Active hiring partner on NEXIF5. Connecting with top students and professionals for high-growth tech roles.'}
              </p>

              {companyMatch && (
                <div className="grid grid-cols-2 gap-2 pt-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400">Industry:</span>
                    <p className="font-bold text-[11px]">{companyMatch.industry}</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] text-slate-400">Company Size:</span>
                    <p className="font-bold text-[11px]">{companyMatch.companySize || '500+ Employees'}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Active Job Openings from this Company */}
            {companyJobs.length > 0 && (
              <div className={`p-4 rounded-2xl border space-y-3 ${
                isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-800'
              }`}>
                <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-500 flex items-center gap-1.5">
                  <Briefcase className="w-4 h-4" />
                  <span>Active Openings ({companyJobs.length})</span>
                </h2>

                <div className="space-y-2">
                  {companyJobs.map((job) => (
                    <div
                      key={job.id}
                      className={`p-3 rounded-xl border flex items-center justify-between ${
                        isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-700'
                      }`}
                    >
                      <div className="min-w-0">
                        <p className="font-bold text-xs truncate">{job.title}</p>
                        <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                          {job.jobType} • ₹{job.salaryRangeMinLPA} - {job.salaryRangeMaxLPA} LPA
                        </p>
                      </div>

                      <button
                        onClick={() => startOrOpenConversation(targetId)}
                        className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold"
                      >
                        Inquire
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* 3. WORKING PROFESSIONAL SECTION */}
        {(role === 'professional' || role === 'job_seeker') && proMatch && (
          <div className={`p-4 rounded-2xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-800'
          }`}>
            <h2 className="text-xs font-bold uppercase tracking-wider text-amber-500 flex items-center gap-1.5">
              <Briefcase className="w-4 h-4" />
              <span>Career Journey & Core Skills</span>
            </h2>

            <div className="flex items-center gap-3 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 flex-1">
                <span className="text-[10px] text-slate-400">Experience:</span>
                <p className="font-bold text-sm text-indigo-500">{proMatch.totalExperienceYears} Years</p>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 flex-1">
                <span className="text-[10px] text-slate-400">Target Role:</span>
                <p className="font-bold text-xs truncate">{proMatch.targetJobRole}</p>
              </div>
            </div>

            {proMatch.skills.length > 0 && (
              <div>
                <p className={`text-[11px] font-bold mb-1.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  Skills:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {proMatch.skills.map((s) => (
                    <span key={s.id} className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-amber-500/15 text-amber-500 border border-amber-500/30">
                      {s.name}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {proMatch.certifications.length > 0 && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60">
                <p className={`text-[11px] font-bold mb-1.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  Certifications:
                </p>
                <div className="space-y-1">
                  {proMatch.certifications.map((cert, idx) => (
                    <div key={idx} className="flex items-center gap-1.5 text-xs text-slate-300">
                      <Award className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>{cert}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* 4. STUDENT PROFILE SECTION */}
        {role === 'student' && studentMatch && (
          <div className={`p-4 rounded-2xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-800'
          }`}>
            <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-500 flex items-center gap-1.5">
              <GraduationCap className="w-4 h-4" />
              <span>Academic & Skill Profile</span>
            </h2>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-xs">
              <p className="font-bold">{studentMatch.education.institution}</p>
              <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                {studentMatch.education.degree} • {studentMatch.education.course}
              </p>
              <p className={`text-[10px] mt-0.5 text-slate-400`}>
                Class of {studentMatch.education.yearOfPassing}
              </p>
            </div>

            {studentMatch.skills.length > 0 && (
              <div>
                <p className={`text-[11px] font-bold mb-1.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  Verified Skills:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {studentMatch.skills.map((s) => (
                    <span key={s.id} className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-indigo-500/15 text-indigo-500 border border-indigo-500/30 flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-500" />
                      {s.name}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {studentMatch.projects.length > 0 && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60">
                <p className={`text-[11px] font-bold mb-1.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  Projects:
                </p>
                <div className="space-y-1.5">
                  {studentMatch.projects.map((proj) => (
                    <div key={proj.id} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-xs">
                      <p className="font-bold text-xs">{proj.title}</p>
                      <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>{proj.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Role-Based Privacy Notice */}
        <div className={`p-3.5 rounded-2xl border flex items-start gap-2.5 text-xs ${
          isLight
            ? 'bg-slate-100/70 border-slate-200 text-slate-600'
            : 'bg-slate-800/40 border-slate-800 text-slate-400'
        }`}>
          <Lock className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
          <div className="text-[11px] leading-relaxed">
            <span className="font-bold">Contact Privacy Enforced:</span> Personal phone number and private email are hidden. Professional outreach should be conducted via NEXIF5 Direct Messaging.
          </div>
        </div>
      </div>
    </div>
  );
};
