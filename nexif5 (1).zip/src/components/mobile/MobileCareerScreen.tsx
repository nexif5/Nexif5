import React from 'react';
import { useApp } from '../../context/AppContext';
import { analyzeCareerReadiness } from '../../services/aiEngine';
import {
  Sparkles,
  TrendingUp,
  Target,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Briefcase,
  FileText,
  Compass,
  Award,
  BookOpen,
  Zap,
  ChevronRight,
  Play
} from 'lucide-react';


export const MobileCareerScreen: React.FC = () => {
  const {
    currentStudent,
    setMobileTab,
    setSubView,
    skillProgressList,
    completeSkillTask,
    sharedResources,
    setSelectedResourceForDetail,
    setLearnSubTab,
    certifiedCourses,
    openCourseLearning,
    openCourseAssessment,
    openCertificateView,
    theme
  } = useApp();


  const isLight = theme === 'light';
  const analysis = analyzeCareerReadiness(currentStudent);

  // Group skills into strengths and gaps
  const strengths = currentStudent.skills.filter(s => s.level === 'advanced' || s.level === 'expert');
  const developing = currentStudent.skills.filter(s => s.level === 'intermediate');
  const gaps = skillProgressList.filter(s => !s.isTaskCompleted);

  return (
    <div className={`space-y-4 px-4 pt-4 pb-24 font-sans min-h-screen transition-colors duration-200 ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-white'
    }`}>
      {/* 1. Header with Tagline */}
      <div className="space-y-1">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-600 dark:text-indigo-400 text-[11px] font-bold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>AI CAREER ANALYSIS & ROADMAP</span>
        </div>
        <h1 className={`text-2xl font-bold tracking-tight font-display ${
          isLight ? 'text-slate-900' : 'text-white'
        }`}>
          From Potential to Career
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Deterministic readiness diagnostics, degree-to-career pathway, and personalized actions.
        </p>
      </div>

      {/* 2. Main Career Readiness Benchmark Hero Card */}
      <div className={`p-5 rounded-2xl border space-y-4 shadow-sm ${
        isLight
          ? 'bg-gradient-to-br from-indigo-50 via-white to-blue-50/50 border-indigo-200 text-slate-900'
          : 'bg-gradient-to-br from-indigo-950/70 via-slate-900 to-indigo-900/40 border-indigo-500/40 text-white'
      }`}>
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              TARGET CAREER GOAL
            </span>
            <h2 className="text-xl font-bold font-display mt-0.5">
              {currentStudent.careerGoal}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Degree: {currentStudent.education.degree} ({currentStudent.education.course})
            </p>
          </div>

          <div className="text-right">
            <span className="text-3xl font-extrabold font-display text-indigo-600 dark:text-indigo-400">
              {currentStudent.careerReadinessScore}%
            </span>
            <span className="block text-[10px] font-bold text-emerald-500 mt-0.5">
              Top 10% in Cohort
            </span>
          </div>
        </div>

        {/* Readiness Meter Breakdown */}
        <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800 text-xs">
          <div className="flex justify-between text-slate-600 dark:text-slate-300">
            <span>Overall Career Readiness Level</span>
            <span className="font-bold text-indigo-600 dark:text-indigo-400">{analysis.readinessLevel}</span>
          </div>
          <div className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 to-emerald-500 rounded-full transition-all duration-500"
              style={{ width: `${currentStudent.careerReadinessScore}%` }}
            />
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2 text-[11px]">
            <div>
              <span className="text-slate-400 block">Market Demand</span>
              <span className="font-bold text-emerald-500">Very High (2025-2026)</span>
            </div>
            <div>
              <span className="text-slate-400 block">Fresher Salary Range</span>
              <span className="font-bold">₹{currentStudent.salaryPreferenceMinLPA} - {currentStudent.salaryPreferenceMaxLPA} LPA</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Priority Action Recommendation Callout */}
      <div className={`p-4 rounded-2xl border space-y-2.5 ${
        isLight
          ? 'bg-amber-50/80 border-amber-200 text-slate-900'
          : 'bg-amber-950/30 border-amber-500/30 text-white'
      }`}>
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-500 flex items-center justify-center font-bold text-xs">
            !
          </div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
            AI Priority Recommendation
          </h3>
        </div>
        <p className="text-xs leading-relaxed">
          "Your priority skill is <strong>Financial Modelling & Power BI</strong>. Start with the recommended learning resource in the Learning Hub and complete the practical dashboard task."
        </p>
        <div className="flex items-center gap-2 pt-1 flex-wrap">
          <button
            onClick={() => {
              setMobileTab('learn');
              setLearnSubTab('tasks');
            }}
            className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1"
          >
            <span>Open Recommended Tasks & Notes</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <span className="text-slate-400 text-xs">•</span>
          <button
            onClick={() => openCourseLearning('course-pbi')}
            className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
          >
            <span>Launch Power BI Video Course</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>


      {/* 4. AI Skill-Gap Analysis Deep Dive */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Target className="w-4 h-4 text-indigo-500" />
            <span>AI Skill-Gap Diagnostics</span>
          </h3>
          <span className="text-[10px] text-slate-400">{gaps.length} Actionable Gaps</span>
        </div>

        <div className="space-y-3">
          {skillProgressList.map((skillItem, idx) => (
            <div
              key={idx}
              className={`p-4 rounded-2xl border space-y-3 ${
                isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
              }`}
            >
              {/* Skill Header */}
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="text-sm font-bold font-display">{skillItem.skill}</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">{skillItem.category}</p>
                </div>
                <div className="text-right">
                  <span className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-bold ${
                    skillItem.isTaskCompleted
                      ? 'bg-emerald-500/15 text-emerald-500'
                      : 'bg-indigo-500/15 text-indigo-500'
                  }`}>
                    {skillItem.currentLevel} → {skillItem.targetLevel}
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5 font-semibold">
                    {skillItem.progressPercent}% Progress
                  </span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    skillItem.isTaskCompleted ? 'bg-emerald-500' : 'bg-indigo-500'
                  }`}
                  style={{ width: `${skillItem.progressPercent}%` }}
                />
              </div>

              {/* 6 Core Diagnostic Points as specified in Prompt */}
              <div className={`p-3 rounded-xl space-y-1.5 text-xs ${
                isLight ? 'bg-slate-50 text-slate-700' : 'bg-slate-900/60 text-slate-300'
              }`}>
                <div>
                  <span className="font-bold text-slate-900 dark:text-white">1. Why it matters: </span>
                  <span>{skillItem.whyItMatters}</span>
                </div>
                <div>
                  <span className="font-bold text-slate-900 dark:text-white">2. What to learn: </span>
                  <span>Recommended notes and case frameworks in the Learning Hub.</span>
                </div>
                <div>
                  <span className="font-bold text-slate-900 dark:text-white">3. Next Action: </span>
                  <span className="font-semibold text-indigo-600 dark:text-indigo-400">{skillItem.nextActionTitle}</span>
                </div>
                <div>
                  <span className="font-bold text-slate-900 dark:text-white">4. How to demonstrate: </span>
                  <span>{skillItem.howToDemonstrate}</span>
                </div>
                <div>
                  <span className="font-bold text-slate-900 dark:text-white">5. Career Readiness Impact: </span>
                  <span className="text-emerald-500 font-semibold">{skillItem.careerReadinessImpact}</span>
                </div>
              </div>

              {/* Linked Certified Course */}
              {(() => {
                const matchedCourse = certifiedCourses.find(c =>
                  c.skill.toLowerCase().includes(skillItem.skill.toLowerCase()) ||
                  skillItem.skill.toLowerCase().includes(c.skill.toLowerCase())
                );
                if (!matchedCourse) return null;
                return (
                  <div className={`p-3 rounded-xl border flex items-center justify-between gap-2 text-xs ${
                    isLight ? 'bg-indigo-50/70 border-indigo-200' : 'bg-indigo-950/30 border-indigo-500/30'
                  }`}>
                    <div className="min-w-0 space-y-0.5">
                      <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider flex items-center gap-1">
                        <Award className="w-3 h-3 text-amber-500" />
                        <span>Certified Course: {matchedCourse.progressPercent}% Finished</span>
                      </span>
                      <p className="font-bold text-slate-900 dark:text-white truncate">
                        {matchedCourse.title}
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => openCourseLearning(matchedCourse.id)}
                        className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[11px] flex items-center gap-1 transition-all"
                      >
                        <Play className="w-3 h-3 fill-current" />
                        <span>Learn</span>
                      </button>
                      {matchedCourse.isCertificateEarned && (
                        <button
                          onClick={() => openCertificateView(matchedCourse.id)}
                          className="px-2 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-[11px] flex items-center gap-1 transition-all"
                        >
                          <Award className="w-3 h-3" />
                          <span>Cert</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-1 gap-2">

                {skillItem.relatedResourceId && (
                  <button
                    onClick={() => {
                      const res = sharedResources.find(r => r.id === skillItem.relatedResourceId);
                      if (res) setSelectedResourceForDetail(res);
                      else setMobileTab('learn');
                    }}
                    className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Open Study Notes</span>
                  </button>
                )}

                {!skillItem.isTaskCompleted ? (
                  <button
                    onClick={() => completeSkillTask(skillItem.skill)}
                    className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs active:scale-95 transition-all flex items-center gap-1 ml-auto"
                  >
                    <span>Complete Task</span>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <span className="text-xs font-bold text-emerald-500 flex items-center gap-1 ml-auto">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified</span>
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5. Strengths vs Developing Breakdown */}
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className={`p-3.5 rounded-2xl border space-y-2 ${
          isLight ? 'bg-white border-slate-200' : 'bg-slate-800/60 border-slate-700'
        }`}>
          <h4 className="font-bold uppercase tracking-wider text-[10px] text-emerald-500 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Current Strengths</span>
          </h4>
          <div className="space-y-1">
            {strengths.slice(0, 3).map(s => (
              <p key={s.id} className="text-xs font-semibold">• {s.name}</p>
            ))}
          </div>
        </div>

        <div className={`p-3.5 rounded-2xl border space-y-2 ${
          isLight ? 'bg-white border-slate-200' : 'bg-slate-800/60 border-slate-700'
        }`}>
          <h4 className="font-bold uppercase tracking-wider text-[10px] text-indigo-500 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Developing</span>
          </h4>
          <div className="space-y-1">
            {developing.slice(0, 3).map(s => (
              <p key={s.id} className="text-xs font-semibold">• {s.name}</p>
            ))}
          </div>
        </div>
      </div>

      {/* 6. Degree-to-Career Roadmap */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200' : 'bg-slate-800/80 border-slate-700'
      }`}>
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <Compass className="w-4 h-4 text-indigo-500" />
          <span>Degree-to-Career Milestone Roadmap</span>
        </h4>

        <div className="space-y-2.5 text-xs">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0 font-bold text-[10px]">
              ✓
            </div>
            <div>
              <p className="font-bold">Education Foundation: B.Com Honours & Analytics</p>
              <p className="text-[11px] text-slate-400">Core accounting, statistics, and business economics.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center shrink-0 font-bold text-[10px]">
              2
            </div>
            <div>
              <p className="font-bold text-indigo-600 dark:text-indigo-400">Current Phase: Practical Skill Execution</p>
              <p className="text-[11px] text-slate-400">Power BI dashboarding, advanced SQL, and financial modeling.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-center shrink-0 font-bold text-[10px]">
              3
            </div>
            <div>
              <p className="font-bold">Target Role: Associate Business Analyst (₹6.5 - 10.5 LPA)</p>
              <p className="text-[11px] text-slate-400">Top recruiter matches: FinEdge Analytics, ABC Tech, Deloitte.</p>
            </div>
          </div>
        </div>
      </div>

      {/* 7. Action Launchers (Resume, Interview Prep, Jobs) */}
      <div className="grid grid-cols-2 gap-2 pt-1">
        <button
          onClick={() => setSubView('resume')}
          className={`p-3 rounded-2xl border text-left space-y-1 transition-all ${
            isLight
              ? 'bg-white hover:bg-slate-100 border-slate-200'
              : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <FileText className="w-4 h-4 text-indigo-500" />
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          </div>
          <p className="font-bold text-xs">ATS Resume Builder</p>
          <p className="text-[10px] text-slate-400">Match target keywords</p>
        </button>

        <button
          onClick={() => setSubView('interview_prep')}
          className={`p-3 rounded-2xl border text-left space-y-1 transition-all ${
            isLight
              ? 'bg-white hover:bg-slate-100 border-slate-200'
              : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <Award className="w-4 h-4 text-purple-500" />
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          </div>
          <p className="font-bold text-xs">Mock Interview Prep</p>
          <p className="text-[10px] text-slate-400">Practice 2025 case studies</p>
        </button>
      </div>

      {/* 8. Matched Opportunities Link */}
      <button
        onClick={() => setMobileTab('jobs')}
        className="w-full py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all active:scale-98 flex items-center justify-center gap-2"
      >
        <Briefcase className="w-4 h-4" />
        <span>View Active AI-Matched Opportunities</span>
        <ArrowRight className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
