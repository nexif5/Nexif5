import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeft,
  Search,
  Send,
  Paperclip,
  Check,
  CheckCheck,
  Sparkles,
  FileText,
  Award,
  Briefcase,
  Code2,
  X,
  ShieldCheck,
  Info,
  Clock,
  MoreVertical,
  User,
  GraduationCap,
  Building2,
  ChevronRight
} from 'lucide-react';
import { MessageAttachment, UserRole } from '../../types';

export const MobileMessagingScreen: React.FC = () => {
  const {
    theme,
    setSubView,
    chatConversations,
    directChatMessages,
    activeConversationId,
    setActiveConversationId,
    sendMessage,
    markConversationRead,
    quickTemplates,
    openUserProfile,
    userConnections,
    currentRole,
    currentStudent,
    currentProfessional,
    currentMentor,
    currentCompany,
    currentCollege
  } = useApp();

  const isLight = theme === 'light';
  const [inputText, setInputText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAttachmentPicker, setShowAttachmentPicker] = useState(false);
  const [selectedAttachment, setSelectedAttachment] = useState<MessageAttachment | null>(null);
  const [showEtiquetteTips, setShowEtiquetteTips] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeConversation = chatConversations.find(c => c.id === activeConversationId);
  const activeMessages = activeConversationId ? directChatMessages[activeConversationId] || [] : [];

  // Auto-scroll to latest message
  useEffect(() => {
    if (activeConversationId) {
      markConversationRead(activeConversationId);
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [activeConversationId, activeMessages.length]);

  const filteredConversations = chatConversations.filter(c =>
    c.peerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.peerHeadline.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSend = () => {
    if ((!inputText.trim() && !selectedAttachment) || !activeConversationId) return;

    sendMessage(activeConversationId, inputText.trim(), selectedAttachment || undefined);
    setInputText('');
    setSelectedAttachment(null);
    setShowAttachmentPicker(false);
  };

  const handleApplyTemplate = (templateContent: string) => {
    if (!activeConversation) return;
    const personalized = templateContent
      .replace(/\[Name\]/g, activeConversation.peerName.split(' ')[0])
      .replace(/\[Company\/Org\]/g, activeConversation.peerOrganization || 'your organization')
      .replace(/\[Org\]/g, activeConversation.peerOrganization || 'your company')
      .replace(/\[Role\]/g, currentStudent.careerGoal || 'Software Engineer')
      .replace(/\[Job Title\]/g, 'open engineering opportunities')
      .replace(/\[Skills\]/g, 'Cloud & React')
      .replace(/\[Domain\]/g, 'Engineering Leadership')
      .replace(/\[Tech Stack\]/g, 'modern web applications');

    setInputText(personalized);
  };

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'student':
        return { label: 'Student', color: 'bg-indigo-500/15 text-indigo-500 border-indigo-500/30' };
      case 'professional':
      case 'job_seeker':
        return { label: 'Professional', color: 'bg-amber-500/15 text-amber-500 border-amber-500/30' };
      case 'recruiter':
        return { label: 'Recruiter', color: 'bg-emerald-500/15 text-emerald-500 border-emerald-500/30' };
      case 'mentor':
        return { label: 'Mentor', color: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30' };
      case 'college':
        return { label: 'Institution', color: 'bg-purple-500/15 text-purple-400 border-purple-500/30' };
      default:
        return { label: 'Member', color: 'bg-slate-500/15 text-slate-400 border-slate-500/30' };
    }
  };

  // -------------------------------------------------------------------------
  // VIEW 1: CONVERSATIONS LIST
  // -------------------------------------------------------------------------
  if (!activeConversationId || !activeConversation) {
    return (
      <div className={`min-h-screen pb-24 ${isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-slate-100'}`}>
        {/* Header */}
        <div className={`sticky top-0 z-30 px-4 py-3 backdrop-blur-md border-b flex items-center justify-between ${
          isLight ? 'bg-white/95 border-slate-200' : 'bg-slate-900/95 border-slate-800'
        }`}>
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setSubView(null)}
              className={`p-2 rounded-xl transition-colors ${
                isLight ? 'text-slate-600 hover:bg-slate-100' : 'text-slate-400 hover:bg-slate-800'
              }`}
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="font-bold text-base leading-tight font-display">
                Professional Messages
              </h1>
              <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Career inquiries, mentorship & recruiter dialogue
              </p>
            </div>
          </div>

          <button
            onClick={() => setSubView('network')}
            className="text-xs font-semibold px-2.5 py-1.5 rounded-xl bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-600/20"
          >
            Find People
          </button>
        </div>

        {/* Search */}
        <div className="px-4 pt-3">
          <div className={`relative flex items-center rounded-2xl border px-3 py-2 transition-all ${
            isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
          }`}>
            <Search className="w-4 h-4 text-slate-400 mr-2" />
            <input
              type="text"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-xs focus:outline-none placeholder:text-slate-400"
            />
          </div>
        </div>

        {/* Guidelines Pill */}
        <div className="px-4 pt-3">
          <div className={`p-3 rounded-2xl border flex items-center justify-between gap-2.5 ${
            isLight
              ? 'bg-indigo-50/70 border-indigo-100 text-indigo-950'
              : 'bg-indigo-950/30 border-indigo-900/50 text-indigo-200'
          }`}>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-indigo-500 shrink-0" />
              <span className="text-[11px]">NEXIF5 enforces career communication etiquette.</span>
            </div>
            <button
              onClick={() => setShowEtiquetteTips(!showEtiquetteTips)}
              className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 underline"
            >
              {showEtiquetteTips ? 'Hide' : 'Tips'}
            </button>
          </div>

          {showEtiquetteTips && (
            <div className={`mt-2 p-3 rounded-2xl border text-[11px] space-y-1.5 ${
              isLight ? 'bg-white border-slate-200 text-slate-700' : 'bg-slate-800 border-slate-700 text-slate-300'
            }`}>
              <p>• <strong>State your objective clearly</strong>: introduce your background and specific inquiry.</p>
              <p>• <strong>Keep it concise</strong>: respect professional schedules.</p>
              <p>• <strong>Share verified credentials</strong>: attach your NEXIF5 ATS resume or certified skill badges.</p>
            </div>
          )}
        </div>

        {/* Conversation List */}
        <div className="px-4 pt-3 space-y-2">
          {filteredConversations.length === 0 ? (
            <div className={`p-8 text-center rounded-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-slate-800/40 border-slate-800'
            }`}>
              <p className="text-xs font-semibold">No conversations found</p>
              <p className={`text-[11px] mt-1 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Connect with mentors, recruiters, or peers to start direct messaging.
              </p>
            </div>
          ) : (
            filteredConversations.map((conv) => {
              const badge = getRoleBadge(conv.peerRole);

              return (
                <div
                  key={conv.id}
                  onClick={() => setActiveConversationId(conv.id)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    isLight
                      ? 'bg-white border-slate-200 hover:border-indigo-300 shadow-xs'
                      : 'bg-slate-800/70 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className="relative shrink-0">
                      <img
                        src={conv.peerAvatar}
                        alt={conv.peerName}
                        className="w-12 h-12 rounded-full object-cover border border-indigo-500/30"
                      />
                      {conv.isOnline && (
                        <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-1">
                        <div className="flex items-center gap-1.5 truncate">
                          <h4 className="font-bold text-xs truncate">{conv.peerName}</h4>
                          <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold border ${badge.color}`}>
                            {badge.label}
                          </span>
                        </div>
                        <span className={`text-[10px] shrink-0 ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
                          {conv.lastMessageTimestamp}
                        </span>
                      </div>

                      <p className={`text-[11px] truncate mt-0.5 ${
                        conv.unreadCount > 0 ? 'font-bold text-indigo-600 dark:text-indigo-400' : isLight ? 'text-slate-500' : 'text-slate-400'
                      }`}>
                        {conv.lastMessage}
                      </p>
                    </div>
                  </div>

                  {conv.unreadCount > 0 && (
                    <span className="w-5 h-5 rounded-full bg-indigo-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">
                      {conv.unreadCount}
                    </span>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------------------
  // VIEW 2: ACTIVE CHAT THREAD
  // -------------------------------------------------------------------------
  const peerBadge = getRoleBadge(activeConversation.peerRole);

  return (
    <div className={`min-h-screen flex flex-col justify-between ${isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-slate-100'}`}>
      {/* Top Conversation Header */}
      <div className={`sticky top-0 z-30 px-3.5 py-2.5 backdrop-blur-md border-b flex items-center justify-between shadow-xs ${
        isLight ? 'bg-white/95 border-slate-200' : 'bg-slate-900/95 border-slate-800'
      }`}>
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <button
            onClick={() => setActiveConversationId(null)}
            className={`p-1.5 rounded-xl ${isLight ? 'hover:bg-slate-100 text-slate-600' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div
            className="flex items-center gap-2.5 min-w-0 cursor-pointer"
            onClick={() => openUserProfile(activeConversation.peerId)}
          >
            <div className="relative shrink-0">
              <img
                src={activeConversation.peerAvatar}
                alt={activeConversation.peerName}
                className="w-10 h-10 rounded-full object-cover border border-indigo-500/40"
              />
              {activeConversation.isOnline && (
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" />
              )}
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h3 className="font-bold text-xs truncate leading-tight hover:text-indigo-500 transition-colors">
                  {activeConversation.peerName}
                </h3>
                <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold border ${peerBadge.color}`}>
                  {peerBadge.label}
                </span>
              </div>
              <p className={`text-[10px] truncate ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                {activeConversation.peerOrganization || activeConversation.peerHeadline}
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={() => openUserProfile(activeConversation.peerId)}
          className={`px-2.5 py-1 rounded-xl text-[11px] font-semibold border transition-colors ${
            isLight
              ? 'border-slate-200 text-slate-700 hover:bg-slate-100'
              : 'border-slate-700 text-slate-300 hover:bg-slate-800'
          }`}
        >
          View Profile
        </button>
      </div>

      {/* Message Stream */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 pb-32">
        {/* Pre-conversation prompt banner */}
        <div className={`p-3 rounded-2xl border text-center text-xs ${
          isLight ? 'bg-white border-slate-200 text-slate-600' : 'bg-slate-800/60 border-slate-800 text-slate-300'
        }`}>
          <p className="font-bold text-indigo-500">Professional Chat with {activeConversation.peerName}</p>
          <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
            Career conversations are encrypted and adhere to NEXIF5 Community Standards.
          </p>
        </div>

        {activeMessages.map((msg) => {
          const isMe = msg.senderRole === currentRole || msg.senderId === currentStudent.id;

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed shadow-xs ${
                  isMe
                    ? 'bg-indigo-600 text-white rounded-br-xs'
                    : isLight
                    ? 'bg-white border border-slate-200 text-slate-800 rounded-bl-xs'
                    : 'bg-slate-800 border border-slate-700 text-slate-100 rounded-bl-xs'
                }`}
              >
                {/* Text content */}
                {msg.content && <p className="whitespace-pre-wrap">{msg.content}</p>}

                {/* Attachment Card if present */}
                {msg.attachment && (
                  <div className={`mt-2 p-2.5 rounded-xl border text-left ${
                    isMe
                      ? 'bg-indigo-700/60 border-indigo-500/40 text-white'
                      : isLight
                      ? 'bg-slate-50 border-slate-200 text-slate-900'
                      : 'bg-slate-900/60 border-slate-700 text-slate-100'
                  }`}>
                    <div className="flex items-start gap-2">
                      {msg.attachment.type === 'resume' && (
                        <FileText className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                      )}
                      {msg.attachment.type === 'certificate' && (
                        <Award className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                      )}
                      {msg.attachment.type === 'job' && (
                        <Briefcase className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                      )}
                      {msg.attachment.type === 'project' && (
                        <Code2 className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
                      )}

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-xs truncate">{msg.attachment.title}</span>
                          {msg.attachment.badge && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded font-bold bg-white/20 text-white">
                              {msg.attachment.badge}
                            </span>
                          )}
                        </div>
                        {msg.attachment.subtitle && (
                          <p className="text-[10px] opacity-80 mt-0.5">{msg.attachment.subtitle}</p>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Timestamp & read receipt */}
              <div className="flex items-center gap-1 mt-1 px-1 text-[10px] text-slate-400">
                <span>{msg.timestamp}</span>
                {isMe && (
                  msg.status === 'read' ? (
                    <CheckCheck className="w-3 h-3 text-emerald-500" />
                  ) : msg.status === 'delivered' ? (
                    <CheckCheck className="w-3 h-3 text-slate-400" />
                  ) : (
                    <Check className="w-3 h-3 text-slate-400" />
                  )
                )}
              </div>
            </div>
          );
        })}

        <div ref={messagesEndRef} />
      </div>

      {/* Bottom Sticky Input & Action Section */}
      <div className={`fixed bottom-0 left-0 right-0 max-w-md mx-auto z-40 border-t backdrop-blur-md px-3 py-2 space-y-2 ${
        isLight ? 'bg-white/95 border-slate-200' : 'bg-slate-900/95 border-slate-800'
      }`}>
        {/* Quick Conversation Starter Templates Carousel */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          <div className="flex items-center gap-1 text-[10px] font-bold text-indigo-500 shrink-0">
            <Sparkles className="w-3 h-3" />
            <span>Starters:</span>
          </div>
          {quickTemplates.map((tmpl) => (
            <button
              key={tmpl.id}
              onClick={() => handleApplyTemplate(tmpl.content)}
              className={`px-2.5 py-1 rounded-xl text-[10px] font-medium whitespace-nowrap border transition-all ${
                isLight
                  ? 'bg-slate-100 hover:bg-indigo-50 border-slate-200 text-slate-700 hover:text-indigo-600'
                  : 'bg-slate-800 hover:bg-indigo-950/60 border-slate-700 text-slate-300 hover:text-indigo-300'
              }`}
            >
              {tmpl.title}
            </button>
          ))}
        </div>

        {/* Selected Attachment Preview Chip */}
        {selectedAttachment && (
          <div className={`p-2 rounded-xl border flex items-center justify-between text-xs ${
            isLight ? 'bg-indigo-50 border-indigo-200 text-indigo-900' : 'bg-indigo-950/40 border-indigo-800 text-indigo-200'
          }`}>
            <div className="flex items-center gap-2 truncate">
              <Award className="w-4 h-4 text-indigo-500" />
              <span className="font-semibold truncate">{selectedAttachment.title}</span>
            </div>
            <button
              onClick={() => setSelectedAttachment(null)}
              className="p-1 text-slate-400 hover:text-slate-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Input Controls Bar */}
        <div className="flex items-end gap-1.5">
          <button
            onClick={() => setShowAttachmentPicker(!showAttachmentPicker)}
            className={`p-2.5 rounded-2xl border transition-colors shrink-0 ${
              showAttachmentPicker
                ? 'bg-indigo-600 text-white border-indigo-600'
                : isLight
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-200'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
            }`}
            title="Attach Resume, Certificate or Job"
          >
            <Paperclip className="w-4 h-4" />
          </button>

          <textarea
            rows={1}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={`Message ${activeConversation.peerName.split(' ')[0]}...`}
            className={`flex-1 p-2.5 rounded-2xl border text-xs max-h-24 resize-none focus:outline-none focus:border-indigo-500 ${
              isLight
                ? 'bg-slate-100 border-slate-200 text-slate-900'
                : 'bg-slate-800 border-slate-700 text-slate-100'
            }`}
          />

          <button
            onClick={handleSend}
            disabled={!inputText.trim() && !selectedAttachment}
            className={`p-2.5 rounded-2xl font-bold transition-all shrink-0 ${
              inputText.trim() || selectedAttachment
                ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs active:scale-95'
                : 'bg-slate-300 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

        {/* Attachment Options Drawer */}
        {showAttachmentPicker && (
          <div className={`p-3 rounded-2xl border animate-fade-in space-y-2 ${
            isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800 border-slate-700'
          }`}>
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Attach Verified Credential:
              </span>
              <button
                onClick={() => setShowAttachmentPicker(false)}
                className="text-[10px] text-slate-400 hover:text-slate-600"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => {
                  setSelectedAttachment({
                    type: 'resume',
                    title: `${currentStudent.name.replace(/\s+/g, '_')}_Verified_Resume.pdf`,
                    subtitle: `ATS Score: 94/100 • ${currentStudent.education.degree}`,
                    badge: 'Verified ATS Resume'
                  });
                  setShowAttachmentPicker(false);
                }}
                className={`p-2.5 rounded-xl border text-left flex items-start gap-2 transition-colors ${
                  isLight ? 'bg-white hover:bg-slate-50 border-slate-200' : 'bg-slate-900 hover:bg-slate-800 border-slate-700'
                }`}
              >
                <FileText className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-[11px]">Share My Resume</p>
                  <p className="text-[9px] text-slate-400">NEXIF5 ATS verified format</p>
                </div>
              </button>

              <button
                onClick={() => {
                  setSelectedAttachment({
                    type: 'certificate',
                    title: 'Microsoft Certified: Power BI & Data Analyst Associate',
                    subtitle: 'Verified Credential • Distinction (86%)',
                    badge: 'Partner Certificate'
                  });
                  setShowAttachmentPicker(false);
                }}
                className={`p-2.5 rounded-xl border text-left flex items-start gap-2 transition-colors ${
                  isLight ? 'bg-white hover:bg-slate-50 border-slate-200' : 'bg-slate-900 hover:bg-slate-800 border-slate-700'
                }`}
              >
                <Award className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-[11px]">Share Certificate</p>
                  <p className="text-[9px] text-slate-400">Verified course badge</p>
                </div>
              </button>

              <button
                onClick={() => {
                  setSelectedAttachment({
                    type: 'job',
                    title: 'Junior Cloud Solutions Engineer',
                    subtitle: 'TechCorp India • ₹8.5 - 12.0 LPA',
                    badge: 'Job Opening'
                  });
                  setShowAttachmentPicker(false);
                }}
                className={`p-2.5 rounded-xl border text-left flex items-start gap-2 transition-colors ${
                  isLight ? 'bg-white hover:bg-slate-50 border-slate-200' : 'bg-slate-900 hover:bg-slate-800 border-slate-700'
                }`}
              >
                <Briefcase className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-[11px]">Share Job Post</p>
                  <p className="text-[9px] text-slate-400">Opportunity discussion</p>
                </div>
              </button>

              <button
                onClick={() => {
                  setSelectedAttachment({
                    type: 'project',
                    title: 'Distributed Task Queue & Telemetry',
                    subtitle: 'Node.js, Redis, Docker • Live Portfolio',
                    badge: 'Project Showcase'
                  });
                  setShowAttachmentPicker(false);
                }}
                className={`p-2.5 rounded-xl border text-left flex items-start gap-2 transition-colors ${
                  isLight ? 'bg-white hover:bg-slate-50 border-slate-200' : 'bg-slate-900 hover:bg-slate-800 border-slate-700'
                }`}
              >
                <Code2 className="w-4 h-4 text-purple-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-[11px]">Share Project</p>
                  <p className="text-[9px] text-slate-400">Code repository & demo</p>
                </div>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
