import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { LanguageCode, SUPPORTED_LANGUAGES } from '../../services/i18n';
import { ArrowLeft, Search, Check, Globe, Sun, Moon, Star } from 'lucide-react';

export const LanguageScreen: React.FC = () => {
  const { currentLanguage, setCurrentLanguage, setAuthState, theme, toggleTheme } = useApp();
  const [selectedLang, setSelectedLang] = useState<LanguageCode>(currentLanguage);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'english' | 'regional'>('all');

  const filteredLanguages = SUPPORTED_LANGUAGES.filter(lang => {
    const matchesSearch =
      lang.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lang.nativeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lang.region.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (filterType === 'english') return lang.code === 'en';
    if (filterType === 'regional') return lang.code !== 'en';
    return true;
  });

  const handleContinue = () => {
    setCurrentLanguage(selectedLang);
    setAuthState('signup');
  };

  const isLight = theme === 'light';

  return (
    <div className={`min-h-screen flex flex-col justify-between px-5 py-6 font-sans transition-colors duration-200 ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-white'
    }`}>
      {/* Top Header */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setAuthState('welcome')}
              className={`p-2 -ml-1 rounded-xl transition-colors active:scale-95 ${
                isLight
                  ? 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                  : 'bg-slate-800 text-slate-300 hover:text-white'
              }`}
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className={`text-xl font-bold font-display ${isLight ? 'text-slate-900' : 'text-white'}`}>
                Choose Language
              </h1>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                English and regional languages supported
              </p>
            </div>
          </div>

          {/* Theme Quick Toggle */}
          <button
            onClick={toggleTheme}
            className={`p-2 rounded-xl border transition-all active:scale-95 flex items-center gap-1.5 text-xs font-semibold ${
              isLight
                ? 'bg-white border-slate-200 text-slate-700 shadow-xs hover:bg-slate-100'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
            title={isLight ? 'Switch to Dark Mode' : 'Switch to White Mode'}
          >
            {isLight ? (
              <>
                <Moon className="w-4 h-4 text-indigo-600" />
                <span className="text-[11px]">Dark</span>
              </>
            ) : (
              <>
                <Sun className="w-4 h-4 text-amber-400" />
                <span className="text-[11px]">Light</span>
              </>
            )}
          </button>
        </div>

        {/* Highlighted English Card */}
        <div
          onClick={() => setSelectedLang('en')}
          className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
            selectedLang === 'en'
              ? 'bg-indigo-600/10 border-indigo-500 ring-2 ring-indigo-500/30'
              : isLight
              ? 'bg-white border-slate-200 hover:border-indigo-300 shadow-xs'
              : 'bg-slate-800/80 border-slate-700 hover:border-slate-600'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${
                selectedLang === 'en'
                  ? 'bg-indigo-600 text-white'
                  : isLight
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'bg-indigo-500/20 text-indigo-300'
              }`}>
                EN
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className={`font-bold text-sm ${isLight ? 'text-slate-900' : 'text-white'}`}>
                    English
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-indigo-500/15 text-indigo-600 text-[10px] font-bold">
                    Primary / Default
                  </span>
                </div>
                <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  Global standard language for jobs & interviews
                </p>
              </div>
            </div>

            {selectedLang === 'en' ? (
              <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                <Check className="w-3.5 h-3.5" />
              </div>
            ) : (
              <div className={`w-5 h-5 rounded-full border ${isLight ? 'border-slate-300' : 'border-slate-600'}`} />
            )}
          </div>
        </div>

        {/* Search Language Input */}
        <div className="relative">
          <Search className={`absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 ${isLight ? 'text-slate-400' : 'text-slate-400'}`} />
          <input
            type="text"
            placeholder="Search English or regional language..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-10 pr-4 py-2.5 rounded-2xl text-sm transition-colors border focus:outline-hidden focus:border-indigo-500 ${
              isLight
                ? 'bg-white border-slate-300 text-slate-900 placeholder-slate-400 shadow-xs'
                : 'bg-slate-800/80 border-slate-700/80 text-white placeholder-slate-400'
            }`}
          />
        </div>

        {/* Quick Filter Chips */}
        <div className="flex gap-2 text-xs">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1 rounded-full font-semibold transition-colors ${
              filterType === 'all'
                ? 'bg-indigo-600 text-white'
                : isLight
                ? 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            All ({SUPPORTED_LANGUAGES.length})
          </button>
          <button
            onClick={() => setFilterType('english')}
            className={`px-3 py-1 rounded-full font-semibold transition-colors flex items-center gap-1 ${
              filterType === 'english'
                ? 'bg-indigo-600 text-white'
                : isLight
                ? 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Star className="w-3 h-3" />
            English
          </button>
          <button
            onClick={() => setFilterType('regional')}
            className={`px-3 py-1 rounded-full font-semibold transition-colors ${
              filterType === 'regional'
                ? 'bg-indigo-600 text-white'
                : isLight
                ? 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            Regional (11)
          </button>
        </div>
      </div>

      {/* Languages List */}
      <div className="flex-1 my-3 overflow-y-auto space-y-2 max-h-[46vh] pr-1">
        {filteredLanguages.map((lang) => {
          const isSelected = selectedLang === lang.code;
          return (
            <motion.button
              key={lang.code}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelectedLang(lang.code)}
              className={`w-full p-3 rounded-2xl text-left border flex items-center justify-between transition-all ${
                isSelected
                  ? 'bg-indigo-600/15 border-indigo-500 shadow-sm'
                  : isLight
                  ? 'bg-white border-slate-200 hover:bg-slate-100 shadow-xs'
                  : 'bg-slate-800/60 border-slate-800 hover:bg-slate-800'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm ${
                  isSelected
                    ? 'bg-indigo-600 text-white'
                    : isLight
                    ? 'bg-slate-100 text-slate-700'
                    : 'bg-slate-700 text-slate-300'
                }`}>
                  {lang.code === 'en' ? 'EN' : lang.nativeName.slice(0, 1)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`font-bold text-sm ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      {lang.name}
                    </span>
                    <span className="text-xs text-indigo-500 font-medium">
                      ({lang.nativeName})
                    </span>
                  </div>
                  <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                    {lang.region}
                  </p>
                </div>
              </div>

              {isSelected ? (
                <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                  <Check className="w-3.5 h-3.5" />
                </div>
              ) : (
                <div className={`w-5 h-5 rounded-full border ${isLight ? 'border-slate-300' : 'border-slate-600'}`} />
              )}
            </motion.button>
          );
        })}

        {filteredLanguages.length === 0 && (
          <div className={`py-12 text-center text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
            No language found matching "{searchQuery}"
          </div>
        )}
      </div>

      {/* Sticky Bottom Continue Button */}
      <div className="pt-2">
        <button
          onClick={handleContinue}
          className="w-full py-3.5 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
        >
          <span>Continue with {SUPPORTED_LANGUAGES.find(l => l.code === selectedLang)?.name || 'English'}</span>
        </button>
      </div>
    </div>
  );
};
