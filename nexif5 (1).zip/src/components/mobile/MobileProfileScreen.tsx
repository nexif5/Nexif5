import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  GraduationCap,
  Sparkles,
  FileText,
  Briefcase,
  Settings,
  ShieldCheck,
  CheckCircle2,
  ChevronRight,
  TrendingUp,
  Award,
  Globe,
  Share2,
  BookOpen,
  Layers
} from 'lucide-react';

export const MobileProfileScreen: React.FC = () => {
  const {
    currentStudent,
    setSubView,
    setAuthState,
    setMobileTab,
    setLearnSubTab,
    applications,
    sharedResources,
    theme
  } = useApp();

  const isLight = theme === 'light';
  const myApplicationsCount = applications.filter(a => a.candidateId === currentStudent.id).length;
  const mySharedResourcesCount = sharedResources.filter(r => r.uploaderId === currentStudent.id).length;

  return (
    <div className={`space-y-4 px-4 pt-4 pb-24 font-sans min-h-screen transition-colors duration-200 ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-white'
    }`}>
      {/* Header Profile Card */}
      <div className={`p-4 rounded-2xl border space-y-4 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-start gap-3.5">
          <img
            src={currentStudent.avatarUrl}
            alt={currentStudent.name}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-indigo-500 shadow-md"
          />
          <div className="space-y-1">
            <h1 className="text-lg font-bold font-display">
              {currentStudent.name}
            </h1>
            <p className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">
              {currentStudent.careerGoal} Candidate
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <GraduationCap className="w-3.5 h-3.5" />
              <span>{currentStudent.education.institution}</span>
            </p>
          </div>
        </div>

        {/* Readiness Badge */}
        <div className={`p-3 rounded-xl border flex items-center justify-between ${
          isLight
            ? 'bg-indigo-50/80 border-indigo-200 text-slate-800'
            : 'bg-indigo-950/50 border-indigo-500/30 text-white'
        }`}>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-500" />
            <div>
              <p className="text-xs font-bold">Career Readiness: {currentStudent.careerReadinessScore}%</p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">Verified for top employer shortlisting</p>
            </div>
          </div>
          <button
            onClick={() => setMobileTab('career')}
            className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            Diagnostics
          </button>
        </div>
      </div>

      {/* Quick Menu Actions */}
      <div className="space-y-2">
        {/* Applications Tracker */}
        <button
          onClick={() => setMobileTab('applications')}
          className={`w-full p-3.5 rounded-2xl border flex items-center justify-between transition-colors ${
            isLight
              ? 'bg-white hover:bg-slate-100 border-slate-200'
              : 'bg-slate-800/70 hover:bg-slate-800 border-slate-700/80'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-500/15 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <div className="text-left">
              <span className="font-bold text-xs block">My Applications Tracker</span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">
                {myApplicationsCount} active job & internship submissions
              </span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Learning Hub & Shared Resources */}
        <button
          onClick={() => {
            setMobileTab('learn');
            setLearnSubTab('my_resources');
          }}
          className={`w-full p-3.5 rounded-2xl border flex items-center justify-between transition-colors ${
            isLight
              ? 'bg-white hover:bg-slate-100 border-slate-200'
              : 'bg-slate-800/70 hover:bg-slate-800 border-slate-700/80'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
            <div className="text-left">
              <span className="font-bold text-xs block">My Uploaded Documents</span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">
                {mySharedResourcesCount} resources shared with NEXIF5 community
              </span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* ATS Resume Builder */}
        <button
          onClick={() => setSubView('resume')}
          className={`w-full p-3.5 rounded-2xl border flex items-center justify-between transition-colors ${
            isLight
              ? 'bg-white hover:bg-slate-100 border-slate-200'
              : 'bg-slate-800/70 hover:bg-slate-800 border-slate-700/80'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <div className="text-left">
              <span className="font-bold text-xs block">ATS Resume Builder</span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">92% score • Export formatted PDF</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* AI Interview Preparation */}
        <button
          onClick={() => setSubView('interview_prep')}
          className={`w-full p-3.5 rounded-2xl border flex items-center justify-between transition-colors ${
            isLight
              ? 'bg-white hover:bg-slate-100 border-slate-200'
              : 'bg-slate-800/70 hover:bg-slate-800 border-slate-700/80'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-500/15 text-purple-600 dark:text-purple-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="text-left">
              <span className="font-bold text-xs block">AI Mock Interview Simulator</span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">Domain-specific questions & feedback</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>
      </div>

      {/* Verified Skills Section */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200' : 'bg-slate-800/70 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Verified Skills ({currentStudent.skills.length})
          </h3>
          <span className="text-[10px] text-emerald-500 font-semibold flex items-center gap-1">
            <ShieldCheck className="w-3 h-3" />
            AI Verified
          </span>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {currentStudent.skills.map((skill) => (
            <span
              key={skill.id}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium ${
                isLight
                  ? 'bg-slate-100 border-slate-200 text-slate-700'
                  : 'bg-slate-700/60 border-slate-600/50 text-slate-200'
              }`}
            >
              <CheckCircle2 className="w-3 h-3 text-emerald-500" />
              <span>{skill.name}</span>
            </span>
          ))}
        </div>
      </div>

      {/* Education & Background */}
      <div className={`p-4 rounded-2xl border space-y-2 ${
        isLight ? 'bg-white border-slate-200' : 'bg-slate-800/70 border-slate-700/80'
      }`}>
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Education
        </h3>
        <p className="text-sm font-bold">
          {currentStudent.education.degree} in {currentStudent.education.course}
        </p>
        <p className="text-xs text-slate-500 dark:text-slate-300">
          {currentStudent.education.institution} • Class of {currentStudent.education.yearOfPassing}
        </p>
        <p className="text-xs text-emerald-500 font-semibold">
          {currentStudent.education.cgpaOrPercentage}
        </p>
      </div>

      {/* App Settings & Language */}
      <div className="space-y-2 pt-2">
        <button
          onClick={() => setSubView('settings')}
          className={`w-full p-3.5 rounded-2xl border flex items-center justify-between text-xs font-semibold ${
            isLight
              ? 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700'
              : 'bg-slate-800/50 hover:bg-slate-800 border-slate-700/60 text-slate-300'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Settings className="w-4 h-4 text-slate-400" />
            <span>Account Settings & Preferences</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        <button
          onClick={() => setAuthState('language')}
          className={`w-full p-3.5 rounded-2xl border flex items-center justify-between text-xs font-semibold ${
            isLight
              ? 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700'
              : 'bg-slate-800/50 hover:bg-slate-800 border-slate-700/60 text-slate-300'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Globe className="w-4 h-4 text-indigo-500" />
            <span>Change App Language</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>
      </div>
    </div>
  );
};
