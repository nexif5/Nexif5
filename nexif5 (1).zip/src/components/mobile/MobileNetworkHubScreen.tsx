import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  Search,
  Sparkles,
  UserCheck,
  UserPlus,
  Clock,
  ArrowLeft,
  Check,
  X,
  MessageSquare,
  Building2,
  GraduationCap,
  Award,
  Briefcase,
  Shield,
  Send,
  Filter,
  Info,
  ChevronRight,
  ShieldCheck,
  Share2,
  Bookmark
} from 'lucide-react';
import { UserRole, SmartConnectionRecommendation } from '../../types';

export const MobileNetworkHubScreen: React.FC = () => {
  const {
    theme,
    setSubView,
    smartRecommendations,
    connectionRequests,
    userConnections,
    sendConnectionRequest,
    acceptConnectionRequest,
    declineConnectionRequest,
    cancelConnectionRequest,
    removeConnection,
    toggleFollowUser,
    startOrOpenConversation,
    openUserProfile,
    getConnectionStatusWithUser,
    currentRole,
    currentStudent,
    currentProfessional,
    currentMentor,
    currentCompany,
    currentCollege
  } = useApp();

  const isLight = theme === 'light';
  const [activeTab, setActiveTab] = useState<'recommendations' | 'requests' | 'connections' | 'following'>('recommendations');
  const [roleFilter, setRoleFilter] = useState<'all' | UserRole>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUserForNote, setSelectedUserForNote] = useState<SmartConnectionRecommendation | null>(null);
  const [customNote, setCustomNote] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const pendingReceivedRequests = connectionRequests.filter(r => r.status === 'pending' && r.receiverId === (
    currentRole === 'recruiter' ? currentCompany.id :
    currentRole === 'college' ? currentCollege.id :
    currentRole === 'mentor' ? currentMentor.id :
    currentRole === 'professional' ? currentProfessional.id :
    currentStudent.id
  ));

  const pendingSentRequests = connectionRequests.filter(r => r.status === 'pending' && r.senderId === (
    currentRole === 'recruiter' ? currentCompany.id :
    currentRole === 'college' ? currentCollege.id :
    currentRole === 'mentor' ? currentMentor.id :
    currentRole === 'professional' ? currentProfessional.id :
    currentStudent.id
  ));

  // Filter recommendations
  const filteredRecommendations = smartRecommendations.filter(rec => {
    const matchesSearch =
      rec.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.headline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.organization.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.sharedSkills.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesRole = roleFilter === 'all' || rec.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  // Filter connections
  const filteredConnections = userConnections.filter(conn => {
    const matchesSearch =
      conn.peerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conn.peerHeadline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conn.peerCompanyOrSchool.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRole = roleFilter === 'all' || conn.peerRole === roleFilter;
    return matchesSearch && matchesRole;
  });

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'student':
        return { label: 'Student', color: 'bg-indigo-500/15 text-indigo-500 border-indigo-500/30', icon: <GraduationCap className="w-3 h-3" /> };
      case 'professional':
      case 'job_seeker':
        return { label: 'Professional', color: 'bg-amber-500/15 text-amber-500 border-amber-500/30', icon: <Briefcase className="w-3 h-3" /> };
      case 'recruiter':
        return { label: 'Recruiter', color: 'bg-emerald-500/15 text-emerald-500 border-emerald-500/30', icon: <Building2 className="w-3 h-3" /> };
      case 'mentor':
        return { label: 'Mentor', color: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30', icon: <Award className="w-3 h-3" /> };
      case 'college':
        return { label: 'Institution', color: 'bg-purple-500/15 text-purple-400 border-purple-500/30', icon: <Building2 className="w-3 h-3" /> };
      default:
        return { label: 'Member', color: 'bg-slate-500/15 text-slate-400 border-slate-500/30', icon: <Shield className="w-3 h-3" /> };
    }
  };

  const handleSendConnectionWithNote = () => {
    if (!selectedUserForNote) return;
    const res = sendConnectionRequest(selectedUserForNote.userId, customNote.trim() || undefined);
    showToast(res.message);
    setSelectedUserForNote(null);
    setCustomNote('');
  };

  return (
    <div className={`min-h-screen pb-24 ${isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-slate-100'}`}>
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-indigo-600 text-white font-medium text-xs shadow-xl animate-fade-in flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className={`sticky top-0 z-30 px-4 py-3 backdrop-blur-md border-b flex items-center justify-between ${
        isLight ? 'bg-white/95 border-slate-200' : 'bg-slate-900/95 border-slate-800'
      }`}>
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setSubView(null)}
            className={`p-2 rounded-xl transition-colors ${
              isLight ? 'text-slate-600 hover:bg-slate-100' : 'text-slate-400 hover:bg-slate-800'
            }`}
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-bold text-base leading-tight font-display flex items-center gap-1.5">
              <span>Professional Network</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-500 font-bold border border-indigo-500/20">
                {userConnections.length} Connected
              </span>
            </h1>
            <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Connect with students, mentors, recruiters & peers
            </p>
          </div>
        </div>

        <button
          onClick={() => setSubView('messages')}
          className="p-2 rounded-xl bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-600 dark:text-indigo-400 relative"
          title="Direct Messages"
        >
          <MessageSquare className="w-4 h-4" />
        </button>
      </div>

      {/* Professional Etiquette Callout Banner */}
      <div className="px-4 pt-3">
        <div className={`p-3 rounded-2xl border flex items-start gap-2.5 ${
          isLight
            ? 'bg-indigo-50/70 border-indigo-100 text-indigo-950'
            : 'bg-indigo-950/30 border-indigo-900/50 text-indigo-200'
        }`}>
          <ShieldCheck className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
          <div className="text-[11px] leading-relaxed">
            <span className="font-bold">Career-Driven Community:</span> NEXIF5 connections are designed for professional development, mentorship guidance, and hiring. Keep outreach purposeful and respectful.
          </div>
        </div>
      </div>

      {/* Search Input */}
      <div className="px-4 pt-3">
        <div className={`relative flex items-center rounded-2xl border px-3 py-2 transition-all ${
          isLight
            ? 'bg-white border-slate-200 focus-within:border-indigo-500 shadow-xs'
            : 'bg-slate-800/80 border-slate-700/80 focus-within:border-indigo-500'
        }`}>
          <Search className="w-4 h-4 text-slate-400 mr-2" />
          <input
            type="text"
            placeholder="Search by name, skill, company, or institution..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent text-xs focus:outline-none placeholder:text-slate-400"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="p-1 text-slate-400 hover:text-slate-600">
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Navigation Subtabs */}
      <div className="px-4 pt-3">
        <div className={`grid grid-cols-4 p-1 rounded-2xl border text-xs font-semibold ${
          isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-800/60 border-slate-800'
        }`}>
          <button
            onClick={() => setActiveTab('recommendations')}
            className={`py-2 px-1 text-center rounded-xl transition-all text-[11px] flex items-center justify-center gap-1 ${
              activeTab === 'recommendations'
                ? 'bg-indigo-600 text-white shadow-xs font-bold'
                : isLight ? 'text-slate-600 hover:text-slate-900' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3 h-3" />
            <span>Discover</span>
          </button>

          <button
            onClick={() => setActiveTab('requests')}
            className={`py-2 px-1 text-center rounded-xl transition-all text-[11px] flex items-center justify-center gap-1 relative ${
              activeTab === 'requests'
                ? 'bg-indigo-600 text-white shadow-xs font-bold'
                : isLight ? 'text-slate-600 hover:text-slate-900' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Clock className="w-3 h-3" />
            <span>Requests</span>
            {pendingReceivedRequests.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center">
                {pendingReceivedRequests.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('connections')}
            className={`py-2 px-1 text-center rounded-xl transition-all text-[11px] flex items-center justify-center gap-1 ${
              activeTab === 'connections'
                ? 'bg-indigo-600 text-white shadow-xs font-bold'
                : isLight ? 'text-slate-600 hover:text-slate-900' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3 h-3" />
            <span>Connected</span>
          </button>

          <button
            onClick={() => setActiveTab('following')}
            className={`py-2 px-1 text-center rounded-xl transition-all text-[11px] flex items-center justify-center gap-1 ${
              activeTab === 'following'
                ? 'bg-indigo-600 text-white shadow-xs font-bold'
                : isLight ? 'text-slate-600 hover:text-slate-900' : 'text-slate-400 hover:text-white'
            }`}
          >
            <UserCheck className="w-3 h-3" />
            <span>Following</span>
          </button>
        </div>
      </div>

      {/* Role Filter Chips */}
      <div className="px-4 pt-3 flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
        {[
          { id: 'all', label: 'All Roles' },
          { id: 'student', label: 'Students' },
          { id: 'professional', label: 'Professionals' },
          { id: 'recruiter', label: 'Recruiters' },
          { id: 'mentor', label: 'Mentors' },
          { id: 'college', label: 'Institutions' }
        ].map((f) => {
          const isActive = roleFilter === f.id;
          return (
            <button
              key={f.id}
              onClick={() => setRoleFilter(f.id as any)}
              className={`px-2.5 py-1 rounded-xl text-[11px] font-semibold whitespace-nowrap border transition-all ${
                isActive
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                  : isLight
                  ? 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700/80'
              }`}
            >
              {f.label}
            </button>
          );
        })}
      </div>

      {/* ------------------------------------------------------------------ */}
      {/* TAB 1: SMART RECOMMENDATIONS */}
      {/* ------------------------------------------------------------------ */}
      {activeTab === 'recommendations' && (
        <div className="px-4 pt-4 space-y-3.5">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold flex items-center gap-1.5 uppercase tracking-wider text-indigo-500">
              <Sparkles className="w-3.5 h-3.5" />
              <span>People You May Want to Connect With</span>
            </h2>
            <span className={`text-[11px] ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
              Powered by NEXIF5 AI
            </span>
          </div>

          {filteredRecommendations.length === 0 ? (
            <div className={`p-8 text-center rounded-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-slate-800/40 border-slate-800'
            }`}>
              <Users className="w-8 h-8 text-slate-400 mx-auto mb-2 opacity-60" />
              <p className="text-xs font-semibold">No recommendations match your search</p>
              <p className={`text-[11px] mt-1 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Try adjusting your role filter or search term
              </p>
            </div>
          ) : (
            filteredRecommendations.map((rec) => {
              const status = getConnectionStatusWithUser(rec.userId);
              const badge = getRoleBadge(rec.role);

              return (
                <div
                  key={rec.userId}
                  className={`p-4 rounded-2xl border transition-all ${
                    isLight
                      ? 'bg-white border-slate-200/80 shadow-xs hover:border-indigo-200'
                      : 'bg-slate-800/70 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div
                      className="flex items-start gap-3 cursor-pointer flex-1"
                      onClick={() => openUserProfile(rec.userId)}
                    >
                      <img
                        src={rec.avatarUrl}
                        alt={rec.name}
                        className="w-12 h-12 rounded-full object-cover border-2 border-indigo-500/30 shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h3 className="font-bold text-sm leading-tight hover:text-indigo-500 transition-colors">
                            {rec.name}
                          </h3>
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border flex items-center gap-1 ${badge.color}`}>
                            {badge.icon}
                            <span>{badge.label}</span>
                          </span>
                        </div>
                        <p className={`text-xs mt-0.5 leading-snug line-clamp-2 ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                          {rec.headline}
                        </p>
                        <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
                          {rec.organization} • {rec.location}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => toggleFollowUser(rec.userId)}
                      className={`p-1.5 rounded-xl border text-xs transition-all ${
                        rec.isFollowing
                          ? 'bg-indigo-500/15 text-indigo-500 border-indigo-500/30'
                          : isLight
                          ? 'text-slate-400 hover:text-slate-600 border-slate-200'
                          : 'text-slate-500 hover:text-slate-300 border-slate-700'
                      }`}
                      title={rec.isFollowing ? 'Following' : 'Follow for public updates'}
                    >
                      <Bookmark className="w-3.5 h-3.5" fill={rec.isFollowing ? 'currentColor' : 'none'} />
                    </button>
                  </div>

                  {/* AI Explanation Callout */}
                  <div className={`mt-3 p-2.5 rounded-xl border flex items-start gap-2 ${
                    isLight
                      ? 'bg-indigo-50/60 border-indigo-100 text-indigo-900'
                      : 'bg-indigo-950/40 border-indigo-900/40 text-indigo-200'
                  }`}>
                    <Sparkles className="w-3.5 h-3.5 text-indigo-500 shrink-0 mt-0.5" />
                    <div className="text-[11px] leading-relaxed">
                      <span className="font-bold text-indigo-600 dark:text-indigo-400">Why Recommended: </span>
                      {rec.whyAiRecommended}
                    </div>
                  </div>

                  {/* Shared Skills tags */}
                  {rec.sharedSkills.length > 0 && (
                    <div className="mt-2.5 flex items-center gap-1.5 flex-wrap">
                      <span className={`text-[10px] font-bold ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
                        Aligned Skills:
                      </span>
                      {rec.sharedSkills.map((skill, idx) => (
                        <span
                          key={idx}
                          className={`px-2 py-0.5 rounded-md text-[10px] font-medium border ${
                            isLight
                              ? 'bg-slate-100 border-slate-200 text-slate-700'
                              : 'bg-slate-700/60 border-slate-700 text-slate-300'
                          }`}
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Actions Row */}
                  <div className="mt-3.5 pt-3 border-t flex items-center justify-between gap-2 border-slate-200 dark:border-slate-800">
                    <button
                      onClick={() => openUserProfile(rec.userId)}
                      className={`text-xs font-semibold px-2.5 py-1.5 rounded-xl transition-colors ${
                        isLight ? 'text-slate-600 hover:bg-slate-100' : 'text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      View Profile
                    </button>

                    <div className="flex items-center gap-2">
                      {status === 'connected' ? (
                        <>
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-500 px-2 py-1 rounded-lg bg-emerald-500/10">
                            <Check className="w-3 h-3" />
                            Connected
                          </span>
                          <button
                            onClick={() => startOrOpenConversation(rec.userId)}
                            className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1 shadow-xs transition-transform active:scale-95"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Message</span>
                          </button>
                        </>
                      ) : status === 'pending_sent' ? (
                        <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-3 py-1.5 rounded-xl border ${
                          isLight
                            ? 'bg-amber-50 text-amber-700 border-amber-200'
                            : 'bg-amber-950/40 text-amber-400 border-amber-900/50'
                        }`}>
                          <Clock className="w-3.5 h-3.5" />
                          <span>Request Sent</span>
                        </span>
                      ) : status === 'pending_received' ? (
                        <button
                          onClick={() => setActiveTab('requests')}
                          className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 shadow-xs"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Respond</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => setSelectedUserForNote(rec)}
                          className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1 shadow-xs transition-transform active:scale-95"
                        >
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>Connect</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* TAB 2: REQUESTS MANAGEMENT */}
      {/* ------------------------------------------------------------------ */}
      {activeTab === 'requests' && (
        <div className="px-4 pt-4 space-y-4">
          {/* Received Requests */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-500 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                <span>Received Requests ({pendingReceivedRequests.length})</span>
              </h3>
            </div>

            {pendingReceivedRequests.length === 0 ? (
              <div className={`p-5 text-center rounded-2xl border text-xs ${
                isLight ? 'bg-white border-slate-200 text-slate-500' : 'bg-slate-800/40 border-slate-800 text-slate-400'
              }`}>
                No pending requests received.
              </div>
            ) : (
              <div className="space-y-3">
                {pendingReceivedRequests.map((req) => (
                  <div
                    key={req.id}
                    className={`p-4 rounded-2xl border ${
                      isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-800'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <img
                        src={req.senderAvatar}
                        alt={req.senderName}
                        className="w-12 h-12 rounded-full object-cover border-2 border-indigo-500/40 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-sm leading-tight hover:text-indigo-500 cursor-pointer"
                              onClick={() => openUserProfile(req.senderId)}>
                            {req.senderName}
                          </h4>
                          <span className={`text-[10px] ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
                            {req.createdAt}
                          </span>
                        </div>
                        <p className={`text-xs mt-0.5 line-clamp-1 ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                          {req.senderHeadline}
                        </p>

                        {/* Note from sender */}
                        {req.note && (
                          <div className={`mt-2 p-2.5 rounded-xl border text-[11px] leading-relaxed ${
                            isLight
                              ? 'bg-slate-50 border-slate-200 text-slate-700'
                              : 'bg-slate-900/60 border-slate-800 text-slate-300'
                          }`}>
                            <span className="font-bold text-indigo-500">Note: </span>
                            "{req.note}"
                          </div>
                        )}

                        {/* Action buttons */}
                        <div className="mt-3 flex items-center gap-2">
                          <button
                            onClick={() => {
                              acceptConnectionRequest(req.id);
                              showToast(`Accepted connection from ${req.senderName}!`);
                            }}
                            className="flex-1 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center justify-center gap-1 shadow-xs"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Accept</span>
                          </button>

                          <button
                            onClick={() => {
                              declineConnectionRequest(req.id);
                              showToast(`Declined request.`);
                            }}
                            className={`px-3 py-1.5 rounded-xl border text-xs font-semibold ${
                              isLight
                                ? 'border-slate-200 hover:bg-slate-100 text-slate-600'
                                : 'border-slate-700 hover:bg-slate-800 text-slate-300'
                            }`}
                          >
                            Decline
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sent Requests */}
          <div>
            <div className="flex items-center justify-between mb-2 mt-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Send className="w-3.5 h-3.5" />
                <span>Sent Invitations ({pendingSentRequests.length})</span>
              </h3>
            </div>

            {pendingSentRequests.length === 0 ? (
              <div className={`p-4 text-center rounded-2xl border text-xs ${
                isLight ? 'bg-white border-slate-200 text-slate-500' : 'bg-slate-800/40 border-slate-800 text-slate-400'
              }`}>
                No invitations currently pending.
              </div>
            ) : (
              <div className="space-y-2.5">
                {pendingSentRequests.map((req) => (
                  <div
                    key={req.id}
                    className={`p-3 rounded-2xl border flex items-center justify-between gap-3 ${
                      isLight ? 'bg-white border-slate-200' : 'bg-slate-800/60 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-9 rounded-full bg-indigo-500/15 flex items-center justify-center text-indigo-500 font-bold text-xs shrink-0">
                        {req.receiverRole.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold truncate">Invitation to User #{req.receiverId}</p>
                        <p className={`text-[10px] ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
                          Sent {req.createdAt} • Awaiting response
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        cancelConnectionRequest(req.id);
                        showToast('Invitation cancelled.');
                      }}
                      className={`text-xs font-semibold px-2.5 py-1 rounded-xl border transition-colors ${
                        isLight
                          ? 'text-rose-600 border-rose-200 hover:bg-rose-50'
                          : 'text-rose-400 border-rose-900/60 hover:bg-rose-950/40'
                      }`}
                    >
                      Cancel
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* TAB 3: MY CONNECTIONS */}
      {/* ------------------------------------------------------------------ */}
      {activeTab === 'connections' && (
        <div className="px-4 pt-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-500 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" />
              <span>All Connections ({filteredConnections.length})</span>
            </h3>
          </div>

          {filteredConnections.length === 0 ? (
            <div className={`p-8 text-center rounded-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-slate-800/40 border-slate-800'
            }`}>
              <Users className="w-8 h-8 text-slate-400 mx-auto mb-2 opacity-60" />
              <p className="text-xs font-semibold">No connections found</p>
              <p className={`text-[11px] mt-1 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Explore recommendations in the Discover tab to build your network!
              </p>
            </div>
          ) : (
            filteredConnections.map((conn) => {
              const badge = getRoleBadge(conn.peerRole);

              return (
                <div
                  key={conn.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/70 border-slate-800'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div
                      className="flex items-start gap-3 cursor-pointer flex-1"
                      onClick={() => openUserProfile(conn.peerId)}
                    >
                      <img
                        src={conn.peerAvatar}
                        alt={conn.peerName}
                        className="w-12 h-12 rounded-full object-cover border-2 border-indigo-500/30 shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h4 className="font-bold text-sm leading-tight hover:text-indigo-500 transition-colors">
                            {conn.peerName}
                          </h4>
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border flex items-center gap-1 ${badge.color}`}>
                            {badge.icon}
                            <span>{badge.label}</span>
                          </span>
                        </div>
                        <p className={`text-xs mt-0.5 leading-snug line-clamp-1 ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                          {conn.peerHeadline}
                        </p>
                        <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
                          {conn.peerCompanyOrSchool} • Connected {conn.connectedAt}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t flex items-center justify-between border-slate-200 dark:border-slate-800">
                    <button
                      onClick={() => {
                        removeConnection(conn.id);
                        showToast(`Removed ${conn.peerName} from connections.`);
                      }}
                      className={`text-[11px] font-medium transition-colors ${
                        isLight ? 'text-slate-400 hover:text-rose-600' : 'text-slate-500 hover:text-rose-400'
                      }`}
                    >
                      Remove Connection
                    </button>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openUserProfile(conn.peerId)}
                        className={`text-xs font-semibold px-2.5 py-1.5 rounded-xl border transition-colors ${
                          isLight
                            ? 'border-slate-200 hover:bg-slate-100 text-slate-700'
                            : 'border-slate-700 hover:bg-slate-800 text-slate-300'
                        }`}
                      >
                        Profile
                      </button>

                      <button
                        onClick={() => startOrOpenConversation(conn.peerId)}
                        className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1 shadow-xs transition-transform active:scale-95"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Message</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* TAB 4: FOLLOWING */}
      {/* ------------------------------------------------------------------ */}
      {activeTab === 'following' && (
        <div className="px-4 pt-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-500 flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5" />
              <span>Accounts You Follow</span>
            </h3>
          </div>

          {smartRecommendations.filter(r => r.isFollowing).length === 0 ? (
            <div className={`p-8 text-center rounded-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-slate-800/40 border-slate-800'
            }`}>
              <Bookmark className="w-8 h-8 text-slate-400 mx-auto mb-2 opacity-60" />
              <p className="text-xs font-semibold">You are not following any accounts yet</p>
              <p className={`text-[11px] mt-1 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Bookmark professional accounts to keep track of their public career updates.
              </p>
            </div>
          ) : (
            smartRecommendations.filter(r => r.isFollowing).map((rec) => (
              <div
                key={rec.userId}
                className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 ${
                  isLight ? 'bg-white border-slate-200' : 'bg-slate-800/70 border-slate-800'
                }`}
              >
                <div
                  className="flex items-center gap-3 min-w-0 cursor-pointer flex-1"
                  onClick={() => openUserProfile(rec.userId)}
                >
                  <img
                    src={rec.avatarUrl}
                    alt={rec.name}
                    className="w-10 h-10 rounded-full object-cover shrink-0 border border-indigo-500/30"
                  />
                  <div className="min-w-0">
                    <h4 className="font-bold text-xs truncate hover:text-indigo-500">{rec.name}</h4>
                    <p className={`text-[11px] truncate ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                      {rec.headline}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => startOrOpenConversation(rec.userId)}
                    className="p-1.5 rounded-xl bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-600/20"
                    title="Send Message"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => {
                      toggleFollowUser(rec.userId);
                      showToast(`Unfollowed ${rec.name}`);
                    }}
                    className={`px-2.5 py-1 rounded-xl border text-[11px] font-semibold ${
                      isLight
                        ? 'border-slate-200 text-slate-600 hover:bg-slate-100'
                        : 'border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    Unfollow
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* MODAL: ADD A PERSONAL NOTE TO CONNECTION REQUEST */}
      {/* ------------------------------------------------------------------ */}
      {selectedUserForNote && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4">
          <div className={`w-full max-w-md rounded-3xl p-5 border shadow-2xl transition-all ${
            isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-slate-900 border-slate-800 text-white'
          }`}>
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <img
                  src={selectedUserForNote.avatarUrl}
                  alt={selectedUserForNote.name}
                  className="w-10 h-10 rounded-full object-cover border border-indigo-500"
                />
                <div>
                  <h3 className="font-bold text-sm leading-tight">Connect with {selectedUserForNote.name}</h3>
                  <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                    {selectedUserForNote.organization}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedUserForNote(null)}
                className={`p-1.5 rounded-xl ${isLight ? 'hover:bg-slate-100' : 'hover:bg-slate-800'}`}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="py-3 space-y-2">
              <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                Add an optional professional note explaining why you'd like to connect:
              </p>

              <textarea
                rows={3}
                placeholder="e.g. Hi, I admire your work on distributed systems and would love to connect and follow your career trajectory!"
                value={customNote}
                onChange={(e) => setCustomNote(e.target.value)}
                className={`w-full p-3 rounded-2xl border text-xs resize-none focus:outline-none focus:border-indigo-500 ${
                  isLight
                    ? 'bg-slate-50 border-slate-200 text-slate-900'
                    : 'bg-slate-800/80 border-slate-700 text-slate-100'
                }`}
              />

              <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                <Info className="w-3 h-3" />
                <span>Personalized notes increase connection acceptance rates by 68%.</span>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                onClick={() => setSelectedUserForNote(null)}
                className={`px-3 py-2 rounded-xl text-xs font-semibold ${
                  isLight ? 'text-slate-600 hover:bg-slate-100' : 'text-slate-400 hover:bg-slate-800'
                }`}
              >
                Cancel
              </button>
              <button
                onClick={handleSendConnectionWithNote}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Send Request</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
