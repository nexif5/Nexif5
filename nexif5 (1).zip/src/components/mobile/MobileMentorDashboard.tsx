import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Award,
  Users,
  CalendarCheck,
  Star,
  Clock,
  CheckCircle2,
  ChevronRight,
  Sparkles,
  FileText,
  MessageSquare,
  Plus
} from 'lucide-react';

export const MobileMentorDashboard: React.FC = () => {
  const { currentMentor, addMentorshipSession, theme } = useApp();
  const isLight = theme === 'light';

  const [activeTab, setActiveTab] = useState<'sessions' | 'evaluations'>('sessions');
  const [showScorecardModal, setShowScorecardModal] = useState(false);
  const [evaluatingMentee, setEvaluatingMentee] = useState('Aarav Sharma');
  const [techRating, setTechRating] = useState(9);
  const [commRating, setCommRating] = useState(8);
  const [problemRating, setProblemRating] = useState(9);
  const [notes, setNotes] = useState('Strong analytical framing. Practice Power BI DAX row-context explanation.');

  return (
    <div className={`p-4 space-y-4 pb-24 font-sans ${isLight ? 'text-slate-900' : 'text-white'}`}>
      {/* Mentor Profile Header */}
      <div className={`p-4 rounded-2xl border ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <img
              src={currentMentor.avatarUrl}
              alt={currentMentor.name}
              className="w-14 h-14 rounded-2xl object-cover border-2 border-cyan-500 shadow-md"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold font-display">{currentMentor.name}</h1>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-600 dark:text-cyan-300 font-bold">
                  Mentor
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {currentMentor.jobTitle} • {currentMentor.company}
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {currentMentor.experienceYears} Yrs Exp • {currentMentor.location}
              </p>
            </div>
          </div>
        </div>

        {/* Rating and Availability Pill */}
        <div className="grid grid-cols-2 gap-2 mt-3.5 pt-3 border-t border-slate-700/50 text-xs">
          <div className="flex items-center gap-1.5">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
            <span className="font-bold">{currentMentor.averageRating} Rating</span>
            <span className="text-slate-400">({currentMentor.sessionsCompletedCount} reviews)</span>
          </div>
          <div className="flex items-center gap-1.5 text-cyan-400 font-bold justify-end">
            <Clock className="w-4 h-4" />
            <span>{currentMentor.availabilityHoursPerWeek} hrs/week open</span>
          </div>
        </div>
      </div>

      {/* 4 Performance Metric Tiles */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Users className="w-4 h-4 text-cyan-500" />
            <span className="text-[10px] text-cyan-400 font-bold">Total</span>
          </div>
          <p className="text-xl font-black font-display">{currentMentor.totalMenteesCount}</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Active Mentees</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <CalendarCheck className="w-4 h-4 text-emerald-500" />
            <span className="text-[10px] text-emerald-500 font-bold">Upcoming</span>
          </div>
          <p className="text-xl font-black font-display">{currentMentor.sessions.filter(s => s.status === 'upcoming').length}</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Scheduled Sessions</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Award className="w-4 h-4 text-purple-500" />
            <span className="text-[10px] text-purple-400 font-bold">Completed</span>
          </div>
          <p className="text-xl font-black font-display">{currentMentor.sessionsCompletedCount}</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Mock Interviews & Reviews</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Star className="w-4 h-4 text-amber-500" />
            <span className="text-[10px] text-amber-500 font-bold">Satisfaction</span>
          </div>
          <p className="text-xl font-black font-display">99%</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Positive Feedback</p>
        </div>
      </div>

      {/* Upcoming Mentorship Sessions */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CalendarCheck className="w-4 h-4 text-cyan-500" />
            <h2 className="text-sm font-bold">Upcoming Mentorship Sessions</h2>
          </div>
          <button
            onClick={() => setShowScorecardModal(true)}
            className="text-[11px] font-bold text-cyan-500 hover:underline flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Evaluation</span>
          </button>
        </div>

        <div className="space-y-2.5">
          {currentMentor.sessions.map((sess) => (
            <div
              key={sess.id}
              className={`p-3 rounded-xl border space-y-2 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <img
                    src={sess.menteeAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                    alt={sess.menteeName}
                    className="w-10 h-10 rounded-full object-cover border border-cyan-500/50"
                  />
                  <div>
                    <h3 className="text-xs font-bold">{sess.menteeName}</h3>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      {sess.menteeGoal}
                    </p>
                  </div>
                </div>

                <span className={`text-[10px] px-2 py-0.5 rounded font-bold capitalize ${
                  sess.status === 'upcoming' ? 'bg-cyan-500/20 text-cyan-300' : 'bg-emerald-500/20 text-emerald-400'
                }`}>
                  {sess.status}
                </span>
              </div>

              <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-800 text-slate-400">
                <span>{sess.type} • {sess.time}</span>
                <span className="font-semibold text-white">{sess.date}</span>
              </div>

              {sess.notes && (
                <p className="text-[10px] text-slate-400 bg-slate-800/40 p-2 rounded-lg">
                  📌 {sess.notes}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Mock Interview Evaluation Scorecard Modal */}
      {showScorecardModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs font-sans">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-cyan-400" />
              <span>Record Mock Interview Scorecard</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Mentee Name</label>
                <input
                  type="text"
                  value={evaluatingMentee}
                  onChange={(e) => setEvaluatingMentee(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-400 text-[10px] mb-1">Technical (1-10)</label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={techRating}
                    onChange={(e) => setTechRating(parseInt(e.target.value) || 5)}
                    className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 text-[10px] mb-1">Communication</label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={commRating}
                    onChange={(e) => setCommRating(parseInt(e.target.value) || 5)}
                    className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 text-[10px] mb-1">Problem Solving</label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={problemRating}
                    onChange={(e) => setProblemRating(parseInt(e.target.value) || 5)}
                    className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Actionable Mentee Feedback</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-[11px]"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowScorecardModal(false)}
                className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  alert(`Evaluation saved and shared with ${evaluatingMentee}!`);
                  setShowScorecardModal(false);
                }}
                className="flex-1 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold"
              >
                Save Scorecard
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
