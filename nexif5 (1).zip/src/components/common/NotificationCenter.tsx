import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { NotificationItem } from '../../types';
import {
  Bell,
  CheckCheck,
  Briefcase,
  CalendarCheck,
  Award,
  Sparkles,
  School,
  X
} from 'lucide-react';

export const NotificationCenter: React.FC = () => {
  const {
    notifications,
    currentRole,
    currentStudent,
    currentCompany,
    currentCollege,
    markNotificationRead,
    markAllNotificationsRead,
    setActiveStudentTab,
    setActiveRecruiterTab,
    setActiveCollegeTab
  } = useApp();

  const [isOpen, setIsOpen] = useState(false);

  // Filter notifications for the current active persona
  const relevantNotifications = notifications.filter(n => {
    if (currentRole === 'student') {
      return n.recipientType === 'student' && (n.recipientId === currentStudent.id || n.recipientId === 'all');
    }
    if (currentRole === 'recruiter') {
      return n.recipientType === 'recruiter';
    }
    if (currentRole === 'college') {
      return n.recipientType === 'college';
    }
    return true;
  });

  const unreadCount = relevantNotifications.filter(n => !n.read).length;

  const handleNotificationClick = (notif: NotificationItem) => {
    markNotificationRead(notif.id);
    setIsOpen(false);

    if (currentRole === 'student') {
      if (notif.type === 'job_match') setActiveStudentTab('jobs');
      else if (notif.type === 'application_update' || notif.type === 'shortlisted' || notif.type === 'interview_scheduled') {
        setActiveStudentTab('applications');
      }
    } else if (currentRole === 'recruiter') {
      if (notif.type === 'new_applicant') setActiveRecruiterTab('applications');
      else if (notif.type === 'interview_scheduled') setActiveRecruiterTab('interviews');
    } else if (currentRole === 'college') {
      if (notif.type === 'campus_drive') setActiveCollegeTab('placements');
      else if (notif.type === 'system') setActiveCollegeTab('skill_gaps');
    }
  };

  const getNotifIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'job_match':
        return <Sparkles className="w-4 h-4 text-purple-600" />;
      case 'interview_scheduled':
        return <CalendarCheck className="w-4 h-4 text-blue-600" />;
      case 'shortlisted':
        return <Award className="w-4 h-4 text-emerald-600" />;
      case 'new_applicant':
        return <Briefcase className="w-4 h-4 text-indigo-600" />;
      case 'campus_drive':
        return <School className="w-4 h-4 text-teal-600" />;
      default:
        return <Bell className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors focus:outline-none"
        aria-label="View notifications"
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-rose-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center animate-pulse">
            {unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setIsOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-200 z-50 overflow-hidden"
            >
              {/* Header */}
              <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-slate-900 text-sm">Notifications</h4>
                  {unreadCount > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 text-xs font-semibold">
                      {unreadCount} new
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {unreadCount > 0 && (
                    <button
                      onClick={markAllNotificationsRead}
                      className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                    >
                      <CheckCheck className="w-3.5 h-3.5" />
                      <span>Mark read</span>
                    </button>
                  )}
                  <button
                    onClick={() => setIsOpen(false)}
                    className="p-1 rounded-md text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* List */}
              <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                {relevantNotifications.length > 0 ? (
                  relevantNotifications.map((notif) => (
                    <button
                      key={notif.id}
                      onClick={() => handleNotificationClick(notif)}
                      className={`w-full text-left p-3.5 hover:bg-slate-50 transition-colors flex items-start gap-3 ${
                        !notif.read ? 'bg-indigo-50/40' : ''
                      }`}
                    >
                      <span className="p-2 rounded-xl bg-slate-100 shrink-0 mt-0.5">
                        {getNotifIcon(notif.type)}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1 mb-0.5">
                          <p className={`text-xs font-semibold truncate ${!notif.read ? 'text-slate-900' : 'text-slate-700'}`}>
                            {notif.title}
                          </p>
                          <span className="text-[10px] text-slate-400 shrink-0 font-medium">{notif.date}</span>
                        </div>
                        <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">
                          {notif.message}
                        </p>
                      </div>
                    </button>
                  ))
                ) : (
                  <div className="p-8 text-center text-xs text-slate-500">
                    <Bell className="w-8 h-8 mx-auto text-slate-300 mb-2 stroke-1" />
                    <p>No recent notifications.</p>
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="p-2.5 bg-slate-50 border-t border-slate-100 text-center text-[11px] text-slate-500">
                Live alerts for jobs, candidate matches & interview updates
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};
