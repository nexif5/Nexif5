import {
  StudentProfile,
  CompanyOrganization,
  CollegeOrganization,
  JobOpportunity,
  JobApplication,
  ScheduledInterview,
  CollegeSkillMetric,
  CollegeDepartmentStat,
  NotificationItem,
  SharedResource,
  SkillProgressItem,
  CertifiedCourse,
  WorkingProfessionalProfile,
  MentorProfile,
  AdminUserRecord,
  ConnectionRequest,
  UserConnection,
  SmartConnectionRecommendation,
  DirectChatMessage,
  ChatConversation,
  QuickMessageTemplate
} from '../types';


export const MOCK_STUDENTS: StudentProfile[] = [
  {
    id: 'std-jobseeker',
    name: 'Rahul Verma',
    email: 'rahul.verma@example.com',
    phone: '+91 98112 34980',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    bio: 'Experienced Business & Financial Analyst with 2+ years executing data-driven business modeling, SQL pipelines, and Power BI dashboards. Seeking Senior Analyst / Strategy roles.',
    userType: 'job_seeker',
    workExperienceYears: 2,
    currentDesignation: 'Associate Business Analyst',
    education: {
      degree: 'B.Com Honours & Analytics',
      course: 'Finance & Applied Analytics',
      institution: 'Delhi University (Graduate)',
      yearOfPassing: 2023,
      currentYear: 'Working Professional (2+ Yrs Exp)',
      cgpaOrPercentage: '8.9 CGPA'
    },
    // Independent General User / Job Seeker without college affiliation
    careerGoal: 'Business Analyst',
    targetIndustry: 'FinTech, SaaS & Analytics Consulting',
    preferredJobRoles: ['Senior Business Analyst', 'Business Analyst', 'Product Operations Analyst', 'Financial Strategy Associate'],
    salaryPreferenceMinLPA: 7.5,
    salaryPreferenceMaxLPA: 14.0,
    locationPreferenceType: 'anywhere_in_india',
    preferredCities: ['Bengaluru', 'Gurugram', 'Mumbai', 'Hyderabad', 'Remote'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's-js-1', name: 'Excel (Advanced)', category: 'tools', level: 'expert', verified: true },
      { id: 's-js-2', name: 'SQL', category: 'technical', level: 'advanced', verified: true },
      { id: 's-js-3', name: 'Power BI', category: 'analytics', level: 'advanced', verified: true },
      { id: 's-js-4', name: 'Business Analysis', category: 'domain', level: 'advanced', verified: true },
      { id: 's-js-5', name: 'Financial Modeling', category: 'analytics', level: 'intermediate', verified: true },
      { id: 's-js-6', name: 'Tableau', category: 'tools', level: 'intermediate', verified: true },
      { id: 's-js-7', name: 'Python Basics', category: 'technical', level: 'beginner', verified: false }
    ],
    achievements: [
      {
        id: 'ach-js-1',
        title: 'Top Performer Award — FY24 Analytics Excellence',
        issuer: 'Finlytics Advisory Corp',
        date: 'Jul 2024',
        description: 'Recognized for automating client reporting workflows, cutting manual turnaround time by 60%.',
        category: 'leadership'
      },
      {
        id: 'ach-js-2',
        title: 'Certified Analytics Professional (CAP)',
        issuer: 'INFORMS / Global Analytics Body',
        date: 'Mar 2024',
        description: 'Comprehensive certification in business problem framing, data modeling, and methodology selection.',
        category: 'certification'
      },
      {
        id: 'ach-js-3',
        title: '1st Place — National Strategy Case Challenge',
        issuer: 'IIM Ahmedabad Confluence',
        date: 'Oct 2023',
        description: 'Built customer cohort margin model for D2C supply chain expansion strategy.',
        category: 'competition'
      }
    ],
    projects: [
      {
        id: 'prj-js-1',
        title: 'Enterprise Customer LTV & Cohort Retention Engine',
        description: 'Engineered an automated SQL + Power BI analytical data mart tracking 120k customer subscription lifecycles, identifying ₹45 Lakhs in churn reduction opportunities.',
        technologies: ['SQL', 'Power BI DAX', 'PostgreSQL', 'Tableau'],
        liveUrl: 'https://github.com/rahul-verma/ltv-retention-engine',
        githubUrl: 'https://github.com/rahul-verma/ltv-retention-engine',
        startDate: 'Aug 2023',
        endDate: 'Dec 2023',
        role: 'Lead Business Analyst'
      },
      {
        id: 'prj-js-2',
        title: 'B2B SaaS Revenue Forecasting & Pricing Optimization Model',
        description: 'Created dynamic scenario-based financial model forecasting ARR growth across multi-tiered enterprise licensing tiers.',
        technologies: ['Advanced Excel', 'Financial Modeling', 'Monte Carlo Sim', 'Power Query'],
        startDate: 'Jan 2024',
        endDate: 'Jun 2024',
        role: 'Senior Financial Modeler'
      }
    ],
    experiences: [
      {
        id: 'exp-js-1',
        role: 'Associate Business Analyst',
        company: 'Finlytics Advisory Corp',
        location: 'Gurugram (Hybrid)',
        startDate: 'Jul 2023',
        endDate: 'Present',
        isCurrent: true,
        description: 'Leading data ingestion, financial KPI tracking, and weekly stakeholder presentations for 6 Tier-1 enterprise clients.'
      }
    ],
    languages: ['English (Fluent)', 'Hindi (Native)', 'Punjabi (Conversational)'],
    resumeName: 'Rahul_Verma_Senior_Business_Analyst_2025.pdf',
    resumeUpdatedDate: '2025-02-01',
    careerReadinessScore: 94,
    isPlacementEligible: false,
    createdAt: '2024-06-15'
  },
  {
    id: 'std-1',
    name: 'Aarav Sharma',
    email: 'aarav.sharma@example.com',
    phone: '+91 98450 12345',
    avatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    bio: 'Aspiring Business Analyst and Data Enthusiast passionate about translating financial & operational data into clear strategic decisions.',
    education: {
      degree: 'B.Com (Computer Applications)',
      course: 'Commerce & Data Analytics',
      institution: 'Rathinam Global University',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.7 CGPA'
    },
    collegeId: 'clg-1',
    collegeName: 'Rathinam Global University',
    department: 'Commerce & Computer Applications',
    careerGoal: 'Business Analyst',
    targetIndustry: 'FinTech & Analytics Consulting',
    preferredJobRoles: ['Business Analyst', 'Junior Data Analyst', 'Operations Associate', 'Financial Analyst'],
    salaryPreferenceMinLPA: 5.5,
    salaryPreferenceMaxLPA: 9.0,
    locationPreferenceType: 'specific_city',
    preferredCities: ['Bengaluru', 'Chennai', 'Coimbatore', 'Hyderabad'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's1', name: 'Excel (Advanced)', category: 'tools', level: 'advanced', verified: true },
      { id: 's2', name: 'Power BI', category: 'analytics', level: 'intermediate', verified: true },
      { id: 's3', name: 'SQL', category: 'technical', level: 'intermediate', verified: false },
      { id: 's4', name: 'Business Analysis', category: 'domain', level: 'advanced', verified: true },
      { id: 's5', name: 'Financial Modeling', category: 'analytics', level: 'intermediate', verified: false },
      { id: 's6', name: 'Tableau', category: 'tools', level: 'beginner', verified: false },
      { id: 's7', name: 'Python Basics', category: 'technical', level: 'beginner', verified: false }
    ],
    achievements: [
      {
        id: 'ach-1',
        title: 'Winner — National FinTech Business Case Challenge 2024',
        issuer: 'IIT Madras Analytics Conclave',
        date: 'Nov 2024',
        description: 'Developed an automated micro-lending risk dashboard using Power BI & financial ratios for 200+ simulated retail borrowers.',
        category: 'competition'
      },
      {
        id: 'ach-2',
        title: 'Certified Data Analytics Associate',
        issuer: 'Microsoft / Coursera',
        date: 'Aug 2024',
        description: 'Completed comprehensive credentials in DAX queries, Power Query ETL, and SQL relational querying.',
        category: 'certification'
      },
      {
        id: 'ach-3',
        title: 'Lead Organizer — Annual Youth Leadership & Case Summit',
        issuer: 'Rathinam Student Council',
        date: 'Feb 2024',
        description: 'Led a team of 18 students to host 450+ delegates across South India.',
        category: 'leadership'
      }
    ],
    projects: [
      {
        id: 'prj-1',
        title: 'OmniChannel Retail Sales Performance & Margin Analyzer',
        description: 'Engineered a unified SQL schema and interactive Power BI executive dashboard for a 50,000-row retail dataset, isolating high churn product categories.',
        technologies: ['SQL', 'Power BI', 'Excel DAX', 'ETL'],
        liveUrl: 'https://github.com/demo/retail-analyzer',
        githubUrl: 'https://github.com/demo/retail-analyzer',
        startDate: 'Sep 2024',
        endDate: 'Nov 2024',
        role: 'Data & Insights Lead'
      },
      {
        id: 'prj-2',
        title: 'Fintech Credit Risk Modeling and Cohort Analysis',
        description: 'Built a predictive spreadsheet model evaluating default risks and cashflow sensitivities across SME loan cohorts.',
        technologies: ['Advanced Excel', 'Financial Ratios', 'Monte Carlo Sim'],
        startDate: 'Jan 2024',
        endDate: 'Apr 2024',
        role: 'Financial Analyst'
      }
    ],
    experiences: [
      {
        id: 'exp-1',
        role: 'Business Analytics Intern',
        company: 'Vanguard Retail Advisory',
        location: 'Coimbatore (Hybrid)',
        startDate: 'Jun 2024',
        endDate: 'Aug 2024',
        isCurrent: false,
        description: 'Analyzed weekly customer transaction logs, audited ERP data anomalies, and presented findings directly to the Operations Director.'
      }
    ],
    languages: ['English (Fluent)', 'Tamil (Native)', 'Hindi (Conversational)'],
    resumeName: 'Aarav_Sharma_Business_Analyst_2025.pdf',
    resumeUpdatedDate: '2025-01-14',
    careerReadinessScore: 78,
    isPlacementEligible: true,
    createdAt: '2024-09-01'
  },
  {
    id: 'std-2',
    name: 'Priya Patel',
    email: 'priya.patel@example.com',
    phone: '+91 97123 45678',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    bio: 'Full Stack & Cloud Developer skilled in React, Node.js, and TypeScript. Eager to solve real customer engineering problems.',
    education: {
      degree: 'B.Tech Computer Science & Engineering',
      course: 'Computer Science',
      institution: 'Independent (Not connected to College)',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '9.2 CGPA'
    },
    // Independent student without college
    careerGoal: 'Full Stack Engineer',
    targetIndustry: 'SaaS & Enterprise Product Companies',
    preferredJobRoles: ['Full Stack Developer', 'Frontend Engineer', 'Software Development Engineer I'],
    salaryPreferenceMinLPA: 7.0,
    salaryPreferenceMaxLPA: 14.0,
    locationPreferenceType: 'anywhere_in_india',
    preferredCities: ['Bengaluru', 'Pune', 'Hyderabad', 'Remote'],
    workPreference: 'remote',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's21', name: 'React / Next.js', category: 'technical', level: 'advanced', verified: true },
      { id: 's22', name: 'TypeScript', category: 'technical', level: 'advanced', verified: true },
      { id: 's23', name: 'Node.js & Express', category: 'technical', level: 'intermediate', verified: true },
      { id: 's24', name: 'PostgreSQL', category: 'technical', level: 'intermediate', verified: false },
      { id: 's25', name: 'Docker & AWS Basics', category: 'tools', level: 'intermediate', verified: false }
    ],
    achievements: [
      {
        id: 'ach-21',
        title: 'Smart India Hackathon 2024 Finalist',
        issuer: 'Ministry of Education, Govt of India',
        date: 'Dec 2024',
        description: 'Built a real-time decentralized disaster relief supply coordination portal for municipal emergency teams.',
        category: 'hackathon'
      }
    ],
    projects: [
      {
        id: 'prj-21',
        title: 'CloudSync — Collaborative Realtime Markdown Notes',
        description: 'Built a multi-tenant workspace with WebSocket CRDT synchronization, auth guards, and automated database backups.',
        technologies: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'WebSockets'],
        liveUrl: 'https://cloudsync-demo.vercel.app',
        githubUrl: 'https://github.com/priyapatel/cloudsync',
        startDate: 'Aug 2024',
        endDate: 'Oct 2024'
      }
    ],
    experiences: [],
    languages: ['English', 'Gujarati', 'Hindi'],
    resumeName: 'Priya_Patel_FullStack_2025.pdf',
    resumeUpdatedDate: '2025-01-20',
    careerReadinessScore: 89,
    createdAt: '2024-10-12'
  },
  {
    id: 'std-3',
    name: 'Rohan Mehta',
    email: 'rohan.mehta@example.com',
    phone: '+91 99201 88344',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    bio: 'Finance & Analytics graduate passionate about equity research, quantitative data wrangling, and financial forecasting.',
    education: {
      degree: 'B.Com (Honours)',
      course: 'Finance & Banking',
      institution: 'Loyola College of Arts & Sciences',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.9 CGPA'
    },
    collegeId: 'clg-3',
    collegeName: 'Loyola College of Arts & Sciences',
    department: 'Commerce & Finance',
    careerGoal: 'Financial Analyst',
    targetIndustry: 'Investment Banking & Corporate Finance',
    preferredJobRoles: ['Financial Analyst', 'Risk Associate', 'Investment Research Associate'],
    salaryPreferenceMinLPA: 6.0,
    salaryPreferenceMaxLPA: 10.5,
    locationPreferenceType: 'specific_city',
    preferredCities: ['Mumbai', 'Bengaluru', 'Chennai'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's31', name: 'Financial Modeling', category: 'analytics', level: 'advanced', verified: true },
      { id: 's32', name: 'Excel (Advanced)', category: 'tools', level: 'advanced', verified: true },
      { id: 's33', name: 'Power BI', category: 'analytics', level: 'intermediate', verified: false },
      { id: 's34', name: 'Corporate Valuation (DCF)', category: 'domain', level: 'advanced', verified: true }
    ],
    achievements: [
      {
        id: 'ach-31',
        title: '1st Place — Inter-Collegiate Equity Pitchathon',
        issuer: 'BSE Institute',
        date: 'Sep 2024',
        description: 'Presented a 30-page investment memo on Indian renewable energy infrastructure companies.',
        category: 'competition'
      }
    ],
    projects: [
      {
        id: 'prj-31',
        title: 'NIFTY 50 Valuation and Sectoral Risk Dashboard',
        description: 'Automated live financial ratio feeds into Excel and Power BI with Monte Carlo simulation for cashflow volatility.',
        technologies: ['Excel VBA', 'Power BI', 'DCF Valuation'],
        startDate: 'Jul 2024',
        endDate: 'Oct 2024'
      }
    ],
    experiences: [],
    languages: ['English', 'Hindi', 'Marathi'],
    resumeName: 'Rohan_Mehta_Finance_2025.pdf',
    resumeUpdatedDate: '2025-01-18',
    careerReadinessScore: 84,
    isPlacementEligible: true,
    createdAt: '2024-09-15'
  },
  {
    id: 'std-4',
    name: 'Ananya Iyer',
    email: 'ananya.iyer@example.com',
    phone: '+91 94441 55670',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    bio: 'Data Science & Machine Learning enthusiast focused on NLP, predictive analytics, and Python pipeline development.',
    education: {
      degree: 'B.Sc Data Analytics',
      course: 'Data Science & Applied Statistics',
      institution: 'Rathinam Global University',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '9.4 CGPA'
    },
    collegeId: 'clg-1',
    collegeName: 'Rathinam Global University',
    department: 'Data Analytics & AI',
    careerGoal: 'Data Scientist',
    targetIndustry: 'AI & Data Platforms',
    preferredJobRoles: ['Data Scientist', 'Machine Learning Engineer', 'Data Analyst'],
    salaryPreferenceMinLPA: 8.0,
    salaryPreferenceMaxLPA: 15.0,
    locationPreferenceType: 'anywhere_in_india',
    preferredCities: ['Bengaluru', 'Hyderabad', 'Chennai'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's41', name: 'Python', category: 'technical', level: 'advanced', verified: true },
      { id: 's42', name: 'SQL', category: 'technical', level: 'advanced', verified: true },
      { id: 's43', name: 'Pandas & Scikit-Learn', category: 'analytics', level: 'advanced', verified: true },
      { id: 's44', name: 'Power BI', category: 'tools', level: 'intermediate', verified: false },
      { id: 's45', name: 'Deep Learning (PyTorch)', category: 'technical', level: 'intermediate', verified: false }
    ],
    achievements: [
      {
        id: 'ach-41',
        title: 'Best Research Paper Award — IEEE Student Symposium',
        issuer: 'IEEE Madras Section',
        date: 'Oct 2024',
        description: 'Published paper on sentiment-grounded consumer demand forecasting using Transformer models.',
        category: 'academic'
      }
    ],
    projects: [
      {
        id: 'prj-41',
        title: 'Customer Churn Predictor with SHAP Explainability',
        description: 'Trained XGBoost and LightGBM models yielding 91% ROC-AUC on 100k customer telecommunication records with web dashboard.',
        technologies: ['Python', 'Scikit-Learn', 'Streamlit', 'SQL'],
        startDate: 'May 2024',
        endDate: 'Aug 2024'
      }
    ],
    experiences: [],
    languages: ['English', 'Tamil', 'French (Basic)'],
    resumeName: 'Ananya_Iyer_DataScience_2025.pdf',
    resumeUpdatedDate: '2025-01-22',
    careerReadinessScore: 92,
    isPlacementEligible: true,
    createdAt: '2024-08-20'
  },
  {
    id: 'std-5',
    name: 'Vikram Sundaram',
    email: 'vikram.s@example.com',
    phone: '+91 98840 99120',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
    bio: 'Product Management aspirant with a dual background in Software Engineering and Marketing Strategy.',
    education: {
      degree: 'B.Tech Information Technology',
      course: 'Information Technology',
      institution: 'PSG College of Technology',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.4 CGPA'
    },
    collegeId: 'clg-2',
    collegeName: 'PSG College of Technology',
    department: 'Information Technology',
    careerGoal: 'Associate Product Manager',
    targetIndustry: 'B2B SaaS & Consumer Tech',
    preferredJobRoles: ['Associate Product Manager', 'Product Analyst', 'Business Analyst'],
    salaryPreferenceMinLPA: 7.5,
    salaryPreferenceMaxLPA: 12.0,
    locationPreferenceType: 'anywhere_in_india',
    preferredCities: ['Bengaluru', 'Coimbatore', 'Chennai'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's51', name: 'Product Roadmapping', category: 'domain', level: 'intermediate', verified: true },
      { id: 's52', name: 'SQL & Analytics', category: 'analytics', level: 'intermediate', verified: true },
      { id: 's53', name: 'Wireframing (Figma)', category: 'tools', level: 'advanced', verified: true },
      { id: 's54', name: 'User Research', category: 'soft', level: 'advanced', verified: false }
    ],
    achievements: [
      {
        id: 'ach-51',
        title: 'National Product Tear-down Winner',
        issuer: 'The Product Folks India',
        date: 'Jul 2024',
        description: 'Analyzed Blinkit quick-commerce onboarding funnel and proposed a 14% cart conversion uplift framework.',
        category: 'competition'
      }
    ],
    projects: [],
    experiences: [],
    languages: ['English', 'Tamil'],
    resumeName: 'Vikram_Sundaram_APM_2025.pdf',
    resumeUpdatedDate: '2025-01-10',
    careerReadinessScore: 81,
    isPlacementEligible: true,
    createdAt: '2024-09-18'
  },
  {
    id: 'std-6',
    name: 'Sneha Reddy',
    email: 'sneha.reddy@example.com',
    phone: '+91 91000 44221',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    bio: 'Enthusiastic QA & Automation Engineer with expertise in Selenium, Python test scripts, and API integration testing.',
    education: {
      degree: 'B.Tech CSE',
      course: 'Computer Science',
      institution: 'Rathinam Global University',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.2 CGPA'
    },
    collegeId: 'clg-1',
    collegeName: 'Rathinam Global University',
    department: 'Computer Science & Engineering',
    careerGoal: 'QA Automation Engineer',
    targetIndustry: 'Enterprise Software & Cloud Platforms',
    preferredJobRoles: ['QA Automation Engineer', 'Software Tester', 'SDET I'],
    salaryPreferenceMinLPA: 5.0,
    salaryPreferenceMaxLPA: 8.5,
    locationPreferenceType: 'specific_city',
    preferredCities: ['Hyderabad', 'Bengaluru', 'Chennai'],
    workPreference: 'on_site',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's61', name: 'Selenium & Cypress', category: 'tools', level: 'intermediate', verified: true },
      { id: 's62', name: 'Python Testing', category: 'technical', level: 'intermediate', verified: true },
      { id: 's63', name: 'Postman & REST API', category: 'tools', level: 'advanced', verified: true },
      { id: 's64', name: 'SQL', category: 'technical', level: 'intermediate', verified: false }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Telugu', 'Hindi'],
    resumeName: 'Sneha_Reddy_QA_2025.pdf',
    resumeUpdatedDate: '2025-01-05',
    careerReadinessScore: 75,
    isPlacementEligible: true,
    createdAt: '2024-09-22'
  },
  {
    id: 'std-7',
    name: 'Karthik Raja',
    email: 'karthik.raja@example.com',
    phone: '+91 98402 33119',
    avatarUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&auto=format&fit=crop&q=80',
    bio: 'B.Com student specializing in financial accounting, GST filings, and ERP Tally Prime operations.',
    education: {
      degree: 'B.Com General',
      course: 'Corporate Accounting',
      institution: 'Rathinam Global University',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '7.8 CGPA'
    },
    collegeId: 'clg-1',
    collegeName: 'Rathinam Global University',
    department: 'Commerce & Finance',
    careerGoal: 'Financial Analyst',
    targetIndustry: 'Banking & Audit Services',
    preferredJobRoles: ['Junior Accountant', 'Financial Analyst', 'Tax Associate'],
    salaryPreferenceMinLPA: 4.0,
    salaryPreferenceMaxLPA: 6.5,
    locationPreferenceType: 'nearby',
    preferredCities: ['Coimbatore', 'Tirupur', 'Chennai'],
    workPreference: 'on_site',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's71', name: 'Tally Prime & GST', category: 'tools', level: 'advanced', verified: true },
      { id: 's72', name: 'Excel (Intermediate)', category: 'tools', level: 'intermediate', verified: true },
      { id: 's73', name: 'Financial Statements', category: 'domain', level: 'intermediate', verified: false }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Tamil'],
    resumeName: 'Karthik_Raja_Accounts_2025.pdf',
    resumeUpdatedDate: '2025-01-11',
    careerReadinessScore: 68,
    isPlacementEligible: true,
    createdAt: '2024-10-01'
  },
  {
    id: 'std-8',
    name: 'Divya Nambiar',
    email: 'divya.nambiar@example.com',
    phone: '+91 97451 88220',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
    bio: 'Cybersecurity and Network Security specialist passionate about penetration testing, SOC analysis, and cloud compliance.',
    education: {
      degree: 'B.Tech Cybersecurity',
      course: 'Information Security',
      institution: 'PSG College of Technology',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.8 CGPA'
    },
    collegeId: 'clg-2',
    collegeName: 'PSG College of Technology',
    department: 'Cybersecurity & Systems',
    careerGoal: 'Cybersecurity Analyst',
    targetIndustry: 'Security Operations & Managed Cloud',
    preferredJobRoles: ['Cybersecurity Analyst', 'SOC Analyst L1', 'Network Security Associate'],
    salaryPreferenceMinLPA: 6.5,
    salaryPreferenceMaxLPA: 11.0,
    locationPreferenceType: 'anywhere_in_india',
    preferredCities: ['Bengaluru', 'Chennai', 'Kochi'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's81', name: 'Wireshark & Packet Analysis', category: 'tools', level: 'advanced', verified: true },
      { id: 's82', name: 'Linux System Admin', category: 'technical', level: 'advanced', verified: true },
      { id: 's83', name: 'SIEM (Splunk Basics)', category: 'tools', level: 'intermediate', verified: false }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Malayalam', 'Tamil'],
    resumeName: 'Divya_Nambiar_CyberSec_2025.pdf',
    resumeUpdatedDate: '2025-01-16',
    careerReadinessScore: 82,
    isPlacementEligible: true,
    createdAt: '2024-09-08'
  },
  {
    id: 'std-9',
    name: 'Rahul Deshmukh',
    email: 'rahul.d@example.com',
    phone: '+91 98220 77112',
    avatarUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&auto=format&fit=crop&q=80',
    bio: 'Cloud DevOps Enthusiast with hands-on Terraform, Kubernetes, and CI/CD pipeline automation skills.',
    education: {
      degree: 'B.Tech Computer Science',
      course: 'Cloud Computing & DevOps',
      institution: 'Independent (Not connected to College)',
      yearOfPassing: 2024,
      currentYear: '2024 Graduate',
      cgpaOrPercentage: '8.3 CGPA'
    },
    careerGoal: 'DevOps Engineer',
    targetIndustry: 'Cloud Infrastructure & High Scale SaaS',
    preferredJobRoles: ['DevOps Engineer', 'Cloud Support Engineer', 'Site Reliability Engineer'],
    salaryPreferenceMinLPA: 6.5,
    salaryPreferenceMaxLPA: 12.0,
    locationPreferenceType: 'remote',
    preferredCities: ['Pune', 'Bengaluru', 'Mumbai', 'Remote'],
    workPreference: 'remote',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's91', name: 'Docker & Kubernetes', category: 'technical', level: 'intermediate', verified: true },
      { id: 's92', name: 'AWS Cloud Services', category: 'technical', level: 'intermediate', verified: true },
      { id: 's93', name: 'GitHub Actions CI/CD', category: 'tools', level: 'advanced', verified: true }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Marathi', 'Hindi'],
    resumeName: 'Rahul_Deshmukh_DevOps.pdf',
    resumeUpdatedDate: '2025-01-19',
    careerReadinessScore: 80,
    createdAt: '2024-11-02'
  },
  {
    id: 'std-10',
    name: 'Pooja Singhania',
    email: 'pooja.s@example.com',
    phone: '+91 98110 33445',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80',
    bio: 'MBA Marketing & Analytics candidate specializing in Growth Marketing, SEO, and Performance Media optimization.',
    education: {
      degree: 'MBA (Marketing & Analytics)',
      course: 'Digital Marketing & Consumer Insights',
      institution: 'Loyola College of Arts & Sciences',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.6 CGPA'
    },
    collegeId: 'clg-3',
    collegeName: 'Loyola College of Arts & Sciences',
    department: 'Management Studies',
    careerGoal: 'Growth Marketing Associate',
    targetIndustry: 'E-commerce & Consumer Internet',
    preferredJobRoles: ['Growth Marketer', 'Digital Marketing Analyst', 'Performance Marketing Specialist'],
    salaryPreferenceMinLPA: 6.0,
    salaryPreferenceMaxLPA: 10.0,
    locationPreferenceType: 'specific_city',
    preferredCities: ['Bengaluru', 'Mumbai', 'Delhi NCR'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's101', name: 'Google Analytics 4 & Mixpanel', category: 'tools', level: 'advanced', verified: true },
      { id: 's102', name: 'Performance Marketing (Meta/Google Ads)', category: 'domain', level: 'advanced', verified: true },
      { id: 's103', name: 'SQL for Marketers', category: 'technical', level: 'beginner', verified: false }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Hindi'],
    resumeName: 'Pooja_Singhania_Marketing_2025.pdf',
    resumeUpdatedDate: '2025-01-21',
    careerReadinessScore: 83,
    isPlacementEligible: true,
    createdAt: '2024-09-28'
  },
  {
    id: 'std-11',
    name: 'Mohammed Zaid',
    email: 'm.zaid@example.com',
    phone: '+91 98480 66231',
    avatarUrl: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=200&auto=format&fit=crop&q=80',
    bio: 'Mobile App Developer skilled in Flutter and React Native with published applications on Google Play Store.',
    education: {
      degree: 'B.Tech CSE',
      course: 'Computer Science',
      institution: 'Rathinam Global University',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.1 CGPA'
    },
    collegeId: 'clg-1',
    collegeName: 'Rathinam Global University',
    department: 'Computer Science & Engineering',
    careerGoal: 'Mobile Application Developer',
    targetIndustry: 'Consumer Mobile Apps & EdTech',
    preferredJobRoles: ['Flutter Developer', 'React Native Developer', 'Mobile App Engineer'],
    salaryPreferenceMinLPA: 5.5,
    salaryPreferenceMaxLPA: 9.5,
    locationPreferenceType: 'anywhere_in_india',
    preferredCities: ['Hyderabad', 'Bengaluru', 'Coimbatore'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's111', name: 'Flutter & Dart', category: 'technical', level: 'advanced', verified: true },
      { id: 's112', name: 'Firebase & REST APIs', category: 'technical', level: 'advanced', verified: true },
      { id: 's113', name: 'UI/UX Mobile Design', category: 'tools', level: 'intermediate', verified: false }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Urdu', 'Telugu'],
    resumeName: 'Mohammed_Zaid_Flutter_2025.pdf',
    resumeUpdatedDate: '2025-01-15',
    careerReadinessScore: 79,
    isPlacementEligible: true,
    createdAt: '2024-10-04'
  },
  {
    id: 'std-12',
    name: 'Tanvi Joshi',
    email: 'tanvi.joshi@example.com',
    phone: '+91 97654 11223',
    avatarUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=200&auto=format&fit=crop&q=80',
    bio: 'UI/UX Designer who bridges user research, design systems in Figma, and atomic front-end prototyping.',
    education: {
      degree: 'B.Des (Interaction Design)',
      course: 'Design & Visual Communication',
      institution: 'Independent (Not connected to College)',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '9.0 CGPA'
    },
    careerGoal: 'UI/UX Product Designer',
    targetIndustry: 'Digital Products & Design Studios',
    preferredJobRoles: ['UI/UX Designer', 'Product Designer', 'Interaction Designer'],
    salaryPreferenceMinLPA: 6.0,
    salaryPreferenceMaxLPA: 11.0,
    locationPreferenceType: 'remote',
    preferredCities: ['Pune', 'Bengaluru', 'Mumbai', 'Remote'],
    workPreference: 'remote',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's121', name: 'Figma & Design Systems', category: 'tools', level: 'advanced', verified: true },
      { id: 's122', name: 'User Journey Mapping & Wireframing', category: 'domain', level: 'advanced', verified: true },
      { id: 's123', name: 'HTML/CSS/Tailwind Basics', category: 'technical', level: 'intermediate', verified: false }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Marathi', 'Hindi'],
    resumeName: 'Tanvi_Joshi_UIUX_Portfolio.pdf',
    resumeUpdatedDate: '2025-01-25',
    careerReadinessScore: 86,
    createdAt: '2024-09-30'
  },
  {
    id: 'std-13',
    name: 'Arvind Swaminathan',
    email: 'arvind.s@example.com',
    phone: '+91 94432 77881',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
    bio: 'B.Com graduate with deep interest in Corporate Tax, Auditing, and Financial Reporting.',
    education: {
      degree: 'B.Com (Professional Accounting)',
      course: 'Accounting & Auditing',
      institution: 'Rathinam Global University',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.5 CGPA'
    },
    collegeId: 'clg-1',
    collegeName: 'Rathinam Global University',
    department: 'Commerce & Finance',
    careerGoal: 'Business Analyst',
    targetIndustry: 'Big 4 & Financial Consulting',
    preferredJobRoles: ['Business Analyst', 'Audit Associate', 'Risk Consulting Trainee'],
    salaryPreferenceMinLPA: 5.0,
    salaryPreferenceMaxLPA: 8.0,
    locationPreferenceType: 'specific_city',
    preferredCities: ['Chennai', 'Bengaluru', 'Coimbatore'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's131', name: 'Excel (Advanced)', category: 'tools', level: 'advanced', verified: true },
      { id: 's132', name: 'SQL Basics', category: 'technical', level: 'beginner', verified: false },
      { id: 's133', name: 'Corporate Taxation', category: 'domain', level: 'advanced', verified: true },
      { id: 's134', name: 'Power BI', category: 'analytics', level: 'beginner', verified: false }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Tamil'],
    resumeName: 'Arvind_Swaminathan_Audit_2025.pdf',
    resumeUpdatedDate: '2025-01-08',
    careerReadinessScore: 72,
    isPlacementEligible: true,
    createdAt: '2024-09-12'
  },
  {
    id: 'std-14',
    name: 'Neha Kapoor',
    email: 'neha.kapoor@example.com',
    phone: '+91 98190 22334',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80',
    bio: 'B.Tech AI & Data Science student eager to work on conversational AI, LLM fine-tuning, and backend APIs.',
    education: {
      degree: 'B.Tech AI & Data Science',
      course: 'Artificial Intelligence',
      institution: 'PSG College of Technology',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '9.1 CGPA'
    },
    collegeId: 'clg-2',
    collegeName: 'PSG College of Technology',
    department: 'Artificial Intelligence',
    careerGoal: 'AI Engineer',
    targetIndustry: 'Generative AI & Enterprise Automation',
    preferredJobRoles: ['AI Engineer', 'Machine Learning Engineer', 'Python Backend Developer'],
    salaryPreferenceMinLPA: 8.5,
    salaryPreferenceMaxLPA: 16.0,
    locationPreferenceType: 'anywhere_in_india',
    preferredCities: ['Bengaluru', 'Hyderabad', 'Pune'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's141', name: 'Python & FastAPI', category: 'technical', level: 'advanced', verified: true },
      { id: 's142', name: 'LLM Prompt & LangChain', category: 'technical', level: 'advanced', verified: true },
      { id: 's143', name: 'Vector DBs (Pinecone, pgvector)', category: 'technical', level: 'intermediate', verified: false }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Hindi', 'Punjabi'],
    resumeName: 'Neha_Kapoor_AI_2025.pdf',
    resumeUpdatedDate: '2025-01-24',
    careerReadinessScore: 90,
    isPlacementEligible: true,
    createdAt: '2024-08-15'
  },
  {
    id: 'std-15',
    name: 'Sanjay Krishnan',
    email: 'sanjay.k@example.com',
    phone: '+91 94448 11990',
    avatarUrl: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=200&auto=format&fit=crop&q=80',
    bio: 'BCA graduate specializing in database management, SQL server performance tuning, and backend reporting.',
    education: {
      degree: 'BCA (Computer Applications)',
      course: 'Database Management & Web Development',
      institution: 'Rathinam Global University',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.0 CGPA'
    },
    collegeId: 'clg-1',
    collegeName: 'Rathinam Global University',
    department: 'Computer Science & Engineering',
    careerGoal: 'Business Analyst',
    targetIndustry: 'IT Services & Consulting',
    preferredJobRoles: ['Database Administrator Trainee', 'Business Analyst', 'Junior SQL Developer'],
    salaryPreferenceMinLPA: 4.5,
    salaryPreferenceMaxLPA: 7.5,
    locationPreferenceType: 'nearby',
    preferredCities: ['Coimbatore', 'Chennai', 'Bengaluru'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's151', name: 'SQL', category: 'technical', level: 'intermediate', verified: true },
      { id: 's152', name: 'Excel', category: 'tools', level: 'intermediate', verified: true },
      { id: 's153', name: 'Power BI', category: 'analytics', level: 'beginner', verified: false }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Tamil'],
    resumeName: 'Sanjay_Krishnan_SQL_2025.pdf',
    resumeUpdatedDate: '2025-01-07',
    careerReadinessScore: 71,
    isPlacementEligible: true,
    createdAt: '2024-10-10'
  },
  {
    id: 'std-16',
    name: 'Shreya Mukhopadhyay',
    email: 'shreya.m@example.com',
    phone: '+91 98300 44556',
    avatarUrl: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=200&auto=format&fit=crop&q=80',
    bio: 'B.Sc Statistics & Analytics student with experience in R, time-series forecasting, and epidemiological data modelling.',
    education: {
      degree: 'B.Sc Statistics',
      course: 'Applied Statistics & Econometrics',
      institution: 'Independent (Not connected to College)',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.9 CGPA'
    },
    careerGoal: 'Data Analyst',
    targetIndustry: 'Healthcare Analytics & Market Research',
    preferredJobRoles: ['Data Analyst', 'Statistical Analyst', 'Operations Research Associate'],
    salaryPreferenceMinLPA: 5.5,
    salaryPreferenceMaxLPA: 9.0,
    locationPreferenceType: 'anywhere_in_india',
    preferredCities: ['Kolkata', 'Bengaluru', 'Delhi NCR'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's161', name: 'R & RStudio', category: 'technical', level: 'advanced', verified: true },
      { id: 's162', name: 'Python for Data Analysis', category: 'technical', level: 'intermediate', verified: true },
      { id: 's163', name: 'Tableau', category: 'tools', level: 'intermediate', verified: false }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Bengali', 'Hindi'],
    resumeName: 'Shreya_Mukhopadhyay_Stats_2025.pdf',
    resumeUpdatedDate: '2025-01-17',
    careerReadinessScore: 81,
    createdAt: '2024-10-20'
  },
  {
    id: 'std-17',
    name: 'Varun Nair',
    email: 'varun.nair@example.com',
    phone: '+91 98471 22998',
    avatarUrl: 'https://images.unsplash.com/photo-1522529599102-193c0d76b5b6?w=200&auto=format&fit=crop&q=80',
    bio: 'Electronics & Embedded Systems Engineer skilled in IoT sensors, C/C++, and micro-controller firmware.',
    education: {
      degree: 'B.Tech ECE',
      course: 'Electronics & Communication',
      institution: 'PSG College of Technology',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.3 CGPA'
    },
    collegeId: 'clg-2',
    collegeName: 'PSG College of Technology',
    department: 'Electronics & Communication',
    careerGoal: 'Embedded Systems Engineer',
    targetIndustry: 'Automotive & IoT Hardware',
    preferredJobRoles: ['Embedded Software Engineer', 'IoT Firmware Developer', 'Hardware Test Engineer'],
    salaryPreferenceMinLPA: 6.0,
    salaryPreferenceMaxLPA: 10.0,
    locationPreferenceType: 'specific_city',
    preferredCities: ['Bengaluru', 'Coimbatore', 'Chennai'],
    workPreference: 'on_site',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's171', name: 'C & Embedded C', category: 'technical', level: 'advanced', verified: true },
      { id: 's172', name: 'RTOS Basics', category: 'technical', level: 'intermediate', verified: false },
      { id: 's173', name: 'IoT Protocols (MQTT, I2C, SPI)', category: 'domain', level: 'advanced', verified: true }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Malayalam', 'Tamil'],
    resumeName: 'Varun_Nair_Embedded_2025.pdf',
    resumeUpdatedDate: '2025-01-13',
    careerReadinessScore: 78,
    isPlacementEligible: true,
    createdAt: '2024-09-05'
  },
  {
    id: 'std-18',
    name: 'Ritu Agarwal',
    email: 'ritu.agarwal@example.com',
    phone: '+91 99102 33887',
    avatarUrl: 'https://images.unsplash.com/photo-1548142813-c348350df52b?w=200&auto=format&fit=crop&q=80',
    bio: 'B.Com Graduate specializing in Corporate Finance, Financial Modeling, and Valuation Metrics.',
    education: {
      degree: 'B.Com (Honours)',
      course: 'Corporate Finance',
      institution: 'Rathinam Global University',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.8 CGPA'
    },
    collegeId: 'clg-1',
    collegeName: 'Rathinam Global University',
    department: 'Commerce & Finance',
    careerGoal: 'Business Analyst',
    targetIndustry: 'Consulting & FinTech',
    preferredJobRoles: ['Business Analyst', 'Financial Modeling Analyst', 'Management Trainee'],
    salaryPreferenceMinLPA: 5.5,
    salaryPreferenceMaxLPA: 9.0,
    locationPreferenceType: 'specific_city',
    preferredCities: ['Bengaluru', 'Coimbatore', 'Hyderabad'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's181', name: 'Excel (Advanced)', category: 'tools', level: 'advanced', verified: true },
      { id: 's182', name: 'SQL', category: 'technical', level: 'intermediate', verified: true },
      { id: 's183', name: 'Power BI', category: 'analytics', level: 'intermediate', verified: true },
      { id: 's184', name: 'Financial Ratio Analysis', category: 'domain', level: 'advanced', verified: true }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Hindi'],
    resumeName: 'Ritu_Agarwal_BA_2025.pdf',
    resumeUpdatedDate: '2025-01-23',
    careerReadinessScore: 88,
    isPlacementEligible: true,
    createdAt: '2024-09-14'
  },
  {
    id: 'std-19',
    name: 'Harish Venkat',
    email: 'harish.v@example.com',
    phone: '+91 98845 66778',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    bio: 'Software Engineer focused on Java Spring Boot, Microservices architecture, and enterprise SQL databases.',
    education: {
      degree: 'B.Tech IT',
      course: 'Information Technology',
      institution: 'PSG College of Technology',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.6 CGPA'
    },
    collegeId: 'clg-2',
    collegeName: 'PSG College of Technology',
    department: 'Information Technology',
    careerGoal: 'Backend Java Developer',
    targetIndustry: 'Fintech & Enterprise Banking Software',
    preferredJobRoles: ['Java Backend Developer', 'Software Engineer I', 'Cloud Backend Engineer'],
    salaryPreferenceMinLPA: 7.0,
    salaryPreferenceMaxLPA: 12.0,
    locationPreferenceType: 'anywhere_in_india',
    preferredCities: ['Chennai', 'Bengaluru', 'Hyderabad'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's191', name: 'Java & Spring Boot', category: 'technical', level: 'advanced', verified: true },
      { id: 's192', name: 'PostgreSQL & Hibernate', category: 'technical', level: 'advanced', verified: true },
      { id: 's193', name: 'Microservices REST APIs', category: 'technical', level: 'intermediate', verified: false }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Tamil'],
    resumeName: 'Harish_Venkat_Java_2025.pdf',
    resumeUpdatedDate: '2025-01-20',
    careerReadinessScore: 85,
    isPlacementEligible: true,
    createdAt: '2024-08-30'
  },
  {
    id: 'std-20',
    name: 'Meera Sen',
    email: 'meera.sen@example.com',
    phone: '+91 97112 88990',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80',
    bio: 'MBA Human Resources candidate passionate about talent analytics, employer branding, and structured campus hiring.',
    education: {
      degree: 'MBA (HR & Organizational Behavior)',
      course: 'Human Resource Management',
      institution: 'Loyola College of Arts & Sciences',
      yearOfPassing: 2025,
      currentYear: 'Final Year (2025)',
      cgpaOrPercentage: '8.7 CGPA'
    },
    collegeId: 'clg-3',
    collegeName: 'Loyola College of Arts & Sciences',
    department: 'Management Studies',
    careerGoal: 'HR Associate / Talent Acquisition',
    targetIndustry: 'Technology & Consulting Services',
    preferredJobRoles: ['Talent Acquisition Specialist', 'HR Business Partner Trainee', 'Recruitment Coordinator'],
    salaryPreferenceMinLPA: 5.5,
    salaryPreferenceMaxLPA: 8.5,
    locationPreferenceType: 'specific_city',
    preferredCities: ['Bengaluru', 'Mumbai', 'Chennai'],
    workPreference: 'hybrid',
    jobTypePreference: 'full_time',
    skills: [
      { id: 's201', name: 'Talent Acquisition & Sourcing', category: 'domain', level: 'advanced', verified: true },
      { id: 's202', name: 'HR Analytics & Excel', category: 'tools', level: 'intermediate', verified: true },
      { id: 's203', name: 'Competency Based Interviewing', category: 'soft', level: 'advanced', verified: true }
    ],
    achievements: [],
    projects: [],
    experiences: [],
    languages: ['English', 'Hindi', 'Bengali'],
    resumeName: 'Meera_Sen_HR_2025.pdf',
    resumeUpdatedDate: '2025-01-22',
    careerReadinessScore: 82,
    isPlacementEligible: true,
    createdAt: '2024-09-25'
  }
];

export const MOCK_COMPANIES: CompanyOrganization[] = [
  {
    id: 'comp-1',
    name: 'ABC Technologies',
    logoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    industry: 'Enterprise Software & Cloud Platforms',
    headquarters: 'Bengaluru, Karnataka',
    locations: ['Bengaluru', 'Chennai', 'Hyderabad', 'Pune'],
    website: 'https://abctechnologies.io',
    description: 'ABC Technologies is a next-generation technology consulting and digital product engineering partner serving Global 2000 leaders.',
    employeeCount: '2,500 - 5,000',
    foundedYear: 2016,
    verified: true,
    activeJobsCount: 12,
    totalHiresCount: 240,
    teamMembers: [
      {
        id: 'rec-1',
        name: 'Rajesh Menon',
        email: 'rajesh.m@abctechnologies.io',
        role: 'company_admin',
        avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
        department: 'Head of Talent Acquisition'
      },
      {
        id: 'rec-2',
        name: 'Smita Kulkarni',
        email: 'smita.k@abctechnologies.io',
        role: 'hr_manager',
        avatarUrl: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=150&auto=format&fit=crop&q=80',
        department: 'Early Careers Lead'
      },
      {
        id: 'rec-3',
        name: 'Vikram Joshi',
        email: 'vikram.j@abctechnologies.io',
        role: 'recruiter',
        avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
        department: 'Technical Recruiter'
      }
    ]
  },
  {
    id: 'comp-2',
    name: 'FinEdge Analytics',
    logoUrl: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=150&auto=format&fit=crop&q=80',
    industry: 'FinTech & Quantitative Advisory',
    headquarters: 'Mumbai, Maharashtra',
    locations: ['Mumbai', 'Bengaluru', 'Coimbatore'],
    website: 'https://finedgeanalytics.in',
    description: 'High-growth quantitative analytics platform specializing in automated credit scoring, investment portfolio signals, and SME lending.',
    employeeCount: '500 - 1,000',
    foundedYear: 2019,
    verified: true,
    activeJobsCount: 8,
    totalHiresCount: 95,
    teamMembers: [
      {
        id: 'rec-4',
        name: 'Priya Verma',
        email: 'priya.v@finedgeanalytics.in',
        role: 'company_admin',
        avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
        department: 'Director of People & Culture'
      },
      {
        id: 'rec-5',
        name: 'Amitabh Sen',
        email: 'amitabh.s@finedgeanalytics.in',
        role: 'recruiter',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        department: 'Campus Talent Lead'
      }
    ]
  },
  {
    id: 'comp-3',
    name: 'TCS Innovate Labs',
    logoUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=150&auto=format&fit=crop&q=80',
    industry: 'Digital Transformation & AI Consulting',
    headquarters: 'Chennai, Tamil Nadu',
    locations: ['Chennai', 'Bengaluru', 'Hyderabad', 'Kochi', 'Coimbatore'],
    website: 'https://tcs.com/innovate',
    description: 'Premier R&D division engineering industrial AI, cloud-native modernization, and supply chain automation for tier-1 enterprises.',
    employeeCount: '10,000+',
    foundedYear: 2008,
    verified: true,
    activeJobsCount: 15,
    totalHiresCount: 1200,
    teamMembers: [
      {
        id: 'rec-6',
        name: 'K. Senthil Kumar',
        email: 'senthil.k@tcs.com',
        role: 'company_admin',
        avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
        department: 'General Manager — Campus Relations'
      }
    ]
  },
  {
    id: 'comp-4',
    name: 'CloudScale Networks',
    logoUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150&auto=format&fit=crop&q=80',
    industry: 'Cloud Infrastructure & SRE',
    headquarters: 'Hyderabad, Telangana',
    locations: ['Hyderabad', 'Bengaluru', 'Remote'],
    website: 'https://cloudscalenetworks.com',
    description: 'Building multi-cloud orchestration and observability frameworks for global telecom and cloud native startups.',
    employeeCount: '350 - 500',
    foundedYear: 2021,
    verified: true,
    activeJobsCount: 5,
    totalHiresCount: 65,
    teamMembers: [
      {
        id: 'rec-7',
        name: 'Tarun Bhatia',
        email: 'tarun@cloudscalenetworks.com',
        role: 'company_admin',
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        department: 'Head of Engineering'
      }
    ]
  },
  {
    id: 'comp-5',
    name: 'Zenith Health AI',
    logoUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=150&auto=format&fit=crop&q=80',
    industry: 'HealthTech & BioInformatics',
    headquarters: 'Bengaluru, Karnataka',
    locations: ['Bengaluru', 'Coimbatore', 'Remote'],
    website: 'https://zenithhealth.ai',
    description: 'Empowering hospitals and clinical trials with predictive patient analytics, diagnostics AI, and HIPAA-compliant data pipelines.',
    employeeCount: '200 - 350',
    foundedYear: 2020,
    verified: true,
    activeJobsCount: 6,
    totalHiresCount: 48,
    teamMembers: [
      {
        id: 'rec-8',
        name: 'Dr. Nandini Roy',
        email: 'nandini@zenithhealth.ai',
        role: 'company_admin',
        avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
        department: 'Founding Partner & HR Lead'
      }
    ]
  },
  {
    id: 'comp-6',
    name: 'Zerodha Tech Labs',
    logoUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=150&auto=format&fit=crop&q=80',
    industry: 'Capital Markets & Trading Technology',
    headquarters: 'Bengaluru, Karnataka',
    locations: ['Bengaluru', 'Remote'],
    website: 'https://zerodha.tech',
    description: 'Pioneering open financial tools, ultra-low latency trading APIs, and educational fintech initiatives across India.',
    employeeCount: '1,000+',
    foundedYear: 2010,
    verified: true,
    activeJobsCount: 4,
    totalHiresCount: 180,
    teamMembers: [
      {
        id: 'rec-9',
        name: 'Kailash N.',
        email: 'kailash@zerodha.tech',
        role: 'company_admin',
        avatarUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
        department: 'Tech Team Lead'
      }
    ]
  }
];

export const MOCK_COLLEGES: CollegeOrganization[] = [
  {
    id: 'clg-1',
    name: 'Rathinam Global University',
    logoUrl: 'https://images.unsplash.com/photo-1562774053-701939374585?w=150&auto=format&fit=crop&q=80',
    location: 'Coimbatore, Tamil Nadu',
    state: 'Tamil Nadu',
    type: 'Autonomous University',
    nirfRank: 'Band 101-150',
    establishedYear: 2001,
    departments: [
      'Commerce & Computer Applications',
      'Computer Science & Engineering',
      'Data Analytics & AI',
      'Commerce & Finance',
      'Management Studies',
      'Information Technology'
    ],
    totalStudents: 4850,
    registeredStudentsCount: 1420,
    placementOfficers: [
      {
        id: 'po-1',
        name: 'Dr. K. Ramanathan',
        email: 'ramanathan.placement@rathinam.ac.in',
        role: 'dean_placement',
        avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
        department: 'Director of Placements & Corporate Relations'
      },
      {
        id: 'po-2',
        name: 'Prof. Mary Shanthi',
        email: 'mary.placement@rathinam.ac.in',
        role: 'placement_officer',
        avatarUrl: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=150&auto=format&fit=crop&q=80',
        department: 'Commerce & Analytics Placement Coordinator'
      },
      {
        id: 'po-3',
        name: 'Dr. R. Vignesh',
        email: 'vignesh.cse@rathinam.ac.in',
        role: 'dept_coordinator',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        department: 'Engineering Placement Officer'
      }
    ]
  },
  {
    id: 'clg-2',
    name: 'PSG College of Technology',
    logoUrl: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=150&auto=format&fit=crop&q=80',
    location: 'Coimbatore, Tamil Nadu',
    state: 'Tamil Nadu',
    type: 'Govt-Aided Autonomous Institution',
    nirfRank: 'Rank 63',
    establishedYear: 1951,
    departments: [
      'Computer Science & Engineering',
      'Information Technology',
      'Electronics & Communication',
      'Artificial Intelligence',
      'Cybersecurity & Systems',
      'Mechanical Engineering'
    ],
    totalStudents: 6200,
    registeredStudentsCount: 2150,
    placementOfficers: [
      {
        id: 'po-4',
        name: 'Dr. P. Radhakrishnan',
        email: 'dean.placement@psgtech.edu',
        role: 'dean_placement',
        avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
        department: 'Center for Placement & Training'
      }
    ]
  },
  {
    id: 'clg-3',
    name: 'Loyola College of Arts & Sciences',
    logoUrl: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=150&auto=format&fit=crop&q=80',
    location: 'Chennai, Tamil Nadu',
    state: 'Tamil Nadu',
    type: 'Autonomous College',
    nirfRank: 'Rank 7 (Colleges)',
    establishedYear: 1925,
    departments: [
      'Commerce & Finance',
      'Management Studies',
      'Economics & Data',
      'Computer Applications'
    ],
    totalStudents: 5400,
    registeredStudentsCount: 1680,
    placementOfficers: [
      {
        id: 'po-5',
        name: 'Rev. Dr. Francis Xavier',
        email: 'placement@loyolacollege.edu',
        role: 'dean_placement',
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        department: 'Training and Placement Cell'
      }
    ]
  }
];

export const MOCK_JOBS: JobOpportunity[] = [
  {
    id: 'job-1',
    companyId: 'comp-1',
    companyName: 'ABC Technologies',
    companyLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    title: 'Associate Business Analyst',
    type: 'job',
    workMode: 'hybrid',
    location: 'Bengaluru / Coimbatore',
    departmentCategory: 'Analytics & Product',
    salaryMinLPA: 6.5,
    salaryMaxLPA: 8.5,
    salaryDisplay: '₹6.5 - 8.5 LPA',
    experienceRequired: 'Fresher (2024 / 2025 Batch)',
    qualificationRequired: ['B.Com', 'BBA', 'BCA', 'B.Tech', 'B.Sc Data Analytics', 'MBA'],
    requiredSkills: ['SQL', 'Power BI', 'Excel (Advanced)', 'Business Analysis'],
    preferredSkills: ['Financial Modeling', 'Tableau', 'Agile User Stories'],
    description: 'We are seeking high-caliber Associate Business Analysts to partner directly with client stakeholders, extract data-driven insights using SQL & Power BI, and translate complex business workflows into functional engineering specifications.',
    responsibilities: [
      'Perform exploratory data analysis and build executive KPI dashboards in Power BI & Excel.',
      'Write optimized SQL queries to extract, transform, and validate transactional data.',
      'Collaborate with Product Managers and Engineering leads to author user stories and acceptance criteria.',
      'Facilitate sprint reviews and deliver weekly metrics presentations to corporate leadership.'
    ],
    perks: ['Health Insurance ₹5 Lakhs', 'Learning & Certification Stipend ₹30k/year', 'Hybrid 2-day WFH', 'Performance Bonus'],
    applicationDeadline: '2025-04-30',
    postedDate: '2025-01-10',
    isOpen: true,
    vacancies: 8,
    applicantsCount: 64
  },
  {
    id: 'job-2',
    companyId: 'comp-2',
    companyName: 'FinEdge Analytics',
    companyLogoUrl: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=150&auto=format&fit=crop&q=80',
    title: 'Junior Quantitative & Business Analyst',
    type: 'job',
    workMode: 'hybrid',
    location: 'Mumbai / Bengaluru / Coimbatore',
    departmentCategory: 'FinTech Analytics',
    salaryMinLPA: 7.0,
    salaryMaxLPA: 9.5,
    salaryDisplay: '₹7.0 - 9.5 LPA',
    experienceRequired: 'Fresher to 1 Year',
    qualificationRequired: ['B.Com', 'B.Sc Statistics', 'B.Tech', 'MBA Finance'],
    requiredSkills: ['Excel (Advanced)', 'SQL', 'Financial Modeling', 'Power BI'],
    preferredSkills: ['Python', 'Credit Risk Scoring', 'DAX'],
    description: 'Join FinEdge Analytics to build quantitative risk engines and commercial underwriting dashboards for leading digital banks and microfinance institutions across India.',
    responsibilities: [
      'Build dynamic spreadsheet financial models with scenario and sensitivity testing.',
      'Analyze borrower cohort metrics and default patterns using SQL database queries.',
      'Design clean interactive Power BI dashboards for credit committee reviews.'
    ],
    perks: ['Equity Stock Options (ESOPs)', 'Annual Performance Bonus', 'Comprehensive Medical Cover', 'Gym Reimbursement'],
    applicationDeadline: '2025-04-15',
    postedDate: '2025-01-08',
    isOpen: true,
    vacancies: 5,
    applicantsCount: 42
  },
  {
    id: 'job-3',
    companyId: 'comp-1',
    companyName: 'ABC Technologies',
    companyLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    title: 'Software Development Engineer I (Full Stack)',
    type: 'job',
    workMode: 'remote',
    location: 'Remote (India)',
    departmentCategory: 'Software Engineering',
    salaryMinLPA: 8.0,
    salaryMaxLPA: 12.5,
    salaryDisplay: '₹8.0 - 12.5 LPA',
    experienceRequired: 'Fresher (2024 / 2025 Batch)',
    qualificationRequired: ['B.Tech CSE', 'B.Tech IT', 'MCA', 'B.Sc Computer Science'],
    requiredSkills: ['React / Next.js', 'TypeScript', 'Node.js & Express', 'PostgreSQL'],
    preferredSkills: ['Docker & AWS Basics', 'Tailwind CSS', 'GraphQL'],
    description: 'Build fast, responsive web products and microservices used by millions of concurrent users. You will write clean TypeScript, design scalable PostgreSQL schemas, and deploy CI/CD pipelines.',
    responsibilities: [
      'Develop pixel-perfect React UI components with rigorous state management.',
      'Design RESTful and event-driven backend microservices with Node.js & TypeScript.',
      'Write comprehensive unit and integration test suites.'
    ],
    perks: ['Home Office Setup Allowance ₹25,000', 'Flexible Hours', 'Unlimited Paid Time Off', 'Health Insurance'],
    applicationDeadline: '2025-05-15',
    postedDate: '2025-01-12',
    isOpen: true,
    vacancies: 6,
    applicantsCount: 112
  },
  {
    id: 'job-4',
    companyId: 'comp-3',
    companyName: 'TCS Innovate Labs',
    companyLogoUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=150&auto=format&fit=crop&q=80',
    title: 'Graduate Data Science & AI Trainee',
    type: 'job',
    workMode: 'hybrid',
    location: 'Chennai / Bengaluru / Hyderabad',
    departmentCategory: 'Data Science',
    salaryMinLPA: 7.5,
    salaryMaxLPA: 11.0,
    salaryDisplay: '₹7.5 - 11.0 LPA',
    experienceRequired: 'Fresher (2025 Batch)',
    qualificationRequired: ['B.Sc Data Analytics', 'B.Tech AI & Data Science', 'B.Tech CSE', 'M.Sc Statistics'],
    requiredSkills: ['Python', 'SQL', 'Pandas & Scikit-Learn', 'Power BI'],
    preferredSkills: ['Deep Learning (PyTorch)', 'SHAP Explainability', 'NLP'],
    description: 'Join the premier R&D wing of TCS to build production machine learning algorithms, predictive maintenance systems, and vision-AI pipelines.',
    responsibilities: [
      'Clean and process multi-gigabyte industrial telemetry datasets in Python & SQL.',
      'Train, tune, and evaluate machine learning models (XGBoost, Random Forests, Transformers).',
      'Deploy inference models via FastAPI containers.'
    ],
    perks: ['Higher Education Sponsorship (M.Tech)', 'Campus Housing Allowance', 'Group Term Life Insurance'],
    applicationDeadline: '2025-04-20',
    postedDate: '2025-01-05',
    isOpen: true,
    vacancies: 10,
    applicantsCount: 88
  },
  {
    id: 'job-5',
    companyId: 'comp-2',
    companyName: 'FinEdge Analytics',
    companyLogoUrl: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=150&auto=format&fit=crop&q=80',
    title: 'Financial Analyst (Corporate & M&A)',
    type: 'job',
    workMode: 'hybrid',
    location: 'Mumbai / Bengaluru',
    departmentCategory: 'Corporate Finance',
    salaryMinLPA: 7.5,
    salaryMaxLPA: 10.5,
    salaryDisplay: '₹7.5 - 10.5 LPA',
    experienceRequired: 'Fresher to 1 Year',
    qualificationRequired: ['B.Com (Honours)', 'BBA Finance', 'MBA Finance', 'CA Inter'],
    requiredSkills: ['Financial Modeling', 'Excel (Advanced)', 'Corporate Valuation (DCF)', 'Financial Ratio Analysis'],
    preferredSkills: ['Power BI', 'SQL Basics', 'Bloomberg Terminal'],
    description: 'Conduct fundamental equity research, build 3-statement financial models, and prepare valuation decks for mid-market corporate acquisitions.',
    responsibilities: [
      'Author Discounted Cash Flow (DCF) and Comparable Company (Trading Comps) valuations.',
      'Analyze quarterly earnings releases, investor transcripts, and balance sheet notes.',
      'Prepare crisp pitch decks for the investment committee.'
    ],
    perks: ['Year-end Performance Incentive', 'CFA Level 1 & 2 Exam Reimbursement', 'Premium Health Cover'],
    applicationDeadline: '2025-04-25',
    postedDate: '2025-01-14',
    isOpen: true,
    vacancies: 4,
    applicantsCount: 38
  },
  {
    id: 'job-6',
    companyId: 'comp-6',
    companyName: 'Zerodha Tech Labs',
    companyLogoUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=150&auto=format&fit=crop&q=80',
    title: 'Backend Systems Engineer (Python / Go)',
    type: 'job',
    workMode: 'remote',
    location: 'Remote / Bengaluru',
    departmentCategory: 'Software Engineering',
    salaryMinLPA: 10.0,
    salaryMaxLPA: 16.0,
    salaryDisplay: '₹10.0 - 16.0 LPA',
    experienceRequired: 'Fresher to 2 Years',
    qualificationRequired: ['B.Tech CSE', 'B.Tech IT', 'B.Sc Computer Science'],
    requiredSkills: ['Python', 'PostgreSQL', 'Microservices REST APIs', 'Linux System Admin'],
    preferredSkills: ['Golang', 'Redis', 'High Throughput Trading Systems'],
    description: 'Build fault-tolerant trading microservices and ledger management pipelines serving 10M+ active retail traders across India.',
    responsibilities: [
      'Write clean, modular backend code designed for minimal latency and strict correctness.',
      'Optimize PostgreSQL queries and transaction locks.',
      'Monitor distributed services with Prometheus and Grafana.'
    ],
    perks: ['Pure Remote Culture', 'Top-tier Equipment Budget', 'Health & Wellness Benefit', 'Zero Corporate Politics'],
    applicationDeadline: '2025-05-01',
    postedDate: '2025-01-15',
    isOpen: true,
    vacancies: 3,
    applicantsCount: 140
  },
  {
    id: 'job-7',
    companyId: 'comp-5',
    companyName: 'Zenith Health AI',
    companyLogoUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=150&auto=format&fit=crop&q=80',
    title: 'Associate Product Manager (Healthcare Tech)',
    type: 'job',
    workMode: 'hybrid',
    location: 'Bengaluru / Coimbatore',
    departmentCategory: 'Product Management',
    salaryMinLPA: 8.0,
    salaryMaxLPA: 12.0,
    salaryDisplay: '₹8.0 - 12.0 LPA',
    experienceRequired: 'Fresher (2025 Batch)',
    qualificationRequired: ['B.Tech', 'B.Sc Data Science', 'MBA', 'B.Com CA'],
    requiredSkills: ['Product Roadmapping', 'SQL & Analytics', 'Wireframing (Figma)', 'User Research'],
    preferredSkills: ['Business Analysis', 'Excel (Advanced)', 'Healthcare Domain'],
    description: 'Lead clinical workflow discovery, define electronic health record (EHR) features, and partner with doctors and machine learning engineers to release clinical AI copilots.',
    responsibilities: [
      'Conduct 1-on-1 discovery interviews with hospital administrators and physicians.',
      'Draft detailed PRDs, wireframes, and KPI tracking matrices.',
      'Lead sprint planning with frontend and AI engineering squads.'
    ],
    perks: ['Comprehensive Family Health Cover', 'Annual Product Leadership Mentorship', 'Flexible Hybrid Work'],
    applicationDeadline: '2025-04-18',
    postedDate: '2025-01-09',
    isOpen: true,
    vacancies: 2,
    applicantsCount: 29
  },
  {
    id: 'job-8',
    companyId: 'comp-4',
    companyName: 'CloudScale Networks',
    companyLogoUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=150&auto=format&fit=crop&q=80',
    title: 'Junior Cloud & DevOps Engineer',
    type: 'job',
    workMode: 'remote',
    location: 'Hyderabad / Bengaluru / Remote',
    departmentCategory: 'Cloud Infrastructure',
    salaryMinLPA: 6.5,
    salaryMaxLPA: 10.0,
    salaryDisplay: '₹6.5 - 10.0 LPA',
    experienceRequired: 'Fresher (0-1 Years)',
    qualificationRequired: ['B.Tech CSE', 'B.Tech IT', 'BCA / MCA'],
    requiredSkills: ['Docker & Kubernetes', 'AWS Cloud Services', 'GitHub Actions CI/CD', 'Linux System Admin'],
    preferredSkills: ['Terraform', 'Python Scripting', 'Prometheus'],
    description: 'Automate zero-downtime application deployments, manage container orchestration clusters in AWS/GCP, and engineer self-healing infrastructure.',
    responsibilities: [
      'Maintain automated CI/CD build and testing pipelines in GitHub Actions.',
      'Configure Kubernetes ingress, secret managers, and autoscaling policies.',
      'Triage cloud networking and system security alerts.'
    ],
    perks: ['AWS Certification Reimbursement', 'Work-from-Anywhere Policy', 'Health & Dental Care'],
    applicationDeadline: '2025-04-28',
    postedDate: '2025-01-11',
    isOpen: true,
    vacancies: 4,
    applicantsCount: 55
  },
  // Internships
  {
    id: 'job-9',
    companyId: 'comp-1',
    companyName: 'ABC Technologies',
    companyLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    title: 'Business Analytics Summer Intern',
    type: 'internship',
    workMode: 'hybrid',
    location: 'Bengaluru / Coimbatore',
    departmentCategory: 'Analytics',
    salaryMinLPA: 3.0,
    salaryMaxLPA: 4.5,
    salaryDisplay: '₹25,000 / month Stipend (PPO Eligible)',
    stipendPerMonth: 25000,
    experienceRequired: 'Pre-final / Final Year Students',
    qualificationRequired: ['B.Com', 'B.Tech', 'BBA', 'B.Sc Data Science', 'MCA'],
    requiredSkills: ['Excel (Advanced)', 'Power BI', 'SQL', 'Business Analysis'],
    preferredSkills: ['Problem Solving', 'Data Storytelling'],
    description: 'Intensive 3-month summer internship with direct mentorship from Principal Consultants. Top performers will receive direct Pre-Placement Offers (PPO) at ₹7.5 LPA.',
    responsibilities: [
      'Assist senior consultants in auditing client financial spreadsheets and KPI metrics.',
      'Build automated ETL pipelines in Power BI to ingest multi-source Excel files.',
      'Document end-to-end data dictionary and workflow diagrams.'
    ],
    perks: ['Pre-Placement Offer (PPO) Opportunity', 'Free Lunch & Transport at Campus', 'Executive Mentorship'],
    applicationDeadline: '2025-03-31',
    postedDate: '2025-01-16',
    isOpen: true,
    vacancies: 12,
    applicantsCount: 95
  },
  {
    id: 'job-10',
    companyId: 'comp-2',
    companyName: 'FinEdge Analytics',
    companyLogoUrl: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=150&auto=format&fit=crop&q=80',
    title: 'FinTech Product & Analytics Intern',
    type: 'internship',
    workMode: 'remote',
    location: 'Remote (India)',
    departmentCategory: 'Product & Analytics',
    salaryMinLPA: 2.4,
    salaryMaxLPA: 3.6,
    salaryDisplay: '₹20,000 / month Stipend (PPO Eligible)',
    stipendPerMonth: 20000,
    experienceRequired: '2025 Batch Graduates / Students',
    qualificationRequired: ['B.Com', 'B.Tech', 'MBA', 'B.Sc Statistics'],
    requiredSkills: ['Excel (Advanced)', 'SQL', 'Financial Modeling'],
    preferredSkills: ['Power BI', 'Figma'],
    description: 'Work alongside the Chief Product Officer to design loan approval funnels, run A/B test analysis, and evaluate credit score benchmarks.',
    responsibilities: [
      'Extract funnel telemetry using SQL queries.',
      'Create executive financial summaries and competitor feature teardowns.'
    ],
    perks: ['Flexible Internship Hours (20 hrs/week)', 'Certificate of Excellence', 'Direct PPO Review'],
    applicationDeadline: '2025-04-10',
    postedDate: '2025-01-18',
    isOpen: true,
    vacancies: 5,
    applicantsCount: 61
  },
  {
    id: 'job-11',
    companyId: 'comp-5',
    companyName: 'Zenith Health AI',
    companyLogoUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=150&auto=format&fit=crop&q=80',
    title: 'AI Engineering & NLP Intern',
    type: 'internship',
    workMode: 'hybrid',
    location: 'Bengaluru / Remote',
    departmentCategory: 'AI Research',
    salaryMinLPA: 3.6,
    salaryMaxLPA: 4.8,
    salaryDisplay: '₹30,000 / month Stipend (PPO Eligible)',
    stipendPerMonth: 30000,
    experienceRequired: 'Final Year / Post-grad',
    qualificationRequired: ['B.Tech CSE', 'B.Tech AI', 'B.Sc Data Science', 'M.Tech'],
    requiredSkills: ['Python', 'LLM Prompt & LangChain', 'FastAPI'],
    preferredSkills: ['Vector DBs', 'PyTorch'],
    description: 'Build retrieval-augmented generation (RAG) agents to summarize medical journals and clinical summaries safely.',
    responsibilities: [
      'Evaluate LLM hallucination benchmarks and fine-tune prompt templates.',
      'Index medical PDF research into Vector databases.'
    ],
    perks: ['High Stipend', 'Opportunity to co-author patent publications', 'PPO Track'],
    applicationDeadline: '2025-04-05',
    postedDate: '2025-01-19',
    isOpen: true,
    vacancies: 4,
    applicantsCount: 74
  },
  {
    id: 'job-12',
    companyId: 'comp-3',
    companyName: 'TCS Innovate Labs',
    companyLogoUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=150&auto=format&fit=crop&q=80',
    title: 'Enterprise Java Backend Intern',
    type: 'internship',
    workMode: 'on_site',
    location: 'Chennai / Coimbatore',
    departmentCategory: 'Engineering',
    salaryMinLPA: 2.4,
    salaryMaxLPA: 3.6,
    salaryDisplay: '₹22,000 / month Stipend',
    stipendPerMonth: 22000,
    experienceRequired: 'Final Year (2025 Batch)',
    qualificationRequired: ['B.Tech CSE', 'B.Tech IT', 'MCA'],
    requiredSkills: ['Java & Spring Boot', 'PostgreSQL & Hibernate', 'SQL'],
    preferredSkills: ['Microservices', 'Git'],
    description: 'Build enterprise microservices and event queues under senior architects at TCS Innovation campus.',
    responsibilities: [
      'Implement REST API endpoints with Spring Security and JPA.',
      'Write JUnit test suites to ensure 85%+ code coverage.'
    ],
    perks: ['PPO Conversion to TCS Digital Track (₹7.5 LPA)', 'Subsidized Hostel & Transport'],
    applicationDeadline: '2025-04-12',
    postedDate: '2025-01-15',
    isOpen: true,
    vacancies: 8,
    applicantsCount: 82
  }
];

export const MOCK_APPLICATIONS: JobApplication[] = [
  {
    id: 'app-1',
    candidateId: 'std-1',
    candidateName: 'Aarav Sharma',
    candidateEmail: 'aarav.sharma@example.com',
    candidatePhone: '+91 98450 12345',
    candidateEducation: 'B.Com (Computer Applications)',
    candidateCourse: 'Commerce & Data Analytics',
    candidateCollegeName: 'Rathinam Global University',
    candidateAvatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    candidateCareerGoal: 'Business Analyst',
    candidateSkills: ['Excel (Advanced)', 'Power BI', 'SQL', 'Business Analysis', 'Financial Modeling'],
    candidateReadinessScore: 78,
    jobId: 'job-1',
    jobTitle: 'Associate Business Analyst',
    jobType: 'job',
    companyId: 'comp-1',
    companyName: 'ABC Technologies',
    companyLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    applicationDate: '2025-01-15',
    applicationSource: 'Applied through Nexif5',
    status: 'interview',
    matchScore: 94,
    matchBreakdown: {
      skillsMatch: 95,
      qualificationMatch: 100,
      careerGoalMatch: 96,
      preferenceMatch: 85
    },
    matchReasons: [
      'Strong core proficiency in Excel (Advanced), Power BI, and Business Analysis.',
      'Degree in B.Com Computer Applications matches desired educational qualification.',
      'Career goal aligned exactly to Business Analyst role.',
      'Preferred location Bengaluru/Coimbatore matches job location.'
    ],
    resumeUsed: 'Aarav_Sharma_Business_Analyst_2025.pdf',
    coverNote: 'Excited to apply for Associate Business Analyst at ABC Technologies. I have hands-on experience in building interactive Power BI dashboards and analyzing large retail data schemas in SQL.',
    recruiterNotes: 'Top candidate from Rathinam. Excellent case study presentation during preliminary screen. Proceeding to Technical & Case Study Round.',
    scheduledInterview: {
      id: 'int-1',
      applicationId: 'app-1',
      candidateId: 'std-1',
      candidateName: 'Aarav Sharma',
      jobTitle: 'Associate Business Analyst',
      companyName: 'ABC Technologies',
      date: '2025-02-18',
      time: '03:30 PM IST',
      roundType: 'Analytics Case Study',
      interviewMode: 'Virtual Video Call',
      meetingLink: 'https://meet.google.com/abc-nexif-interview',
      interviewerName: 'Smita Kulkarni (Early Careers Lead)',
      status: 'upcoming'
    },
    timeline: [
      { status: 'applied', date: '2025-01-15', note: 'Applied through Nexif5 with 94% AI Match' },
      { status: 'under_review', date: '2025-01-17', note: 'Profile reviewed by Recruiter Smita Kulkarni' },
      { status: 'shortlisted', date: '2025-01-20', note: 'Candidate shortlisted for preliminary round' },
      { status: 'interview', date: '2025-01-24', note: 'Case Study Round scheduled for Feb 18, 3:30 PM IST' }
    ]
  },
  {
    id: 'app-2',
    candidateId: 'std-1',
    candidateName: 'Aarav Sharma',
    candidateEmail: 'aarav.sharma@example.com',
    candidatePhone: '+91 98450 12345',
    candidateEducation: 'B.Com (Computer Applications)',
    candidateCourse: 'Commerce & Data Analytics',
    candidateCollegeName: 'Rathinam Global University',
    candidateAvatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    candidateCareerGoal: 'Business Analyst',
    candidateSkills: ['Excel (Advanced)', 'Power BI', 'SQL', 'Business Analysis', 'Financial Modeling'],
    candidateReadinessScore: 78,
    jobId: 'job-2',
    jobTitle: 'Junior Quantitative & Business Analyst',
    jobType: 'job',
    companyId: 'comp-2',
    companyName: 'FinEdge Analytics',
    companyLogoUrl: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=150&auto=format&fit=crop&q=80',
    applicationDate: '2025-01-18',
    applicationSource: 'Applied through Nexif5',
    status: 'shortlisted',
    matchScore: 91,
    matchBreakdown: {
      skillsMatch: 90,
      qualificationMatch: 100,
      careerGoalMatch: 92,
      preferenceMatch: 82
    },
    matchReasons: [
      'Advanced Excel and Financial Modeling skills directly match quantitative portfolio needs.',
      'B.Com background provides strong foundation in accounting & financial ratios.',
      'Active participant in National FinTech Business Case Challenge 2024.'
    ],
    resumeUsed: 'Aarav_Sharma_Business_Analyst_2025.pdf',
    timeline: [
      { status: 'applied', date: '2025-01-18', note: 'Applied via Nexif5' },
      { status: 'under_review', date: '2025-01-21', note: 'Application assigned to Amitabh Sen' },
      { status: 'shortlisted', date: '2025-01-25', note: 'Selected for FinTech modeling test' }
    ]
  },
  {
    id: 'app-3',
    candidateId: 'std-1',
    candidateName: 'Aarav Sharma',
    candidateEmail: 'aarav.sharma@example.com',
    candidatePhone: '+91 98450 12345',
    candidateEducation: 'B.Com (Computer Applications)',
    candidateCourse: 'Commerce & Data Analytics',
    candidateCollegeName: 'Rathinam Global University',
    candidateAvatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    candidateCareerGoal: 'Business Analyst',
    candidateSkills: ['Excel (Advanced)', 'Power BI', 'SQL', 'Business Analysis'],
    candidateReadinessScore: 78,
    jobId: 'job-9',
    jobTitle: 'Business Analytics Summer Intern',
    jobType: 'internship',
    companyId: 'comp-1',
    companyName: 'ABC Technologies',
    companyLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    applicationDate: '2025-01-16',
    applicationSource: 'Applied through Nexif5',
    status: 'selected',
    matchScore: 96,
    matchBreakdown: {
      skillsMatch: 98,
      qualificationMatch: 100,
      careerGoalMatch: 95,
      preferenceMatch: 91
    },
    matchReasons: [
      'High skill overlap for summer analytics track with Excel, SQL, and Power BI.',
      'Strong academic performance and leadership record.'
    ],
    resumeUsed: 'Aarav_Sharma_Business_Analyst_2025.pdf',
    timeline: [
      { status: 'applied', date: '2025-01-16', note: 'Applied via Nexif5' },
      { status: 'under_review', date: '2025-01-18', note: 'Reviewed by Talent Lead' },
      { status: 'shortlisted', date: '2025-01-20', note: 'Fast-tracked based on high AI match' },
      { status: 'interview', date: '2025-01-23', note: 'Video interview completed with 9/10 score' },
      { status: 'selected', date: '2025-01-27', note: 'Offer Letter Issued: ₹25,000/month stipend with PPO Track!' }
    ]
  },
  {
    id: 'app-4',
    candidateId: 'std-2',
    candidateName: 'Priya Patel',
    candidateEmail: 'priya.patel@example.com',
    candidatePhone: '+91 97123 45678',
    candidateEducation: 'B.Tech Computer Science & Engineering',
    candidateCourse: 'Computer Science',
    candidateAvatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    candidateCareerGoal: 'Full Stack Engineer',
    candidateSkills: ['React / Next.js', 'TypeScript', 'Node.js & Express', 'PostgreSQL'],
    candidateReadinessScore: 89,
    jobId: 'job-3',
    jobTitle: 'Software Development Engineer I (Full Stack)',
    jobType: 'job',
    companyId: 'comp-1',
    companyName: 'ABC Technologies',
    companyLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    applicationDate: '2025-01-14',
    applicationSource: 'Applied through Nexif5',
    status: 'interview',
    matchScore: 95,
    matchBreakdown: {
      skillsMatch: 98,
      qualificationMatch: 95,
      careerGoalMatch: 95,
      preferenceMatch: 92
    },
    matchReasons: [
      'Exceptional TypeScript, React, and Node.js GitHub projects demonstrated.',
      'SIH 2024 finalist with practical full-stack deployment experience.',
      'Remote work preference matches job specifications perfectly.'
    ],
    resumeUsed: 'Priya_Patel_FullStack_2025.pdf',
    recruiterNotes: 'Code sample review passed with distinction. Scheduled for System Design & Coding interview.',
    timeline: [
      { status: 'applied', date: '2025-01-14', note: 'Independent applicant on Nexif5' },
      { status: 'under_review', date: '2025-01-16', note: 'Reviewed by Tech Recruiter Vikram Joshi' },
      { status: 'shortlisted', date: '2025-01-19', note: 'Online coding assessment cleared (100% score)' },
      { status: 'interview', date: '2025-01-26', note: 'Technical Round 1 scheduled for Feb 12' }
    ]
  },
  {
    id: 'app-5',
    candidateId: 'std-3',
    candidateName: 'Rohan Mehta',
    candidateEmail: 'rohan.mehta@example.com',
    candidatePhone: '+91 99201 88344',
    candidateEducation: 'B.Com (Honours)',
    candidateCourse: 'Finance & Banking',
    candidateCollegeName: 'Loyola College of Arts & Sciences',
    candidateAvatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    candidateCareerGoal: 'Financial Analyst',
    candidateSkills: ['Financial Modeling', 'Excel (Advanced)', 'Corporate Valuation (DCF)'],
    candidateReadinessScore: 84,
    jobId: 'job-5',
    jobTitle: 'Financial Analyst (Corporate & M&A)',
    jobType: 'job',
    companyId: 'comp-2',
    companyName: 'FinEdge Analytics',
    companyLogoUrl: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=150&auto=format&fit=crop&q=80',
    applicationDate: '2025-01-19',
    applicationSource: 'Applied through Nexif5',
    status: 'under_review',
    matchScore: 93,
    matchBreakdown: {
      skillsMatch: 95,
      qualificationMatch: 95,
      careerGoalMatch: 95,
      preferenceMatch: 87
    },
    matchReasons: [
      'Top-notch DCF valuation portfolio and BSE Pitchathon winner.',
      'Strong financial accounting foundation from Loyola College.'
    ],
    resumeUsed: 'Rohan_Mehta_Finance_2025.pdf',
    timeline: [
      { status: 'applied', date: '2025-01-19', note: 'Applied via Nexif5' },
      { status: 'under_review', date: '2025-01-22', note: 'In review with Corporate Finance lead' }
    ]
  },
  {
    id: 'app-6',
    candidateId: 'std-4',
    candidateName: 'Ananya Iyer',
    candidateEmail: 'ananya.iyer@example.com',
    candidatePhone: '+91 94441 55670',
    candidateEducation: 'B.Sc Data Analytics',
    candidateCourse: 'Data Science & Applied Statistics',
    candidateCollegeName: 'Rathinam Global University',
    candidateAvatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    candidateCareerGoal: 'Data Scientist',
    candidateSkills: ['Python', 'SQL', 'Pandas & Scikit-Learn', 'Power BI'],
    candidateReadinessScore: 92,
    jobId: 'job-4',
    jobTitle: 'Graduate Data Science & AI Trainee',
    jobType: 'job',
    companyId: 'comp-3',
    companyName: 'TCS Innovate Labs',
    companyLogoUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=150&auto=format&fit=crop&q=80',
    applicationDate: '2025-01-10',
    applicationSource: 'College Campus Drive',
    status: 'selected',
    matchScore: 97,
    matchBreakdown: {
      skillsMatch: 98,
      qualificationMatch: 100,
      careerGoalMatch: 96,
      preferenceMatch: 94
    },
    matchReasons: [
      'Published IEEE research paper in Predictive AI.',
      'Perfect 9.4 CGPA and advanced Python/SQL capability.'
    ],
    resumeUsed: 'Ananya_Iyer_DataScience_2025.pdf',
    timeline: [
      { status: 'applied', date: '2025-01-10', note: 'Campus drive application via Rathinam placement cell' },
      { status: 'shortlisted', date: '2025-01-13', note: 'Selected for AI hackathon & panel' },
      { status: 'interview', date: '2025-01-17', note: 'Technical interview with R&D Director' },
      { status: 'selected', date: '2025-01-22', note: 'Offer Extended: ₹8.5 LPA Package at Chennai Innovate Lab!' }
    ]
  },
  {
    id: 'app-7',
    candidateId: 'std-7',
    candidateName: 'Karthik Raja',
    candidateEmail: 'karthik.raja@example.com',
    candidatePhone: '+91 98402 33119',
    candidateEducation: 'B.Com General',
    candidateCourse: 'Corporate Accounting',
    candidateCollegeName: 'Rathinam Global University',
    candidateAvatarUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&auto=format&fit=crop&q=80',
    candidateCareerGoal: 'Financial Analyst',
    candidateSkills: ['Tally Prime & GST', 'Excel (Intermediate)'],
    candidateReadinessScore: 68,
    jobId: 'job-1',
    jobTitle: 'Associate Business Analyst',
    jobType: 'job',
    companyId: 'comp-1',
    companyName: 'ABC Technologies',
    companyLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    applicationDate: '2025-01-12',
    applicationSource: 'Applied through Nexif5',
    status: 'rejected',
    matchScore: 62,
    matchBreakdown: {
      skillsMatch: 52,
      qualificationMatch: 85,
      careerGoalMatch: 65,
      preferenceMatch: 70
    },
    matchReasons: [
      'Missing core SQL querying and Power BI dashboarding skills required for this technical analytics role.'
    ],
    resumeUsed: 'Karthik_Raja_Accounts_2025.pdf',
    rejectionFeedback: {
      provided: true,
      reasonCategory: 'skill_gap',
      comment: 'Candidate demonstrated good foundational accounting knowledge, but the Associate Business Analyst position requires intermediate-to-advanced SQL query writing and Power BI visualization.',
      suggestedSkillsToLearn: ['SQL (Joins, Aggregations, Subqueries)', 'Power BI DAX Formulas', 'Agile Business Requirements']
    },
    timeline: [
      { status: 'applied', date: '2025-01-12', note: 'Applied via Nexif5' },
      { status: 'under_review', date: '2025-01-15', note: 'Profile evaluated by Recruiter' },
      { status: 'rejected', date: '2025-01-19', note: 'Constructive feedback and skill recommendations provided by recruiter' }
    ]
  },
  {
    id: 'app-8',
    candidateId: 'std-13',
    candidateName: 'Arvind Swaminathan',
    candidateEmail: 'arvind.s@example.com',
    candidatePhone: '+91 94432 77881',
    candidateEducation: 'B.Com (Professional Accounting)',
    candidateCourse: 'Accounting & Auditing',
    candidateCollegeName: 'Rathinam Global University',
    candidateAvatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
    candidateCareerGoal: 'Business Analyst',
    candidateSkills: ['Excel (Advanced)', 'Corporate Taxation', 'SQL Basics'],
    candidateReadinessScore: 72,
    jobId: 'job-1',
    jobTitle: 'Associate Business Analyst',
    jobType: 'job',
    companyId: 'comp-1',
    companyName: 'ABC Technologies',
    companyLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    applicationDate: '2025-01-14',
    applicationSource: 'Applied through Nexif5',
    status: 'rejected',
    matchScore: 69,
    matchBreakdown: {
      skillsMatch: 68,
      qualificationMatch: 90,
      careerGoalMatch: 75,
      preferenceMatch: 65
    },
    matchReasons: [
      'Strong in Excel, but Power BI and practical analytics project experience are limited.'
    ],
    resumeUsed: 'Arvind_Swaminathan_Audit_2025.pdf',
    // Rule: Honest rejection where NO feedback was provided
    rejectionFeedback: {
      provided: false
    },
    timeline: [
      { status: 'applied', date: '2025-01-14', note: 'Applied via Nexif5' },
      { status: 'under_review', date: '2025-01-16', note: 'Reviewed by recruitment team' },
      { status: 'rejected', date: '2025-01-20', note: 'Application status updated to Not Selected' }
    ]
  },
  {
    id: 'app-9',
    candidateId: 'std-18',
    candidateName: 'Ritu Agarwal',
    candidateEmail: 'ritu.agarwal@example.com',
    candidatePhone: '+91 99102 33887',
    candidateEducation: 'B.Com (Honours)',
    candidateCourse: 'Corporate Finance',
    candidateCollegeName: 'Rathinam Global University',
    candidateAvatarUrl: 'https://images.unsplash.com/photo-1548142813-c348350df52b?w=200&auto=format&fit=crop&q=80',
    candidateCareerGoal: 'Business Analyst',
    candidateSkills: ['Excel (Advanced)', 'SQL', 'Power BI', 'Financial Ratio Analysis'],
    candidateReadinessScore: 88,
    jobId: 'job-1',
    jobTitle: 'Associate Business Analyst',
    jobType: 'job',
    companyId: 'comp-1',
    companyName: 'ABC Technologies',
    companyLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    applicationDate: '2025-01-16',
    applicationSource: 'Applied through Nexif5',
    status: 'shortlisted',
    matchScore: 92,
    matchBreakdown: {
      skillsMatch: 94,
      qualificationMatch: 95,
      careerGoalMatch: 92,
      preferenceMatch: 86
    },
    matchReasons: [
      'Solid combination of Excel, SQL and Power BI analytics skills.',
      'Strong financial ratio analysis acumen.'
    ],
    resumeUsed: 'Ritu_Agarwal_BA_2025.pdf',
    timeline: [
      { status: 'applied', date: '2025-01-16', note: 'Applied via Nexif5' },
      { status: 'under_review', date: '2025-01-19', note: 'Screened by HR Manager Smita Kulkarni' },
      { status: 'shortlisted', date: '2025-01-24', note: 'Shortlisted for Business Analyst Cohort' }
    ]
  },
  {
    id: 'app-10',
    candidateId: 'std-5',
    candidateName: 'Vikram Sundaram',
    candidateEmail: 'vikram.s@example.com',
    candidatePhone: '+91 98840 99120',
    candidateEducation: 'B.Tech Information Technology',
    candidateCourse: 'Information Technology',
    candidateCollegeName: 'PSG College of Technology',
    candidateAvatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
    candidateCareerGoal: 'Associate Product Manager',
    candidateSkills: ['Product Roadmapping', 'SQL & Analytics', 'Wireframing (Figma)', 'User Research'],
    candidateReadinessScore: 81,
    jobId: 'job-7',
    jobTitle: 'Associate Product Manager (Healthcare Tech)',
    jobType: 'job',
    companyId: 'comp-5',
    companyName: 'Zenith Health AI',
    companyLogoUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=150&auto=format&fit=crop&q=80',
    applicationDate: '2025-01-17',
    applicationSource: 'Applied through Nexif5',
    status: 'interview',
    matchScore: 92,
    matchBreakdown: {
      skillsMatch: 95,
      qualificationMatch: 92,
      careerGoalMatch: 96,
      preferenceMatch: 85
    },
    matchReasons: [
      'Product tear-down winner with practical Figma wireframing & SQL analytics skillset.'
    ],
    resumeUsed: 'Vikram_Sundaram_APM_2025.pdf',
    scheduledInterview: {
      id: 'int-2',
      applicationId: 'app-10',
      candidateId: 'std-5',
      candidateName: 'Vikram Sundaram',
      jobTitle: 'Associate Product Manager',
      companyName: 'Zenith Health AI',
      date: '2025-02-20',
      time: '04:00 PM IST',
      roundType: 'HR Discussion',
      interviewMode: 'Virtual Video Call',
      meetingLink: 'https://meet.google.com/zenith-product-interview',
      interviewerName: 'Dr. Nandini Roy (Founding Partner)',
      status: 'upcoming'
    },
    timeline: [
      { status: 'applied', date: '2025-01-17', note: 'Applied via Nexif5' },
      { status: 'under_review', date: '2025-01-20', note: 'Reviewed by Product Lead' },
      { status: 'shortlisted', date: '2025-01-23', note: 'Product tear-down presentation passed' },
      { status: 'interview', date: '2025-01-28', note: 'Interview scheduled with Founding Partner' }
    ]
  },
  {
    id: 'app-jobseeker-1',
    candidateId: 'std-jobseeker',
    candidateName: 'Rahul Verma',
    candidateEmail: 'rahul.verma@example.com',
    candidatePhone: '+91 98112 34980',
    candidateEducation: 'B.Com Honours & Analytics (2+ Yrs Exp)',
    candidateCourse: 'Finance & Applied Analytics',
    candidateAvatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    candidateCareerGoal: 'Business Analyst',
    candidateSkills: ['Excel (Advanced)', 'SQL', 'Power BI', 'Business Analysis', 'Financial Modeling', 'Tableau'],
    candidateReadinessScore: 94,
    candidateType: 'job_seeker',
    jobId: 'job-1',
    jobTitle: 'Associate Business Analyst',
    jobType: 'job',
    companyId: 'comp-1',
    companyName: 'ABC Technologies',
    companyLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    applicationDate: '2025-01-22',
    applicationSource: 'Applied through Nexif5',
    status: 'interview',
    matchScore: 96,
    matchBreakdown: {
      skillsMatch: 98,
      qualificationMatch: 100,
      careerGoalMatch: 96,
      preferenceMatch: 90
    },
    matchReasons: [
      'Independent candidate with 2+ years verified corporate experience in SQL & Power BI analytics.',
      'Certified Analytics Professional with 1st place in National Strategy Case Challenge.',
      'Strong match across all core technical and domain requirements.'
    ],
    resumeUsed: 'Rahul_Verma_Senior_Business_Analyst_2025.pdf',
    coverNote: 'With 2+ years optimizing enterprise analytics data marts and building interactive executive dashboards, I am excited to contribute to ABC Technologies analytics client delivery.',
    recruiterNotes: 'Top lateral candidate from independent Nexif5 pool. Proven portfolio in customer LTV and cohort retention. Fast-tracked for Technical Case Study.',
    scheduledInterview: {
      id: 'int-js-1',
      applicationId: 'app-jobseeker-1',
      candidateId: 'std-jobseeker',
      candidateName: 'Rahul Verma',
      jobTitle: 'Associate Business Analyst',
      companyName: 'ABC Technologies',
      date: '2025-02-22',
      time: '02:00 PM IST',
      roundType: 'Analytics Case Study',
      interviewMode: 'Virtual Video Call',
      meetingLink: 'https://meet.google.com/abc-nexif-rahul-case',
      interviewerName: 'Rajesh Menon (Lead Architect)',
      status: 'upcoming'
    },
    timeline: [
      { status: 'applied', date: '2025-01-22', note: 'Applied independently through Nexif5' },
      { status: 'under_review', date: '2025-01-24', note: 'Fast-tracked by HR Recruiter Smita Kulkarni' },
      { status: 'shortlisted', date: '2025-01-27', note: 'Shortlisted based on 96% AI Match & CAP Certification' },
      { status: 'interview', date: '2025-01-30', note: 'Technical Case Study scheduled for Feb 22, 2:00 PM IST' }
    ]
  }
];

export const MOCK_COLLEGE_SKILL_METRICS: CollegeSkillMetric[] = [
  {
    skillName: 'Excel (Advanced)',
    category: 'Analytics & Tools',
    readyCount: 160,
    needTrainingCount: 20,
    totalAssessed: 180,
    growthMoM: '+14%'
  },
  {
    skillName: 'Power BI',
    category: 'Business Intelligence',
    readyCount: 90,
    needTrainingCount: 90,
    totalAssessed: 180,
    growthMoM: '+28%'
  },
  {
    skillName: 'SQL (Relational & Analytical)',
    category: 'Database & Data Engineering',
    readyCount: 65,
    needTrainingCount: 115,
    totalAssessed: 180,
    growthMoM: '+18%'
  },
  {
    skillName: 'Python for Analytics',
    category: 'Programming',
    readyCount: 45,
    needTrainingCount: 135,
    totalAssessed: 180,
    growthMoM: '+35%'
  },
  {
    skillName: 'Financial Modeling & DCF',
    category: 'Finance & Domain',
    readyCount: 82,
    needTrainingCount: 58,
    totalAssessed: 140,
    growthMoM: '+12%'
  },
  {
    skillName: 'React & TypeScript',
    category: 'Software Engineering',
    readyCount: 110,
    needTrainingCount: 70,
    totalAssessed: 180,
    growthMoM: '+22%'
  }
];

export const MOCK_COLLEGE_DEPT_STATS: CollegeDepartmentStat[] = [
  {
    department: 'Commerce & Computer Applications',
    totalStudents: 320,
    registeredCount: 285,
    shortlistedCount: 142,
    selectedCount: 88,
    placementRate: 84.6,
    avgSalaryLPA: 6.4,
    highestSalaryLPA: 12.0
  },
  {
    department: 'Computer Science & Engineering',
    totalStudents: 420,
    registeredCount: 390,
    shortlistedCount: 230,
    selectedCount: 168,
    placementRate: 91.2,
    avgSalaryLPA: 7.8,
    highestSalaryLPA: 18.5
  },
  {
    department: 'Data Analytics & AI',
    totalStudents: 180,
    registeredCount: 172,
    shortlistedCount: 118,
    selectedCount: 84,
    placementRate: 94.0,
    avgSalaryLPA: 8.6,
    highestSalaryLPA: 16.0
  },
  {
    department: 'Commerce & Finance',
    totalStudents: 260,
    registeredCount: 230,
    shortlistedCount: 96,
    selectedCount: 64,
    placementRate: 78.4,
    avgSalaryLPA: 5.8,
    highestSalaryLPA: 10.5
  },
  {
    department: 'Management Studies (MBA)',
    totalStudents: 240,
    registeredCount: 215,
    shortlistedCount: 104,
    selectedCount: 72,
    placementRate: 81.5,
    avgSalaryLPA: 7.2,
    highestSalaryLPA: 14.0
  }
];

export const MOCK_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    recipientType: 'student',
    recipientId: 'std-1',
    title: 'New High AI Opportunity Match (94%)',
    message: 'Associate Business Analyst at ABC Technologies matches your skills in Excel, Power BI, and SQL.',
    type: 'job_match',
    date: '10 mins ago',
    read: false,
    actionLink: 'job-1'
  },
  {
    id: 'notif-2',
    recipientType: 'student',
    recipientId: 'std-1',
    title: 'Interview Scheduled — ABC Technologies',
    message: 'Analytics Case Study round scheduled for Feb 18, 2025 at 03:30 PM IST.',
    type: 'interview_scheduled',
    date: '2 hours ago',
    read: false,
    actionLink: 'app-1'
  },
  {
    id: 'notif-3',
    recipientType: 'student',
    recipientId: 'std-1',
    title: 'Offer Letter Received! 🎉',
    message: 'Congratulations! ABC Technologies selected you for the Business Analytics Summer Intern role (₹25k/mo).',
    type: 'application_update',
    date: '1 day ago',
    read: true,
    actionLink: 'app-3'
  },
  {
    id: 'notif-4',
    recipientType: 'recruiter',
    recipientId: 'rec-1',
    title: 'Strong AI Match Applied (94%)',
    message: 'Aarav Sharma applied for Associate Business Analyst via Nexif5.',
    type: 'new_applicant',
    date: '30 mins ago',
    read: false,
    actionLink: 'app-1'
  },
  {
    id: 'notif-5',
    recipientType: 'recruiter',
    recipientId: 'rec-1',
    title: 'Interview Reminder Today',
    message: 'Case Study round with Candidate Aarav Sharma at 03:30 PM IST.',
    type: 'interview_scheduled',
    date: '3 hours ago',
    read: false,
    actionLink: 'int-1'
  },
  {
    id: 'notif-6',
    recipientType: 'college',
    recipientId: 'clg-1',
    title: 'New Student Selection Recorded',
    message: 'Ananya Iyer (Data Analytics) selected by TCS Innovate Labs at ₹8.5 LPA.',
    type: 'campus_drive',
    date: '1 hour ago',
    read: false,
    actionLink: 'clg-analytics'
  },
  {
    id: 'notif-7',
    recipientType: 'college',
    recipientId: 'clg-1',
    title: 'Skill Gap Alert: SQL Training Recommended',
    message: '115 Commerce & Analytics students need SQL training for upcoming Business Analyst recruitment drives.',
    type: 'system',
    date: '5 hours ago',
    read: false,
    actionLink: 'clg-skills'
  }
];

export const MOCK_SHARED_RESOURCES: SharedResource[] = [
  {
    id: 'res-1',
    title: 'Power BI Beginner Notes & DAX Formulas.pdf',
    description: 'Comprehensive beginner-friendly study notes covering Power BI Desktop setup, Power Query data transformation, star-schema modeling, and top 25 DAX formulas for corporate business reporting.',
    fileType: 'pdf',
    fileSize: '3.4 MB',
    fileName: 'power_bi_beginner_notes_dax.pdf',
    category: 'Skill Learning',
    subject: 'Business Analytics',
    skill: 'Power BI',
    careerRelevance: 'Finance / Business / Analytics',
    tags: ['Power BI', 'DAX', 'Dashboard', 'Beginner', 'Analytics'],
    uploaderId: 'usr-sneha',
    uploaderName: 'Sneha Kulkarni',
    uploaderRole: 'Senior Analytics Consultant (Ex-Deloitte)',
    uploaderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&auto=format&fit=crop&q=80',
    uploadDate: '3 days ago',
    viewsCount: 348,
    savesCount: 142,
    helpfulCount: 119,
    downloadsCount: 88,
    visibility: 'community',
    previewSnippet: `CHAPTER 1: POWER BI FUNDAMENTALS
Power BI is a unified business intelligence platform that converts disparate data into interactive visual insights.
1. Core Architecture: Power Query (ETL Engine) → Power Pivot (Data Modeling & Relationships) → Power View (Visualization Canvas).
2. Data Modeling Best Practice: Always normalize data into a Star Schema. Fact tables store quantitative transactional metrics; Dimension tables store descriptive context (Date, Product, Region, Customer).
3. Critical DAX Formulas:
   • Total Sales = SUM(Sales[Revenue])
   • YTD Sales = TOTALYTD([Total Sales], 'Date'[Date])
   • Profit Margin % = DIVIDE([Total Profit], [Total Sales], 0)
   • MoM Growth = DIVIDE([Total Sales] - CALCULATE([Total Sales], DATEADD('Date'[Date], -1, MONTH)), CALCULATE([Total Sales], DATEADD('Date'[Date], -1, MONTH)), 0)
4. Dashboard Practical Exercise: Connect Sample_Superstore.xlsx, create 3 KPI cards, a Monthly Trend area chart, and a Regional bar breakdown with slicers.`,
    contentOutline: [
      '1. Getting Started with Power BI Desktop & UI Overview',
      '2. Power Query: Cleaning & Transforming Raw Messy Data',
      '3. Star Schema Data Modeling: Fact vs Dimension Tables',
      '4. Essential DAX: SUM, CALCULATE, RELATED, DATEADD',
      '5. Step-by-Step Practical Sales Dashboard Project'
    ],
    aiRelevanceReason: 'Directly addresses your Power BI skill gap. Completing this resource and building the practice dashboard advances your Power BI proficiency toward Working Proficiency.',
    practicalTaskTitle: 'Build a 3-KPI Sales Dashboard with Date Slicers in Power BI',
    downloadUrl: '#'
  },
  {
    id: 'res-2',
    title: 'Financial Modelling & DCF Valuation Handbook.pdf',
    description: 'Step-by-step practical guide to constructing dynamic 3-statement financial models, working capital schedules, DCF enterprise valuation, and sensitivity analysis in Excel.',
    fileType: 'pdf',
    fileSize: '4.8 MB',
    fileName: 'financial_modelling_dcf_handbook.pdf',
    category: 'Skill Learning',
    subject: 'Corporate Finance',
    skill: 'Financial Modeling',
    careerRelevance: 'Finance Analyst / Investment Banking',
    tags: ['Financial Modeling', 'DCF', 'Valuation', 'Excel', 'Finance'],
    uploaderId: 'usr-ananya',
    uploaderName: 'Ananya Patel',
    uploaderRole: 'Equity Research Associate',
    uploaderAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=120&auto=format&fit=crop&q=80',
    uploadDate: '1 week ago',
    viewsCount: 512,
    savesCount: 226,
    helpfulCount: 184,
    downloadsCount: 135,
    visibility: 'community',
    previewSnippet: `1. 3-STATEMENT FINANCIAL INTEGRATION RULES:
• Net Income from the Income Statement flows directly into the starting line of the Cash Flow from Operations (CFO).
• Depreciation & Amortization is added back in Cash Flow and reduces Gross PP&E on the Balance Sheet.
• Capital Expenditures (CapEx) from Cash Flow from Investing (CFI) increases Net PP&E on the Balance Sheet.
• Ending Cash Balance from Cash Flow reconciles Cash & Cash Equivalents under Current Assets.
2. DISCOUNTED CASH FLOW (DCF) ESSENTIALS:
• Unlevered Free Cash Flow (UFCF) = EBIT * (1 - Tax Rate) + D&A - CapEx - Change in Net Working Capital.
• Weighted Average Cost of Capital (WACC) = (E/V * Re) + (D/V * Rd * (1 - Tc)).
• Terminal Value (Perpetuity Method) = (Final Year UFCF * (1 + g)) / (WACC - g).`,
    contentOutline: [
      '1. Structuring Clean Excel Financial Workbooks',
      '2. Revenue Drivers & COGS Forecasting Methodologies',
      '3. Linking Income Statement, Balance Sheet, and Cash Flows',
      '4. WACC Calculation & Beta Unlevering / Relevering',
      '5. Sensitivity Tables (Data Tables) for Scenario Analysis'
    ],
    aiRelevanceReason: 'Identified as a Priority Skill Gap for your Finance Analyst & Business Analyst career aspirations. Boosts your technical readiness by +6%.',
    practicalTaskTitle: 'Complete a 3-Statement Model with Sensitivity Table in Excel',
    downloadUrl: '#'
  },
  {
    id: 'res-3',
    title: 'Advanced SQL Window Functions & Analytics Queries.pdf',
    description: 'Real corporate case studies on ROW_NUMBER(), DENSE_RANK(), LAG/LEAD, running totals, and recursive CTEs with solution queries tested in PostgreSQL and MySQL.',
    fileType: 'pdf',
    fileSize: '2.1 MB',
    fileName: 'sql_window_functions_guide.pdf',
    category: 'Skill Learning',
    subject: 'Database Engineering',
    skill: 'SQL',
    careerRelevance: 'Data & Business Analytics',
    tags: ['SQL', 'Window Functions', 'Queries', 'Database', 'PostgreSQL'],
    uploaderId: 'std-jobseeker',
    uploaderName: 'Rahul Verma',
    uploaderRole: 'Lead Business Analyst',
    uploaderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    uploadDate: '4 days ago',
    viewsCount: 620,
    savesCount: 290,
    helpfulCount: 247,
    downloadsCount: 198,
    visibility: 'community',
    previewSnippet: `COMMON WINDOW FUNCTION PATTERNS IN RECRUITER ASSESSMENTS:
1. Finding the Top 3 Salaried Employees per Department:
   SELECT emp_id, department, salary,
          DENSE_RANK() OVER (PARTITION BY department ORDER BY salary DESC) as rank_num
   FROM employees
   WHERE rank_num <= 3;
2. Month-over-Month Revenue Growth:
   WITH monthly_rev AS (
     SELECT DATE_TRUNC('month', order_date) AS mth, SUM(amount) AS total_rev
     FROM transactions GROUP BY 1
   )
   SELECT mth, total_rev,
          LAG(total_rev, 1) OVER (ORDER BY mth) AS prev_rev,
          ROUND(((total_rev - LAG(total_rev, 1) OVER (ORDER BY mth)) / LAG(total_rev, 1) OVER (ORDER BY mth)) * 100, 2) AS mom_pct
   FROM monthly_rev;`,
    contentOutline: [
      '1. Concept: Aggregate Functions vs Window Functions',
      '2. Partition By vs Group By Deep Dive',
      '3. Ranking Functions: ROW_NUMBER, RANK, DENSE_RANK',
      '4. Value Functions: LAG, LEAD, FIRST_VALUE, NTH_VALUE',
      '5. 15 Live Interview Case Studies with Solutions'
    ],
    aiRelevanceReason: 'Reinforces your SQL proficiency from Intermediate to Advanced, fulfilling requirements for 92% of targeted analyst roles.',
    practicalTaskTitle: 'Solve 5 MoM and Ranking SQL Practice Challenges',
    downloadUrl: '#'
  },
  {
    id: 'res-4',
    title: '50 High-Frequency Business Analyst Interview Questions.pdf',
    description: 'Curated collection of actual 2025 interview questions and case frameworks asked by leading consulting, tech, and banking recruiters.',
    fileType: 'pdf',
    fileSize: '3.1 MB',
    fileName: 'ba_50_interview_questions.pdf',
    category: 'Interview Prep',
    subject: 'Interview Preparation',
    skill: 'Business Analysis',
    careerRelevance: 'Business Analyst / Strategy',
    tags: ['Interview Prep', 'Case Studies', 'Root Cause', 'Behavioral', 'Questions'],
    uploaderId: 'usr-vikram',
    uploaderName: 'Vikramaditya Roy',
    uploaderRole: 'Analytics Director & Hiring Panelist',
    uploaderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    uploadDate: '2 weeks ago',
    viewsCount: 840,
    savesCount: 410,
    helpfulCount: 360,
    downloadsCount: 280,
    visibility: 'community',
    previewSnippet: `COMMON BUSINESS ANALYST CASE FRAMEWORKS:
1. Root Cause Analysis (Metric Drop Problem):
   "Daily active users on our mobile checkout page dropped by 18% yesterday. How do you diagnose this?"
   Framework:
   Step 1: Clarify and confirm the metric (Is it sudden or gradual? Is the data pipeline healthy?).
   Step 2: Segment the data (By iOS vs Android, Geography, New vs Returning users, App version).
   Step 3: Internal factors (Recent code deployment, checkout gateway downtime, price increase).
   Step 4: External factors (Public holiday, competitor marketing campaign, network ISP outage).
   Step 5: Formulate hypothesis and propose corrective test.`,
    contentOutline: [
      '1. Technical Round: SQL, Excel & Data Modeling Scenarios',
      '2. Business Problem Solving & Root Cause Frameworks',
      '3. Stakeholder Conflict & Requirement Elicitation Questions',
      '4. STAR Method Behavioral Responses for Freshers',
      '5. Questions to Ask the Hiring Panel at the End'
    ],
    aiRelevanceReason: 'Crucial for passing recruiter round 2 technical and case study evaluations. Prepares you for upcoming interviews.',
    practicalTaskTitle: 'Practice answering 3 metric-drop case studies using the 5-step framework',
    downloadUrl: '#'
  },
  {
    id: 'res-5',
    title: 'Excel Dynamic Dashboards & Pivot Mastery Notes.pdf',
    description: 'Complete handbook on XLOOKUP, INDEX/MATCH, Dynamic Arrays (FILTER, UNIQUE, SORT), Power Pivot, and automating executive KPI sheets.',
    fileType: 'pdf',
    fileSize: '2.9 MB',
    fileName: 'excel_dynamic_dashboards_mastery.pdf',
    category: 'Skill Learning',
    subject: 'Data Reporting',
    skill: 'Excel (Advanced)',
    careerRelevance: 'Business & Financial Reporting',
    tags: ['Excel', 'Dashboards', 'XLOOKUP', 'Power Pivot', 'Formulas'],
    uploaderId: 'usr-priya',
    uploaderName: 'Priya Sharma',
    uploaderRole: 'Finance Operations Lead',
    uploaderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80',
    uploadDate: '5 days ago',
    viewsCount: 430,
    savesCount: 185,
    helpfulCount: 152,
    downloadsCount: 110,
    visibility: 'community',
    previewSnippet: `MODERN EXCEL POWER FUNCTIONS:
1. Dynamic Filtering:
   =FILTER(SalesData, (Region="North") * (Revenue > 50000), "No Records Found")
2. Unique Lists without Manual De-duplication:
   =SORT(UNIQUE(Customers[Industry]))
3. 2-Way Lookups with XLOOKUP:
   =XLOOKUP(Target_Metric, Metric_List, XLOOKUP(Target_Year, Year_Headers, Table_Data))`,
    contentOutline: [
      '1. Transitioning from VLOOKUP to Modern XLOOKUP',
      '2. Spill Ranges and Dynamic Array Functions',
      '3. Building Clean Formatted Interactive Dropdowns',
      '4. Conditional Formatting for Executive Presentations',
      '5. 1-Page Summary KPI Executive Dashboard Template'
    ],
    aiRelevanceReason: 'Reinforces your core strength (Excel Advanced). High utility for practical test rounds.',
    practicalTaskTitle: 'Build a dynamic filterable Excel dashboard using FILTER and SORT formulas',
    downloadUrl: '#'
  },
  {
    id: 'res-6',
    title: 'Product Metrics & KPI Frameworks for Freshers.pdf',
    description: 'Practical guide to North Star metrics, AARRR pirate metrics, cohort retention curves, and Business Requirement Document (BRD) writing for aspiring analysts.',
    fileType: 'pdf',
    fileSize: '1.9 MB',
    fileName: 'product_metrics_and_kpis.pdf',
    category: 'Career Guide',
    subject: 'Product & Analytics',
    skill: 'Business Analysis',
    careerRelevance: 'Product Operations & Business Analysis',
    tags: ['BRD', 'Product Metrics', 'AARRR', 'Freshers', 'Documentation'],
    uploaderId: 'std-1',
    uploaderName: 'Aarav Sharma',
    uploaderRole: 'B.Com Honours & Analytics Student',
    uploaderAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=120&auto=format&fit=crop&q=80',
    uploadDate: 'Yesterday',
    viewsCount: 172,
    savesCount: 64,
    helpfulCount: 58,
    downloadsCount: 39,
    visibility: 'community',
    previewSnippet: `METRIC ARCHITECTURE FOR ANALYSTS:
• North Star Metric: The single metric that best captures the core value delivered to customers (e.g., Spotify: Time spent listening to music; Airbnb: Nights booked).
• Input Metrics: Levers teams can directly influence (e.g., Playlist creation count, search query response time).
• AARRR Funnel:
  1. Acquisition: How do users find us? (Signups, CAC).
  2. Activation: Do users have a great first experience? (Day-1 core action completion).
  3. Retention: Do users come back? (Cohort retention curve, churn %).
  4. Referral: Do users share? (Viral coefficient, NPS).
  5. Revenue: How do we monetize? (LTV, ARPU, Gross Margin).`,
    contentOutline: [
      '1. Defining the North Star Metric vs Vanity Metrics',
      '2. Breaking Down the Pirate AARRR Funnel',
      '3. Reading and Interpreting Cohort Retention Graphs',
      '4. Writing a Concise Business Requirements Document (BRD)',
      '5. 3 Real Product Case Exercises'
    ],
    aiRelevanceReason: 'Your own uploaded resource! Other NEXIF5 learners are actively discovering and saving this document.',
    practicalTaskTitle: 'Draft a 1-page BRD for a feature enhancement on an e-commerce app',
    downloadUrl: '#'
  },
  {
    id: 'res-7',
    title: 'Complete B.Com to Financial Analyst Career Roadmap.pdf',
    description: 'Strategic degree-to-career blueprint for commerce graduates: High-ROI certifications (NISM, CFA Level 1, FMVA), resume optimization, and campus recruitment strategies.',
    fileType: 'pdf',
    fileSize: '2.5 MB',
    fileName: 'bcom_to_financial_analyst_roadmap.pdf',
    category: 'Career Guide',
    subject: 'Career Strategy',
    skill: 'Career Planning',
    careerRelevance: 'Finance Analyst / Corporate Finance',
    tags: ['B.Com', 'Finance Analyst', 'Roadmap', 'Certifications', 'Placement'],
    uploaderId: 'usr-sundaram',
    uploaderName: 'Dr. K. Sundaram',
    uploaderRole: 'Dean of Placement & Industry Relations',
    uploaderAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    uploadDate: '10 days ago',
    viewsCount: 920,
    savesCount: 460,
    helpfulCount: 395,
    downloadsCount: 320,
    visibility: 'community',
    previewSnippet: `PATHWAY FOR COMMERCE STUDENTS:
1. Semester 5-6 Focus: Transition from theoretical accounting to applied corporate analytics (Advanced Excel, Financial Modeling, Power BI).
2. Industry Certifications that Recruiters Respect:
   • NISM Series XV: Research Analyst Certification (Mandatory for Indian brokerage & equity research).
   • Corporate Finance Institute (FMVA) or NSE Academy Certified Financial Modeler.
3. Portfolio Demonstration: Having two verified Excel financial models on your profile boosts shortlisting by 3.5x over candidate resumes that only list degree percentages.`,
    contentOutline: [
      '1. Current Corporate Finance Job Market for 2025/2026 Graduates',
      '2. Mandatory Technical vs Soft Skill Prerequisites',
      '3. High-ROI Certifications to Target Before Graduation',
      '4. Structuring a 1-Page ATS-Optimized Finance Resume',
      '5. Campus Placement & Off-Campus Application Strategies'
    ],
    aiRelevanceReason: 'Tailored specifically to your B.Com degree background and target career ambitions in Business and Finance analysis.',
    practicalTaskTitle: 'Review certification roadmap and select your next credential milestone',
    downloadUrl: '#'
  }
];

export const MOCK_SKILL_PROGRESS: SkillProgressItem[] = [
  {
    skill: 'Power BI',
    category: 'Analytics & BI',
    currentLevel: 'Beginner',
    targetLevel: 'Working Proficiency',
    whyItMatters: 'Mandatory technical skill for 84% of Business Analyst and Financial Analyst roles in your target salary tier (₹6.5 - 10.5 LPA).',
    progressPercent: 35,
    nextActionTitle: 'Read "Power BI Beginner Notes" and build a Sales KPI dashboard task',
    nextActionDescription: 'Study the recommended community PDF notes and build a 3-KPI card dashboard with Star Schema modeling.',
    howToDemonstrate: 'Publish dashboard screenshots or project report in your NEXIF5 verified portfolio.',
    careerReadinessImpact: '+8% to overall Career Readiness (moves benchmark from 78% to 86%).',
    isTaskCompleted: false,
    relatedResourceId: 'res-1'
  },
  {
    skill: 'Financial Modeling',
    category: 'Corporate Finance',
    currentLevel: 'Developing',
    targetLevel: 'Working Proficiency',
    whyItMatters: 'Identified by AI as your highest priority skill gap to qualify for elite corporate finance and strategy positions.',
    progressPercent: 20,
    nextActionTitle: 'Complete a 3-Statement Model with Sensitivity Table in Excel',
    nextActionDescription: 'Use the shared DCF Valuation Handbook to link Income Statement, Balance Sheet, and Cash Flow.',
    howToDemonstrate: 'Submit completed Excel financial model on NEXIF5 for automated diagnostic checks.',
    careerReadinessImpact: '+6% to overall Career Readiness.',
    isTaskCompleted: false,
    relatedResourceId: 'res-2'
  },
  {
    skill: 'SQL (Window Functions)',
    category: 'Database & Queries',
    currentLevel: 'Intermediate',
    targetLevel: 'Advanced',
    whyItMatters: 'Tested in round 1 technical assessments by 92% of top tech and FinTech recruiters.',
    progressPercent: 65,
    nextActionTitle: 'Solve 5 MoM and Ranking SQL Practice Challenges',
    nextActionDescription: 'Write and test queries using DENSE_RANK(), LAG(), and PARTITION BY clauses.',
    howToDemonstrate: 'Pass the 15-minute SQL interactive diagnostic test on NEXIF5.',
    careerReadinessImpact: '+5% to overall Career Readiness.',
    isTaskCompleted: false,
    relatedResourceId: 'res-3'
  },
  {
    skill: 'Business Analysis',
    category: 'Domain & Strategy',
    currentLevel: 'Advanced',
    targetLevel: 'Advanced',
    whyItMatters: 'Core pillar of your degree. Validates your capability to elicit requirements and frame business problems.',
    progressPercent: 90,
    nextActionTitle: 'Practice 3 Root Cause Analysis Case Questions',
    nextActionDescription: 'Review the 50 High-Frequency BA Questions handbook to prepare for interview rounds.',
    howToDemonstrate: 'Verified through hackathons and university coursework.',
    careerReadinessImpact: 'Already verified (Top tier).',
    isTaskCompleted: true,
    relatedResourceId: 'res-4'
  }
];

export const MOCK_CERTIFIED_COURSES: CertifiedCourse[] = [
  {
    id: 'course-pbi',
    title: 'Power BI Data Analyst Certified Professional',
    skill: 'Power BI',
    targetCareer: 'Business Analyst & Data Analyst',
    provider: 'NEXIF5 Academy',
    partner: 'Microsoft Learn Curriculum Alignment',
    level: 'Intermediate',
    durationHours: 14,
    durationLabel: '14 Hours • 8 Modules',
    progressPercent: 75,
    enrolled: true,
    modulesCount: 8,
    practiceActivitiesCount: 6,
    whyAiRecommended: 'Priority gap identified for your target Business Analyst career goal. High recruiter demand at FinEdge & ABC Tech.',
    careerReadinessImpact: '+8% to Career Readiness',
    badgeColor: 'amber',
    isCertificateEligible: true,
    isCertificateEarned: true,
    certificate: {
      certificateId: 'NXF-PBI-2026-00124',
      courseId: 'course-pbi',
      courseTitle: 'Power BI Data Analyst Certified Professional',
      skill: 'Power BI',
      learnerName: 'Aarav Sharma',
      learnerId: 'std-1',
      issuerName: 'NEXIF5 Career Execution Platform',
      partnerName: 'Microsoft Learn Curriculum Alignment',
      certificateType: 'completion',
      disclaimer: 'NEXIF5 Skill Mastery Completion Certificate. Confirms completion of 8 modules, practical dashboards, and passing the comprehensive capstone assessment. For statutory external certification, link verified Microsoft PL-300 credentials.',
      issueDate: 'October 4, 2026',
      assessmentScore: 86,
      grade: 'Distinction (86%)',
      verificationStatus: 'verified',
      verificationUrl: 'https://nexif5.careers/verify/NXF-PBI-2026-00124',
      skillsDemonstrated: [
        'Star Schema Relational Modelling',
        'DAX Measure Engineering (CALCULATE, FILTER, Time-Intelligence)',
        'Power Query ETL Data Ingestion & Cleansing',
        'Executive KPI Dashboard Design & Cross-Filtering'
      ],
      signatoryName: 'Dr. Ramesh Sundaram',
      signatoryTitle: 'Head of Industry Academics, NEXIF5'
    },
    assessment: {
      id: 'assess-pbi',
      title: 'Power BI Professional Capstone Assessment',
      description: 'Comprehensive 5-question evaluation testing dimensional modeling, DAX measure creation, Power Query transformations, and dashboard KPI logic.',
      passingScorePercent: 80,
      totalQuestions: 5,
      estimatedMinutes: 20,
      userScorePercent: 86,
      userPassed: true,
      completedAt: 'Oct 4, 2026',
      strengths: [
        'Star schema modeling relationships (1-to-many single direction)',
        'Understanding DAX filter context and CALCULATE modifiers',
        'Power Query automated columnar transformations'
      ],
      weakAreas: [
        'Advanced dynamic row-level security (RLS) expressions'
      ],
      skillLevelAwarded: 'Working Proficiency (Industry Ready)',
      recommendedNextAction: 'Incorporate your retail margin dashboard into your ATS resume and portfolio.',
      questions: [
        {
          id: 'q-pbi-1',
          type: 'mcq',
          question: 'In Power BI dimensional data modeling, why is a Star Schema strongly preferred over a deeply nested Snowflake schema?',
          options: [
            'It reduces relationship traversing overhead, simplifies DAX logic, and enables the VertiPaq engine to optimize memory scans.',
            'It encrypts sensitive company financial data automatically.',
            'It forces all tables to be merged into a single flat CSV file.',
            'It allows Power BI to run without requiring any RAM.'
          ],
          correctAnswerIndex: 0,
          explanation: 'Star schemas provide fewer relationship hops, cleaner filter propagation, and allow the VertiPaq columnar in-memory engine to compress columns with high cardinality efficiency.',
          skillFocus: 'Data Modeling'
        },
        {
          id: 'q-pbi-2',
          type: 'scenario',
          question: 'Scenario: You need a DAX measure that computes Sales for the same month of the previous calendar year. Which DAX pattern is correct?',
          options: [
            'CALCULATE(SUM(Sales[Amount]), SAMEPERIODLASTYEAR(Calendar[Date]))',
            'SUM(Sales[Amount]) - LASTYEAR(Calendar[Date])',
            'FILTER(Sales, Date = Date - 365)',
            'LOOKUPVALUE(Sales[Amount], Sales[Date], PreviousYear)'
          ],
          correctAnswerIndex: 0,
          explanation: 'CALCULATE modifies the filter context, and SAMEPERIODLASTYEAR returns a single-column table of dates shifted back by one full year over the date dimension.',
          skillFocus: 'DAX Engineering'
        },
        {
          id: 'q-pbi-3',
          type: 'mcq',
          question: 'What is the fundamental difference between CALCULATE and standard SUM in DAX?',
          options: [
            'CALCULATE can modify, override, or expand the current filter context using filter arguments.',
            'CALCULATE only works with text strings while SUM works with numbers.',
            'CALCULATE runs on the client browser while SUM runs on the server.',
            'There is no difference; they are exact synonyms.'
          ],
          correctAnswerIndex: 0,
          explanation: 'CALCULATE evaluates an expression within an altered or newly specified filter context, making it the most powerful function in DAX.',
          skillFocus: 'DAX Filter Context'
        },
        {
          id: 'q-pbi-4',
          type: 'scenario',
          question: 'Scenario: When importing a 2,000,000-row table from SQL Server into Power BI, which step should always be applied in Power Query to maximize performance?',
          options: [
            'Remove unnecessary columns, filter out unneeded historical rows, and ensure correct column data types so query folding occurs.',
            'Convert all numeric columns to text strings.',
            'Duplicate the table 3 times for backup inside Power Query.',
            'Disable background refresh permanently.'
          ],
          correctAnswerIndex: 0,
          explanation: 'Trimming columns early reduces memory footprint by 60-80% and query folding pushes filtration down to the relational database engine.',
          skillFocus: 'ETL & Query Optimization'
        },
        {
          id: 'q-pbi-5',
          type: 'practical',
          question: 'Practical Logic: A business stakeholder complains that selecting "Region: South" does not filter the "Customer Headcount" KPI card. What is the most likely architectural root cause?',
          options: [
            'The relationship between Region and Customer table has incorrect cross-filter direction or is inactive.',
            'The stakeholder has their computer monitor resolution set too high.',
            'Power BI only allows filtering on dates, never on text fields.',
            'The card visual was accidentally turned off by Windows Defender.'
          ],
          correctAnswerIndex: 0,
          explanation: 'If cross-filtering direction is set to single instead of both or if the relationship is inactive, filters applied on dimension tables will not propagate down to target tables.',
          skillFocus: 'Filter Propagation & Troubleshooting'
        }
      ]
    },
    videoLessons: [
      {
        id: 'pbi-m1',
        moduleNumber: 1,
        title: 'Module 1 — Introduction to Power BI & Architecture',
        description: 'Understand the end-to-end Power BI architecture: Power BI Desktop, Power BI Service, VertiPaq engine, and dataset refresh gateways.',
        durationMinutes: 12,
        videoDurationFormatted: '12:20',
        skillDeveloped: 'BI Architecture',
        difficulty: 'Beginner',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-1',
        practiceTask: {
          id: 'pt-pbi-1',
          title: 'Install & Setup Power BI Workspace',
          description: 'Launch Power BI Desktop and create a new report canvas with standard 16:9 canvas settings.',
          instructions: [
            'Verify installation of Power BI Desktop.',
            'Set report theme to Corporate Navy.',
            'Review report canvas layout grid.'
          ],
          isCompleted: true,
          userSubmission: 'Workspace initialized with Corporate Navy theme and 16:9 canvas resolution.'
        }
      },
      {
        id: 'pbi-m2',
        moduleNumber: 2,
        title: 'Module 2 — Data Import & Connectors',
        description: 'Connecting to multi-source data: PostgreSQL databases, enterprise Excel spreadsheets, web endpoints, and REST APIs.',
        durationMinutes: 18,
        videoDurationFormatted: '18:45',
        skillDeveloped: 'Data Connectivity',
        difficulty: 'Beginner',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-1',
        practiceTask: {
          id: 'pt-pbi-2',
          title: 'Connect Sales & Customer Tables',
          description: 'Import the mock e-commerce sales dataset and customer demographic dataset.',
          instructions: [
            'Use Get Data → Excel / CSV.',
            'Verify 12,500 rows ingested without delimiter errors.',
            'Review preview schema.'
          ],
          isCompleted: true,
          userSubmission: 'Ingested 12,500 sales transaction rows and verified primary keys.'
        }
      },
      {
        id: 'pbi-m3',
        moduleNumber: 3,
        title: 'Module 3 — Data Cleaning with Power Query & M Engine',
        description: 'Master data shaping: unpivoting columns, handling nulls, splitting delimiters, creating custom conditional columns, and ensuring query folding.',
        durationMinutes: 24,
        videoDurationFormatted: '24:10',
        skillDeveloped: 'Data Cleansing & ETL',
        difficulty: 'Intermediate',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-1',
        practiceTask: {
          id: 'pt-pbi-3',
          title: 'Clean Customer Dimension Data',
          description: 'Remove whitespace, replace missing postal codes, and unpivot quarterly revenue metrics.',
          instructions: [
            'Trim and clean string columns.',
            'Replace null country codes with "Domestic".',
            'Create standardized CustomerID hash.'
          ],
          isCompleted: true,
          userSubmission: 'Applied 7 transform steps in Power Query; query folding verified on SQL source.'
        }
      },
      {
        id: 'pbi-m4',
        moduleNumber: 4,
        title: 'Module 4 — Star Schema Data Modelling & Relationships',
        description: 'Design robust dimensional models. Contrast fact vs dimension tables, configure 1-to-many relationships, manage active/inactive paths, and avoid bi-directional traps.',
        durationMinutes: 28,
        videoDurationFormatted: '28:30',
        skillDeveloped: 'Dimensional Modeling',
        difficulty: 'Intermediate',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-1',
        practiceTask: {
          id: 'pt-pbi-4',
          title: 'Construct Star Schema Relationships',
          description: 'Link Fact_Sales with Dim_Customer, Dim_Product, and Dim_Date.',
          instructions: [
            'Create 1-to-many relationships from Dim to Fact.',
            'Ensure single cross-filter direction.',
            'Hide foreign key ID fields in report view to avoid end-user confusion.'
          ],
          isCompleted: true,
          userSubmission: 'Star schema established with 3 dimensions and 1 fact table; single cross-filter enforced.'
        }
      },
      {
        id: 'pbi-m5',
        moduleNumber: 5,
        title: 'Module 5 — DAX Basics: Measures, Columns & CALCULATE',
        description: 'Understand the difference between calculated columns and DAX measures. Write basic aggregations (SUM, AVERAGE, DIVIDE) and master CALCULATE with FILTER.',
        durationMinutes: 32,
        videoDurationFormatted: '32:15',
        skillDeveloped: 'DAX Measure Engineering',
        difficulty: 'Intermediate',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-1',
        practiceTask: {
          id: 'pt-pbi-5',
          title: 'Write 4 Essential DAX Measures',
          description: 'Create Total Revenue, Total Margin, Margin %, and Prior Year Revenue measures.',
          instructions: [
            'Total Revenue = SUM(Fact_Sales[NetRevenue])',
            'Margin % = DIVIDE([Total Margin], [Total Revenue], 0)',
            'PY Sales = CALCULATE([Total Revenue], SAMEPERIODLASTYEAR(Dim_Date[Date]))'
          ],
          isCompleted: true,
          userSubmission: 'Measures created inside a dedicated _Measures table with correct number formatting.'
        }
      },
      {
        id: 'pbi-m6',
        moduleNumber: 6,
        title: 'Module 6 — Dashboard Creation & Visual Best Practices',
        description: 'Craft executive-ready layouts. Learn visual hierarchy, KPI card cards, bar chart sorting, matrix table sparklines, and interactive cross-highlighting.',
        durationMinutes: 26,
        videoDurationFormatted: '26:00',
        skillDeveloped: 'Data Visualization & Storytelling',
        difficulty: 'Intermediate',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-1',
        practiceTask: {
          id: 'pt-pbi-6',
          title: 'Build Executive Summary Page',
          description: 'Construct top KPI ribbon with Revenue, Orders, and Gross Margin %, followed by Regional Trend charts.',
          instructions: [
            'Place 3 KPI Cards at the top.',
            'Add bar chart of Revenue by Product Category.',
            'Include date range slicer and category multi-select.'
          ],
          isCompleted: true,
          userSubmission: 'Executive summary canvas completed with responsive slicers and synchronized bookmark filters.'
        }
      },
      {
        id: 'pbi-m7',
        moduleNumber: 7,
        title: 'Module 7 — Practical Project: Retail Sales & Margin Analytics',
        description: 'End-to-end practical project. Build a commercial dashboard analyzing revenue, region, and product performance with profit variance waterfall.',
        durationMinutes: 40,
        videoDurationFormatted: '40:10',
        skillDeveloped: 'Practical Capstone Execution',
        difficulty: 'Advanced',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-1',
        practiceTask: {
          id: 'pt-pbi-7',
          title: 'Build End-to-End Retail Margin Dashboard',
          description: 'Create a multi-page interactive dashboard showing revenue, region, and product performance with drill-through to store level.',
          instructions: [
            'Page 1: Executive KPI overview with regional breakdown.',
            'Page 2: Product category margin drill-down.',
            'Page 3: MoM growth variance waterfall.',
            'Record interactive demo walkthrough notes.'
          ],
          isCompleted: true,
          userSubmission: 'Built 3-page interactive dashboard with drill-through customer page and dynamic MoM variance waterfall.'
        }
      },
      {
        id: 'pbi-m8',
        moduleNumber: 8,
        title: 'Module 8 — Final Assessment & Verification',
        description: 'Review core concepts, sit for the interactive 5-question AI assessment, and verify your certification credentials.',
        durationMinutes: 30,
        videoDurationFormatted: '30:00',
        skillDeveloped: 'Assessment & Certification',
        difficulty: 'Intermediate',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-1',
        practiceTask: {
          id: 'pt-pbi-8',
          title: 'Review Cheat Sheet & Take Final Exam',
          description: 'Review the Power BI DAX cheat sheet and complete the 5 capstone exam questions.',
          instructions: [
            'Score at least 80% to earn the verifiable certificate.',
            'Review detailed feedback on correct and incorrect options.'
          ],
          isCompleted: true,
          userSubmission: 'Scored 86% on final assessment; earned verifiable Certificate ID: NXF-PBI-2026-00124.'
        }
      }
    ]
  },
  {
    id: 'course-fin',
    title: 'Financial Modelling & Valuation Certified Analyst',
    skill: 'Financial Modeling',
    targetCareer: 'Finance Analyst & Corporate Finance Associate',
    provider: 'NEXIF5 Academy',
    partner: 'Corporate Finance Institute (CFI) Syllabus Alignment',
    level: 'Intermediate',
    durationHours: 16,
    durationLabel: '16 Hours • 6 Modules',
    progressPercent: 35,
    enrolled: true,
    modulesCount: 6,
    practiceActivitiesCount: 5,
    whyAiRecommended: 'Core requirement for Finance Analyst and Business Analyst roles. Priority skill gap identified in your career diagnostics.',
    careerReadinessImpact: '+6% to Career Readiness',
    badgeColor: 'blue',
    isCertificateEligible: false,
    isCertificateEarned: false,
    certificate: {
      certificateId: 'NXF-FIN-2026-00341',
      courseId: 'course-fin',
      courseTitle: 'Financial Modelling & Valuation Certified Analyst',
      skill: 'Financial Modeling',
      learnerName: 'Aarav Sharma',
      learnerId: 'std-1',
      issuerName: 'NEXIF5 Career Execution Platform',
      partnerName: 'Corporate Finance Institute (CFI) Syllabus Alignment',
      certificateType: 'completion',
      disclaimer: 'NEXIF5 Skill Mastery Completion Certificate. Confirms completion of 3-statement modeling, working capital forecasting, DCF valuation, and practical assessment.',
      issueDate: 'October 8, 2026',
      assessmentScore: 90,
      grade: 'Distinction (90%)',
      verificationStatus: 'verified',
      verificationUrl: 'https://nexif5.careers/verify/NXF-FIN-2026-00341',
      skillsDemonstrated: [
        '3-Statement Integrated Financial Model Architecture',
        'Discounted Cash Flow (DCF) & Terminal Value Forecasting',
        'Working Capital & Revolving Debt Schedules',
        'Scenario & Sensitivity Stress-Testing'
      ],
      signatoryName: 'Prof. Alok Mukherjee',
      signatoryTitle: 'Director of Financial Analytics, NEXIF5'
    },
    assessment: {
      id: 'assess-fin',
      title: 'Financial Modelling & Valuation Capstone Exam',
      description: '5-question rigorous test covering 3-statement model linkages, cash flow mechanics, WACC, and sensitivity analysis.',
      passingScorePercent: 80,
      totalQuestions: 5,
      estimatedMinutes: 25,
      userScorePercent: 0,
      userPassed: false,
      questions: [
        {
          id: 'q-fin-1',
          type: 'mcq',
          question: 'How does a ₹10,000 increase in Depreciation affect the 3 financial statements assuming a 25% corporate tax rate?',
          options: [
            'Net Income drops by ₹7,500; Cash flow from operations increases by ₹2,500 (tax shield); Balance sheet balances with lower PP&E and higher Cash.',
            'Net Income drops by ₹10,000; Cash stays identical everywhere.',
            'Cash increases by ₹10,000 because depreciation is added to revenue.',
            'Balance sheet becomes permanently unbalanced.'
          ],
          correctAnswerIndex: 0,
          explanation: 'Depreciation reduces taxable income by ₹10,000, saving ₹2,500 in cash taxes. While Net Income falls by ₹7,500, non-cash depreciation is added back in Cash Flow from Operations, leaving net cash +₹2,500.',
          skillFocus: '3-Statement Linkages'
        },
        {
          id: 'q-fin-2',
          type: 'scenario',
          question: 'Scenario: In a DCF model, which formula correctly calculates Free Cash Flow to Firm (FCFF)?',
          options: [
            'EBIT * (1 - Tax Rate) + D&A - CapEx - Change in Net Working Capital',
            'Net Income + Dividends - Taxes Paid',
            'Operating Cash Flow + Cash from Financing',
            'Gross Profit - Selling Expenses'
          ],
          correctAnswerIndex: 0,
          explanation: 'FCFF represents cash available to all capital providers: NOPAT (EBIT*(1-t)) plus non-cash D&A, deducting necessary CapEx reinvestment and working capital expansion.',
          skillFocus: 'DCF Mechanics'
        },
        {
          id: 'q-fin-3',
          type: 'mcq',
          question: 'In financial modeling, why is circular reference commonly encountered in debt schedules, and how is it safely managed?',
          options: [
            'Interest expense depends on average debt balance, which depends on ending cash, which depends on Net Income (which includes interest). Managed using an Excel iteration switch or beginning-debt approximation.',
            'Circular references mean Excel has a corrupt file and must be closed.',
            'Because debt must equal total equity by Indian accounting standards.',
            'It is caused by typing lowercase letters instead of uppercase.'
          ],
          correctAnswerIndex: 0,
          explanation: 'The interest-debt loop is an inherent circularity in corporate finance modeling. Top practitioners use a dedicated toggle switch or compute interest on the beginning debt balance to prevent file crashes.',
          skillFocus: 'Debt Schedule Architecture'
        },
        {
          id: 'q-fin-4',
          type: 'scenario',
          question: 'When performing sensitivity analysis on a DCF model, which two variables are most commonly paired in an Excel Data Table?',
          options: [
            'WACC (Discount Rate) and Terminal Growth Rate (g)',
            'Company Office Rent and Stationery Expenses',
            'HR headcount and Laptop costs',
            'Website clicks and Instagram followers'
          ],
          correctAnswerIndex: 0,
          explanation: 'WACC and Perpetual Terminal Growth Rate drive 65-80% of enterprise valuation in a DCF model, making them the most critical sensitivity variables for investment committees.',
          skillFocus: 'Sensitivity Analysis'
        },
        {
          id: 'q-fin-5',
          type: 'practical',
          question: 'Practical Logic: A company reports increasing Net Income for 3 consecutive years, but its Cash Flow from Operations turns negative. What is the most alarming operational cause?',
          options: [
            'Aggressive revenue recognition with ballooning uncollected Accounts Receivable and unsold inventory buildup.',
            'The company paid off all its bank loans ahead of time.',
            'The CEO took a 50% voluntary salary cut.',
            'The company switched from Microsoft Windows to Apple Mac.'
          ],
          correctAnswerIndex: 0,
          explanation: 'A widening divergence between accrual Net Income and Cash Flow from Operations is a classic indicator of aggressive revenue booking without real cash collection (working capital deterioration).',
          skillFocus: 'Quality of Earnings Analysis'
        }
      ]
    },
    videoLessons: [
      {
        id: 'fin-m1',
        moduleNumber: 1,
        title: 'Module 1 — 3-Statement Linkages & Architecture',
        description: 'Build the foundational blueprint connecting the Income Statement, Balance Sheet, and Statement of Cash Flows with dynamic formula linkages.',
        durationMinutes: 25,
        videoDurationFormatted: '25:10',
        skillDeveloped: 'Financial Statement Analysis',
        difficulty: 'Beginner',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-2',
        practiceTask: {
          id: 'pt-fin-1',
          title: 'Link Net Income to Cash Flow Statement',
          description: 'Establish the primary linkage connecting net income to cash flow from operations and retained earnings.',
          instructions: [
            'Route Net Income to the top of the Cash Flow Statement.',
            'Add back non-cash Depreciation & Amortization.',
            'Link ending Cash balance to Balance Sheet asset line.'
          ],
          isCompleted: true,
          userSubmission: 'Successfully routed Net Income to Cash Flow and closed balance sheet equation.'
        }
      },
      {
        id: 'fin-m2',
        moduleNumber: 2,
        title: 'Module 2 — Working Capital, CapEx & Depreciation Schedules',
        description: 'Forecast Accounts Receivable (DSO), Inventory (DIO), Accounts Payable (DPO), and build clean PP&E waterfalls.',
        durationMinutes: 30,
        videoDurationFormatted: '30:45',
        skillDeveloped: 'Working Capital Modeling',
        difficulty: 'Intermediate',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-2',
        practiceTask: {
          id: 'pt-fin-2',
          title: 'Build 5-Year Working Capital Schedule',
          description: 'Forecast working capital days and determine cash impact on operations.',
          instructions: [
            'Calculate Days Sales Outstanding (DSO = 45 days).',
            'Compute delta change in Net Working Capital.',
            'Ensure assets subtract and liabilities add to cash.'
          ],
          isCompleted: true,
          userSubmission: 'Completed working capital schedule with automated DSO/DIO metric toggles.'
        }
      },
      {
        id: 'fin-m3',
        moduleNumber: 3,
        title: 'Module 3 — Debt Schedules, Revolvers & Circular Interest',
        description: 'Construct senior debt tranches, mandatory amortizations, sweep revolvers, and safe circular interest handlers.',
        durationMinutes: 28,
        videoDurationFormatted: '28:15',
        skillDeveloped: 'Debt Modeling',
        difficulty: 'Intermediate',
        isCompleted: false,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-2',
        practiceTask: {
          id: 'pt-fin-3',
          title: 'Construct Revolving Credit Facility',
          description: 'Build automated cash sweep that draws debt if minimum cash drops below ₹50 Lakhs.',
          instructions: [
            'Setup Minimum Cash Balance test.',
            'Write MIN/MAX revolver borrowing formula.',
            'Link interest expense to P&L.'
          ],
          isCompleted: false
        }
      },
      {
        id: 'fin-m4',
        moduleNumber: 4,
        title: 'Module 4 — Discounted Cash Flow (DCF) & WACC',
        description: 'Calculate Cost of Equity using CAPM, Cost of Debt post-tax, Weighted Average Cost of Capital, and project 5-year FCFF with Terminal Value.',
        durationMinutes: 35,
        videoDurationFormatted: '35:20',
        skillDeveloped: 'Valuation & DCF',
        difficulty: 'Advanced',
        isCompleted: false,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-2',
        practiceTask: {
          id: 'pt-fin-4',
          title: 'Calculate Enterprise Value via DCF',
          description: 'Discount 5-year projected free cash flows using 11.5% WACC and 3.0% perpetual growth rate.',
          instructions: [
            'Compute Present Value of Unlevered Free Cash Flows.',
            'Calculate Gordon Growth Terminal Value.',
            'Deduct Net Debt to determine Implied Equity Value.'
          ],
          isCompleted: false
        }
      },
      {
        id: 'fin-m5',
        moduleNumber: 5,
        title: 'Module 5 — Scenario & Sensitivity Stress-Testing',
        description: 'Build executive scenario toggles (Bull, Base, Bear) and dynamic 2-variable Data Tables for investment review presentations.',
        durationMinutes: 30,
        videoDurationFormatted: '30:00',
        skillDeveloped: 'Sensitivity Analysis',
        difficulty: 'Advanced',
        isCompleted: false,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-2',
        practiceTask: {
          id: 'pt-fin-5',
          title: 'Generate Two-Way Sensitivity Data Table',
          description: 'Create a 5x5 sensitivity matrix varying WACC and Terminal Growth Rate.',
          instructions: [
            'Setup Excel Data Table row and column inputs.',
            'Apply conditional heat-map formatting.',
            'Verify table recalculation.'
          ],
          isCompleted: false
        }
      },
      {
        id: 'fin-m6',
        moduleNumber: 6,
        title: 'Module 6 — Capstone Case & Comprehensive Assessment',
        description: 'Review the completed valuation model, interpret implied share prices, and complete the final certification exam.',
        durationMinutes: 45,
        videoDurationFormatted: '45:00',
        skillDeveloped: 'Financial Synthesis',
        difficulty: 'Advanced',
        isCompleted: false,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-2',
        practiceTask: {
          id: 'pt-fin-6',
          title: 'Review Valuation Notes & Take Assessment',
          description: 'Sit for the 5-question comprehensive capstone exam to unlock your verifiable certificate.',
          instructions: [
            'Review CFI alignment notes.',
            'Score >= 80% to earn certification.'
          ],
          isCompleted: false
        }
      }
    ]
  },
  {
    id: 'course-exc',
    title: 'Advanced Excel for Business & Financial Analytics',
    skill: 'Advanced Excel',
    targetCareer: 'Business Analyst, Finance Analyst & Operations',
    provider: 'NEXIF5 Academy',
    partner: 'Microsoft Office Specialist (MOS) Partner Alignment',
    level: 'Advanced',
    durationHours: 10,
    durationLabel: '10 Hours • 6 Modules',
    progressPercent: 100,
    enrolled: true,
    modulesCount: 6,
    practiceActivitiesCount: 5,
    whyAiRecommended: 'Core technical baseline. Validated strength in your current profile (Advanced level).',
    careerReadinessImpact: '+5% to Career Readiness (Verified)',
    badgeColor: 'emerald',
    isCertificateEligible: true,
    isCertificateEarned: true,
    certificate: {
      certificateId: 'NXF-EXC-2026-00892',
      courseId: 'course-exc',
      courseTitle: 'Advanced Excel for Business & Financial Analytics',
      skill: 'Advanced Excel',
      learnerName: 'Aarav Sharma',
      learnerId: 'std-1',
      issuerName: 'NEXIF5 Career Execution Platform',
      partnerName: 'Microsoft Office Specialist (MOS) Partner Alignment',
      certificateType: 'completion',
      disclaimer: 'NEXIF5 Skill Mastery Completion Certificate. Validates mastery of modern dynamic arrays, nested lookups, financial functions, and executive spreadsheet models.',
      issueDate: 'September 18, 2026',
      assessmentScore: 94,
      grade: 'Distinction (94%)',
      verificationStatus: 'verified',
      verificationUrl: 'https://nexif5.careers/verify/NXF-EXC-2026-00892',
      skillsDemonstrated: [
        'Dynamic Arrays (FILTER, SORT, UNIQUE, XLOOKUP)',
        'Complex Aggregations (SUMIFS, COUNTIFS, LET, LAMBDA)',
        'Financial Functions (NPV, IRR, XIRR, PMT)',
        'Power Pivot Data Modeling & Executive Reporting'
      ],
      signatoryName: 'Sanjay Krishnan',
      signatoryTitle: 'Lead Analytics Instructor, NEXIF5'
    },
    assessment: {
      id: 'assess-exc',
      title: 'Advanced Excel Analytics Capstone Exam',
      description: 'Comprehensive test of modern array formulas, business lookup strategies, and data model best practices.',
      passingScorePercent: 80,
      totalQuestions: 5,
      estimatedMinutes: 20,
      userScorePercent: 94,
      userPassed: true,
      completedAt: 'Sep 18, 2026',
      strengths: ['Dynamic arrays', 'Financial engineering functions', 'Formula auditing'],
      weakAreas: ['VBA macro scripting (legacy)'],
      skillLevelAwarded: 'Expert / Master',
      recommendedNextAction: 'Apply advanced formulas inside your Power BI and Financial Modeling tasks.',
      questions: [
        {
          id: 'q-exc-1',
          type: 'mcq',
          question: 'What is the primary architectural advantage of XLOOKUP over traditional VLOOKUP?',
          options: [
            'It looks both left and right, defaults to exact match, handles missing values natively, and does not break when columns are inserted.',
            'It converts Excel files into animated 3D videos.',
            'It sends an automatic WhatsApp message to your manager.',
            'It only works if you pay a monthly Microsoft fee.'
          ],
          correctAnswerIndex: 0,
          explanation: 'XLOOKUP separates lookup array from return array, eliminating fragile column index numbers and left-to-right limitations.',
          skillFocus: 'Dynamic Lookups'
        },
        {
          id: 'q-exc-2',
          type: 'scenario',
          question: 'Scenario: Which modern dynamic array formula filters sales orders for "Region = South" and sorts them by revenue in descending order?',
          options: [
            '=SORT(FILTER(Orders, Orders[Region]="South"), 3, -1)',
            '=VLOOKUP("South", Orders, 3, FALSE)',
            '=IF(Orders[Region]="South", Orders, 0)',
            '=INDEX(MATCH("South", Orders))'
          ],
          correctAnswerIndex: 0,
          explanation: 'The combination of FILTER with SORT spills matching records dynamically and sorts column 3 descending (-1).',
          skillFocus: 'Dynamic Arrays'
        },
        {
          id: 'q-exc-3',
          type: 'mcq',
          question: 'What does the LET function do in modern Excel formulas?',
          options: [
            'Assigns names to intermediate calculation results, improving readability and eliminating redundant formula recalculations.',
            'Deletes duplicate rows from the workbook.',
            'Converts numbers into French currency.',
            'Locks the entire worksheet with a master password.'
          ],
          correctAnswerIndex: 0,
          explanation: 'LET assigns variable names to intermediate expressions, speeding up calculation by calculating repetitive formulas only once.',
          skillFocus: 'Formula Optimization'
        },
        {
          id: 'q-exc-4',
          type: 'scenario',
          question: 'When analyzing irregular periodic investment cash flows, which formula should be preferred over standard IRR?',
          options: [
            'XIRR (which accounts for exact cash flow dates)',
            'SUMPRODUCT',
            'AVERAGEA',
            'STDEV.P'
          ],
          correctAnswerIndex: 0,
          explanation: 'Standard IRR assumes uniform yearly or monthly intervals; XIRR accepts exact dates for each cash inflow/outflow.',
          skillFocus: 'Financial Functions'
        },
        {
          id: 'q-exc-5',
          type: 'practical',
          question: 'Practical Logic: You are asked to build a commission tiered calculation: 5% for sales < ₹10L, 8% for ₹10L-₹25L, and 12% for > ₹25L. What is the cleanest formula approach?',
          options: [
            'Use XLOOKUP with match_mode 1 (exact or next larger item) or IFS() function.',
            'Create 50 nested IF statements without spaces.',
            'Manually calculate each person using a handheld calculator.',
            'Format the text in Comic Sans font.'
          ],
          correctAnswerIndex: 0,
          explanation: 'XLOOKUP with approximate match or IFS() provides clean, self-documenting tiered logic without deeply nested fragile IF structures.',
          skillFocus: 'Business Logic Modeling'
        }
      ]
    },
    videoLessons: [
      {
        id: 'exc-m1',
        moduleNumber: 1,
        title: 'Module 1 — Modern Dynamic Arrays (FILTER, SORT, UNIQUE)',
        description: 'Ditch legacy CSE formulas. Master dynamic spill ranges, array filtering, and multi-criteria uniqueness.',
        durationMinutes: 20,
        videoDurationFormatted: '20:00',
        skillDeveloped: 'Dynamic Array Formulas',
        difficulty: 'Intermediate',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        practiceTask: {
          id: 'pt-exc-1',
          title: 'Create Dynamic Filtered Customer List',
          description: 'Write dynamic formula filtering customers with active accounts.',
          instructions: ['Use FILTER and UNIQUE.', 'Sort by annual spend.'],
          isCompleted: true,
          userSubmission: 'Spill range implemented with SORT(UNIQUE(FILTER())) syntax.'
        }
      },
      {
        id: 'exc-m2',
        moduleNumber: 2,
        title: 'Module 2 — Advanced Logic & Aggregations (LET & LAMBDA)',
        description: 'Supercharge spreadsheet speed and maintainability by structuring variables with LET and custom functions with LAMBDA.',
        durationMinutes: 25,
        videoDurationFormatted: '25:30',
        skillDeveloped: 'Advanced Formula Engineering',
        difficulty: 'Advanced',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        practiceTask: {
          id: 'pt-exc-2',
          title: 'Refactor Nested Formulas with LET',
          description: 'Reduce a 4-line nested formula into a clean, readable LET expression.',
          instructions: ['Define variables for subtotal, discount, and tax.', 'Verify execution time.'],
          isCompleted: true,
          userSubmission: 'Refactored formula using LET; calculation overhead reduced.'
        }
      },
      {
        id: 'exc-m3',
        moduleNumber: 3,
        title: 'Module 3 — Power Pivot, Data Models & Relationships',
        description: 'Ingest millions of rows directly into Excel. Create dimensional relationships and measure calculations without VLOOKUP.',
        durationMinutes: 30,
        videoDurationFormatted: '30:00',
        skillDeveloped: 'Excel Data Modeling',
        difficulty: 'Advanced',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        practiceTask: {
          id: 'pt-exc-3',
          title: 'Link 3 Tables in Excel Data Model',
          description: 'Create relationships in Power Pivot and build a multi-table pivot table.',
          instructions: ['Load tables into Data Model.', 'Relate Fact_Orders with Dim_Products.'],
          isCompleted: true,
          userSubmission: 'Data model linked in Power Pivot with single relation direction.'
        }
      },
      {
        id: 'exc-m4',
        moduleNumber: 4,
        title: 'Module 4 — Financial Functions (NPV, IRR, XIRR)',
        description: 'Professional financial mathematics for investment appraisal and project profitability analysis.',
        durationMinutes: 25,
        videoDurationFormatted: '25:10',
        skillDeveloped: 'Financial Mathematics',
        difficulty: 'Intermediate',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        practiceTask: {
          id: 'pt-exc-4',
          title: 'Compute Project XIRR & Payback Period',
          description: 'Analyze 5 years of irregular project cash flows.',
          instructions: ['Use XIRR with exact date column.', 'Compute discounted payback period.'],
          isCompleted: true,
          userSubmission: 'Project XIRR computed at 18.4% with 3.2 year payback period.'
        }
      },
      {
        id: 'exc-m5',
        moduleNumber: 5,
        title: 'Module 5 — Executive Dashboard Prototyping',
        description: 'Build polished, interactive dashboards with timeline slicers, dynamic chart labels, and formatted KPI scorecards.',
        durationMinutes: 30,
        videoDurationFormatted: '30:00',
        skillDeveloped: 'Executive Reporting',
        difficulty: 'Advanced',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        practiceTask: {
          id: 'pt-exc-5',
          title: 'Build Sales Commission Scorecard',
          description: 'Create interactive dashboard showing sales rep attainment against quarterly targets.',
          instructions: ['Use XLOOKUP, IF, and SUMIFS.', 'Format with professional color palette.'],
          isCompleted: true,
          userSubmission: 'Completed executive commission scorecard with dynamic tier lookups.'
        }
      },
      {
        id: 'exc-m6',
        moduleNumber: 6,
        title: 'Module 6 — Final Assessment & Verification',
        description: 'Comprehensive evaluation of advanced formulas and certified completion validation.',
        durationMinutes: 25,
        videoDurationFormatted: '25:00',
        skillDeveloped: 'Assessment Mastery',
        difficulty: 'Advanced',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        practiceTask: {
          id: 'pt-exc-6',
          title: 'Complete Certification Exam',
          description: 'Take the 5-question capstone assessment.',
          instructions: ['Scored 94% on exam.', 'Certificate issued.'],
          isCompleted: true,
          userSubmission: 'Passed with 94% Distinction. Certificate ID: NXF-EXC-2026-00892.'
        }
      }
    ]
  },
  {
    id: 'course-sql',
    title: 'SQL & Relational Analytics Certified Professional',
    skill: 'SQL',
    targetCareer: 'Data Analyst & Business Intelligence Engineer',
    provider: 'NEXIF5 Academy',
    partner: 'PostgreSQL & Enterprise Analytics Partner Alignment',
    level: 'Intermediate',
    durationHours: 12,
    durationLabel: '12 Hours • 6 Modules',
    progressPercent: 50,
    enrolled: true,
    modulesCount: 6,
    practiceActivitiesCount: 5,
    whyAiRecommended: 'Key technical requirement for Business Analyst and Data Analyst roles at FinEdge, ABC Tech, and Deloitte.',
    careerReadinessImpact: '+6% to Career Readiness',
    badgeColor: 'purple',
    isCertificateEligible: false,
    isCertificateEarned: false,
    certificate: {
      certificateId: 'NXF-SQL-2026-00512',
      courseId: 'course-sql',
      courseTitle: 'SQL & Relational Analytics Certified Professional',
      skill: 'SQL',
      learnerName: 'Aarav Sharma',
      learnerId: 'std-1',
      issuerName: 'NEXIF5 Career Execution Platform',
      partnerName: 'PostgreSQL & Enterprise Analytics Partner Alignment',
      certificateType: 'completion',
      disclaimer: 'NEXIF5 Skill Mastery Completion Certificate. Validates competency in relational schema queries, multi-table joins, window functions, and enterprise query optimization.',
      issueDate: 'October 8, 2026',
      assessmentScore: 88,
      grade: 'Distinction (88%)',
      verificationStatus: 'verified',
      verificationUrl: 'https://nexif5.careers/verify/NXF-SQL-2026-00512',
      skillsDemonstrated: [
        'Relational Database Normalization & Primary Key Integrity',
        'Complex Multi-Table Joins & Grouping Sets',
        'Window Functions (ROW_NUMBER, DENSE_RANK, LAG, LEAD)',
        'Common Table Expressions (CTEs) & Query Tuning'
      ],
      signatoryName: 'Vikram Seth',
      signatoryTitle: 'Lead Data Architect, NEXIF5'
    },
    assessment: {
      id: 'assess-sql',
      title: 'SQL & Relational Analytics Capstone Exam',
      description: '5-question test on complex JOIN logic, window functions, aggregation, and query performance.',
      passingScorePercent: 80,
      totalQuestions: 5,
      estimatedMinutes: 20,
      userScorePercent: 0,
      userPassed: false,
      questions: [
        {
          id: 'q-sql-1',
          type: 'mcq',
          question: 'What is the key difference between RANK() and DENSE_RANK() in SQL window functions?',
          options: [
            'RANK() leaves gaps in ranking numbers when there are ties (e.g. 1, 2, 2, 4), while DENSE_RANK() does not skip numbers (e.g. 1, 2, 2, 3).',
            'RANK() only works on text while DENSE_RANK() only works on dates.',
            'DENSE_RANK() deletes duplicate rows from the table.',
            'RANK() requires an Internet connection.'
          ],
          correctAnswerIndex: 0,
          explanation: 'DENSE_RANK() generates continuous ranking integers without gaps when peer values tie, which is essential for sales leaderboard calculations.',
          skillFocus: 'Window Functions'
        },
        {
          id: 'q-sql-2',
          type: 'scenario',
          question: 'Scenario: Which window function should you use to retrieve the previous month\'s revenue for the same customer to calculate month-over-month growth?',
          options: [
            'LAG(monthly_revenue, 1) OVER (PARTITION BY customer_id ORDER BY order_month)',
            'PREV(monthly_revenue)',
            'LAST_VALUE(customer_id)',
            'COUNT(monthly_revenue) OVER ()'
          ],
          correctAnswerIndex: 0,
          explanation: 'LAG() accesses data from a preceding row at a specified physical offset within the partitioned window.',
          skillFocus: 'Time-Series Windowing'
        },
        {
          id: 'q-sql-3',
          type: 'mcq',
          question: 'When should you choose a Common Table Expression (CTE) using the WITH clause instead of deeply nested subqueries?',
          options: [
            'CTEs improve code readability, enable recursive hierarchical queries, and allow self-referencing in downstream steps.',
            'CTEs make the database encrypt passwords.',
            'CTEs guarantee your code runs in half a millisecond always.',
            'CTEs are only used when formatting HTML.'
          ],
          correctAnswerIndex: 0,
          explanation: 'CTEs structure complex queries into sequential, readable modular blocks and can be referenced multiple times within the same statement.',
          skillFocus: 'Query Architecture'
        },
        {
          id: 'q-sql-4',
          type: 'scenario',
          question: 'Scenario: A query filtering on "WHERE order_status = \'DELIVERED\' AND order_date >= \'2025-01-01\'" takes 14 seconds on a 15-million row table. What database index would speed this up most?',
          options: [
            'A composite B-Tree index on (order_status, order_date)',
            'Deleting the table and restarting the computer',
            'Creating an index only on the customer name column',
            'Changing font size in pgAdmin'
          ],
          correctAnswerIndex: 0,
          explanation: 'A composite index matching the equality predicate (order_status) followed by the range predicate (order_date) allows index range scans without scanning table blocks.',
          skillFocus: 'Indexing & Performance'
        },
        {
          id: 'q-sql-5',
          type: 'practical',
          question: 'Practical Logic: Why must columns in the SELECT clause that are not part of an aggregate function (e.g. SUM, AVG) be included in the GROUP BY clause?',
          options: [
            'Because the relational engine needs to know how to bundle and collapse non-aggregated rows into discrete groups.',
            'It is just an arbitrary rule made up by SQL programmers.',
            'Because SQL does not know how to multiply numbers.',
            'It only applies when using Microsoft SQL Server.'
          ],
          correctAnswerIndex: 0,
          explanation: 'Standard SQL requires non-aggregated projections to define the grouping granularity so the engine knows how to aggregate dependent measures.',
          skillFocus: 'Relational Aggregations'
        }
      ]
    },
    videoLessons: [
      {
        id: 'sql-m1',
        moduleNumber: 1,
        title: 'Module 1 — Relational Schema Architecture & Constraints',
        description: 'Understanding primary keys, foreign keys, unique constraints, and schema normalization.',
        durationMinutes: 20,
        videoDurationFormatted: '20:10',
        skillDeveloped: 'Schema Design',
        difficulty: 'Beginner',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-3',
        practiceTask: {
          id: 'pt-sql-1',
          title: 'Design Relational Orders Schema',
          description: 'Write DDL statements establishing primary and foreign key constraints.',
          instructions: ['Define customer and order tables.', 'Add CASCADE constraints.'],
          isCompleted: true,
          userSubmission: 'Schema validated with proper foreign key cascades.'
        }
      },
      {
        id: 'sql-m2',
        moduleNumber: 2,
        title: 'Module 2 — Multi-Table JOINs & Filtering Rules',
        description: 'INNER, LEFT, RIGHT, FULL OUTER, and CROSS JOINs with nuanced NULL handling.',
        durationMinutes: 25,
        videoDurationFormatted: '25:00',
        skillDeveloped: 'Relational JOINs',
        difficulty: 'Intermediate',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-3',
        practiceTask: {
          id: 'pt-sql-2',
          title: 'Combine Customer, Orders & Products Data',
          description: 'Write 3-table join retrieving customer order totals.',
          instructions: ['Use LEFT JOIN for customers with zero orders.', 'Filter inactive accounts.'],
          isCompleted: true,
          userSubmission: '3-table query written and verified against PostgreSQL mock database.'
        }
      },
      {
        id: 'sql-m3',
        moduleNumber: 3,
        title: 'Module 3 — Window Functions (RANK, DENSE_RANK, LAG, LEAD)',
        description: 'Master analytical calculations over partitions: running totals, ranks, and lead/lag time offsets.',
        durationMinutes: 35,
        videoDurationFormatted: '35:15',
        skillDeveloped: 'Window Functions',
        difficulty: 'Advanced',
        isCompleted: true,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-3',
        practiceTask: {
          id: 'pt-sql-3',
          title: 'Calculate 30-Day MoM Customer Growth',
          description: 'Use LAG() and PARTITION BY to compute revenue change.',
          instructions: ['Partition by customer_id.', 'Order by order_month.', 'Compute percentage growth.'],
          isCompleted: true,
          userSubmission: 'Query written using LAG() window function; calculated MoM percentage drift.'
        }
      },
      {
        id: 'sql-m4',
        moduleNumber: 4,
        title: 'Module 4 — Common Table Expressions (CTEs) & Subqueries',
        description: 'Build modular, maintainable analytical queries using WITH clauses.',
        durationMinutes: 30,
        videoDurationFormatted: '30:00',
        skillDeveloped: 'Modular Queries',
        difficulty: 'Intermediate',
        isCompleted: false,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-3',
        practiceTask: {
          id: 'pt-sql-4',
          title: 'Structure Multi-Stage CTE Pipeline',
          description: 'Chain 3 CTEs to filter, aggregate, and rank customer cohorts.',
          instructions: ['Stage 1: filter orders.', 'Stage 2: aggregate cohort revenue.', 'Stage 3: rank cohorts.'],
          isCompleted: false
        }
      },
      {
        id: 'sql-m5',
        moduleNumber: 5,
        title: 'Module 5 — Query Optimization, Indexing & Execution Plans',
        description: 'Interpret EXPLAIN ANALYZE output, optimize slow JOINs, and design efficient B-Tree composite indexes.',
        durationMinutes: 25,
        videoDurationFormatted: '25:20',
        skillDeveloped: 'Database Optimization',
        difficulty: 'Advanced',
        isCompleted: false,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-3',
        practiceTask: {
          id: 'pt-sql-5',
          title: 'Analyze Execution Plan & Add Index',
          description: 'Diagnose sequential scan and add composite index to speed query up.',
          instructions: ['Run EXPLAIN ANALYZE.', 'Identify high-cost Seq Scan.', 'Add index and re-test.'],
          isCompleted: false
        }
      },
      {
        id: 'sql-m6',
        moduleNumber: 6,
        title: 'Module 6 — Enterprise Capstone Assessment',
        description: 'Complete the final 5-question capstone exam to unlock your verifiable certificate.',
        durationMinutes: 30,
        videoDurationFormatted: '30:00',
        skillDeveloped: 'Assessment & Certification',
        difficulty: 'Advanced',
        isCompleted: false,
        videoSourceLabel: 'HD Video • NEXIF5 Academy',
        relatedResourceId: 'res-3',
        practiceTask: {
          id: 'pt-sql-6',
          title: 'Review SQL Window Notes & Take Exam',
          description: 'Take the final assessment.',
          instructions: ['Score >= 80% to earn certification.'],
          isCompleted: false
        }
      }
    ]
  }
];

export const MOCK_PROFESSIONALS: WorkingProfessionalProfile[] = [
  {
    id: 'pro-1',
    name: 'Rahul Verma',
    email: 'rahul.verma@example.com',
    phone: '+91 98112 34980',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    location: 'Bengaluru, India',
    currentJobTitle: 'Associate Business Analyst',
    currentCompany: 'Finlytics Advisory Corp',
    totalExperienceYears: 2.5,
    industry: 'FinTech & Analytics Consulting',
    workMode: 'hybrid',
    skills: [
      { id: 'pro-s1', name: 'Excel (Advanced)', category: 'tools', level: 'expert', verified: true },
      { id: 'pro-s2', name: 'SQL', category: 'technical', level: 'advanced', verified: true },
      { id: 'pro-s3', name: 'Power BI', category: 'analytics', level: 'advanced', verified: true },
      { id: 'pro-s4', name: 'Financial Modeling', category: 'analytics', level: 'intermediate', verified: true },
      { id: 'pro-s5', name: 'Python for Finance', category: 'technical', level: 'beginner', verified: false }
    ],
    targetSkills: ['Financial Modeling', 'Strategic Forecasting', 'Python Automation', 'Tableau Server'],
    careerGoal: 'Senior Business Analyst',
    targetJobRole: 'Lead Product Analyst / Strategy Lead',
    preferredIndustry: 'FinTech, SaaS, Investment Banking',
    preferredLocation: 'Bengaluru / Remote',
    jobTypePreference: 'full_time',
    salaryCurrentLPA: 8.5,
    salaryTargetLPA: 14.5,
    pastRoles: [
      {
        id: 'pr-1',
        title: 'Associate Business Analyst',
        company: 'Finlytics Advisory Corp',
        duration: '2023 - Present (1.5 yrs)',
        keyAchievements: ['Automated cohort margin reporting for 6 Tier-1 accounts', 'Reduced ETL cycle latency by 45% using SQL window functions']
      },
      {
        id: 'pr-2',
        title: 'Junior Analytics Associate',
        company: 'Vanguard Retail Systems',
        duration: '2022 - 2023 (1 yr)',
        keyAchievements: ['Developed inventory replenishment forecasting in Power BI']
      }
    ],
    projects: [
      {
        id: 'pro-prj-1',
        title: 'Enterprise Customer LTV & Cohort Engine',
        description: 'Engineered an automated SQL + Power BI analytical data mart tracking 120k customer lifecycles.',
        technologies: ['SQL', 'Power BI', 'PostgreSQL'],
        startDate: 'Aug 2023',
        endDate: 'Dec 2023',
        role: 'Lead Business Analyst'
      }
    ],
    certifications: [
      'Certified Analytics Professional (CAP)',
      'NEXIF5 Microsoft Power BI Business Intelligence Certified',
      'Advanced Excel for Financial Modeling'
    ],
    resumeName: 'Rahul_Verma_Senior_Analyst_2026.pdf',
    careerGrowthScore: 88,
    profileViewsCount: 42,
    recruiterInquiriesCount: 6
  },
  {
    id: 'pro-2',
    name: 'Sneha Kapoor',
    email: 'sneha.kapoor@example.com',
    phone: '+91 99201 44520',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
    location: 'Mumbai, India',
    currentJobTitle: 'Full Stack Engineer',
    currentCompany: 'CloudScale Technologies',
    totalExperienceYears: 3.5,
    industry: 'Cloud SaaS & Developer Tools',
    workMode: 'remote',
    skills: [
      { id: 'pro-s6', name: 'React', category: 'technical', level: 'expert', verified: true },
      { id: 'pro-s7', name: 'Node.js', category: 'technical', level: 'advanced', verified: true },
      { id: 'pro-s8', name: 'TypeScript', category: 'technical', level: 'expert', verified: true },
      { id: 'pro-s9', name: 'PostgreSQL', category: 'technical', level: 'intermediate', verified: true }
    ],
    targetSkills: ['System Design', 'Kubernetes', 'Microservices', 'GraphQL'],
    careerGoal: 'Senior Engineering Lead',
    targetJobRole: 'Lead Software Architect',
    preferredIndustry: 'Cloud SaaS, AI Infrastructure',
    preferredLocation: 'Mumbai / Remote',
    jobTypePreference: 'full_time',
    salaryCurrentLPA: 16.0,
    salaryTargetLPA: 26.0,
    pastRoles: [
      {
        id: 'pr-3',
        title: 'Full Stack Engineer',
        company: 'CloudScale Technologies',
        duration: '2022 - Present (2.5 yrs)',
        keyAchievements: ['Migrated monolithic frontend to modular micro-frontends with 99.98% uptime']
      }
    ],
    projects: [],
    certifications: ['AWS Certified Developer Associate', 'CKAD: Kubernetes Certified'],
    resumeName: 'Sneha_Kapoor_Senior_Engineer_2026.pdf',
    careerGrowthScore: 92,
    profileViewsCount: 78,
    recruiterInquiriesCount: 11
  }
];

export const MOCK_MENTORS: MentorProfile[] = [
  {
    id: 'men-1',
    name: 'Dr. Ananya Sen',
    email: 'ananya.sen@example.com',
    phone: '+91 98200 55123',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80',
    location: 'Bengaluru / San Francisco',
    jobTitle: 'Principal Solutions Architect',
    company: 'Google Cloud Partner Network',
    experienceYears: 12,
    domains: ['Cloud Architecture', 'Distributed Systems', 'Career Transitions', 'Tech Leadership'],
    bio: '12+ years building global hyper-scale cloud platforms. Passionate about helping students and engineers navigate technical interviews and leadership tracks.',
    availabilityHoursPerWeek: 6,
    mentorshipTypes: ['1:1 Mentoring', 'Mock Interview', 'Resume Review', 'Career Guidance'],
    linkedInUrl: 'https://linkedin.com/in/ananya-sen-cloud',
    portfolioUrl: 'https://ananyasen.dev',
    totalMenteesCount: 38,
    averageRating: 4.95,
    sessionsCompletedCount: 52,
    sessions: [
      {
        id: 'ms-1',
        mentorId: 'men-1',
        menteeId: 'std-1',
        menteeName: 'Aarav Sharma',
        menteeAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
        menteeGoal: 'Cracking Business Analyst & Analytics Interviews',
        date: 'Tomorrow, 5:30 PM',
        time: '45 mins',
        type: 'Mock Interview',
        status: 'upcoming',
        notes: 'Review Power BI portfolio project and practice behavioral STAR questions.'
      },
      {
        id: 'ms-2',
        mentorId: 'men-1',
        menteeId: 'pro-1',
        menteeName: 'Rahul Verma',
        menteeAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
        menteeGoal: 'Transitioning to Senior Business Analyst',
        date: 'Oct 12, 7:00 PM',
        time: '60 mins',
        type: 'Career Guidance',
        status: 'upcoming',
        notes: 'Discussion on negotiation strategy and executive storytelling.'
      },
      {
        id: 'ms-3',
        mentorId: 'men-1',
        menteeId: 'std-5',
        menteeName: 'Vikram Sundaram',
        menteeGoal: 'Product Management teardown critique',
        date: 'Last Week',
        time: '45 mins',
        type: 'Resume Review',
        status: 'completed',
        rating: 5,
        feedback: 'Superb structuring. Emphasize metrics impact in bullet point #2.',
        scorecard: {
          technicalDepth: 9,
          communication: 9,
          problemSolving: 10,
          domainKnowledge: 8,
          recommendation: 'Highly Recommended for APM Cohorts'
        }
      }
    ]
  },
  {
    id: 'men-2',
    name: 'Karthik Subramaniam',
    email: 'karthik.s@example.com',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&auto=format&fit=crop&q=80',
    location: 'Chennai / Hyderabad',
    jobTitle: 'Director of Talent & Analytics',
    company: 'Cognizant Corporate Strategy',
    experienceYears: 10,
    domains: ['Data Analytics', 'Management Consulting', 'Case Interviews', 'Resume Strategy'],
    bio: 'Guided over 70+ graduates and early professionals into top analytics consultancies.',
    availabilityHoursPerWeek: 4,
    mentorshipTypes: ['1:1 Mentoring', 'Mock Interview', 'Resume Review'],
    totalMenteesCount: 24,
    averageRating: 4.88,
    sessionsCompletedCount: 34,
    sessions: []
  }
];

export const MOCK_ADMIN_USERS: AdminUserRecord[] = [
  {
    id: 'adm-u1',
    name: 'Aarav Sharma',
    email: 'aarav.sharma@example.com',
    role: 'student',
    status: 'active',
    joinedDate: '2025-01-10',
    organizationOrCollege: 'Rathinam Global University',
    lastActive: '5 mins ago'
  },
  {
    id: 'adm-u2',
    name: 'Rahul Verma',
    email: 'rahul.verma@example.com',
    role: 'professional',
    status: 'active',
    joinedDate: '2025-02-01',
    organizationOrCollege: 'Finlytics Advisory Corp',
    lastActive: '12 mins ago'
  },
  {
    id: 'adm-u3',
    name: 'Rajesh Menon',
    email: 'rajesh.m@abctechnologies.io',
    role: 'recruiter',
    status: 'active',
    joinedDate: '2024-11-15',
    organizationOrCollege: 'ABC Technologies',
    lastActive: '1 hour ago'
  },
  {
    id: 'adm-u4',
    name: 'Dr. K. Ramanathan',
    email: 'ramanathan.placement@rathinam.ac.in',
    role: 'college',
    status: 'active',
    joinedDate: '2024-09-01',
    organizationOrCollege: 'Rathinam Global University',
    lastActive: '3 hours ago'
  },
  {
    id: 'adm-u5',
    name: 'Dr. Ananya Sen',
    email: 'ananya.sen@example.com',
    role: 'mentor',
    status: 'active',
    joinedDate: '2025-01-20',
    organizationOrCollege: 'Google Cloud Partner Network',
    lastActive: 'Yesterday'
  },
  {
    id: 'adm-u6',
    name: 'Admin Central',
    email: 'admin@nexif5.io',
    role: 'admin',
    status: 'active',
    joinedDate: '2024-01-01',
    organizationOrCollege: 'NEXIF5 Core Operations',
    lastActive: 'Just now'
  }
];

// ==========================================
// MOCK CONNECTION REQUESTS
// ==========================================

export const MOCK_CONNECTION_REQUESTS: ConnectionRequest[] = [
  {
    id: 'req-rec-1',
    senderId: 'men-1',
    senderName: 'Dr. Ananya Sen',
    senderRole: 'mentor',
    senderAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80',
    senderHeadline: 'Principal Solutions Architect • Google Cloud Network',
    receiverId: 'std-1',
    receiverRole: 'student',
    note: 'Hi Aarav, I reviewed your project on Distributed Task Queue and your 88% Career Readiness score. Would love to connect and share tips on systems design!',
    createdAt: '2 hours ago',
    status: 'pending',
    sharedSkillsCount: 4
  },
  {
    id: 'req-rec-2',
    senderId: 'rec-1',
    senderName: 'Sarah Jenkins',
    senderRole: 'recruiter',
    senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
    senderHeadline: 'Technical Talent Lead @ TechCorp India',
    receiverId: 'std-1',
    receiverRole: 'student',
    note: 'Hello Aarav! Your verified Power BI & React credentials caught our team’s eye for our Junior Cloud Engineer opening. Let’s connect!',
    createdAt: 'Yesterday',
    status: 'pending',
    sharedSkillsCount: 3
  },
  {
    id: 'req-rec-3',
    senderId: 'pro-2',
    senderName: 'Sneha Kapoor',
    senderRole: 'professional',
    senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
    senderHeadline: 'Full Stack Engineer @ CloudScale Technologies',
    receiverId: 'std-1',
    receiverRole: 'student',
    note: 'Hi Aarav, saw your work on TypeScript & SQL. Happy to connect and discuss career transitions into full-stack engineering!',
    createdAt: '3 days ago',
    status: 'pending',
    sharedSkillsCount: 3
  },
  {
    id: 'req-sent-1',
    senderId: 'std-1',
    senderName: 'Aarav Sharma',
    senderRole: 'student',
    senderAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    senderHeadline: 'Aspiring Cloud & Full Stack Engineer • Final Year CSE',
    receiverId: 'men-2',
    receiverRole: 'mentor',
    note: 'Dear Rajiv, I would love to connect to seek your feedback on high-throughput backend architecture.',
    createdAt: '1 day ago',
    status: 'pending',
    sharedSkillsCount: 2
  }
];

// ==========================================
// MOCK USER CONNECTIONS (ALREADY CONNECTED)
// ==========================================

export const MOCK_USER_CONNECTIONS: UserConnection[] = [
  {
    id: 'conn-1',
    peerId: 'std-2',
    peerName: 'Sneha Patel',
    peerRole: 'student',
    peerAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    peerHeadline: 'AI & Data Science Student • Python & Machine Learning',
    peerCompanyOrSchool: 'IIT Bombay (2025)',
    location: 'Mumbai, India',
    connectedAt: '2 weeks ago',
    isFollowing: true,
    sharedSkills: ['Python', 'SQL', 'FastAPI'],
    mutualConnectionsCount: 14
  },
  {
    id: 'conn-2',
    peerId: 'pro-1',
    peerName: 'Rahul Verma',
    peerRole: 'professional',
    peerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    peerHeadline: 'Senior Financial & Business Analyst @ FinTech Apex',
    peerCompanyOrSchool: 'FinTech Apex Global',
    location: 'Bengaluru, India',
    connectedAt: '1 month ago',
    isFollowing: true,
    sharedSkills: ['Power BI', 'SQL', 'Data Analytics'],
    mutualConnectionsCount: 8
  },
  {
    id: 'conn-3',
    peerId: 'col-1',
    peerName: 'Dr. Rajesh Sharma',
    peerRole: 'college',
    peerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    peerHeadline: 'Placement & Industry Relations Director • Rathinam Group',
    peerCompanyOrSchool: 'Rathinam College of Arts and Science',
    location: 'Coimbatore, India',
    connectedAt: '3 weeks ago',
    isFollowing: true,
    sharedSkills: ['Career Development', 'Placement Drives'],
    mutualConnectionsCount: 42
  },
  {
    id: 'conn-4',
    peerId: 'men-3',
    peerName: 'Kavita Reddy',
    peerRole: 'mentor',
    peerAvatar: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=200&auto=format&fit=crop&q=80',
    peerHeadline: 'Head of Product Design @ InnovateLabs • UX Career Mentor',
    peerCompanyOrSchool: 'InnovateLabs Design',
    location: 'Hyderabad, India',
    connectedAt: '1 month ago',
    isFollowing: false,
    sharedSkills: ['Figma', 'System Design', 'UI/UX'],
    mutualConnectionsCount: 6
  }
];

// ==========================================
// MOCK SMART RECOMMENDATIONS (WHY AI RECOMMENDS)
// ==========================================

export const MOCK_SMART_RECOMMENDATIONS: SmartConnectionRecommendation[] = [
  {
    userId: 'rec-1',
    name: 'Sarah Jenkins',
    role: 'recruiter',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
    headline: 'Technical Talent Acquisition Lead @ TechCorp India',
    organization: 'TechCorp India',
    location: 'Bengaluru / Hybrid',
    sharedSkills: ['React', 'TypeScript', 'Cloud Infrastructure'],
    whyAiRecommended: 'Actively recruiting for Junior Cloud Engineer roles matching your certified skills and 88% Career Readiness score.',
    connectionStatus: 'pending_received',
    isFollowing: true,
    isActivelyHiring: true
  },
  {
    userId: 'men-1',
    name: 'Dr. Ananya Sen',
    role: 'mentor',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80',
    headline: 'Principal Solutions Architect @ Google Cloud Network',
    organization: 'Google Cloud Partner Network',
    location: 'Bengaluru / SF',
    sharedSkills: ['System Design', 'Cloud Architecture', 'Distributed Systems'],
    whyAiRecommended: 'Expertise in Distributed Systems and high-scale backends aligns with your career goal of becoming a Cloud Software Engineer.',
    connectionStatus: 'pending_received',
    isFollowing: true,
    openToMentoring: true,
    experienceYears: 12
  },
  {
    userId: 'pro-2',
    name: 'Sneha Kapoor',
    role: 'professional',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
    headline: 'Full Stack Engineer @ CloudScale Technologies',
    organization: 'CloudScale Technologies',
    location: 'Mumbai, India',
    sharedSkills: ['React', 'Node.js', 'TypeScript', 'SQL'],
    whyAiRecommended: 'Shares 4 core skills and successfully completed the transition from university graduate to Senior Engineer within 3 years.',
    connectionStatus: 'pending_received',
    isFollowing: false,
    experienceYears: 3.5
  },
  {
    userId: 'std-3',
    name: 'Rohan Gupta',
    role: 'student',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
    headline: 'Backend Systems Enthusiast • Golang & Distributed Data',
    organization: 'IIT Delhi (2025)',
    location: 'New Delhi, India',
    sharedSkills: ['PostgreSQL', 'Docker', 'Go', 'API Design'],
    whyAiRecommended: 'Working on complementary open-source backend tools and ranked in top 5% in NEXIF5 Practice Challenges.',
    connectionStatus: 'none',
    isFollowing: false,
    targetRole: 'Backend Systems Engineer'
  },
  {
    userId: 'men-2',
    name: 'Rajiv Nambiar',
    role: 'mentor',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
    headline: 'Director of AI Engineering @ FinTech Apex Global',
    organization: 'FinTech Apex Global',
    location: 'Bengaluru, India',
    sharedSkills: ['Machine Learning', 'Data Pipelines', 'Python'],
    whyAiRecommended: 'Mentors engineers transitioning into production AI and leads hiring committees at top tech firms.',
    connectionStatus: 'pending_sent',
    isFollowing: true,
    openToMentoring: true,
    experienceYears: 14
  },
  {
    userId: 'col-2',
    name: 'Prof. Meenakshi Sundaram',
    role: 'college',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
    headline: 'Dean of Corporate Relations & Academic Partnerships',
    organization: 'BITS Pilani Hyderabad Campus',
    location: 'Hyderabad, India',
    sharedSkills: ['Industry Collaborations', 'Curriculum Design'],
    whyAiRecommended: 'Orchestrates multi-campus industry hiring drives with companies matching your target job role.',
    connectionStatus: 'none',
    isFollowing: false
  }
];

// ==========================================
// MOCK QUICK MESSAGE TEMPLATES
// ==========================================

export const MOCK_MESSAGE_TEMPLATES: QuickMessageTemplate[] = [
  {
    id: 'tmpl-1',
    title: 'Career Advice Request',
    category: 'career_advice',
    targetRoleText: 'Professionals & Mentors',
    content: 'Hi [Name], I admire your work at [Company/Org]. As someone working toward a [Role] career on NEXIF5, could I ask you for 1-2 quick pieces of advice on breaking into this domain?'
  },
  {
    id: 'tmpl-2',
    title: 'Internship & Junior Inquiry',
    category: 'internship',
    targetRoleText: 'Recruiters & Companies',
    content: 'Hello [Name], I am actively preparing for [Role] positions. My NEXIF5 verified readiness score is 88% with validated projects in [Skills]. I would love to share my portfolio if you have open roles.'
  },
  {
    id: 'tmpl-3',
    title: 'Mentorship Session Request',
    category: 'mentorship',
    targetRoleText: 'Industry Mentors',
    content: 'Dear [Name], I noticed your expertise in [Domain] and would value your guidance on technical preparation and resume positioning. Are you open to a brief mentorship discussion on NEXIF5?'
  },
  {
    id: 'tmpl-4',
    title: 'Job Opportunity Discussion',
    category: 'job_inquiry',
    targetRoleText: 'Recruiters & Hiring Managers',
    content: 'Hi [Name], thank you for connecting! I saw your recent hiring requisition for [Job Title]. My skill profile closely matches your requirements and I have attached my NEXIF5 verified credentials.'
  },
  {
    id: 'tmpl-5',
    title: 'Project Collaboration',
    category: 'project_collab',
    targetRoleText: 'Students & Developers',
    content: 'Hi [Name], I noticed we both focus on [Tech Stack]. I am currently building a hands-on project and would love to collaborate or exchange architectural feedback!'
  }
];

// ==========================================
// MOCK CHAT CONVERSATIONS
// ==========================================

export const MOCK_CHAT_CONVERSATIONS: ChatConversation[] = [
  {
    id: 'conv-1',
    peerId: 'men-1',
    peerName: 'Dr. Ananya Sen',
    peerAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80',
    peerRole: 'mentor',
    peerHeadline: 'Principal Solutions Architect @ Google Cloud Network',
    peerOrganization: 'Google Cloud Partner Network',
    lastMessage: 'Great progress on the Distributed Task Queue project! Take a look at the system design checklist I sent.',
    lastMessageTimestamp: '10:45 AM',
    unreadCount: 1,
    isOnline: true,
    isConnected: true
  },
  {
    id: 'conv-2',
    peerId: 'rec-1',
    peerName: 'Sarah Jenkins',
    peerAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
    peerRole: 'recruiter',
    peerHeadline: 'Technical Talent Acquisition Lead @ TechCorp India',
    peerOrganization: 'TechCorp India',
    lastMessage: 'We have shortlisted your profile for the Junior Cloud Engineer opening. Are you available for a 20-min technical screen this Thursday?',
    lastMessageTimestamp: 'Yesterday',
    unreadCount: 0,
    isOnline: false,
    isConnected: true
  },
  {
    id: 'conv-3',
    peerId: 'std-2',
    peerName: 'Sneha Patel',
    peerAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    peerRole: 'student',
    peerHeadline: 'AI & Data Science Student • Python & Machine Learning',
    peerOrganization: 'IIT Bombay',
    lastMessage: 'Thanks for sharing the SQL notes! Did you complete Module 3 assessment yet?',
    lastMessageTimestamp: '2 days ago',
    unreadCount: 0,
    isOnline: true,
    isConnected: true
  },
  {
    id: 'conv-4',
    peerId: 'pro-1',
    peerName: 'Rahul Verma',
    peerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    peerRole: 'professional',
    peerHeadline: 'Senior Financial & Business Analyst @ FinTech Apex',
    peerOrganization: 'FinTech Apex Global',
    lastMessage: 'Always keep your executive summaries to one page. Recruiters love that clarity.',
    lastMessageTimestamp: 'Oct 3',
    unreadCount: 0,
    isOnline: false,
    isConnected: true
  }
];

// ==========================================
// MOCK CHAT MESSAGES
// ==========================================

export const MOCK_CHAT_MESSAGES: Record<string, DirectChatMessage[]> = {
  'conv-1': [
    {
      id: 'm-1-1',
      conversationId: 'conv-1',
      senderId: 'std-1',
      senderName: 'Aarav Sharma',
      senderAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
      senderRole: 'student',
      receiverId: 'men-1',
      content: 'Hello Dr. Sen! Thank you for accepting my connection request. I am working towards Cloud Architecture and would appreciate any guidance on distributed queues.',
      timestamp: 'Yesterday, 4:20 PM',
      isRead: true,
      status: 'read'
    },
    {
      id: 'm-1-2',
      conversationId: 'conv-1',
      senderId: 'men-1',
      senderName: 'Dr. Ananya Sen',
      senderAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80',
      senderRole: 'mentor',
      receiverId: 'std-1',
      content: 'Hello Aarav! Very happy to connect. I took a look at your NEXIF5 profile and noticed your verified Power BI and SQL certifications. Excellent foundation!',
      timestamp: 'Yesterday, 5:15 PM',
      isRead: true,
      status: 'read'
    },
    {
      id: 'm-1-3',
      conversationId: 'conv-1',
      senderId: 'std-1',
      senderName: 'Aarav Sharma',
      senderAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
      senderRole: 'student',
      receiverId: 'men-1',
      content: 'Thank you! Here is my latest project documentation and resume verified on NEXIF5.',
      timestamp: 'Today, 9:30 AM',
      isRead: true,
      status: 'read',
      attachment: {
        type: 'resume',
        title: 'Aarav_Sharma_Cloud_Resume.pdf',
        subtitle: 'Verified ATS Score: 94/100 • CSE 2026',
        badge: 'Verified Resume'
      }
    },
    {
      id: 'm-1-4',
      conversationId: 'conv-1',
      senderId: 'men-1',
      senderName: 'Dr. Ananya Sen',
      senderAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80',
      senderRole: 'mentor',
      receiverId: 'std-1',
      content: 'Great progress on the Distributed Task Queue project! Take a look at the system design checklist I sent.',
      timestamp: '10:45 AM',
      isRead: false,
      status: 'delivered'
    }
  ],
  'conv-2': [
    {
      id: 'm-2-1',
      conversationId: 'conv-2',
      senderId: 'rec-1',
      senderName: 'Sarah Jenkins',
      senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
      senderRole: 'recruiter',
      receiverId: 'std-1',
      content: 'Hi Aarav, our team reviewed your application for the Junior Cloud Engineer opening. Your technical skill readiness score of 88% stood out to our hiring manager.',
      timestamp: 'Oct 6, 2:10 PM',
      isRead: true,
      status: 'read',
      attachment: {
        type: 'job',
        title: 'Junior Cloud Solutions Engineer',
        subtitle: 'TechCorp India • ₹8.5 - 12.0 LPA • Bengaluru',
        itemId: 'job-1',
        badge: 'Job Match 92%'
      }
    },
    {
      id: 'm-2-2',
      conversationId: 'conv-2',
      senderId: 'std-1',
      senderName: 'Aarav Sharma',
      senderAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
      senderRole: 'student',
      receiverId: 'rec-1',
      content: 'Thank you Sarah! I have attached my partner-verified certificate in Advanced Cloud Data Architecture as well.',
      timestamp: 'Oct 6, 3:30 PM',
      isRead: true,
      status: 'read',
      attachment: {
        type: 'certificate',
        title: 'Microsoft Certified: Power BI & Data Analyst Associate',
        subtitle: 'Partner Verified • Grade: Distinction (86%)',
        itemId: 'NXF-PBI-2026-00124',
        badge: 'Verified Certificate'
      }
    },
    {
      id: 'm-2-3',
      conversationId: 'conv-2',
      senderId: 'rec-1',
      senderName: 'Sarah Jenkins',
      senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
      senderRole: 'recruiter',
      receiverId: 'std-1',
      content: 'We have shortlisted your profile for the Junior Cloud Engineer opening. Are you available for a 20-min technical screen this Thursday?',
      timestamp: 'Yesterday, 11:15 AM',
      isRead: true,
      status: 'read'
    }
  ],
  'conv-3': [
    {
      id: 'm-3-1',
      senderId: 'std-2',
      senderName: 'Sneha Patel',
      senderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
      senderRole: 'student',
      receiverId: 'std-1',
      conversationId: 'conv-3',
      content: 'Thanks for sharing the SQL notes! Did you complete Module 3 assessment yet?',
      timestamp: '2 days ago',
      isRead: true,
      status: 'read'
    }
  ],
  'conv-4': [
    {
      id: 'm-4-1',
      senderId: 'pro-1',
      senderName: 'Rahul Verma',
      senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
      senderRole: 'professional',
      receiverId: 'std-1',
      conversationId: 'conv-4',
      content: 'Always keep your executive summaries to one page. Recruiters love that clarity.',
      timestamp: 'Oct 3',
      isRead: true,
      status: 'read'
    }
  ]
};


