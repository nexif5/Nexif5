import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { calculateJobMatch, analyzeCareerReadiness } from '../../services/aiEngine';
import { JobDetailModal } from '../common/JobDetailModal';
import { JobOpportunity } from '../../types';
import {
  Search,
  Bot,
  Briefcase,
  GraduationCap,
  Building2,
  FileText,
  Layers,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Target,
  Zap,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  School
} from 'lucide-react';

export const StudentHome: React.FC = () => {
  const {
    currentStudent,
    jobs,
    applications,
    setActiveStudentTab,
    joinCollege,
    colleges
  } = useApp();

  const [selectedJob, setSelectedJob] = useState<JobOpportunity | null>(null);
  const [quickSearch, setQuickSearch] = useState('');

  const careerAnalysis = analyzeCareerReadiness(currentStudent);

  // Top 3 matched jobs for current student
  const topMatchedJobs = jobs
    .filter(j => j.isOpen)
    .map(j => ({ job: j, match: calculateJobMatch(currentStudent, j) }))
    .sort((a, b) => b.match.overallScore - a.match.overallScore)
    .slice(0, 3);

  const activeApplicationsCount = applications.filter(
    a => a.candidateId === currentStudent.id && a.status !== 'rejected' && a.status !== 'selected'
  ).length;

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Welcome & Goal Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-lg">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold border border-indigo-400/30 flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5" />
                Target Goal: {currentStudent.careerGoal}
              </span>
              {currentStudent.collegeName ? (
                <span className="px-3 py-1 rounded-full bg-slate-800 text-slate-300 text-xs font-medium border border-slate-700 flex items-center gap-1">
                  <School className="w-3 h-3 text-purple-400" />
                  {currentStudent.collegeName}
                </span>
              ) : (
                <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-medium border border-amber-500/30">
                  ✦ Independent Student Path
                </span>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold font-display">
              Welcome back, {currentStudent.name.split(' ')[0]}!
            </h1>

            <p className="text-sm text-slate-300 leading-relaxed">
              Your Career Execution engine is active. You have a <strong>{careerAnalysis.careerReadinessScore}/100 Readiness Score</strong> for <strong>{currentStudent.careerGoal}</strong> roles with <strong>{topMatchedJobs.length} top company matches</strong> ready for direct application.
            </p>
          </div>

          {/* Quick Action Widget */}
          <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/15 w-full md:w-auto shrink-0 flex items-center gap-4">
            <div className="text-center px-2">
              <span className="text-3xl font-black text-indigo-300 font-display block">
                {careerAnalysis.careerReadinessScore}
              </span>
              <span className="text-[10px] text-slate-300 uppercase font-semibold">Readiness</span>
            </div>
            <div className="h-10 w-px bg-white/20" />
            <div>
              <span className="text-xs text-slate-300 block">Next Best Action</span>
              <span className="text-xs font-bold text-white block max-w-[200px] truncate">
                Build 1 SQL Project
              </span>
              <button
                onClick={() => setActiveStudentTab('ai')}
                className="mt-1 text-[11px] text-indigo-300 hover:text-white font-semibold flex items-center gap-1"
              >
                <span>Ask AI Coach</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Section 4: 6 Core Quick Launch Cards */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-slate-900 font-display">
            Quick Career Launchpad
          </h2>
          <span className="text-xs text-slate-500">
            Immediate access without opening complex menus
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {/* 1. Search Jobs */}
          <button
            onClick={() => setActiveStudentTab('jobs')}
            className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-indigo-400 hover:shadow-md transition-all text-left group flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                Search Jobs
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">{jobs.filter(j => j.type === 'job').length} openings</p>
            </div>
          </button>

          {/* 2. Search Internships */}
          <button
            onClick={() => setActiveStudentTab('internships')}
            className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-indigo-400 hover:shadow-md transition-all text-left group flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                Internships
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">{jobs.filter(j => j.type === 'internship').length} PPO tracks</p>
            </div>
          </button>

          {/* 3. Search Companies */}
          <button
            onClick={() => setActiveStudentTab('companies')}
            className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-indigo-400 hover:shadow-md transition-all text-left group flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                Companies
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">Explore 6+ firms</p>
            </div>
          </button>

          {/* 4. Ask Nexif5 AI */}
          <button
            onClick={() => setActiveStudentTab('ai')}
            className="p-4 rounded-2xl bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-200 hover:border-indigo-400 hover:shadow-md transition-all text-left group flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center mb-3 group-hover:scale-110 transition-transform shadow-xs">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-indigo-950 group-hover:text-indigo-600 transition-colors flex items-center gap-1">
                <span>Ask AI</span>
                <Sparkles className="w-3 h-3 text-indigo-600" />
              </p>
              <p className="text-[11px] text-indigo-700 mt-0.5">Instant Advice</p>
            </div>
          </button>

          {/* 5. Resume & ATS */}
          <button
            onClick={() => setActiveStudentTab('resume')}
            className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-indigo-400 hover:shadow-md transition-all text-left group flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                Resume Hub
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">Updated PDF</p>
            </div>
          </button>

          {/* 6. My Applications */}
          <button
            onClick={() => setActiveStudentTab('applications')}
            className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-indigo-400 hover:shadow-md transition-all text-left group flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                Applications
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">{applications.filter(a => a.candidateId === currentStudent.id).length} tracked</p>
            </div>
          </button>
        </div>
      </div>

      {/* AI Top Opportunity Matches */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>DETERMINISTIC AI MATCH ENGINE</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 font-display">
              Top Verified Opportunities Matching You
            </h2>
          </div>

          <button
            onClick={() => setActiveStudentTab('jobs')}
            className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
          >
            <span>View All {jobs.length} Opportunities</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {topMatchedJobs.map(({ job, match }) => (
            <div
              key={job.id}
              className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <img
                    src={job.companyLogoUrl}
                    alt={job.companyName}
                    className="w-12 h-12 rounded-xl object-cover border border-slate-200"
                  />
                  <div className="flex flex-col items-end">
                    <span className="px-2.5 py-1 rounded-lg bg-indigo-600 text-white font-bold text-xs shadow-xs">
                      {match.overallScore}% Match
                    </span>
                    <span className="text-[10px] text-slate-400 mt-0.5">High Alignment</span>
                  </div>
                </div>

                <div>
                  <h3 className="font-bold text-slate-900 text-sm">{job.title}</h3>
                  <p className="text-xs text-indigo-600 font-medium">{job.companyName}</p>
                </div>

                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 pt-1">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> {job.location}
                  </span>
                  <span>•</span>
                  <span className="text-emerald-700 font-semibold">{job.salaryDisplay}</span>
                </div>

                {/* Match reason highlight */}
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-[11px] text-slate-700">
                  <span className="font-semibold text-slate-900 block mb-0.5">Why it matches:</span>
                  <p className="line-clamp-2">{match.whyItMatches[0]}</p>
                </div>
              </div>

              <div className="pt-4 mt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                <span className="text-[11px] text-slate-400">Deadline: {job.applicationDeadline}</span>
                <button
                  onClick={() => setSelectedJob(job)}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-indigo-600 text-white text-xs font-bold transition-colors flex items-center gap-1"
                >
                  <span>Review & Apply</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Career Readiness & Skill Gap Diagnostic Section */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>AI CAREER READINESS DIAGNOSTICS</span>
            </div>
            <h2 className="text-lg font-bold text-slate-900 font-display">
              Skill Benchmarks for "{currentStudent.careerGoal}"
            </h2>
            <p className="text-xs text-slate-500">
              Evaluated against real recruiter screening requirements for 2025 freshers
            </p>
          </div>

          <button
            onClick={() => setActiveStudentTab('dashboard')}
            className="px-4 py-2 rounded-xl bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-bold text-xs transition-colors flex items-center gap-1.5 w-fit"
          >
            <span>Open Career Dashboard</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Skill Gap Matrix */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {careerAnalysis.skillGaps.slice(0, 3).map((item, idx) => (
            <div
              key={idx}
              className={`p-4 rounded-xl border text-xs space-y-2 ${
                item.status === 'Strong'
                  ? 'bg-emerald-50/50 border-emerald-200'
                  : item.status === 'Intermediate'
                  ? 'bg-blue-50/50 border-blue-200'
                  : 'bg-amber-50/50 border-amber-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">{item.skill}</span>
                <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                  item.status === 'Strong'
                    ? 'bg-emerald-100 text-emerald-800'
                    : item.status === 'Intermediate'
                    ? 'bg-blue-100 text-blue-800'
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {item.status}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">{item.actionItem}</p>
            </div>
          ))}
        </div>

        {/* Next Best Action Banner */}
        <div className="mt-4 p-4 rounded-xl bg-slate-900 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="p-2 bg-indigo-500 text-white rounded-lg">
              <Zap className="w-4 h-4" />
            </span>
            <div>
              <span className="text-[11px] text-indigo-300 font-semibold uppercase tracking-wider block">
                Next Best Action
              </span>
              <p className="text-xs font-medium text-slate-100">{careerAnalysis.nextBestAction}</p>
            </div>
          </div>
          <button
            onClick={() => setActiveStudentTab('ai')}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-colors whitespace-nowrap"
          >
            Guide Me with AI
          </button>
        </div>
      </div>

      {selectedJob && (
        <JobDetailModal
          job={selectedJob}
          onClose={() => setSelectedJob(null)}
        />
      )}
    </div>
  );
};
