import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  School,
  Mail,
  Phone,
  Globe,
  MapPin,
  Users,
  Award,
  ShieldCheck,
  BookOpen
} from 'lucide-react';

export const MobileCollegeProfile: React.FC = () => {
  const { currentCollege, theme } = useApp();
  const isLight = theme === 'light';

  return (
    <div className={`p-4 space-y-4 pb-24 font-sans ${isLight ? 'text-slate-900' : 'text-white'}`}>
      {/* College Identity Header */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-start gap-3.5">
          <img
            src={currentCollege.logoUrl}
            alt={currentCollege.name}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-purple-500 shadow-md"
          />
          <div className="space-y-0.5">
            <div className="flex items-center gap-1.5">
              <h1 className="text-base font-bold font-display">{currentCollege.name}</h1>
              <ShieldCheck className="w-4 h-4 text-purple-400" />
            </div>
            <p className="text-xs text-purple-600 dark:text-purple-400 font-semibold">
              {currentCollege.type}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>{currentCollege.location}</span>
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-700/60 text-xs">
          <div>
            <span className="text-slate-500 dark:text-slate-400 text-[10px] block">Accreditation</span>
            <span className="font-bold">{currentCollege.nirfRank || 'NAAC A++'}</span>
          </div>
          <div>
            <span className="text-slate-500 dark:text-slate-400 text-[10px] block">Student Batch</span>
            <span className="font-bold">{currentCollege.registeredStudentsCount || 1420} Registered</span>
          </div>
        </div>
      </div>

      {/* Placement Cell Committee */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-purple-500" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Placement Cell Directorate
          </h2>
        </div>

        <div className="space-y-2 text-xs">
          <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/60 space-y-1">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white">Dr. K. Ramanathan</h3>
              <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold">
                Dean & Director
              </span>
            </div>
            <p className="text-[11px] text-slate-400">ramanathan.placement@rathinam.ac.in</p>
            <p className="text-[10px] text-slate-500">+91 94432 10987</p>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/60 space-y-1">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white">Prof. Mary Shanthi</h3>
              <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold">
                Placement Officer
              </span>
            </div>
            <p className="text-[11px] text-slate-400">mary.placement@rathinam.ac.in</p>
          </div>
        </div>
      </div>

      {/* Departments Supported */}
      <div className={`p-4 rounded-2xl border space-y-2.5 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-purple-500" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Enrolled Academic Departments
          </h2>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {currentCollege.departments.map((dept, idx) => (
            <span
              key={idx}
              className="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-xs font-medium text-slate-300"
            >
              {dept}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
