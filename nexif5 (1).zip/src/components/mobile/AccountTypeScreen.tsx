import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import { ArrowLeft, GraduationCap, Briefcase, Building2, School, Award, ShieldCheck, Check } from 'lucide-react';

export const AccountTypeScreen: React.FC = () => {
  const { setAuthState, setCurrentRole } = useApp();
  const [selectedType, setSelectedType] = useState<UserRole>('student');

  const options: {
    role: UserRole;
    title: string;
    description: string;
    icon: React.ReactNode;
    badge: string;
    bgAccent: string;
  }[] = [
    {
      role: 'student',
      title: 'STUDENT',
      description: 'Build skills, prepare for careers and discover opportunities.',
      icon: <GraduationCap className="w-6 h-6 text-blue-400" />,
      badge: 'Internships & Placements',
      bgAccent: 'group-hover:border-blue-500'
    },
    {
      role: 'professional',
      title: 'WORKING PROFESSIONAL',
      description: 'Develop skills, grow your career and discover better opportunities.',
      icon: <Briefcase className="w-6 h-6 text-amber-400" />,
      badge: 'Upskilling & Growth',
      bgAccent: 'group-hover:border-amber-500'
    },
    {
      role: 'recruiter',
      title: 'RECRUITER',
      description: 'Discover talent, manage hiring and connect with candidates.',
      icon: <Building2 className="w-6 h-6 text-emerald-400" />,
      badge: 'Talent Acquisition',
      bgAccent: 'group-hover:border-emerald-500'
    },
    {
      role: 'college',
      title: 'COLLEGE / INSTITUTION',
      description: 'Support students, connect with industry and improve career outcomes.',
      icon: <School className="w-6 h-6 text-purple-400" />,
      badge: 'Placement & Industry Cell',
      bgAccent: 'group-hover:border-purple-500'
    },
    {
      role: 'mentor',
      title: 'MENTOR',
      description: 'Guide learners and professionals through career development.',
      icon: <Award className="w-6 h-6 text-cyan-400" />,
      badge: '1:1 Coaching & Reviews',
      bgAccent: 'group-hover:border-cyan-500'
    }
  ];

  const handleContinue = () => {
    setCurrentRole(selectedType);
    sessionStorage.setItem('temp_selected_role', selectedType);

    // Route to role-specific onboarding
    if (selectedType === 'student') {
      setAuthState('profile_setup');
    } else if (selectedType === 'professional') {
      setAuthState('professional_onboarding');
    } else if (selectedType === 'recruiter') {
      setAuthState('recruiter_onboarding');
    } else if (selectedType === 'college') {
      setAuthState('college_onboarding');
    } else if (selectedType === 'mentor') {
      setAuthState('mentor_onboarding');
    } else {
      setAuthState('profile_setup');
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col justify-between px-5 py-6 font-sans">
      <div>
        {/* Top Header */}
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={() => setAuthState('signup')}
            className="p-2 -ml-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors active:scale-95"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-white font-display">
              How will you use Nexif5?
            </h1>
            <p className="text-xs text-slate-400">
              Personalize your career ecosystem experience
            </p>
          </div>
        </div>

        {/* Account Type Selection Cards */}
        <div className="space-y-3 mt-4">
          {options.map((opt) => {
            const isSelected = selectedType === opt.role;
            return (
              <motion.button
                key={opt.role}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedType(opt.role)}
                className={`w-full p-4 rounded-2xl text-left border flex items-center justify-between transition-all ${
                  isSelected
                    ? 'bg-indigo-600/20 border-indigo-500 shadow-lg shadow-indigo-500/10'
                    : 'bg-slate-800/70 border-slate-700/80 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                    isSelected ? 'bg-indigo-600/30' : 'bg-slate-700/50'
                  }`}>
                    {opt.icon}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-base">
                        {opt.title}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-700/80 text-slate-300 font-medium">
                        {opt.badge}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 mt-1">
                      {opt.description}
                    </p>
                  </div>
                </div>

                <div className="shrink-0 ml-2">
                  {isSelected ? (
                    <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                      <Check className="w-4 h-4" />
                    </div>
                  ) : (
                    <div className="w-5 h-5 rounded-full border border-slate-600" />
                  )}
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Sticky Bottom Continue Button & Admin Access */}
      <div className="pt-4 space-y-2">
        <button
          onClick={handleContinue}
          className="w-full py-4 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-base shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
        >
          <span>Continue</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setCurrentRole('admin');
            setAuthState('admin_login');
          }}
          className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-xs font-semibold text-slate-400 hover:text-white flex items-center justify-center gap-2 transition-all"
        >
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>System Administrator? Access Secure Admin Portal</span>
        </button>
      </div>
    </div>
  );
};
