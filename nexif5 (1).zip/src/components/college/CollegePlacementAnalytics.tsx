import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  TrendingUp,
  Award,
  DollarSign,
  Building2,
  PieChart as PieIcon,
  BarChart2
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';

export const CollegePlacementAnalytics: React.FC = () => {
  const { currentCollege } = useApp();

  const salaryBracketData = [
    { name: '3 - 5 LPA', value: 320, color: '#94a3b8' },
    { name: '5 - 8 LPA', value: 380, color: '#6366f1' },
    { name: '8 - 12 LPA', value: 110, color: '#a855f7' },
    { name: '12+ LPA (Super Dream)', value: 40, color: '#10b981' }
  ];

  const topRecruiters = [
    { company: 'FinEdge Global Technologies', offers: 38, avgPackage: '8.2 LPA' },
    { company: 'Deloitte Digital Services', offers: 32, avgPackage: '7.8 LPA' },
    { company: 'Nexus Analytics Corp', offers: 24, avgPackage: '6.5 LPA' },
    { company: 'HealthScale AI', offers: 18, avgPackage: '9.0 LPA' },
    { company: 'PayFlow Commerce Systems', offers: 14, avgPackage: '7.2 LPA' }
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-purple-600 mb-1">
          <TrendingUp className="w-4 h-4" />
          <span>INSTITUTIONAL PERFORMANCE METRICS</span>
        </div>
        <h1 className="text-2xl font-bold text-slate-900 font-display">
          Placement Analytics & Recruiter Trends
        </h1>
        <p className="text-xs text-slate-500">
          Comprehensive salary distributions, conversion rates, and hiring partner metrics for {currentCollege.name}
        </p>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left (6 cols): Salary Package Bracket Distribution */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-base font-display">
                Compensation Package Distribution
              </h3>
              <p className="text-xs text-slate-500">
                Number of placed students across CTC brackets (LPA)
              </p>
            </div>
            <span className="p-2 bg-purple-50 text-purple-600 rounded-xl">
              <DollarSign className="w-4 h-4" />
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={salaryBracketData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {salaryBracketData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    borderRadius: '12px',
                    backgroundColor: '#0f172a',
                    color: '#fff',
                    border: 'none',
                    fontSize: '12px'
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right (6 cols): Top Hiring Corporate Partners */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-base font-display">
                Top Hiring Partners Leaderboard
              </h3>
              <p className="text-xs text-slate-500">
                Companies extending the highest volume of verified campus offers
              </p>
            </div>
            <span className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Building2 className="w-4 h-4" />
            </span>
          </div>

          <div className="space-y-2.5 pt-2">
            {topRecruiters.map((rec, i) => (
              <div
                key={i}
                className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white transition-colors flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-lg bg-purple-100 text-purple-800 font-bold flex items-center justify-center text-xs">
                    {i + 1}
                  </div>
                  <div>
                    <strong className="text-slate-900 font-bold block">{rec.company}</strong>
                    <span className="text-[10px] text-slate-400">Avg CTC: {rec.avgPackage}</span>
                  </div>
                </div>

                <span className="px-3 py-1 bg-emerald-50 text-emerald-800 rounded-lg font-bold text-xs border border-emerald-200">
                  {rec.offers} Offers
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
