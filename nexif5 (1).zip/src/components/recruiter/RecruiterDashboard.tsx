import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Building2,
  Briefcase,
  Layers,
  Sparkles,
  Award,
  CalendarCheck,
  CheckCircle2,
  Users,
  ArrowRight,
  TrendingUp,
  Bot,
  Plus
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';

export const RecruiterDashboard: React.FC = () => {
  const {
    currentCompany,
    jobs,
    applications,
    setActiveRecruiterTab
  } = useApp();

  const companyJobs = jobs.filter(j => j.companyId === currentCompany.id);
  const companyApps = applications.filter(a => a.companyId === currentCompany.id);

  const activeJobsCount = companyJobs.filter(j => j.isOpen).length;
  const totalAppsCount = companyApps.length + 340; // demo aggregate
  const aiMatchesCount = companyApps.filter(a => a.matchScore >= 80).length + 80;
  const shortlistedCount = companyApps.filter(a => a.status === 'shortlisted').length + 42;
  const interviewsCount = companyApps.filter(a => a.status === 'interview').length + 16;
  const selectedCount = companyApps.filter(a => a.status === 'selected').length + 5;

  const funnelChartData = [
    { stage: 'Applied', count: 368, fill: '#64748b' },
    { stage: 'AI Matched (80%+)', count: 186, fill: '#6366f1' },
    { stage: 'Shortlisted', count: 45, fill: '#a855f7' },
    { stage: 'Interviewed', count: 18, fill: '#3b82f6' },
    { stage: 'Selected / Hired', count: 6, fill: '#10b981' }
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <img
            src={currentCompany.logoUrl}
            alt={currentCompany.name}
            className="w-12 h-12 rounded-2xl object-cover border border-slate-200 shadow-xs"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-slate-900 font-display">
                {currentCompany.name} Recruiter Workspace
              </h1>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200">
                Verified Organization
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Company Group Management • {currentCompany.industry} • {currentCompany.headquarters}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveRecruiterTab('ai_match')}
            className="px-4 py-2.5 rounded-xl bg-indigo-50 text-indigo-700 hover:bg-indigo-100 text-xs font-bold transition-colors flex items-center gap-1.5"
          >
            <Bot className="w-4 h-4" />
            <span>AI Candidate Search</span>
          </button>
          <button
            onClick={() => setActiveRecruiterTab('jobs')}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs hover:shadow transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Post New Requisition</span>
          </button>
        </div>
      </div>

      {/* Section 16: 6 High-Level Key Performance Metric Tiles */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* 1. Active Jobs */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="p-2 bg-blue-50 text-blue-600 rounded-xl">
              <Briefcase className="w-4 h-4" />
            </span>
            <span className="text-[10px] font-bold text-blue-600">Open</span>
          </div>
          <div>
            <span className="text-2xl font-black text-slate-900 font-display block">12</span>
            <span className="text-[11px] text-slate-500 font-medium">Active Jobs</span>
          </div>
        </div>

        {/* 2. Applications */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="p-2 bg-slate-100 text-slate-700 rounded-xl">
              <Layers className="w-4 h-4" />
            </span>
            <span className="text-[10px] font-bold text-slate-500">Pipeline</span>
          </div>
          <div>
            <span className="text-2xl font-black text-slate-900 font-display block">368</span>
            <span className="text-[11px] text-slate-500 font-medium">Applications</span>
          </div>
        </div>

        {/* 3. AI Matches */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Sparkles className="w-4 h-4" />
            </span>
            <span className="text-[10px] font-bold text-indigo-600">80%+ Match</span>
          </div>
          <div>
            <span className="text-2xl font-black text-indigo-600 font-display block">86</span>
            <span className="text-[11px] text-slate-500 font-medium">AI Matches</span>
          </div>
        </div>

        {/* 4. Shortlisted */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="p-2 bg-purple-50 text-purple-600 rounded-xl">
              <Award className="w-4 h-4" />
            </span>
            <span className="text-[10px] font-bold text-purple-600">Screened</span>
          </div>
          <div>
            <span className="text-2xl font-black text-purple-600 font-display block">45</span>
            <span className="text-[11px] text-slate-500 font-medium">Shortlisted</span>
          </div>
        </div>

        {/* 5. Interviews */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="p-2 bg-blue-50 text-blue-600 rounded-xl">
              <CalendarCheck className="w-4 h-4" />
            </span>
            <span className="text-[10px] font-bold text-blue-600">Rounds</span>
          </div>
          <div>
            <span className="text-2xl font-black text-blue-600 font-display block">18</span>
            <span className="text-[11px] text-slate-500 font-medium">Interviews</span>
          </div>
        </div>

        {/* 6. Selected */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
              <CheckCircle2 className="w-4 h-4" />
            </span>
            <span className="text-[10px] font-bold text-emerald-700">Offers</span>
          </div>
          <div>
            <span className="text-2xl font-black text-emerald-600 font-display block">6</span>
            <span className="text-[11px] text-slate-500 font-medium">Selected</span>
          </div>
        </div>
      </div>

      {/* Funnel Analytics & Quick Candidate Pipeline */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left (7 cols): Candidate Pipeline Funnel Chart */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-base font-display">
                Hiring Execution Funnel
              </h3>
              <p className="text-xs text-slate-500">
                Candidate progression from direct submissions & AI matching to final selection
              </p>
            </div>

            <button
              onClick={() => setActiveRecruiterTab('applications')}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
            >
              View Full Pipeline
            </button>
          </div>

          <div className="h-64 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={funnelChartData} layout="vertical" margin={{ top: 5, right: 20, left: 40, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis dataKey="stage" type="category" tick={{ fontSize: 11, fill: '#334155' }} width={100} />
                <Tooltip
                  contentStyle={{
                    borderRadius: '12px',
                    backgroundColor: '#0f172a',
                    color: '#fff',
                    border: 'none',
                    fontSize: '12px'
                  }}
                />
                <Bar dataKey="count" radius={[0, 8, 8, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
            <span>Average Screening-to-Offer Velocity: <strong>6.2 Days</strong></span>
            <span className="text-emerald-700 font-semibold">✦ 3.4x faster than email sourcing</span>
          </div>
        </div>

        {/* Right (5 cols): AI Talent Sourcing Quick Callout */}
        <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-2xl p-6 shadow-xs space-y-5 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold border border-indigo-500/30">
              <Bot className="w-3.5 h-3.5" />
              <span>AI RECRUITER TALENT QUERY</span>
            </div>

            <h3 className="text-xl font-bold font-display leading-snug">
              "Find B.Com freshers with Excel, SQL, and Power BI."
            </h3>

            <p className="text-xs text-slate-300 leading-relaxed">
              Our AI search engine automatically scans verified student achievements, coursework, and projects across independent candidates and affiliated partner colleges.
            </p>
          </div>

          <div className="space-y-3 pt-2">
            <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-xl border border-white/10 text-xs space-y-1">
              <span className="text-indigo-300 font-semibold block text-[11px]">Human-in-the-Loop Safeguard:</span>
              <p className="text-slate-200 text-[11px]">
                Nexif5 AI analyzes and ranks candidates. Final shortlisting and hiring decisions are always made by you, the recruiter.
              </p>
            </div>

            <button
              onClick={() => setActiveRecruiterTab('ai_match')}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2"
            >
              <span>Launch AI Recruiter Assistant</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
