import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, Building2, User, Globe, MapPin, Check, Briefcase, Mail, Phone } from 'lucide-react';

export const RecruiterOnboardingScreen: React.FC = () => {
  const { setAuthState, setCurrentRole, currentCompany, setCurrentCompany } = useApp();

  // Recruiter Personal Details
  const [recruiterName, setRecruiterName] = useState('Rajesh Menon');
  const [recruiterEmail, setRecruiterEmail] = useState('rajesh.m@abctechnologies.io');
  const [recruiterPhone, setRecruiterPhone] = useState('+91 98401 23456');
  const [jobTitle, setJobTitle] = useState('Head of Talent Acquisition');
  const [department, setDepartment] = useState('Global People & Talent');
  const [linkedInUrl, setLinkedInUrl] = useState('https://linkedin.com/in/rajesh-menon-talent');

  // Company Details
  const [companyName, setCompanyName] = useState('ABC Technologies');
  const [logoUrl, setLogoUrl] = useState('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80');
  const [website, setWebsite] = useState('https://abctechnologies.io');
  const [industry, setIndustry] = useState('Enterprise Software & Cloud Platforms');
  const [employeeCount, setEmployeeCount] = useState('2,500 - 5,000');
  const [headquarters, setHeadquarters] = useState('Bengaluru, Karnataka');
  const [aboutCompany, setAboutCompany] = useState('Next-generation technology consulting and digital product engineering partner serving Global 2000 leaders.');
  const [hiringLocations, setHiringLocations] = useState('Bengaluru, Chennai, Hyderabad, Pune, Remote');

  const [step, setStep] = useState<1 | 2>(1);

  const handleFinish = () => {
    // Update company details
    setCurrentCompany({
      ...currentCompany,
      name: companyName,
      logoUrl,
      website,
      industry,
      employeeCount,
      headquarters,
      description: aboutCompany,
      locations: hiringLocations.split(',').map(s => s.trim())
    });

    setCurrentRole('recruiter');
    setAuthState('authenticated');
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col justify-between px-5 py-6 font-sans">
      <div>
        {/* Top Header */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (step > 1) setStep(1);
                else setAuthState('account_type');
              }}
              className="p-2 -ml-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors active:scale-95"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white font-display">
                Recruiter & Company Setup
              </h1>
              <p className="text-xs text-slate-400">
                Step {step} of 2 — {step === 1 ? 'Recruiter Profile' : 'Company Organization'}
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-emerald-400">{step === 1 ? '50%' : '100%'}</span>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1.5 bg-slate-800 rounded-full mb-4 overflow-hidden">
          <div
            className="h-full bg-emerald-500 rounded-full transition-all duration-300"
            style={{ width: `${(step / 2) * 100}%` }}
          />
        </div>

        {/* Step 1: Recruiter Personal Details */}
        {step === 1 && (
          <div className="space-y-3.5 max-h-[68vh] overflow-y-auto pr-1">
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-lg">
                <Briefcase className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs font-bold text-emerald-300">Talent Acquisition Lead</p>
                <p className="text-[11px] text-slate-400">Manage jobs, candidates & placement drives</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Recruiter Name</label>
              <input
                type="text"
                value={recruiterName}
                onChange={(e) => setRecruiterName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Official Work Email</label>
              <input
                type="email"
                value={recruiterEmail}
                onChange={(e) => setRecruiterEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                placeholder="name@company.com"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Contact Phone</label>
                <input
                  type="text"
                  value={recruiterPhone}
                  onChange={(e) => setRecruiterPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Recruiter Title</label>
                <input
                  type="text"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Department</label>
              <input
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">LinkedIn Profile (optional)</label>
              <input
                type="url"
                value={linkedInUrl}
                onChange={(e) => setLinkedInUrl(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                placeholder="https://linkedin.com/in/username"
              />
            </div>
          </div>
        )}

        {/* Step 2: Company Details */}
        {step === 2 && (
          <div className="space-y-3.5 max-h-[68vh] overflow-y-auto pr-1">
            <div className="flex items-center gap-3.5 p-3.5 bg-slate-800/60 border border-slate-700/80 rounded-2xl">
              <img
                src={logoUrl}
                alt={companyName}
                className="w-14 h-14 rounded-xl object-cover border border-slate-600"
              />
              <div>
                <p className="text-xs font-bold text-white">Company Identity</p>
                <p className="text-[11px] text-slate-400">Candidates will see this branding on listings</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Company Name</label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Industry</label>
                <input
                  type="text"
                  value={industry}
                  onChange={(e) => setIndustry(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Company Size</label>
                <select
                  value={employeeCount}
                  onChange={(e) => setEmployeeCount(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                >
                  <option value="1 - 50">1 - 50</option>
                  <option value="51 - 200">51 - 200</option>
                  <option value="201 - 1,000">201 - 1,000</option>
                  <option value="1,000 - 5,000">1,000 - 5,000</option>
                  <option value="5,000+">5,000+</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Company Website</label>
              <input
                type="url"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Headquarters Location</label>
              <input
                type="text"
                value={headquarters}
                onChange={(e) => setHeadquarters(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Hiring Locations</label>
              <input
                type="text"
                value={hiringLocations}
                onChange={(e) => setHiringLocations(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">About Company</label>
              <textarea
                rows={2}
                value={aboutCompany}
                onChange={(e) => setAboutCompany(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-800/80 border border-slate-700/80 rounded-xl text-xs text-white"
              />
            </div>
          </div>
        )}
      </div>

      {/* Bottom Button */}
      <div className="pt-4">
        {step < 2 ? (
          <button
            onClick={() => setStep(2)}
            className="w-full py-3.5 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 flex items-center justify-center transition-all active:scale-[0.98]"
          >
            Continue to Company Details
          </button>
        ) : (
          <button
            onClick={handleFinish}
            className="w-full py-3.5 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
          >
            <Check className="w-4 h-4" />
            <span>Launch Recruiter Workspace</span>
          </button>
        )}
      </div>
    </div>
  );
};
