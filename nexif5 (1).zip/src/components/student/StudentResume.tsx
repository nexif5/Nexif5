import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  FileText,
  CheckCircle2,
  Sparkles,
  Download,
  Upload,
  Eye,
  AlertCircle,
  TrendingUp,
  Target,
  Edit2,
  Save
} from 'lucide-react';

export const StudentResume: React.FC = () => {
  const { currentStudent, updateStudentProfile, setActiveStudentTab } = useApp();

  const [resumeName, setResumeName] = useState(currentStudent.resumeName);
  const [isEditing, setIsEditing] = useState(false);

  const atsChecks = [
    { label: 'Role-Targeted Header (Business Analyst)', status: 'pass' },
    { label: 'Standard Clean Layout & PDF Structure', status: 'pass' },
    { label: 'Quantified Project Metrics (DAX, ROI, Latency)', status: 'pass' },
    { label: 'Verified Skills Matrix Section', status: 'pass' },
    { label: 'Verified National Hackathon Achievement', status: 'pass' },
    { label: 'SQL Query Optimization Projects', status: 'warning', note: 'Add 1 more multi-table SQL project to score 95%+' }
  ];

  const handleSave = () => {
    updateStudentProfile({
      resumeName,
      resumeUpdatedDate: 'Just now'
    });
    setIsEditing(false);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
          <FileText className="w-4 h-4" />
          <span>VERIFIED RESUME & ATS DIAGNOSTICS</span>
        </div>
        <h1 className="text-2xl font-bold text-slate-900 font-display">
          Resume Optimization Hub
        </h1>
        <p className="text-xs text-slate-500">
          Your active resume is verified and dynamically synchronized with your profile skills & achievements
        </p>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left (7 cols): Resume Preview Card */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-rose-50 text-rose-600 rounded-xl border border-rose-100">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">{currentStudent.resumeName}</h3>
                  <p className="text-[11px] text-slate-400">
                    Updated {currentStudent.resumeUpdatedDate} • Verified PDF
                  </p>
                </div>
              </div>

              <span className="px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-bold border border-emerald-200 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Active Resume
              </span>
            </div>

            {/* Document Render Mock */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 text-xs text-slate-700 space-y-4 font-sans shadow-inner">
              <div className="text-center border-b border-slate-200 pb-3 space-y-1">
                <h2 className="text-base font-bold text-slate-900 font-display">{currentStudent.name}</h2>
                <p className="text-[11px] text-indigo-700 font-semibold uppercase tracking-wider">
                  Aspiring {currentStudent.careerGoal}
                </p>
                <p className="text-[10px] text-slate-500">
                  {currentStudent.email} • {currentStudent.phone} • {currentStudent.location}
                </p>
              </div>

              <div className="space-y-1">
                <h4 className="font-bold text-slate-900 text-[11px] uppercase tracking-wider text-slate-500">
                  Education
                </h4>
                <p className="font-semibold text-slate-800">
                  {currentStudent.education.degree} in {currentStudent.education.course}
                </p>
                <p className="text-[11px] text-slate-600">
                  {currentStudent.collegeName || 'Accredited University'} • CGPA: {currentStudent.education.cgpaOrPercentage} • Batch of {currentStudent.education.graduationYear}
                </p>
              </div>

              <div className="space-y-1">
                <h4 className="font-bold text-slate-900 text-[11px] uppercase tracking-wider text-slate-500">
                  Core Skills Matrix
                </h4>
                <p className="text-[11px] text-slate-700 leading-relaxed">
                  {currentStudent.skills.map(s => `${s.name} (${s.level})`).join(' • ')}
                </p>
              </div>

              <div className="space-y-1">
                <h4 className="font-bold text-slate-900 text-[11px] uppercase tracking-wider text-slate-500">
                  Key Achievements
                </h4>
                {currentStudent.achievements.map((ach) => (
                  <p key={ach.id} className="text-[11px] text-slate-700">
                    • <strong>{ach.title}</strong>: {ach.description}
                  </p>
                ))}
              </div>

              <div className="space-y-1">
                <h4 className="font-bold text-slate-900 text-[11px] uppercase tracking-wider text-slate-500">
                  Projects
                </h4>
                {currentStudent.projects.map((proj) => (
                  <div key={proj.id} className="text-[11px] text-slate-700">
                    <p className="font-semibold text-slate-900">• {proj.title}</p>
                    <p className="text-slate-600">{proj.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-2">
              <span className="text-[11px] text-slate-400">Nexif5 1-Click Sync is active</span>
              <button
                onClick={() => setActiveStudentTab('profile')}
                className="px-4 py-2 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-xl font-bold text-xs transition-colors"
              >
                Edit Content in Profile
              </button>
            </div>
          </div>
        </div>

        {/* Right (5 cols): ATS Score Diagnostics */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                  ATS Match Score
                </span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-3xl font-black text-emerald-600 font-display">88</span>
                  <span className="text-xs text-slate-400 font-semibold">/ 100</span>
                </div>
              </div>

              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl border border-emerald-100">
                <Sparkles className="w-6 h-6" />
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Your resume exceeds the 80-point ATS benchmark required for tier-1 corporate automated screening.
            </p>

            <div className="space-y-2 pt-2 border-t border-slate-100">
              <span className="text-xs font-bold text-slate-900 block mb-2">
                ATS Screening Checklist
              </span>
              {atsChecks.map((chk, i) => (
                <div key={i} className="p-2.5 rounded-xl border border-slate-100 bg-slate-50/50 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-800">{chk.label}</span>
                    {chk.status === 'pass' ? (
                      <span className="text-emerald-600 font-bold text-[11px] flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Pass
                      </span>
                    ) : (
                      <span className="text-amber-600 font-bold text-[11px] flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" /> Tip
                      </span>
                    )}
                  </div>
                  {chk.note && (
                    <p className="text-[11px] text-slate-500 italic">{chk.note}</p>
                  )}
                </div>
              ))}
            </div>

            <div className="pt-2">
              <button
                onClick={() => setActiveStudentTab('ai')}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-2"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Ask AI to Rewrite Bullet Points</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
