import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { JobOpportunity } from '../../types';
import { calculateJobMatch } from '../../services/aiEngine';
import { JobApplyModal } from './JobApplyModal';
import {
  X,
  MapPin,
  Building,
  Briefcase,
  GraduationCap,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Users,
  Send,
  Share2,
  ExternalLink
} from 'lucide-react';

interface JobDetailModalProps {
  job: JobOpportunity | null;
  onClose: () => void;
}

export const JobDetailModal: React.FC<JobDetailModalProps> = ({ job, onClose }) => {
  const { currentStudent, applications, currentRole } = useApp();
  const [showApplyModal, setShowApplyModal] = useState(false);

  if (!job) return null;

  const match = calculateJobMatch(currentStudent, job);
  const existingApplication = applications.find(
    a => a.jobId === job.id && a.candidateId === currentStudent.id
  );

  return (
    <>
      <div className="fixed inset-0 z-40 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 15 }}
          className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col"
        >
          {/* Header */}
          <div className="p-4 sm:p-6 border-b border-slate-100 bg-slate-50/60 relative shrink-0">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 z-10"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-start gap-3 sm:gap-4 pr-8 sm:pr-0">
              <img
                src={job.companyLogoUrl}
                alt={job.companyName}
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl object-cover border border-slate-200 shadow-xs shrink-0"
              />
              <div className="space-y-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-base sm:text-xl font-bold text-slate-900 font-display leading-tight truncate">
                    {job.title}
                  </h2>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-semibold uppercase tracking-wider ${
                    job.type === 'internship' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                  }`}>
                    {job.type}
                  </span>
                </div>
                <p className="text-xs sm:text-sm font-medium text-slate-600 flex flex-wrap items-center gap-1.5">
                  <span className="text-indigo-600 font-semibold">{job.companyName}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-400" /> {job.location.split(',')[0]}
                  </span>
                  <span>•</span>
                  <span className="capitalize text-slate-500">{job.workMode.replace('_', ' ')}</span>
                </p>
              </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4 pt-3 border-t border-slate-200/70 text-xs">
              <div className="bg-white p-2 sm:p-2.5 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[9px] sm:text-[10px]">Compensation</span>
                <strong className="text-emerald-700 font-bold text-xs sm:text-sm">{job.salaryDisplay}</strong>
              </div>
              <div className="bg-white p-2 sm:p-2.5 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[9px] sm:text-[10px]">Experience</span>
                <strong className="text-slate-800 font-semibold text-xs">{job.experienceRequired}</strong>
              </div>
              <div className="bg-white p-2 sm:p-2.5 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[9px] sm:text-[10px]">Applicants</span>
                <strong className="text-slate-800 font-semibold text-xs">{job.applicantsCount} Applied</strong>
              </div>
              <div className="bg-white p-2 sm:p-2.5 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[9px] sm:text-[10px]">Deadline</span>
                <strong className="text-slate-800 font-semibold text-xs">{job.applicationDeadline}</strong>
              </div>
            </div>
          </div>

          {/* AI Match Deep Breakdown (For Students) */}
          {currentRole === 'student' && (
            <div className="p-5 bg-gradient-to-r from-indigo-50/80 to-blue-50/80 border-b border-indigo-100">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 bg-indigo-600 text-white rounded-lg">
                    <Sparkles className="w-4 h-4" />
                  </span>
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">Nexif5 AI Match Analysis</h4>
                    <p className="text-xs text-slate-600">Calculated against your verified student profile</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-black text-indigo-700 font-display">{match.overallScore}%</span>
                  <span className="text-[10px] text-indigo-900 block font-semibold">Match Score</span>
                </div>
              </div>

              {/* 4 Factor Sub-Scores */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
                <div className="bg-white/90 p-2 rounded-lg border border-indigo-100 text-center">
                  <span className="text-[10px] text-slate-500 block">Skills Match</span>
                  <span className="font-bold text-slate-800 text-xs">{match.skillsMatch}%</span>
                </div>
                <div className="bg-white/90 p-2 rounded-lg border border-indigo-100 text-center">
                  <span className="text-[10px] text-slate-500 block">Qualification</span>
                  <span className="font-bold text-slate-800 text-xs">{match.qualificationMatch}%</span>
                </div>
                <div className="bg-white/90 p-2 rounded-lg border border-indigo-100 text-center">
                  <span className="text-[10px] text-slate-500 block">Career Goal</span>
                  <span className="font-bold text-slate-800 text-xs">{match.careerGoalMatch}%</span>
                </div>
                <div className="bg-white/90 p-2 rounded-lg border border-indigo-100 text-center">
                  <span className="text-[10px] text-slate-500 block">Preferences</span>
                  <span className="font-bold text-slate-800 text-xs">{match.preferenceMatch}%</span>
                </div>
              </div>

              <div className="bg-white/90 p-3 rounded-lg border border-indigo-100 text-xs space-y-1">
                <span className="font-bold text-indigo-950 block">Why this matches you:</span>
                {match.whyItMatches.map((reason, idx) => (
                  <p key={idx} className="text-slate-700 flex items-start gap-1.5 text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{reason}</span>
                  </p>
                ))}
              </div>
            </div>
          )}

          {/* Job Details Body */}
          <div className="p-6 space-y-6 max-h-[50vh] overflow-y-auto text-sm text-slate-700">
            {/* Description */}
            <div>
              <h4 className="font-bold text-slate-900 mb-2 text-xs uppercase tracking-wider text-slate-500">
                About the Role
              </h4>
              <p className="leading-relaxed text-slate-600 text-xs sm:text-sm">{job.description}</p>
            </div>

            {/* Skills & Qualifications */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <h4 className="font-bold text-slate-900 mb-2 text-xs uppercase tracking-wider text-slate-500">
                  Required Competencies
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {job.requiredSkills.map((sk, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-md text-xs font-semibold bg-slate-100 text-slate-800 border border-slate-200"
                    >
                      {sk}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 mb-2 text-xs uppercase tracking-wider text-slate-500">
                  Eligible Degrees
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {job.qualificationRequired.map((deg, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-md text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100"
                    >
                      {deg}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Key Responsibilities */}
            <div>
              <h4 className="font-bold text-slate-900 mb-2 text-xs uppercase tracking-wider text-slate-500">
                Key Deliverables & Responsibilities
              </h4>
              <ul className="space-y-2 text-xs sm:text-sm text-slate-600">
                {job.responsibilities.map((resp, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-2 shrink-0" />
                    <span>{resp}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Perks */}
            {job.perks && job.perks.length > 0 && (
              <div>
                <h4 className="font-bold text-slate-900 mb-2 text-xs uppercase tracking-wider text-slate-500">
                  Benefits & Perks
                </h4>
                <div className="flex flex-wrap gap-2">
                  {job.perks.map((perk, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 rounded-full text-xs font-medium bg-emerald-50 text-emerald-800 border border-emerald-200"
                    >
                      ✦ {perk}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Footer Actions */}
          <div className="p-3 sm:p-5 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-3 shrink-0">
            <div className="text-xs text-slate-500 hidden sm:block">
              Posting ID: <span className="font-mono text-slate-700 font-semibold">{job.id}</span>
            </div>

            <div className="flex items-center gap-2 sm:gap-3 w-full sm:w-auto justify-end">
              <button
                onClick={onClose}
                className="flex-1 sm:flex-initial px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-200/70 border border-slate-200 sm:border-transparent text-center"
              >
                Close
              </button>

              {existingApplication ? (
                <span className="flex-1 sm:flex-initial px-4 sm:px-5 py-2.5 text-xs font-bold bg-slate-200 text-slate-700 rounded-xl flex items-center justify-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Applied</span>
                </span>
              ) : (
                <button
                  onClick={() => setShowApplyModal(true)}
                  className="flex-1 sm:flex-initial px-5 sm:px-6 py-2.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-sm hover:shadow transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Apply Now</span>
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </div>

      {showApplyModal && (
        <JobApplyModal
          job={job}
          onClose={() => {
            setShowApplyModal(false);
            onClose();
          }}
        />
      )}
    </>
  );
};
