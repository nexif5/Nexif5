import React from 'react';
import { AppProvider, useApp } from './context/AppContext';

// Mobile-first Flow Screens
import { WelcomeScreen } from './components/mobile/WelcomeScreen';
import { LanguageScreen } from './components/mobile/LanguageScreen';
import { SignUpScreen } from './components/mobile/SignUpScreen';
import { LoginScreen } from './components/mobile/LoginScreen';
import { AccountTypeScreen } from './components/mobile/AccountTypeScreen';
import { ProfileSetupScreen } from './components/mobile/ProfileSetupScreen';
import { CareerGoalScreen } from './components/mobile/CareerGoalScreen';
import { PreferencesScreen } from './components/mobile/PreferencesScreen';
import { ProfessionalOnboardingScreen } from './components/mobile/ProfessionalOnboardingScreen';
import { RecruiterOnboardingScreen } from './components/mobile/RecruiterOnboardingScreen';
import { CollegeOnboardingScreen } from './components/mobile/CollegeOnboardingScreen';
import { MentorOnboardingScreen } from './components/mobile/MentorOnboardingScreen';
import { AdminLoginScreen } from './components/mobile/AdminLoginScreen';
import { MobileFirstApp } from './components/mobile/MobileFirstApp';

const MainAppContent: React.FC = () => {
  const { authState, theme } = useApp();
  const isLight = theme === 'light';

  return (
    <div className={`min-h-screen font-sans flex flex-col justify-center items-center transition-colors duration-200 ${
      isLight ? 'bg-slate-200 text-slate-900' : 'bg-slate-950 text-slate-100'
    }`}>
      <div className={`w-full max-w-md min-h-screen shadow-2xl relative overflow-x-hidden transition-colors duration-200 ${
        isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-slate-100'
      }`}>
        {/* Mobile Flow Routing State Machine */}
        {authState === 'welcome' && <WelcomeScreen />}
        {authState === 'language' && <LanguageScreen />}
        {authState === 'signup' && <SignUpScreen />}
        {authState === 'login' && <LoginScreen />}
        {authState === 'account_type' && <AccountTypeScreen />}
        {authState === 'profile_setup' && <ProfileSetupScreen />}
        {authState === 'career_goal' && <CareerGoalScreen />}
        {authState === 'preferences' && <PreferencesScreen />}
        {authState === 'professional_onboarding' && <ProfessionalOnboardingScreen />}
        {authState === 'recruiter_onboarding' && <RecruiterOnboardingScreen />}
        {authState === 'college_onboarding' && <CollegeOnboardingScreen />}
        {authState === 'mentor_onboarding' && <MentorOnboardingScreen />}
        {authState === 'admin_login' && <AdminLoginScreen />}
        {authState === 'authenticated' && <MobileFirstApp />}
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
