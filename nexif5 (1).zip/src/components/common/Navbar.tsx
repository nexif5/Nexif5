import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { NotificationCenter } from './NotificationCenter';
import { AuthModal } from './AuthModal';
import { CareerOnboardingModal } from '../onboarding/CareerOnboardingModal';
import { SettingsModal } from './SettingsModal';
import { LanguageSelectorModal } from './LanguageSelectorModal';
import {
  Sparkles,
  GraduationCap,
  Building2,
  School,
  Search,
  Bot,
  FileText,
  Briefcase,
  Layers,
  User,
  Users,
  BarChart3,
  Calendar,
  Settings,
  HelpCircle,
  LogOut,
  Compass,
  Menu,
  X,
  ChevronDown,
  ArrowRight,
  TrendingUp,
  FileCheck,
  Globe
} from 'lucide-react';

interface NavbarProps {
  onOpenPublicJobs?: () => void;
  onOpenPublicCompanies?: () => void;
  onOpenPublicAbout?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenPublicJobs,
  onOpenPublicCompanies,
  onOpenPublicAbout
}) => {
  const {
    currentRole,
    setCurrentRole,
    activeStudentTab,
    setActiveStudentTab,
    activeJobSeekerTab,
    setActiveJobSeekerTab,
    activeRecruiterTab,
    setActiveRecruiterTab,
    activeCollegeTab,
    setActiveCollegeTab,
    currentStudent,
    currentCompany,
    currentCollege,
    switchToStudentDemo,
    switchToJobSeekerDemo,
    switchToRecruiterDemo,
    switchToCollegeDemo,
    currentLanguage,
    t
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [onboardingOpen, setOnboardingOpen] = useState(false);
  const [registeredUser, setRegisteredUser] = useState<{ name: string; email: string; role: any }>({
    name: 'Aadhi Kesavan',
    email: 'aadhikesavanks@gmail.com',
    role: 'student'
  });
  const [settingsModalOpen, setSettingsModalOpen] = useState(false);
  const [languageModalOpen, setLanguageModalOpen] = useState(false);

  // Student Navigation Items
  const studentNavItems = [
    { id: 'home', label: t('nav.home'), icon: <Compass className="w-4 h-4" /> },
    { id: 'jobs', label: t('nav.jobs'), icon: <Briefcase className="w-4 h-4" /> },
    { id: 'internships', label: t('nav.internships'), icon: <GraduationCap className="w-4 h-4" /> },
    { id: 'companies', label: t('nav.companies'), icon: <Building2 className="w-4 h-4" /> },
    { id: 'ai', label: t('nav.ai_assistant'), icon: <Bot className="w-4 h-4 text-indigo-500" /> },
    { id: 'applications', label: t('nav.applications'), icon: <Layers className="w-4 h-4" /> },
    { id: 'resume', label: t('nav.resume'), icon: <FileText className="w-4 h-4" /> },
    { id: 'dashboard', label: t('nav.dashboard'), icon: <BarChart3 className="w-4 h-4" /> }
  ];

  // Job Seeker Navigation Items
  const jobSeekerNavItems = [
    { id: 'home', label: t('nav.home'), icon: <Compass className="w-4 h-4" /> },
    { id: 'jobs', label: t('nav.jobs'), icon: <Briefcase className="w-4 h-4" /> },
    { id: 'internships', label: t('nav.internships'), icon: <GraduationCap className="w-4 h-4" /> },
    { id: 'companies', label: t('nav.companies'), icon: <Building2 className="w-4 h-4" /> },
    { id: 'ai', label: t('nav.ai_assistant'), icon: <Bot className="w-4 h-4 text-amber-500" /> },
    { id: 'applications', label: t('nav.applications'), icon: <Layers className="w-4 h-4" /> },
    { id: 'resume', label: t('nav.resume'), icon: <FileText className="w-4 h-4" /> },
    { id: 'dashboard', label: t('nav.dashboard'), icon: <BarChart3 className="w-4 h-4" /> }
  ];

  // Recruiter Navigation Items
  const recruiterNavItems = [
    { id: 'overview', label: 'Overview', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'jobs', label: 'Jobs', icon: <Briefcase className="w-4 h-4" /> },
    { id: 'applications', label: 'Applications', icon: <Layers className="w-4 h-4" /> },
    { id: 'candidates', label: 'Candidates', icon: <Users className="w-4 h-4" /> },
    { id: 'ai_match', label: 'AI Matching', icon: <Bot className="w-4 h-4 text-emerald-500" /> },
    { id: 'interviews', label: 'Interviews', icon: <Calendar className="w-4 h-4" /> },
    { id: 'analytics', label: 'Analytics', icon: <TrendingUp className="w-4 h-4" /> }
  ];

  // College Navigation Items
  const collegeNavItems = [
    { id: 'overview', label: 'Overview', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'students', label: 'Students', icon: <Users className="w-4 h-4" /> },
    { id: 'opportunities', label: 'Opportunities', icon: <Briefcase className="w-4 h-4" /> },
    { id: 'applications', label: 'Applications', icon: <Layers className="w-4 h-4" /> },
    { id: 'companies', label: 'Companies', icon: <Building2 className="w-4 h-4" /> },
    { id: 'placements', label: 'Placements', icon: <GraduationCap className="w-4 h-4" /> },
    { id: 'skill_gaps', label: 'Skill Gaps', icon: <Bot className="w-4 h-4 text-purple-500" /> },
    { id: 'analytics', label: 'Analytics', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'reports', label: 'Reports', icon: <FileCheck className="w-4 h-4" /> },
    { id: 'ai', label: 'AI Advisor', icon: <Bot className="w-4 h-4" /> }
  ];

  const handleOpenAuth = (mode: 'signin' | 'signup') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
    setMobileMenuOpen(false);
  };

  const handleSuccessSignUp = (user: { name: string; email: string; role: any }) => {
    setRegisteredUser(user);
    if (user.role === 'student' || user.role === 'job_seeker') {
      setOnboardingOpen(true);
    } else if (user.role === 'recruiter') {
      switchToRecruiterDemo('comp-1');
    } else if (user.role === 'college') {
      switchToCollegeDemo('clg-1');
    }
  };

  const handleLogout = () => {
    setProfileDropdownOpen(false);
    setCurrentRole('landing');
  };

  const getInitials = (name: string) => {
    if (!name) return 'NX';
    const parts = name.split(' ');
    if (parts.length >= 2) return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    return name.slice(0, 2).toUpperCase();
  };

  const renderNavLinks = () => {
    // 1. Logged-out Public Experience
    if (currentRole === 'landing') {
      return (
        <div className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600">
          <button
            onClick={() => {
              if (onOpenPublicJobs) onOpenPublicJobs();
              else {
                switchToStudentDemo('std-1');
                setActiveStudentTab('jobs');
              }
            }}
            className="hover:text-indigo-600 transition-colors"
          >
            {t('nav.jobs')}
          </button>
          <button
            onClick={() => {
              switchToStudentDemo('std-1');
              setActiveStudentTab('internships');
            }}
            className="hover:text-indigo-600 transition-colors"
          >
            {t('nav.internships')}
          </button>
          <button
            onClick={() => {
              if (onOpenPublicCompanies) onOpenPublicCompanies();
              else {
                switchToStudentDemo('std-1');
                setActiveStudentTab('companies');
              }
            }}
            className="hover:text-indigo-600 transition-colors"
          >
            {t('nav.companies')}
          </button>
          <button
            onClick={() => {
              switchToStudentDemo('std-1');
              setActiveStudentTab('ai');
            }}
            className="hover:text-indigo-600 transition-colors flex items-center gap-1 text-indigo-600"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t('nav.ai_assistant')}</span>
          </button>
          <button
            onClick={() => {
              const elem = document.getElementById('platform-pillars');
              if (elem) elem.scrollIntoView({ behavior: 'smooth' });
              else if (onOpenPublicAbout) onOpenPublicAbout();
            }}
            className="hover:text-indigo-600 transition-colors"
          >
            {t('nav.about')}
          </button>
        </div>
      );
    }

    // 2. Logged-in App Experience
    let items = studentNavItems;
    let activeTab = activeStudentTab;
    let setTab = setActiveStudentTab;

    if (currentRole === 'job_seeker') {
      items = jobSeekerNavItems;
      activeTab = activeJobSeekerTab;
      setTab = setActiveJobSeekerTab;
    } else if (currentRole === 'recruiter') {
      items = recruiterNavItems;
      activeTab = activeRecruiterTab;
      setTab = setActiveRecruiterTab;
    } else if (currentRole === 'college') {
      items = collegeNavItems;
      activeTab = activeCollegeTab;
      setTab = setActiveCollegeTab;
    }

    return (
      <div className="hidden lg:flex items-center gap-1">
        {items.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    );
  };

  return (
    <>
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16 gap-4">
            {/* Real App Brand Header */}
            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={() => setCurrentRole('landing')}
                className="flex items-center gap-2.5 text-left group focus:outline-hidden"
              >
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-purple-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xl font-extrabold text-slate-950 tracking-tight font-display flex items-center gap-0.5">
                    NEXIF<span className="text-indigo-600">5</span>
                  </span>
                  <span className="text-[10px] text-slate-500 font-medium tracking-wide uppercase block -mt-1">
                    Career Execution Platform
                  </span>
                </div>
              </button>
            </div>

            {/* Center Navigation links */}
            <nav className="flex-1 flex items-center justify-center">
              {renderNavLinks()}
            </nav>

            {/* Right Controls */}
            <div className="flex items-center gap-2 sm:gap-3 shrink-0">
              {/* Language Selector Button */}
              <button
                type="button"
                onClick={() => setLanguageModalOpen(true)}
                className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors flex items-center gap-1 border border-slate-200/80"
                title="Choose Language"
              >
                <Globe className="w-4 h-4 text-indigo-600" />
                <span className="text-xs font-bold uppercase hidden sm:inline">{currentLanguage}</span>
              </button>

              {/* Logged Out Actions */}
              {currentRole === 'landing' ? (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleOpenAuth('signin')}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-slate-700 hover:text-slate-900 hover:bg-slate-100 transition-colors"
                  >
                    {t('nav.sign_in')}
                  </button>
                  <button
                    onClick={() => handleOpenAuth('signup')}
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs hover:shadow transition-all flex items-center gap-1.5"
                  >
                    <span>{t('nav.get_started')}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                /* Logged In Actions */
                <div className="flex items-center gap-2">
                  {/* Notifications with real badge */}
                  <NotificationCenter />

                  {/* Profile Avatar & Dropdown */}
                  <div className="relative">
                    <button
                      onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                      className="flex items-center gap-2 p-1 rounded-xl hover:bg-slate-100 transition-colors border border-transparent hover:border-slate-200 focus:outline-hidden"
                    >
                      {/* Avatar Image or Initials */}
                      {(currentRole === 'student' || currentRole === 'job_seeker') && (
                        currentStudent?.avatarUrl ? (
                          <img
                            src={currentStudent.avatarUrl}
                            alt={currentStudent.name}
                            className="w-8 h-8 rounded-lg object-cover border border-slate-200"
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shadow-xs">
                            {getInitials(currentStudent?.name || 'Aarav Sharma')}
                          </div>
                        )
                      )}

                      {currentRole === 'recruiter' && (
                        currentCompany?.logoUrl ? (
                          <img
                            src={currentCompany.logoUrl}
                            alt={currentCompany.name}
                            className="w-8 h-8 rounded-lg object-cover border border-slate-200"
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shadow-xs">
                            {getInitials(currentCompany?.name || 'ABC Tech')}
                          </div>
                        )
                      )}

                      {currentRole === 'college' && (
                        currentCollege?.logoUrl ? (
                          <img
                            src={currentCollege.logoUrl}
                            alt={currentCollege.name}
                            className="w-8 h-8 rounded-lg object-cover border border-slate-200"
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-lg bg-purple-600 text-white font-bold text-xs flex items-center justify-center shadow-xs">
                            {getInitials(currentCollege?.name || 'Rathinam')}
                          </div>
                        )
                      )}

                      <div className="hidden sm:block text-left">
                        <p className="text-xs font-bold text-slate-900 leading-tight">
                          {(currentRole === 'student' || currentRole === 'job_seeker') && currentStudent.name}
                          {currentRole === 'recruiter' && currentCompany.name}
                          {currentRole === 'college' && currentCollege.name}
                        </p>
                        <p className="text-[10px] text-slate-500 capitalize">
                          {currentRole === 'student' && (currentStudent.collegeName ? `Student • ${currentStudent.collegeName}` : 'Student Candidate')}
                          {currentRole === 'job_seeker' && 'Job Seeker'}
                          {currentRole === 'recruiter' && 'Talent Recruiter'}
                          {currentRole === 'college' && 'Placement Office'}
                        </p>
                      </div>

                      <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                    </button>

                    {/* Profile Dropdown Menu */}
                    {profileDropdownOpen && (
                      <>
                        <div
                          className="fixed inset-0 z-40"
                          onClick={() => setProfileDropdownOpen(false)}
                        />
                        <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 z-50 p-2 text-xs space-y-1">
                          {/* User Header */}
                          <div className="p-2.5 border-b border-slate-100 mb-1">
                            <p className="font-bold text-slate-900 text-sm">
                              {(currentRole === 'student' || currentRole === 'job_seeker') && currentStudent.name}
                              {currentRole === 'recruiter' && currentCompany.name}
                              {currentRole === 'college' && currentCollege.name}
                            </p>
                            <p className="text-[11px] text-slate-500 font-mono truncate">
                              {(currentRole === 'student' || currentRole === 'job_seeker') && currentStudent.email}
                              {currentRole === 'recruiter' && currentCompany.website}
                              {currentRole === 'college' && currentCollege.location}
                            </p>
                            <span className={`inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              currentRole === 'student' ? 'bg-blue-50 text-blue-700' :
                              currentRole === 'job_seeker' ? 'bg-amber-50 text-amber-800' :
                              currentRole === 'recruiter' ? 'bg-emerald-50 text-emerald-700' :
                              'bg-purple-50 text-purple-700'
                            }`}>
                              {currentRole === 'job_seeker' ? 'Job Seeker' : currentRole.charAt(0).toUpperCase() + currentRole.slice(1)}
                            </span>
                          </div>

                          {/* Menu Items */}
                          <button
                            onClick={() => {
                              if (currentRole === 'student' || currentRole === 'job_seeker') {
                                setActiveStudentTab('profile');
                                setActiveJobSeekerTab('profile');
                              } else if (currentRole === 'recruiter') {
                                setActiveRecruiterTab('company');
                              } else if (currentRole === 'college') {
                                setActiveCollegeTab('overview');
                              }
                              setProfileDropdownOpen(false);
                            }}
                            className="w-full text-left p-2 rounded-xl hover:bg-slate-100 font-semibold text-slate-700 flex items-center gap-2.5"
                          >
                            <User className="w-4 h-4 text-slate-400" />
                            <span>
                              {currentRole === 'recruiter' ? 'Company Profile' :
                               currentRole === 'college' ? 'College Profile' :
                               'View Profile'}
                            </span>
                          </button>

                          <button
                            onClick={() => {
                              if (currentRole === 'student' || currentRole === 'job_seeker') {
                                setActiveStudentTab('dashboard');
                                setActiveJobSeekerTab('dashboard');
                              } else if (currentRole === 'recruiter') {
                                setActiveRecruiterTab('overview');
                              } else if (currentRole === 'college') {
                                setActiveCollegeTab('overview');
                              }
                              setProfileDropdownOpen(false);
                            }}
                            className="w-full text-left p-2 rounded-xl hover:bg-slate-100 font-semibold text-slate-700 flex items-center gap-2.5"
                          >
                            <BarChart3 className="w-4 h-4 text-slate-400" />
                            <span>Dashboard</span>
                          </button>

                          <button
                            onClick={() => {
                              setSettingsModalOpen(true);
                              setProfileDropdownOpen(false);
                            }}
                            className="w-full text-left p-2 rounded-xl hover:bg-slate-100 font-semibold text-slate-700 flex items-center gap-2.5"
                          >
                            <Settings className="w-4 h-4 text-slate-400" />
                            <span>Settings</span>
                          </button>

                          <button
                            onClick={() => {
                              setSettingsModalOpen(true);
                              setProfileDropdownOpen(false);
                            }}
                            className="w-full text-left p-2 rounded-xl hover:bg-slate-100 font-semibold text-slate-700 flex items-center gap-2.5"
                          >
                            <HelpCircle className="w-4 h-4 text-slate-400" />
                            <span>Help & Support</span>
                          </button>

                          <div className="pt-1 border-t border-slate-100">
                            <button
                              onClick={handleLogout}
                              className="w-full text-left p-2 rounded-xl hover:bg-rose-50 font-semibold text-rose-600 flex items-center gap-2.5"
                            >
                              <LogOut className="w-4 h-4 text-rose-500" />
                              <span>Log Out</span>
                            </button>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={settingsModalOpen}
        onClose={() => setSettingsModalOpen(false)}
      />

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authMode}
        onSuccessSignUp={handleSuccessSignUp}
      />

      {/* Career Onboarding Modal */}
      <CareerOnboardingModal
        isOpen={onboardingOpen}
        onClose={() => setOnboardingOpen(false)}
        initialRole={registeredUser.role}
        userEmail={registeredUser.email}
        initialName={registeredUser.name}
      />

      {/* Language Selector Modal */}
      <LanguageSelectorModal
        isOpen={languageModalOpen}
        onClose={() => setLanguageModalOpen(false)}
      />
    </>
  );
};
