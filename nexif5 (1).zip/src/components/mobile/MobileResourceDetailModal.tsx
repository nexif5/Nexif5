import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  FileText,
  Sparkles,
  Bookmark,
  ThumbsUp,
  Download,
  Share2,
  CheckCircle2,
  AlertCircle,
  Eye,
  Layers,
  ArrowRight,
  Shield,
  BookOpen
} from 'lucide-react';

export const MobileResourceDetailModal: React.FC = () => {
  const {
    selectedResourceForDetail,
    setSelectedResourceForDetail,
    savedResourceIds,
    toggleSaveResource,
    markResourceHelpful,
    completeSkillTask,
    sharedResources,
    theme
  } = useApp();

  const [hasCopiedShare, setHasCopiedShare] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [isReported, setIsReported] = useState(false);
  const [hasMarkedHelpful, setHasMarkedHelpful] = useState(false);

  if (!selectedResourceForDetail) return null;

  const resource = selectedResourceForDetail;
  const isLight = theme === 'light';
  const isSaved = savedResourceIds.includes(resource.id);

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setHasCopiedShare(true);
    setTimeout(() => setHasCopiedShare(false), 2200);
  };

  const handleDownload = () => {
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  const handleHelpful = () => {
    if (!hasMarkedHelpful) {
      markResourceHelpful(resource.id);
      setHasMarkedHelpful(true);
    }
  };

  // Find related resources
  const relatedResources = sharedResources
    .filter(r => r.id !== resource.id && (r.skill === resource.skill || r.category === resource.category))
    .slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-slate-950/75 backdrop-blur-xs font-sans">
      {/* Backdrop */}
      <div
        className="flex-1"
        onClick={() => setSelectedResourceForDetail(null)}
      />

      {/* Modal Content */}
      <div className={`rounded-t-3xl border-t p-5 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto transition-colors duration-200 ${
        isLight
          ? 'bg-white border-slate-200 text-slate-900'
          : 'bg-slate-900 border-slate-800 text-white'
      }`}>
        {/* Top Header */}
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 text-[10px] font-bold uppercase tracking-wider">
                {resource.category}
              </span>
              <span className="text-[11px] text-slate-400 font-medium">
                {resource.fileType.toUpperCase()} • {resource.fileSize}
              </span>
            </div>
            <h2 className="text-lg font-bold font-display leading-snug">
              {resource.title}
            </h2>
          </div>

          <button
            onClick={() => setSelectedResourceForDetail(null)}
            className={`p-2 rounded-xl transition-colors ${
              isLight
                ? 'text-slate-500 hover:text-slate-900 bg-slate-100'
                : 'text-slate-400 hover:text-white bg-slate-800'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Uploader Profile Strip */}
        <div className={`p-3 rounded-2xl border flex items-center justify-between ${
          isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/60 border-slate-700/60'
        }`}>
          <div className="flex items-center gap-2.5">
            {resource.uploaderAvatar ? (
              <img
                src={resource.uploaderAvatar}
                alt={resource.uploaderName}
                className="w-10 h-10 rounded-full object-cover border border-indigo-500/30"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-indigo-600/30 text-indigo-400 flex items-center justify-center font-bold text-xs">
                {resource.uploaderName.charAt(0)}
              </div>
            )}
            <div>
              <p className="text-xs font-bold leading-tight flex items-center gap-1.5">
                <span>{resource.uploaderName}</span>
                <span className="text-[10px] font-normal text-slate-400">• Shared {resource.uploadDate}</span>
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">{resource.uploaderRole}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span className="flex items-center gap-1 text-[11px]">
              <Eye className="w-3.5 h-3.5" />
              <span>{resource.viewsCount}</span>
            </span>
            <span className="flex items-center gap-1 text-[11px]">
              <ThumbsUp className="w-3.5 h-3.5 text-indigo-400" />
              <span>{resource.helpfulCount + (hasMarkedHelpful ? 1 : 0)}</span>
            </span>
          </div>
        </div>

        {/* AI Recommendation Reason Banner */}
        {resource.aiRelevanceReason && (
          <div className={`p-3.5 rounded-2xl border ${
            isLight
              ? 'bg-indigo-50/80 border-indigo-200 text-slate-800'
              : 'bg-indigo-950/40 border-indigo-500/30 text-indigo-100'
          }`}>
            <div className="flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-indigo-600/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                  Why NEXIF5 AI Recommends This:
                </p>
                <p className="text-xs mt-0.5 leading-relaxed">
                  {resource.aiRelevanceReason}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Metadata Details Grid */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className={`p-2.5 rounded-xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/50 border-slate-800'}`}>
            <span className="text-[10px] text-slate-400 block font-semibold">SKILL TARGET</span>
            <span className="font-bold text-indigo-600 dark:text-indigo-300">{resource.skill}</span>
          </div>
          <div className={`p-2.5 rounded-xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/50 border-slate-800'}`}>
            <span className="text-[10px] text-slate-400 block font-semibold">CAREER RELEVANCE</span>
            <span className="font-bold">{resource.careerRelevance}</span>
          </div>
        </div>

        {/* Action Buttons Row */}
        <div className="grid grid-cols-4 gap-2 pt-1">
          {/* Save / Bookmark */}
          <button
            onClick={() => toggleSaveResource(resource.id)}
            className={`py-2 px-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all text-xs font-semibold ${
              isSaved
                ? 'bg-indigo-600 border-indigo-600 text-white'
                : isLight
                ? 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
                : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
            }`}
          >
            <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
            <span className="text-[10px]">{isSaved ? 'Saved' : 'Save'}</span>
          </button>

          {/* Mark Helpful */}
          <button
            onClick={handleHelpful}
            disabled={hasMarkedHelpful}
            className={`py-2 px-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all text-xs font-semibold ${
              hasMarkedHelpful
                ? 'bg-emerald-600 border-emerald-600 text-white'
                : isLight
                ? 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
                : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
            }`}
          >
            <ThumbsUp className="w-4 h-4" />
            <span className="text-[10px]">{hasMarkedHelpful ? 'Helpful!' : 'Helpful'}</span>
          </button>

          {/* Download */}
          <button
            onClick={handleDownload}
            className={`py-2 px-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all text-xs font-semibold ${
              downloadSuccess
                ? 'bg-emerald-600 border-emerald-600 text-white'
                : isLight
                ? 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
                : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
            }`}
          >
            <Download className="w-4 h-4" />
            <span className="text-[10px]">{downloadSuccess ? 'Done' : 'Download'}</span>
          </button>

          {/* Share */}
          <button
            onClick={handleShare}
            className={`py-2 px-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all text-xs font-semibold ${
              hasCopiedShare
                ? 'bg-indigo-600 border-indigo-600 text-white'
                : isLight
                ? 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
                : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
            }`}
          >
            <Share2 className="w-4 h-4" />
            <span className="text-[10px]">{hasCopiedShare ? 'Copied' : 'Share'}</span>
          </button>
        </div>

        {downloadSuccess && (
          <p className="text-center text-xs text-emerald-500 font-semibold animate-pulse">
            ✓ Document saved to local downloads.
          </p>
        )}

        {/* Document Description */}
        <div className="space-y-1.5">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            About this Resource
          </h4>
          <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-300">
            {resource.description}
          </p>
        </div>

        {/* Content Outline */}
        {resource.contentOutline && resource.contentOutline.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5" />
              <span>Chapters & Table of Contents</span>
            </h4>
            <div className={`p-3 rounded-2xl border space-y-1.5 text-xs ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/50 border-slate-700/60'
            }`}>
              {resource.contentOutline.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Live Document Preview Viewer */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
              <span>Document Reading Preview</span>
            </h4>
            <span className="text-[10px] text-indigo-500 font-semibold">Page 1-3 Excerpt</span>
          </div>

          <div className={`p-4 rounded-2xl border font-mono text-[11px] leading-relaxed whitespace-pre-wrap max-h-56 overflow-y-auto select-text shadow-inner ${
            isLight
              ? 'bg-slate-100 border-slate-300 text-slate-800'
              : 'bg-slate-950 border-slate-800 text-slate-300'
          }`}>
            {resource.previewSnippet}
          </div>
        </div>

        {/* Practical Action Task Connected to Resource */}
        {resource.practicalTaskTitle && (
          <div className={`p-4 rounded-2xl border space-y-2.5 ${
            isLight
              ? 'bg-emerald-50/70 border-emerald-200 text-slate-900'
              : 'bg-emerald-950/30 border-emerald-500/30 text-white'
          }`}>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-500 flex items-center justify-center font-bold text-xs">
                ✓
              </div>
              <h4 className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                Recommended Practical Task
              </h4>
            </div>
            <p className="text-xs font-semibold">
              {resource.practicalTaskTitle}
            </p>
            <p className="text-[11px] text-slate-600 dark:text-slate-400">
              Apply what you read in this document by completing this exercise to advance your skill progress and boost your AI Career Readiness.
            </p>
            <button
              onClick={() => {
                completeSkillTask(resource.skill);
                setSelectedResourceForDetail(null);
              }}
              className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all active:scale-98 flex items-center justify-center gap-1.5"
            >
              <span>Mark Practical Task Completed</span>
              <CheckCircle2 className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Tags */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {resource.tags.map((tag, idx) => (
            <span
              key={idx}
              className={`px-2 py-0.5 rounded-full text-[10px] font-medium border ${
                isLight
                  ? 'bg-slate-100 border-slate-200 text-slate-600'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
            >
              #{tag}
            </span>
          ))}
        </div>

        {/* Related Resources */}
        {relatedResources.length > 0 && (
          <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Related Learning Resources
            </h4>
            <div className="space-y-1.5">
              {relatedResources.map((rel) => (
                <button
                  key={rel.id}
                  onClick={() => setSelectedResourceForDetail(rel)}
                  className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-colors ${
                    isLight
                      ? 'bg-slate-50 hover:bg-slate-100 border-slate-200'
                      : 'bg-slate-800/60 hover:bg-slate-800 border-slate-700'
                  }`}
                >
                  <div className="truncate pr-2">
                    <p className="text-xs font-bold truncate">{rel.title}</p>
                    <p className="text-[10px] text-slate-400">{rel.skill} • {rel.uploaderName}</p>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Moderation / Privacy footer */}
        <div className="pt-2 text-center">
          <button
            onClick={() => setIsReported(true)}
            disabled={isReported}
            className="text-[10px] text-slate-400 hover:text-rose-400 transition-colors inline-flex items-center gap-1"
          >
            <Shield className="w-3 h-3" />
            <span>{isReported ? 'Report Submitted for Moderation' : 'Report inappropriate educational content'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
