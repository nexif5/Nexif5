import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CompanyOrganization, JobOpportunity } from '../../types';
import { JobDetailModal } from '../common/JobDetailModal';
import { JobApplyModal } from '../common/JobApplyModal';
import {
  Building2,
  Search,
  MapPin,
  Globe,
  Briefcase,
  Users,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  ExternalLink
} from 'lucide-react';

export const StudentCompanySearch: React.FC = () => {
  const { companies, jobs, currentStudent } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCompany, setSelectedCompany] = useState<CompanyOrganization | null>(companies[0]);
  const [detailJob, setDetailJob] = useState<JobOpportunity | null>(null);
  const [applyJob, setApplyJob] = useState<JobOpportunity | null>(null);

  const filteredCompanies = companies.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.industry.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.headquarters.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const activeCompanyJobs = selectedCompany
    ? jobs.filter(j => j.companyId === selectedCompany.id && j.isOpen)
    : [];

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
          <Building2 className="w-4 h-4" />
          <span>DIRECT CORPORATE DIRECTORY</span>
        </div>
        <h1 className="text-2xl font-bold text-slate-900 font-display">
          Search Hiring Companies
        </h1>
        <p className="text-xs text-slate-500">
          Discover verified hiring partners and explore active openings directly with or without a college
        </p>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 Cols): Companies List */}
        <div className="lg:col-span-5 space-y-3">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search companies by name, industry, or HQ..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
            />
          </div>

          {/* Companies scroll list */}
          <div className="space-y-2 max-h-[70vh] overflow-y-auto pr-1">
            {filteredCompanies.map((comp) => {
              const isSelected = selectedCompany?.id === comp.id;
              const companyOpenings = jobs.filter(j => j.companyId === comp.id && j.isOpen).length;

              return (
                <div
                  key={comp.id}
                  onClick={() => setSelectedCompany(comp)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                    isSelected
                      ? 'bg-white border-indigo-500 shadow-md ring-2 ring-indigo-500/10'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                  }`}
                >
                  <img
                    src={comp.logoUrl}
                    alt={comp.name}
                    className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0"
                  />
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-slate-900 text-sm truncate">{comp.name}</h3>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                        {companyOpenings} {companyOpenings === 1 ? 'Job' : 'Jobs'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 truncate">{comp.industry}</p>
                    <p className="text-[11px] text-slate-400 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-300" /> {comp.headquarters}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (7 Cols): Selected Company Profile & Openings */}
        <div className="lg:col-span-7">
          {selectedCompany ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
              {/* Company Header */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                <div className="flex items-center gap-4">
                  <img
                    src={selectedCompany.logoUrl}
                    alt={selectedCompany.name}
                    className="w-16 h-16 rounded-2xl object-cover border border-slate-200 shadow-xs"
                  />
                  <div>
                    <h2 className="text-xl font-bold text-slate-900 font-display">
                      {selectedCompany.name}
                    </h2>
                    <p className="text-xs text-indigo-600 font-medium">{selectedCompany.industry}</p>
                    <p className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" /> {selectedCompany.headquarters}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Users className="w-3.5 h-3.5 text-slate-400" /> {selectedCompany.companySize} employees
                      </span>
                    </p>
                  </div>
                </div>

                <a
                  href={`https://${selectedCompany.website}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 hover:text-indigo-600 hover:bg-slate-50 text-xs font-semibold flex items-center gap-1.5 transition-colors self-start sm:self-center"
                >
                  <Globe className="w-3.5 h-3.5" />
                  <span>Website</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              </div>

              {/* Description & Culture */}
              <div className="space-y-3">
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider text-slate-500">
                  About the Organization
                </h4>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {selectedCompany.description}
                </p>

                {/* Benefits / Culture Tags */}
                {selectedCompany.benefits && selectedCompany.benefits.length > 0 && (
                  <div className="pt-2">
                    <span className="text-[11px] font-semibold text-slate-700 block mb-1.5">
                      Company Benefits & Work Environment:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedCompany.benefits.map((b, i) => (
                        <span
                          key={i}
                          className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 text-xs font-medium border border-emerald-100"
                        >
                          ✦ {b}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Available Job Postings */}
              <div className="pt-4 border-t border-slate-100 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 text-sm font-display flex items-center gap-2">
                    <Briefcase className="w-4 h-4 text-indigo-600" />
                    <span>Open Positions at {selectedCompany.name} ({activeCompanyJobs.length})</span>
                  </h4>
                  <span className="text-xs text-slate-400">Direct Application Enabled</span>
                </div>

                {activeCompanyJobs.length > 0 ? (
                  <div className="space-y-3">
                    {activeCompanyJobs.map((job) => (
                      <div
                        key={job.id}
                        className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:border-indigo-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <strong className="text-slate-900 font-bold text-sm">{job.title}</strong>
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              job.type === 'internship' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                            }`}>
                              {job.type}
                            </span>
                          </div>
                          <div className="flex flex-wrap items-center gap-2 text-slate-500 text-[11px]">
                            <span className="text-emerald-700 font-bold">{job.salaryDisplay}</span>
                            <span>•</span>
                            <span>{job.location} ({job.workMode})</span>
                            <span>•</span>
                            <span>Deadline: {job.applicationDeadline}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setDetailJob(job)}
                            className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 font-semibold"
                          >
                            Details
                          </button>
                          <button
                            onClick={() => setApplyJob(job)}
                            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold shadow-xs transition-colors"
                          >
                            Apply Now
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-slate-100">
                    <p>No active requisitions posted by this company today.</p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="p-12 text-center text-xs text-slate-500 bg-white rounded-2xl border border-slate-200">
              Select a company from the list to view profile and opportunities.
            </div>
          )}
        </div>
      </div>

      {detailJob && (
        <JobDetailModal
          job={detailJob}
          onClose={() => setDetailJob(null)}
        />
      )}

      {applyJob && (
        <JobApplyModal
          job={applyJob}
          onClose={() => setApplyJob(null)}
        />
      )}
    </div>
  );
};
