import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, ShieldCheck, Lock, Mail, AlertCircle, KeyRound, Check } from 'lucide-react';

export const AdminLoginScreen: React.FC = () => {
  const { setAuthState, setCurrentRole, setActiveAdminTab } = useApp();

  const [adminEmail, setAdminEmail] = useState('admin@nexif5.io');
  const [adminPassword, setAdminPassword] = useState('AdminRoot2026!');
  const [mfaCode, setMfaCode] = useState('892410');
  const [errorMessage, setErrorMessage] = useState('');

  const handleAdminSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!adminEmail.includes('@') || !adminPassword) {
      setErrorMessage('Please provide valid admin credentials.');
      return;
    }

    setCurrentRole('admin');
    setActiveAdminTab('overview');
    setAuthState('authenticated');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-between px-5 py-6 font-sans">
      <div>
        {/* Top Header */}
        <div className="flex items-center gap-3 mb-6">
          <button
            onClick={() => setAuthState('account_type')}
            className="p-2 -ml-1 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition-colors active:scale-95"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-extrabold text-white font-display">
                NEXIF5 Admin Portal
              </h1>
              <span className="px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[10px] font-bold uppercase tracking-wider">
                Restricted
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Platform Governance, Audits & User Control
            </p>
          </div>
        </div>

        {/* Security Alert Banner */}
        <div className="mb-4 p-3 rounded-2xl bg-slate-900 border border-rose-500/30 text-xs flex items-center gap-3">
          <div className="p-2 rounded-xl bg-rose-500/15 text-rose-400 shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <p className="font-bold text-rose-300">Admin Clearance Required</p>
            <p className="text-[11px] text-slate-400">
              Authorized personnel only. Sessions are cryptographically audited.
            </p>
          </div>
        </div>

        {errorMessage && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleAdminSignIn} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Admin Identity Email
            </label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="email"
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-hidden focus:border-rose-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Security Token / Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-hidden focus:border-rose-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              MFA Hardware Key / Passcode
            </label>
            <div className="relative">
              <KeyRound className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={mfaCode}
                onChange={(e) => setMfaCode(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white tracking-widest font-mono"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3.5 px-6 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-sm shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Authenticate & Enter Admin Console</span>
            </button>
          </div>
        </form>

        {/* Demo Fast Fill */}
        <div className="mt-4 p-3 bg-slate-900/60 border border-slate-800 rounded-xl text-center">
          <p className="text-[11px] text-slate-400">
            Evaluating Admin View? Credentials pre-filled above.
          </p>
        </div>
      </div>

      <div className="pt-4 text-center">
        <button
          onClick={() => setAuthState('login')}
          className="text-xs text-slate-500 hover:text-slate-300 transition-colors"
        >
          Return to Standard Sign In
        </button>
      </div>
    </div>
  );
};
