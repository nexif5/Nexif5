import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import {
  Settings,
  X,
  User,
  Shield,
  Bell,
  Lock,
  Eye,
  Sliders,
  Globe,
  HelpCircle,
  Smartphone,
  Laptop,
  Check,
  Download,
  AlertTriangle,
  Moon,
  Sun,
  Monitor,
  Trash2,
  LogOut,
  Sparkles
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type SettingsTab =
  | 'account'
  | 'profile'
  | 'notifications'
  | 'privacy'
  | 'security'
  | 'appearance'
  | 'language'
  | 'help';

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const {
    currentRole,
    currentStudent,
    currentCompany,
    currentCollege,
    updateStudentProfile,
    setCurrentRole
  } = useApp();

  const [activeTab, setActiveTab] = useState<SettingsTab>('account');
  const [saveToast, setSaveToast] = useState(false);

  // Form states
  const [name, setName] = useState(currentStudent?.name || '');
  const [email, setEmail] = useState(currentStudent?.email || '');
  const [phone, setPhone] = useState(currentStudent?.phone || '');
  const [careerGoal, setCareerGoal] = useState(currentStudent?.careerGoal || '');
  const [minLPA, setMinLPA] = useState(currentStudent?.salaryPreferenceMinLPA || 6);
  const [maxLPA, setMaxLPA] = useState(currentStudent?.salaryPreferenceMaxLPA || 12);
  const [profileVisibility, setProfileVisibility] = useState<'public' | 'verified_only' | 'private'>('verified_only');
  const [resumeVisibility, setResumeVisibility] = useState(true);

  // Notification toggles
  const [notifJobMatches, setNotifJobMatches] = useState(true);
  const [notifAppUpdates, setNotifAppUpdates] = useState(true);
  const [notifInterviews, setNotifInterviews] = useState(true);
  const [notifRecruiterMsgs, setNotifRecruiterMsgs] = useState(true);
  const [notifAIRecommendations, setNotifAIRecommendations] = useState(true);

  // Privacy toggles
  const [allowRecruiterDirectAccess, setAllowRecruiterDirectAccess] = useState(true);
  const [allowCollegeSync, setAllowCollegeSync] = useState(Boolean(currentStudent?.collegeId));
  const [allowDataAnalyticsSharing, setAllowDataAnalyticsSharing] = useState(true);

  // Appearance & Accessibility
  const [themeMode, setThemeMode] = useState<'light' | 'dark' | 'system'>('light');
  const [textSize, setTextSize] = useState<'normal' | 'large'>('normal');
  const [highContrast, setHighContrast] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [preferredLang, setPreferredLang] = useState('en');

  // Security password fields
  const [currentPwd, setCurrentPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');

  if (!isOpen) return null;

  const handleSavePreferences = () => {
    if (currentRole === 'student' || currentRole === 'job_seeker') {
      updateStudentProfile({
        name,
        email,
        phone,
        careerGoal,
        salaryPreferenceMinLPA: minLPA,
        salaryPreferenceMaxLPA: maxLPA
      });
    }
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 2500);
  };

  const navItems = [
    { id: 'account', label: 'Account & Info', icon: <User className="w-4 h-4" /> },
    { id: 'profile', label: 'Profile & Career', icon: <Sliders className="w-4 h-4" /> },
    { id: 'notifications', label: 'Notifications', icon: <Bell className="w-4 h-4" /> },
    { id: 'privacy', label: 'Privacy & Access', icon: <Eye className="w-4 h-4" /> },
    { id: 'security', label: 'Security & Sessions', icon: <Lock className="w-4 h-4" /> },
    { id: 'appearance', label: 'Appearance & UI', icon: <Sun className="w-4 h-4" /> },
    { id: 'language', label: 'Language & A11y', icon: <Globe className="w-4 h-4" /> },
    { id: 'help', label: 'Help & Support', icon: <HelpCircle className="w-4 h-4" /> }
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden z-10 flex flex-col max-h-[90vh] my-auto"
        >
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70 shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-sm">
                <Settings className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-base">Nexif5 System Settings</h3>
                <p className="text-xs text-slate-500">Configure account parameters, notifications, security & display</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
              aria-label="Close settings"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Main Body */}
          <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
            {/* Sidebar Navigation */}
            <div className="w-full md:w-60 border-b md:border-b-0 md:border-r border-slate-100 p-3 bg-slate-50/50 flex md:flex-col gap-1 overflow-x-auto md:overflow-y-auto shrink-0">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as SettingsTab)}
                  className={`px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2.5 transition-all text-left whitespace-nowrap ${
                    activeTab === item.id
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              ))}
            </div>

            {/* Content Area */}
            <div className="flex-1 p-5 sm:p-7 overflow-y-auto space-y-6">
              {/* Toast Feedback */}
              {saveToast && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-2"
                >
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Settings updated successfully!</span>
                </motion.div>
              )}

              {/* 1. Account Section */}
              {activeTab === 'account' && (
                <div className="space-y-5">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">Personal & Account Information</h4>
                    <p className="text-xs text-slate-500">Manage your primary contact and personal credentials</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700">Full Name</label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700">Email Address</label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700">Phone Number</label>
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700">Account Role</label>
                      <input
                        type="text"
                        disabled
                        value={
                          currentRole === 'student' ? 'Student Candidate' :
                          currentRole === 'job_seeker' ? 'General Job Seeker' :
                          currentRole === 'recruiter' ? 'Recruiter / Talent Acquisition' :
                          'College Placement Office'
                        }
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 bg-slate-100 text-slate-500 text-xs font-medium cursor-not-allowed"
                      />
                    </div>
                  </div>

                  {/* Connected Accounts */}
                  <div className="pt-4 border-t border-slate-100 space-y-3">
                    <h5 className="font-bold text-slate-900 text-xs">Connected Accounts</h5>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-white">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xs">
                            G
                          </div>
                          <div>
                            <p className="font-bold text-slate-900 text-xs">Google Account</p>
                            <p className="text-[11px] text-slate-500 font-mono">{email || 'connected@gmail.com'}</p>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold">
                          Connected
                        </span>
                      </div>

                      <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-white">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-xs">
                            GH
                          </div>
                          <div>
                            <p className="font-bold text-slate-900 text-xs">GitHub Profile</p>
                            <p className="text-[11px] text-slate-500">github.com/developer</p>
                          </div>
                        </div>
                        <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800">
                          Sync
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Data & Deactivation */}
                  <div className="pt-4 border-t border-slate-100 space-y-3">
                    <h5 className="font-bold text-slate-900 text-xs">Data & Account Actions</h5>
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => alert('Your data archive has been generated and queued for download.')}
                        className="px-3.5 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center gap-2"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download Personal Archive</span>
                      </button>

                      <button
                        onClick={() => {
                          if (confirm('Are you sure you want to deactivate your account temporarily?')) {
                            setCurrentRole('landing');
                            onClose();
                          }
                        }}
                        className="px-3.5 py-2 rounded-xl border border-rose-200 hover:bg-rose-50 text-rose-700 font-bold text-xs flex items-center gap-2"
                      >
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>Deactivate Account</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* 2. Profile & Career Preferences */}
              {activeTab === 'profile' && (
                <div className="space-y-5">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">Career Preferences & Targeting</h4>
                    <p className="text-xs text-slate-500">Fine-tune your salary range and visibility to hiring managers</p>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700">Primary Career Ambition</label>
                      <input
                        type="text"
                        value={careerGoal}
                        onChange={(e) => setCareerGoal(e.target.value)}
                        placeholder="e.g. Business Analyst, Full Stack Developer"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-700">Minimum Target CTC (LPA)</label>
                        <input
                          type="number"
                          value={minLPA}
                          onChange={(e) => setMinLPA(Number(e.target.value))}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-700">Maximum Target CTC (LPA)</label>
                        <input
                          type="number"
                          value={maxLPA}
                          onChange={(e) => setMaxLPA(Number(e.target.value))}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs"
                        />
                      </div>
                    </div>

                    <div className="space-y-2 pt-2">
                      <label className="text-xs font-bold text-slate-700 block">Candidate Profile Visibility</label>
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        <button
                          type="button"
                          onClick={() => setProfileVisibility('public')}
                          className={`p-3 rounded-xl border text-left transition-all ${
                            profileVisibility === 'public'
                              ? 'border-indigo-600 bg-indigo-50 text-indigo-900 font-bold shadow-xs'
                              : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <span className="block font-bold text-xs">Public</span>
                          <span className="text-[10px] text-slate-500 block mt-0.5">Discoverable by all employers</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setProfileVisibility('verified_only')}
                          className={`p-3 rounded-xl border text-left transition-all ${
                            profileVisibility === 'verified_only'
                              ? 'border-indigo-600 bg-indigo-50 text-indigo-900 font-bold shadow-xs'
                              : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <span className="block font-bold text-xs">Verified Recruiters</span>
                          <span className="text-[10px] text-slate-500 block mt-0.5">Only audited hiring partners</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setProfileVisibility('private')}
                          className={`p-3 rounded-xl border text-left transition-all ${
                            profileVisibility === 'private'
                              ? 'border-indigo-600 bg-indigo-50 text-indigo-900 font-bold shadow-xs'
                              : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <span className="block font-bold text-xs">Incognito</span>
                          <span className="text-[10px] text-slate-500 block mt-0.5">Only when you apply directly</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 3. Notifications */}
              {activeTab === 'notifications' && (
                <div className="space-y-5">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">Notification Channels & Alerts</h4>
                    <p className="text-xs text-slate-500">Choose what updates you want to receive immediately</p>
                  </div>

                  <div className="space-y-3">
                    {[
                      {
                        label: 'Real-time Job Matches',
                        desc: 'Receive alerts whenever a job fits your career goal and skills >80%',
                        val: notifJobMatches,
                        setVal: setNotifJobMatches
                      },
                      {
                        label: 'Application Status Updates',
                        desc: 'Get notified when an employer reviews, shortlists, or advances your application',
                        val: notifAppUpdates,
                        setVal: setNotifAppUpdates
                      },
                      {
                        label: 'Interview Schedule Reminders',
                        desc: 'Alerts 24 hours and 1 hour before scheduled technical interviews',
                        val: notifInterviews,
                        setVal: setNotifInterviews
                      },
                      {
                        label: 'Direct Recruiter Inquiries',
                        desc: 'Allow verified recruiters to message you directly about tailored opportunities',
                        val: notifRecruiterMsgs,
                        setVal: setNotifRecruiterMsgs
                      },
                      {
                        label: 'AI Career Coach Recommendations',
                        desc: 'Suggestions on high-ROI skill certifications and resume tweaks',
                        val: notifAIRecommendations,
                        setVal: setNotifAIRecommendations
                      }
                    ].map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 bg-white hover:bg-slate-50/80 transition-colors"
                      >
                        <div className="pr-4">
                          <p className="font-bold text-slate-900 text-xs">{item.label}</p>
                          <p className="text-[11px] text-slate-500 mt-0.5">{item.desc}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => item.setVal(!item.val)}
                          className={`w-11 h-6 rounded-full transition-colors relative shrink-0 ${
                            item.val ? 'bg-indigo-600' : 'bg-slate-300'
                          }`}
                        >
                          <span
                            className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                              item.val ? 'left-6' : 'left-1'
                            }`}
                          />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 4. Privacy & Access */}
              {activeTab === 'privacy' && (
                <div className="space-y-5">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">Privacy & Institutional Access</h4>
                    <p className="text-xs text-slate-500">Control who can access your academic and resume data</p>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 bg-white">
                      <div className="pr-4">
                        <p className="font-bold text-slate-900 text-xs">Direct Recruiter Outreach</p>
                        <p className="text-[11px] text-slate-500">Allow companies to contact you without submitting an application first</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setAllowRecruiterDirectAccess(!allowRecruiterDirectAccess)}
                        className={`w-11 h-6 rounded-full transition-colors relative shrink-0 ${
                          allowRecruiterDirectAccess ? 'bg-indigo-600' : 'bg-slate-300'
                        }`}
                      >
                        <span
                          className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                            allowRecruiterDirectAccess ? 'left-6' : 'left-1'
                          }`}
                        />
                      </button>
                    </div>

                    <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 bg-white">
                      <div className="pr-4">
                        <p className="font-bold text-slate-900 text-xs">College Placement Cell Sync</p>
                        <p className="text-[11px] text-slate-500">Allow your college placement officers to see your placement status & stats</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setAllowCollegeSync(!allowCollegeSync)}
                        className={`w-11 h-6 rounded-full transition-colors relative shrink-0 ${
                          allowCollegeSync ? 'bg-indigo-600' : 'bg-slate-300'
                        }`}
                      >
                        <span
                          className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                            allowCollegeSync ? 'left-6' : 'left-1'
                          }`}
                        />
                      </button>
                    </div>

                    <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 bg-white">
                      <div className="pr-4">
                        <p className="font-bold text-slate-900 text-xs">Anonymized Career Trends Data</p>
                        <p className="text-[11px] text-slate-500">Contribute anonymized skill gap telemetry to improve AI recommendations</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setAllowDataAnalyticsSharing(!allowDataAnalyticsSharing)}
                        className={`w-11 h-6 rounded-full transition-colors relative shrink-0 ${
                          allowDataAnalyticsSharing ? 'bg-indigo-600' : 'bg-slate-300'
                        }`}
                      >
                        <span
                          className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                            allowDataAnalyticsSharing ? 'left-6' : 'left-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* 5. Security & Sessions */}
              {activeTab === 'security' && (
                <div className="space-y-5">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">Security & Active Device Sessions</h4>
                    <p className="text-xs text-slate-500">Update password and monitor authorized login sessions</p>
                  </div>

                  {/* Change Password */}
                  <div className="space-y-3 p-4 rounded-2xl border border-slate-200 bg-slate-50/50">
                    <h5 className="font-bold text-slate-900 text-xs">Change Password</h5>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                      <input
                        type="password"
                        placeholder="Current Password"
                        value={currentPwd}
                        onChange={(e) => setCurrentPwd(e.target.value)}
                        className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs"
                      />
                      <input
                        type="password"
                        placeholder="New Password"
                        value={newPwd}
                        onChange={(e) => setNewPwd(e.target.value)}
                        className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs"
                      />
                      <input
                        type="password"
                        placeholder="Confirm New Password"
                        value={confirmPwd}
                        onChange={(e) => setConfirmPwd(e.target.value)}
                        className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs"
                      />
                    </div>
                    <button
                      onClick={() => {
                        if (newPwd && newPwd === confirmPwd) {
                          alert('Password updated successfully.');
                          setCurrentPwd('');
                          setNewPwd('');
                          setConfirmPwd('');
                        } else {
                          alert('Please enter matching new passwords.');
                        }
                      }}
                      className="px-4 py-2 rounded-xl bg-slate-900 text-white font-bold text-xs hover:bg-slate-800"
                    >
                      Update Password
                    </button>
                  </div>

                  {/* Active Sessions */}
                  <div className="space-y-3 pt-2">
                    <div className="flex items-center justify-between">
                      <h5 className="font-bold text-slate-900 text-xs">Active Sessions</h5>
                      <button
                        onClick={() => alert('All other devices have been signed out.')}
                        className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
                      >
                        Sign Out Other Sessions
                      </button>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-white">
                        <div className="flex items-center gap-3">
                          <Laptop className="w-5 h-5 text-indigo-600" />
                          <div>
                            <p className="font-bold text-slate-900 text-xs">Chrome on macOS (Current)</p>
                            <p className="text-[11px] text-slate-500">Bengaluru, India • IP: 106.51.72.19</p>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold">
                          Active Now
                        </span>
                      </div>

                      <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-white">
                        <div className="flex items-center gap-3">
                          <Smartphone className="w-5 h-5 text-slate-500" />
                          <div>
                            <p className="font-bold text-slate-900 text-xs">Nexif5 Mobile on iPhone 15 Pro</p>
                            <p className="text-[11px] text-slate-500">Coimbatore, India • 2 hours ago</p>
                          </div>
                        </div>
                        <button
                          onClick={() => alert('Device session revoked.')}
                          className="text-[11px] text-rose-600 hover:text-rose-800 font-semibold"
                        >
                          Revoke
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 6. Appearance */}
              {activeTab === 'appearance' && (
                <div className="space-y-5">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">Visual Theme & Interface Display</h4>
                    <p className="text-xs text-slate-500">Customize how Nexif5 looks on your screen</p>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-700 block">Color Theme</label>
                      <div className="grid grid-cols-3 gap-3">
                        <button
                          type="button"
                          onClick={() => setThemeMode('light')}
                          className={`p-3.5 rounded-2xl border flex flex-col items-center gap-2 transition-all ${
                            themeMode === 'light'
                              ? 'border-indigo-600 bg-indigo-50/80 text-indigo-900 font-bold shadow-xs'
                              : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <Sun className="w-5 h-5 text-amber-500" />
                          <span className="text-xs font-bold">Light Mode</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setThemeMode('dark')}
                          className={`p-3.5 rounded-2xl border flex flex-col items-center gap-2 transition-all ${
                            themeMode === 'dark'
                              ? 'border-indigo-600 bg-indigo-50/80 text-indigo-900 font-bold shadow-xs'
                              : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <Moon className="w-5 h-5 text-indigo-600" />
                          <span className="text-xs font-bold">Dark Mode</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setThemeMode('system')}
                          className={`p-3.5 rounded-2xl border flex flex-col items-center gap-2 transition-all ${
                            themeMode === 'system'
                              ? 'border-indigo-600 bg-indigo-50/80 text-indigo-900 font-bold shadow-xs'
                              : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <Monitor className="w-5 h-5 text-slate-600" />
                          <span className="text-xs font-bold">System Default</span>
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-2">
                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-700">Display Text Size</label>
                        <select
                          value={textSize}
                          onChange={(e) => setTextSize(e.target.value as 'normal' | 'large')}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs bg-white"
                        >
                          <option value="normal">Normal (14px baseline)</option>
                          <option value="large">Large (+15% scale)</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-700">Motion & Transitions</label>
                        <button
                          type="button"
                          onClick={() => setReducedMotion(!reducedMotion)}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs bg-white flex items-center justify-between text-left"
                        >
                          <span>{reducedMotion ? 'Reduced Motion (Active)' : 'Standard Motion'}</span>
                          <span className={`w-2 h-2 rounded-full ${reducedMotion ? 'bg-indigo-600' : 'bg-slate-300'}`} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 7. Language & Accessibility */}
              {activeTab === 'language' && (
                <div className="space-y-5">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">Language & Accessibility</h4>
                    <p className="text-xs text-slate-500">Adjust language preferences and high-contrast styling</p>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-700">Preferred Platform Language</label>
                      <select
                        value={preferredLang}
                        onChange={(e) => setPreferredLang(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs bg-white"
                      >
                        <option value="en">English (Global)</option>
                        <option value="hi">हिंदी (Hindi)</option>
                        <option value="ta">தமிழ் (Tamil)</option>
                        <option value="es">Español (Spanish)</option>
                        <option value="de">Deutsch (German)</option>
                        <option value="fr">Français (French)</option>
                      </select>
                    </div>

                    <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 bg-white">
                      <div className="pr-4">
                        <p className="font-bold text-slate-900 text-xs">High Contrast Mode</p>
                        <p className="text-[11px] text-slate-500">Increases border and text distinction for maximum legibility</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setHighContrast(!highContrast)}
                        className={`w-11 h-6 rounded-full transition-colors relative shrink-0 ${
                          highContrast ? 'bg-indigo-600' : 'bg-slate-300'
                        }`}
                      >
                        <span
                          className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                            highContrast ? 'left-6' : 'left-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* 8. Help & Support */}
              {activeTab === 'help' && (
                <div className="space-y-5">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">Help Center & Support Resources</h4>
                    <p className="text-xs text-slate-500">Need assistance? Explore guides or reach out directly</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-4 rounded-2xl border border-slate-200 bg-white space-y-2">
                      <h5 className="font-bold text-slate-900 text-xs">Nexif5 Documentation</h5>
                      <p className="text-[11px] text-slate-500">Learn how our deterministic AI matching engine calculates scores.</p>
                      <button
                        onClick={() => alert('Opening Nexif5 Knowledge Base...')}
                        className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
                      >
                        Read Guides →
                      </button>
                    </div>

                    <div className="p-4 rounded-2xl border border-slate-200 bg-white space-y-2">
                      <h5 className="font-bold text-slate-900 text-xs">Report a Problem</h5>
                      <p className="text-[11px] text-slate-500">Encountered an issue or glitch? Submit a direct ticket.</p>
                      <button
                        onClick={() => alert('Feedback ticket submitted to engineering team.')}
                        className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
                      >
                        Submit Ticket →
                      </button>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200/80 space-y-2">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-indigo-600" />
                      <h5 className="font-bold text-indigo-950 text-xs">Direct Support Contact</h5>
                    </div>
                    <p className="text-xs text-indigo-900">
                      Our support team is available 24/7 at <strong className="font-mono">support@nexif5.com</strong>
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Footer Save & Close */}
          <div className="p-4 sm:p-5 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-3 shrink-0">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-200/60 font-semibold text-slate-700 text-xs transition-colors"
            >
              Close
            </button>

            <button
              onClick={handleSavePreferences}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-sm hover:shadow transition-all flex items-center gap-2 active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>Save Changes</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
