import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { handleCollegeAIQuery } from '../../services/aiEngine';
import {
  Bot,
  Sparkles,
  Send,
  Lightbulb,
  School,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';

export const CollegeAIAdvisor: React.FC = () => {
  const { currentCollege, students, jobs } = useApp();

  const [inputQuery, setInputQuery] = useState('');

  const promptSuggestions = [
    'Which department needs urgent training?',
    'Which companies hire for Business Analyst?',
    'Predict 2025 placement rate',
    'How to improve placement by 15%?',
    'Suggest skills for next semester curriculum'
  ];

  const [chatLog, setChatLog] = useState<{
    id: string;
    sender: 'user' | 'ai';
    text: string;
    metrics?: any;
    actions?: string[];
  }[]>([
    {
      id: 'c-init',
      sender: 'ai',
      text: `Greetings **${currentCollege.name} Placement Cell**!\n\nI am your **Nexif5 AI Institutional Placement Advisor**.\n\nI continuously monitor hiring requirements across corporate recruiters and compare them with your enrolled student skill matrices to provide real-time curriculum optimization and placement predictions.\n\nHow can I assist your placement cell today?`,
      actions: [
        'Which department needs urgent training?',
        'Predict 2025 placement rate',
        'Which companies hire for Business Analyst?'
      ]
    }
  ]);

  const handleSend = (textToSend?: string) => {
    const q = textToSend || inputQuery;
    if (!q.trim()) return;

    setChatLog(prev => [
      ...prev,
      { id: `user-${Date.now()}`, sender: 'user', text: q }
    ]);
    if (!textToSend) setInputQuery('');

    setTimeout(() => {
      const response = handleCollegeAIQuery(q, currentCollege, students, jobs);
      setChatLog(prev => [
        ...prev,
        {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: response.answer,
          actions: response.actions
        }
      ]);
    }, 400);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-purple-600 mb-1">
          <Bot className="w-4 h-4" />
          <span>INSTITUTIONAL AI STRATEGIC ADVISOR</span>
        </div>
        <h1 className="text-2xl font-bold text-slate-900 font-display">
          Placement Intelligence & Curriculum AI
        </h1>
        <p className="text-xs text-slate-500">
          Predictive placement analytics and actionable department training recommendations
        </p>
      </div>

      {/* Suggested Chips */}
      <div className="flex flex-wrap gap-2">
        {promptSuggestions.map((sug, i) => (
          <button
            key={i}
            onClick={() => handleSend(sug)}
            className="px-3 py-1.5 rounded-xl bg-white hover:bg-purple-50 border border-slate-200 hover:border-purple-300 text-xs font-semibold text-slate-700 hover:text-purple-700 transition-all shadow-2xs flex items-center gap-1.5"
          >
            <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
            <span>{sug}</span>
          </button>
        ))}
      </div>

      {/* Chat Container */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col h-[650px] overflow-hidden">
        {/* Messages */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-5">
          {chatLog.map((item) => (
            <div
              key={item.id}
              className={`flex gap-3 text-xs leading-relaxed ${
                item.sender === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {item.sender === 'ai' && (
                <div className="w-8 h-8 rounded-xl bg-purple-900 text-white flex items-center justify-center shrink-0 shadow-xs mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`p-4 rounded-2xl max-w-2xl space-y-3 ${
                  item.sender === 'user'
                    ? 'bg-purple-700 text-white rounded-tr-none'
                    : 'bg-slate-50 border border-slate-200 text-slate-800 rounded-tl-none'
                }`}
              >
                <div className="whitespace-pre-line space-y-2">
                  {item.text}
                </div>

                {item.actions && item.actions.length > 0 && (
                  <div className="pt-2 border-t border-slate-200/80 space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      Explore Further:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {item.actions.map((act, i) => (
                        <button
                          key={i}
                          onClick={() => handleSend(act)}
                          className="px-2.5 py-1 rounded-lg bg-white hover:bg-purple-50 border border-slate-200 hover:border-purple-300 text-[11px] text-slate-700 transition-colors"
                        >
                          {act}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Ask anything about department placement rates, recruiter demand trends, training modules..."
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              className="flex-1 p-3 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white"
            />
            <button
              type="submit"
              disabled={!inputQuery.trim()}
              className="p-3 bg-purple-700 hover:bg-purple-800 text-white rounded-xl shadow-xs transition-colors disabled:opacity-40"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
