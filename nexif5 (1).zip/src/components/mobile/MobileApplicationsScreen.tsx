import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ApplicationStatus } from '../../types';
import { Layers, CheckCircle2, ChevronRight, X, ArrowRight } from 'lucide-react';

export const MobileApplicationsScreen: React.FC = () => {
  const { applications, currentStudent, jobs, setMobileTab, setSelectedJobForDetails } = useApp();
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);

  const myApps = applications.filter(a => a.candidateId === currentStudent.id);

  const getStatusBadge = (status: ApplicationStatus) => {
    switch (status) {
      case 'applied':
        return <span className="px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-bold">Applied</span>;
      case 'under_review':
        return <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold">Under Review</span>;
      case 'shortlisted':
        return <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-bold">Shortlisted 🎉</span>;
      case 'interview':
        return <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-bold">Interview Scheduled 📅</span>;
      case 'selected':
        return <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">Offer Extended 🌟</span>;
      case 'rejected':
        return <span className="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-[10px] font-bold">Not Selected</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full bg-slate-700 text-slate-300 text-[10px] font-bold">{status}</span>;
    }
  };

  const selectedApp = myApps.find(a => a.id === selectedAppId);

  return (
    <div className="space-y-4 px-4 pt-4 pb-20 font-sans bg-slate-900 text-white min-h-screen">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-white font-display">
          Your Applications ({myApps.length})
        </h1>
        <p className="text-xs text-slate-400">
          Track hiring status and recruiter updates in real-time
        </p>
      </div>

      {/* Applications List */}
      {myApps.length > 0 ? (
        <div className="space-y-3">
          {myApps.map((app) => (
            <div
              key={app.id}
              onClick={() => setSelectedAppId(app.id)}
              className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 hover:border-indigo-500/50 transition-all cursor-pointer space-y-3"
            >
              {/* Header */}
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-white text-sm">{app.jobTitle}</h3>
                  <p className="text-xs text-slate-300 font-medium mt-0.5">{app.companyName}</p>
                </div>
                {getStatusBadge(app.status)}
              </div>

              {/* Meta info */}
              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-700/60">
                <span>Applied on {app.applicationDate}</span>
                <span className="text-indigo-400 font-semibold flex items-center gap-0.5">
                  Details <ChevronRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="py-16 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mx-auto border border-slate-700">
            <Layers className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">No Applications Yet</h3>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              Explore opportunities tailored to your skill set and submit your first application.
            </p>
          </div>
          <button
            onClick={() => setMobileTab('jobs')}
            className="py-3 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs inline-flex items-center gap-1.5 shadow-lg"
          >
            <span>Explore Jobs</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Application Details Sheet */}
      {selectedApp && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-slate-950/80 backdrop-blur-xs">
          <div className="flex-1" onClick={() => setSelectedAppId(null)} />
          <div className="bg-slate-900 rounded-t-3xl border-t border-slate-800 p-5 space-y-4 shadow-2xl max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-white text-base">Application Status</h3>
              <button
                onClick={() => setSelectedAppId(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-1">
              <h4 className="text-base font-bold text-white">{selectedApp.jobTitle}</h4>
              <p className="text-xs text-slate-300 font-medium">{selectedApp.companyName}</p>
            </div>

            {/* Application Progress Stepper */}
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-3">
              <h5 className="text-xs font-bold text-slate-300">Hiring Pipeline</h5>
              
              <div className="space-y-3">
                {selectedApp.timeline.map((item, idx) => (
                  <div key={idx} className="flex items-start gap-3 relative">
                    <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/40">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white capitalize">{item.status.replace('_', ' ')}</p>
                      <p className="text-[10px] text-slate-400">{item.date} • {item.note}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recruiter Feedback Note */}
            {selectedApp.recruiterNotes && (
              <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-1">
                <p className="text-[10px] font-bold text-indigo-300 uppercase">Recruiter Feedback</p>
                <p className="text-xs text-slate-200">{selectedApp.recruiterNotes}</p>
              </div>
            )}

            {/* View Original Job Button */}
            <div className="pt-2">
              <button
                onClick={() => {
                  const matchingJob = jobs.find(j => j.id === selectedApp.jobId);
                  if (matchingJob) {
                    setSelectedAppId(null);
                    setSelectedJobForDetails(matchingJob);
                  }
                }}
                className="w-full py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold text-center"
              >
                View Job Posting
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
