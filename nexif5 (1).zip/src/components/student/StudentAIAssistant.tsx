import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { handleStudentAIQuery, analyzeCareerReadiness } from '../../services/aiEngine';
import { JobDetailModal } from '../common/JobDetailModal';
import { JobOpportunity } from '../../types';
import {
  Bot,
  Sparkles,
  Send,
  Target,
  TrendingUp,
  Briefcase,
  FileText,
  HelpCircle,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  CornerDownLeft
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  recommendations?: any[];
  suggestedActions?: string[];
  timestamp: string;
}

export const StudentAIAssistant: React.FC = () => {
  const { currentStudent, jobs, applications, setActiveStudentTab } = useApp();

  const [inputQuery, setInputQuery] = useState('');
  const [selectedJob, setSelectedJob] = useState<JobOpportunity | null>(null);

  const starterPromptChips = [
    'Find Business Analyst jobs for me',
    'What skills am I missing?',
    'Improve my resume',
    'Find internships for me',
    'Prepare me for this interview',
    'Why am I not getting shortlisted?'
  ];

  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'init-1',
      sender: 'ai',
      text: `Hello **${currentStudent.name.split(' ')[0]}**! I am your **Nexif5 AI Career Coach**.\n\nI have analyzed your profile against live 2025 recruiter criteria for **${currentStudent.careerGoal}** roles:\n\n• **Career Readiness**: ${currentStudent.careerReadinessScore}/100\n• **Core Strengths**: Excel (Advanced), Power BI\n• **Priority Growth Area**: SQL (Subqueries & Window Functions)\n\nHow can I help accelerate your career execution today?`,
      suggestedActions: [
        'Find Business Analyst jobs for me',
        'What skills am I missing?',
        'Improve my resume'
      ],
      timestamp: 'Just now'
    }
  ]);

  const handleSend = (textToSend?: string) => {
    const query = textToSend || inputQuery;
    if (!query.trim()) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInputQuery('');

    // Simulate AI deterministic response
    setTimeout(() => {
      const response = handleStudentAIQuery(query, currentStudent, jobs, applications);

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: response.answer,
        recommendations: response.recommendations,
        suggestedActions: response.suggestedActions,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, aiMsg]);
    }, 400);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
            <Sparkles className="w-4 h-4" />
            <span>DETERMINISTIC AI CAREER COACH</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 font-display">
            Ask Nexif5 AI
          </h1>
          <p className="text-xs text-slate-500">
            Real-time guidance on job matching, skill gap closure, interview prep, and resume tuning
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs bg-indigo-50 text-indigo-700 px-3 py-1.5 rounded-xl border border-indigo-200">
          <Target className="w-3.5 h-3.5" />
          <span>Tracking: <strong>{currentStudent.careerGoal}</strong></span>
        </div>
      </div>

      {/* Suggested Prompt Chips */}
      <div className="flex flex-wrap gap-2">
        {starterPromptChips.map((chip, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(chip)}
            className="px-3 py-1.5 rounded-xl bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-xs font-semibold text-slate-700 hover:text-indigo-700 transition-all shadow-2xs flex items-center gap-1.5"
          >
            <Lightbulb className="w-3 h-3 text-amber-500" />
            <span>{chip}</span>
          </button>
        ))}
      </div>

      {/* Chat Container */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col h-[650px] overflow-hidden">
        {/* Messages Scroll Area */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-5">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 text-xs leading-relaxed ${
                msg.sender === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {msg.sender === 'ai' && (
                <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`p-4 rounded-2xl max-w-2xl space-y-3 ${
                  msg.sender === 'user'
                    ? 'bg-slate-900 text-white rounded-tr-none'
                    : 'bg-slate-50 border border-slate-200 text-slate-800 rounded-tl-none shadow-2xs'
                }`}
              >
                <div className="whitespace-pre-line space-y-2 text-xs">
                  {msg.text}
                </div>

                {/* Recommendations Grid (Jobs/Internships) */}
                {msg.recommendations && msg.recommendations.length > 0 && (
                  <div className="grid grid-cols-1 gap-2 pt-2 border-t border-slate-200/80">
                    {msg.recommendations.map((rec, i) => {
                      const matchedJobObj = jobs.find(j => j.id === rec.id);
                      return (
                        <div
                          key={i}
                          className="bg-white p-3 rounded-xl border border-slate-200 hover:border-indigo-300 transition-colors flex items-center justify-between text-xs"
                        >
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2">
                              <strong className="text-slate-900 font-bold">{rec.title}</strong>
                              <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                                {rec.score}% Match
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500">{rec.company} • {rec.location} • {rec.salary}</p>
                          </div>

                          {matchedJobObj && (
                            <button
                              onClick={() => setSelectedJob(matchedJobObj)}
                              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-[11px] shrink-0"
                            >
                              Apply
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Suggested Action Chips */}
                {msg.suggestedActions && msg.suggestedActions.length > 0 && (
                  <div className="pt-2 border-t border-slate-200/80 space-y-1.5">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      Recommended Follow-ups:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {msg.suggestedActions.map((act, i) => (
                        <button
                          key={i}
                          onClick={() => handleSend(act)}
                          className="px-2.5 py-1 rounded-lg bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-[11px] font-medium text-slate-700 hover:text-indigo-700 transition-colors"
                        >
                          {act}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <span className="text-[10px] text-slate-400 block text-right pt-1">
                  {msg.timestamp}
                </span>
              </div>

              {msg.sender === 'user' && (
                <img
                  src={currentStudent.avatarUrl}
                  alt={currentStudent.name}
                  className="w-8 h-8 rounded-xl object-cover border border-slate-200 shrink-0 mt-1"
                />
              )}
            </div>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Ask Nexif5 AI anything about your career path, interview prep, skill gaps..."
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              className="flex-1 p-3 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
            />
            <button
              type="submit"
              disabled={!inputQuery.trim()}
              className="p-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs transition-colors disabled:opacity-40"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {selectedJob && (
        <JobDetailModal
          job={selectedJob}
          onClose={() => setSelectedJob(null)}
        />
      )}
    </div>
  );
};
