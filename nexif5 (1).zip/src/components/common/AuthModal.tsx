import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import {
  Sparkles,
  X,
  Mail,
  Lock,
  User,
  GraduationCap,
  Briefcase,
  Building2,
  School,
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  AlertCircle
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'signin' | 'signup';
  initialRole?: UserRole;
  onSuccessSignUp?: (userData: { name: string; email: string; role: UserRole }) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'signin',
  initialRole = 'student',
  onSuccessSignUp
}) => {
  const {
    switchToStudentDemo,
    switchToJobSeekerDemo,
    switchToRecruiterDemo,
    switchToCollegeDemo,
    addNotification,
    t
  } = useApp();

  const [mode, setMode] = useState<'signin' | 'signup' | 'forgot_password'>(initialMode);
  const [selectedRole, setSelectedRole] = useState<UserRole>(initialRole === 'landing' ? 'student' : initialRole);
  const [showPassword, setShowPassword] = useState(false);
  
  // Sign Up / Sign In Form Fields
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  // Forgot Password State
  const [forgotEmailSent, setForgotEmailSent] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Synchronize initial mode when modal opens
  React.useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setSelectedRole(initialRole === 'landing' ? 'student' : initialRole);
      setErrorMsg('');
      setForgotEmailSent(false);
    }
  }, [isOpen, initialMode, initialRole]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (mode === 'signup') {
      if (!firstName.trim()) {
        setErrorMsg('Please enter your first name.');
        return;
      }
      if (!email.trim() || !email.includes('@')) {
        setErrorMsg('Please enter a valid email address.');
        return;
      }
      if (password.length < 6) {
        setErrorMsg('Password must be at least 6 characters.');
        return;
      }
      if (password !== confirmPassword) {
        setErrorMsg('Passwords do not match.');
        return;
      }

      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        const fullName = `${firstName.trim()} ${lastName.trim()}`.trim();
        if (onSuccessSignUp) {
          onSuccessSignUp({ name: fullName, email: email.trim(), role: selectedRole });
        } else {
          if (selectedRole === 'student') switchToStudentDemo('std-1');
          else if (selectedRole === 'job_seeker') switchToJobSeekerDemo('std-jobseeker');
          else if (selectedRole === 'recruiter') switchToRecruiterDemo('comp-1');
          else if (selectedRole === 'college') switchToCollegeDemo('clg-1');
        }
        onClose();
      }, 500);
    } else if (mode === 'signin') {
      if (!email.trim()) {
        setErrorMsg('Please enter your email.');
        return;
      }
      if (!password) {
        setErrorMsg('Please enter your password.');
        return;
      }

      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        // Authenticate based on role or email heuristics
        if (selectedRole === 'student') {
          switchToStudentDemo('std-1');
        } else if (selectedRole === 'job_seeker') {
          switchToJobSeekerDemo('std-jobseeker');
        } else if (selectedRole === 'recruiter') {
          switchToRecruiterDemo('comp-1');
        } else if (selectedRole === 'college') {
          switchToCollegeDemo('clg-1');
        }
        onClose();
      }, 500);
    } else if (mode === 'forgot_password') {
      if (!email.trim() || !email.includes('@')) {
        setErrorMsg('Please enter a valid email address.');
        return;
      }

      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        setForgotEmailSent(true);
      }, 500);
    }
  };

  const handleGoogleAuth = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const googleUser = {
        name: 'Aadhi Kesavan',
        email: 'aadhikesavanks@gmail.com',
        role: selectedRole
      };
      if (mode === 'signup' && onSuccessSignUp) {
        onSuccessSignUp(googleUser);
      } else {
        if (selectedRole === 'student') switchToStudentDemo('std-1');
        else if (selectedRole === 'job_seeker') switchToJobSeekerDemo('std-jobseeker');
        else if (selectedRole === 'recruiter') switchToRecruiterDemo('comp-1');
        else if (selectedRole === 'college') switchToCollegeDemo('clg-1');
      }
      onClose();
    }, 600);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
        />

        {/* Modal Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden z-10 my-8 max-h-[90vh] flex flex-col"
        >
          {/* Header Bar */}
          <div className="p-6 pb-4 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-900 text-lg font-display">
                  Nexif<span className="text-indigo-600">5</span>
                </h3>
                <p className="text-[11px] text-slate-500 font-medium">Career Execution Platform</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 sm:p-8 overflow-y-auto flex-1 space-y-6">
            {/* Title / Subtitle */}
            <div className="text-center space-y-1">
              <h2 className="text-2xl font-black text-slate-900 font-display">
                {mode === 'signup' && 'Join Nexif5'}
                {mode === 'signin' && 'Welcome Back'}
                {mode === 'forgot_password' && 'Reset Your Password'}
              </h2>
              <p className="text-xs text-slate-500">
                {mode === 'signup' && 'Create your account to execute your career path with AI precision'}
                {mode === 'signin' && 'Sign in to access your personalized career opportunities & applications'}
                {mode === 'forgot_password' && 'Enter your email to receive a password recovery link'}
              </p>
            </div>

            {/* Error Message */}
            {errorMsg && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Forgot Password Confirmation */}
            {mode === 'forgot_password' && forgotEmailSent ? (
              <div className="text-center space-y-4 py-4">
                <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Recovery Email Sent</h4>
                  <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                    We sent password reset instructions to <strong>{email}</strong>.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setMode('signin')}
                  className="px-6 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800"
                >
                  Return to Sign In
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* ROLE SELECTION ("What best describes you?") */}
                {mode === 'signup' && (
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 block">
                      What best describes you?
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { id: 'student', label: 'Student', icon: GraduationCap },
                        { id: 'job_seeker', label: 'Job Seeker', icon: Briefcase },
                        { id: 'recruiter', label: 'Recruiter', icon: Building2 },
                        { id: 'college', label: 'College', icon: School }
                      ].map((item) => {
                        const Icon = item.icon;
                        const isSelected = selectedRole === item.id;
                        return (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => setSelectedRole(item.id as UserRole)}
                            className={`p-2.5 rounded-xl border text-left transition-all flex flex-col items-center justify-center text-center gap-1.5 ${
                              isSelected
                                ? 'border-indigo-600 bg-indigo-50/70 text-indigo-900 font-bold shadow-xs'
                                : 'border-slate-200 hover:border-slate-300 text-slate-600 bg-white'
                            }`}
                          >
                            <Icon className={`w-4 h-4 ${isSelected ? 'text-indigo-600' : 'text-slate-400'}`} />
                            <span className="text-[11px] leading-none">{item.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* SIGN UP NAME FIELDS */}
                {mode === 'signup' && (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">First Name</label>
                      <input
                        type="text"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        placeholder="Aadhi"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:border-indigo-500 outline-hidden"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Last Name</label>
                      <input
                        type="text"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        placeholder="Kesavan"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:border-indigo-500 outline-hidden"
                        required
                      />
                    </div>
                  </div>
                )}

                {/* EMAIL FIELD */}
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Email</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:border-indigo-500 outline-hidden"
                      required
                    />
                  </div>
                </div>

                {/* PASSWORD FIELDS */}
                {mode !== 'forgot_password' && (
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-slate-700">Password</label>
                      {mode === 'signin' && (
                        <button
                          type="button"
                          onClick={() => setMode('forgot_password')}
                          className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-700"
                        >
                          Forgot Password?
                        </button>
                      )}
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-200 text-xs focus:border-indigo-500 outline-hidden"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                )}

                {/* CONFIRM PASSWORD (SIGNUP) */}
                {mode === 'signup' && (
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Confirm Password</label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:border-indigo-500 outline-hidden"
                        required
                      />
                    </div>
                  </div>
                )}

                {/* SUBMIT BUTTON */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50 mt-2"
                >
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>
                        {mode === 'signup' && 'Create Account'}
                        {mode === 'signin' && 'Sign In'}
                        {mode === 'forgot_password' && 'Send Recovery Email'}
                      </span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>

                {/* GOOGLE CONTINUATION */}
                {mode !== 'forgot_password' && (
                  <>
                    <div className="relative my-4">
                      <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-slate-200" />
                      </div>
                      <div className="relative flex justify-center text-[10px] uppercase">
                        <span className="bg-white px-2 text-slate-400 font-bold">or</span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleGoogleAuth}
                      disabled={isLoading}
                      className="w-full py-2.5 rounded-xl border border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all flex items-center justify-center gap-2.5"
                    >
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                        />
                      </svg>
                      <span>Continue with Google</span>
                    </button>
                  </>
                )}
              </form>
            )}

            {/* SWITCH MODE FOOTER */}
            <div className="text-center pt-2 border-t border-slate-100 space-y-2">
              {mode === 'signup' && (
                <p className="text-xs text-slate-600">
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => setMode('signin')}
                    className="font-bold text-indigo-600 hover:text-indigo-700"
                  >
                    Sign In
                  </button>
                </p>
              )}

              {mode === 'signin' && (
                <p className="text-xs text-slate-600">
                  Don't have an account?{' '}
                  <button
                    type="button"
                    onClick={() => setMode('signup')}
                    className="font-bold text-indigo-600 hover:text-indigo-700"
                  >
                    Create Account
                  </button>
                </p>
              )}

              {mode === 'forgot_password' && (
                <button
                  type="button"
                  onClick={() => setMode('signin')}
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-700"
                >
                  Back to Sign In
                </button>
              )}

              <div className="flex items-center justify-center gap-3 text-[11px] text-slate-400 pt-1">
                <span className="hover:underline cursor-pointer">Terms of Service</span>
                <span>•</span>
                <span className="hover:underline cursor-pointer">Privacy Policy</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
