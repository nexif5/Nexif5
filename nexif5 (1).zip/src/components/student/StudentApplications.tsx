import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { JobApplication, ApplicationStatus } from '../../types';
import {
  Layers,
  CheckCircle2,
  Clock,
  CalendarCheck,
  Award,
  XCircle,
  Video,
  ExternalLink,
  Sparkles,
  Bot,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  FileText
} from 'lucide-react';

export const StudentApplications: React.FC = () => {
  const { currentStudent, applications, setActiveStudentTab } = useApp();
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);

  const studentApplications = applications.filter(
    a => a.candidateId === currentStudent.id
  );

  const activeApp = studentApplications.find(a => a.id === selectedAppId) || studentApplications[0];

  const statusSteps: { key: ApplicationStatus; label: string }[] = [
    { key: 'applied', label: 'Applied' },
    { key: 'under_review', label: 'Under Review' },
    { key: 'shortlisted', label: 'Shortlisted' },
    { key: 'interview', label: 'Interview' },
    { key: 'selected', label: 'Offer / Selected' }
  ];

  const getStatusStepIndex = (status: ApplicationStatus) => {
    if (status === 'rejected') return -1;
    switch (status) {
      case 'applied': return 0;
      case 'under_review': return 1;
      case 'shortlisted': return 2;
      case 'interview': return 3;
      case 'selected': return 4;
      default: return 0;
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
          <Layers className="w-4 h-4" />
          <span>APPLICATION LIFECYCLE & EXECUTION TRACKER</span>
        </div>
        <h1 className="text-2xl font-bold text-slate-900 font-display">
          My Tracked Applications ({studentApplications.length})
        </h1>
        <p className="text-xs text-slate-500">
          Real-time recruiter pipeline transparency with automated interview coordination and feedback loops
        </p>
      </div>

      {studentApplications.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Applications List (5 cols) */}
          <div className="lg:col-span-5 space-y-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              Application Submissions
            </span>

            <div className="space-y-2 max-h-[75vh] overflow-y-auto pr-1">
              {studentApplications.map((app) => {
                const isSelected = activeApp?.id === app.id;
                const isRejected = app.status === 'rejected';
                const isSelectedOffer = app.status === 'selected';

                return (
                  <div
                    key={app.id}
                    onClick={() => setSelectedAppId(app.id)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                      isSelected
                        ? 'bg-white border-indigo-500 shadow-md ring-2 ring-indigo-500/10'
                        : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                    }`}
                  >
                    <img
                      src={app.companyLogoUrl}
                      alt={app.companyName}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0"
                    />
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold text-slate-900 text-sm truncate">{app.jobTitle}</h3>
                        <span className="text-xs font-bold text-indigo-600 shrink-0">
                          {app.matchScore}%
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 truncate">{app.companyName}</p>

                      <div className="flex items-center justify-between pt-1 text-[11px]">
                        <span className="text-slate-400">Applied {app.applicationDate}</span>
                        <span className={`px-2 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                          isSelectedOffer ? 'bg-emerald-100 text-emerald-800' :
                          isRejected ? 'bg-rose-100 text-rose-800' :
                          app.status === 'interview' ? 'bg-blue-100 text-blue-800' :
                          app.status === 'shortlisted' ? 'bg-purple-100 text-purple-800' :
                          'bg-slate-100 text-slate-700'
                        }`}>
                          {app.status.replace('_', ' ')}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Detailed Application Inspection & Funnel Tracker (7 cols) */}
          <div className="lg:col-span-7">
            {activeApp && (
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
                {/* Top Company & Status Header */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
                  <div className="flex items-center gap-4">
                    <img
                      src={activeApp.companyLogoUrl}
                      alt={activeApp.companyName}
                      className="w-14 h-14 rounded-2xl object-cover border border-slate-200"
                    />
                    <div>
                      <h2 className="text-lg font-bold text-slate-900 font-display">
                        {activeApp.jobTitle}
                      </h2>
                      <p className="text-xs font-semibold text-indigo-600">{activeApp.companyName}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Application ID: <span className="font-mono text-slate-700">{activeApp.id}</span> • {activeApp.applicationSource}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-2xl font-black text-indigo-600 font-display block">
                      {activeApp.matchScore}%
                    </span>
                    <span className="text-[10px] text-slate-500 font-semibold uppercase">AI Match Score</span>
                  </div>
                </div>

                {/* Section 14: Visual Status Pipeline Tracker */}
                <div className="space-y-3">
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                    Execution Stage Progression
                  </span>

                  {activeApp.status === 'rejected' ? (
                    <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-3">
                      <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
                      <div>
                        <strong className="block font-bold">Application Status: Decision Reached</strong>
                        <span>The recruiter has concluded screening for this requisition.</span>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-5 gap-1.5">
                      {statusSteps.map((step, idx) => {
                        const currentStepIndex = getStatusStepIndex(activeApp.status);
                        const isPast = idx < currentStepIndex;
                        const isCurrent = idx === currentStepIndex;

                        return (
                          <div
                            key={step.key}
                            className={`p-2 rounded-xl border text-center transition-all ${
                              isCurrent
                                ? 'bg-indigo-600 border-indigo-600 text-white shadow-xs'
                                : isPast
                                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                                : 'bg-slate-50 border-slate-200 text-slate-400'
                            }`}
                          >
                            <span className="text-[10px] block font-bold">0{idx + 1}</span>
                            <span className="text-[11px] font-bold block truncate mt-0.5">
                              {step.label}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Scheduled Interview Card (if status === 'interview') */}
                {activeApp.status === 'interview' && activeApp.scheduledInterview && (
                  <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <CalendarCheck className="w-5 h-5 text-blue-600" />
                        <h4 className="font-bold text-slate-900 text-sm">
                          {activeApp.scheduledInterview.roundType} Scheduled
                        </h4>
                      </div>
                      <span className="text-[11px] font-bold text-blue-700 bg-white px-2.5 py-1 rounded-full border border-blue-200">
                        Upcoming Round
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs text-slate-700 pt-1">
                      <div>
                        <span className="text-slate-400 block text-[10px]">Date & Time</span>
                        <strong className="text-slate-900">{activeApp.scheduledInterview.date} • {activeApp.scheduledInterview.time}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Interviewer</span>
                        <strong className="text-slate-900">{activeApp.scheduledInterview.interviewerName}</strong>
                      </div>
                    </div>

                    <div className="pt-2 flex flex-col sm:flex-row gap-2">
                      <a
                        href={activeApp.scheduledInterview.meetingLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-colors"
                      >
                        <Video className="w-4 h-4" />
                        <span>Launch Video Meeting</span>
                      </a>
                      <button
                        onClick={() => setActiveStudentTab('ai')}
                        className="py-2.5 px-4 bg-white hover:bg-slate-100 text-indigo-700 rounded-xl font-bold text-xs border border-indigo-200 transition-colors flex items-center justify-center gap-1.5"
                      >
                        <Bot className="w-3.5 h-3.5" />
                        <span>AI Interview Prep Drill</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Section 29: Rejection Improvement Feedback Loop */}
                {activeApp.status === 'rejected' && (
                  <div className="p-5 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-3">
                    <div className="flex items-center gap-2">
                      <Bot className="w-5 h-5 text-amber-700" />
                      <h4 className="font-bold text-slate-900 text-sm">
                        Nexif5 AI Rejection Analysis & Next Steps
                      </h4>
                    </div>

                    {activeApp.rejectionFeedback?.provided ? (
                      <div className="space-y-3 text-xs">
                        <div className="bg-white p-3 rounded-xl border border-amber-200">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                            Recruiter Constructive Feedback:
                          </span>
                          <p className="text-slate-800 italic">
                            "{activeApp.rejectionFeedback.comment}"
                          </p>
                        </div>

                        {activeApp.rejectionFeedback.suggestedSkillsToLearn && (
                          <div>
                            <span className="font-semibold text-slate-900 block mb-1">
                              Recommended Competencies to Upgrade:
                            </span>
                            <div className="flex flex-wrap gap-1.5">
                              {activeApp.rejectionFeedback.suggestedSkillsToLearn.map((s, i) => (
                                <span
                                  key={i}
                                  className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-900 font-semibold text-xs"
                                >
                                  ✦ {s}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        <div className="pt-2 flex justify-end">
                          <button
                            onClick={() => setActiveStudentTab('ai')}
                            className="px-4 py-2 bg-amber-700 hover:bg-amber-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5"
                          >
                            <span>Generate Improvement Plan with AI</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-xs text-slate-600 space-y-2">
                        <p>
                          No specific recruiter feedback comment was provided for this requisition.
                        </p>
                        <p className="text-[11px] text-slate-500">
                          Nexif5 AI recommends focusing on high-frequency hiring skills: complete 1 end-to-end portfolio project and apply to 85%+ matched openings.
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* Application Timeline History */}
                <div className="space-y-3 pt-2">
                  <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider text-slate-500">
                    Application Event Timeline
                  </h4>

                  <div className="space-y-3 pl-2 border-l-2 border-slate-200">
                    {activeApp.timeline.map((event, idx) => (
                      <div key={idx} className="relative pl-4 text-xs space-y-0.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 absolute -left-[21px] top-1.5 ring-4 ring-white" />
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 capitalize">
                            {event.status.replace('_', ' ')}
                          </span>
                          <span className="text-[10px] text-slate-400">• {event.date}</span>
                        </div>
                        {event.note && (
                          <p className="text-[11px] text-slate-600">{event.note}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Resume Attached */}
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5">
                    <FileText className="w-4 h-4 text-slate-500" />
                    <div>
                      <span className="text-slate-400 block text-[10px]">Attached Resume</span>
                      <strong className="text-slate-800">{activeApp.resumeUsed}</strong>
                    </div>
                  </div>
                  <span className="text-[11px] font-semibold text-emerald-600">Delivered</span>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="p-12 text-center text-xs text-slate-500 bg-white rounded-2xl border border-slate-200 space-y-3">
          <Layers className="w-10 h-10 mx-auto text-slate-300 stroke-1" />
          <h3 className="text-base font-bold text-slate-800">No applications submitted yet</h3>
          <p className="max-w-sm mx-auto text-slate-500">
            Explore active verified jobs and internships with your {currentStudent.careerReadinessScore}/100 readiness profile.
          </p>
          <button
            onClick={() => setActiveStudentTab('jobs')}
            className="px-5 py-2.5 bg-indigo-600 text-white font-bold rounded-xl text-xs"
          >
            Explore Opportunities
          </button>
        </div>
      )}
    </div>
  );
};
