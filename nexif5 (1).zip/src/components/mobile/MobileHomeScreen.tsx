import React from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { JobOpportunity } from '../../types';
import { calculateJobMatch } from '../../services/aiEngine';
import {
  Search,
  Briefcase,
  Bot,
  FileText,
  Sparkles,
  ArrowRight,
  TrendingUp,
  MapPin,
  Bookmark,
  CheckCircle2,
  Zap,
  BookOpen,
  Compass,
  Upload,
  Layers,
  ChevronRight,
  ExternalLink,
  Award,
  Play,
  Users,
  UserPlus,
  MessageSquare
} from 'lucide-react';

export const MobileHomeScreen: React.FC = () => {
  const {
    currentStudent,
    jobs,
    setMobileTab,
    setSubView,
    setSelectedJobForDetails,
    setSelectedJobForApply,
    savedJobIds,
    toggleSaveJob,
    searchQuery,
    setSearchQuery,
    applications,
    sharedResources,
    setSelectedResourceForDetail,
    setLearnSubTab,
    certifiedCourses,
    openCourseLearning,
    smartRecommendations,
    sendConnectionRequest,
    startOrOpenConversation,
    openUserProfile,
    getConnectionStatusWithUser,
    theme
  } = useApp();


  const isLight = theme === 'light';

  // Time-aware greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const firstName = currentStudent.name.split(' ')[0] || 'Aarav';

  // Calculate matches for all jobs
  const jobsWithMatches = jobs.map(job => {
    const match = calculateJobMatch(currentStudent, job);
    return {
      ...job,
      matchScore: match.overallScore,
      matchReasons: match.whyItMatches
    };
  }).sort((a, b) => b.matchScore - a.matchScore);

  const topRecommendedJobs = jobsWithMatches.slice(0, 3);

  // Top AI matched community resources
  const recommendedCommunityResources = sharedResources.slice(0, 2);

  const myApps = applications.filter(a => a.candidateId === currentStudent.id);

  return (
    <div className={`space-y-4 px-4 pt-4 pb-24 font-sans min-h-screen transition-colors duration-200 ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-white'
    }`}>
      {/* 1. Header Greeting & Brand Tagline */}
      <div className="space-y-1">
        <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5" />
          <span>{getGreeting()}, {firstName}</span>
        </p>
        <h1 className={`text-2xl font-bold tracking-tight font-display ${
          isLight ? 'text-slate-900' : 'text-white'
        }`}>
          From Potential to Career
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Your AI-powered career execution platform. From Learning to Opportunity.
        </p>
      </div>

      {/* 2. Global Search Bar */}
      <div className="relative">
        <Search className={`absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 ${isLight ? 'text-slate-400' : 'text-slate-400'}`} />
        <input
          type="text"
          placeholder="Search jobs, skill notes, subjects, companies..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onFocus={() => setMobileTab('jobs')}
          className={`w-full pl-10 pr-4 py-2.5 rounded-2xl text-xs border focus:outline-hidden focus:border-indigo-500 shadow-xs transition-colors ${
            isLight
              ? 'bg-white border-slate-300 text-slate-900 placeholder-slate-400'
              : 'bg-slate-800/90 border-slate-700/80 text-white placeholder-slate-400 shadow-inner'
          }`}
        />
      </div>

      {/* 3. HERO FOCUS CARD: "Your Next AI Recommended Action" (Prompt Core Priority) */}
      <div className={`p-4 rounded-2xl border relative overflow-hidden shadow-sm ${
        isLight
          ? 'bg-gradient-to-br from-indigo-50 via-white to-blue-50/70 border-indigo-200 text-slate-900'
          : 'bg-gradient-to-br from-indigo-950/70 via-slate-900 to-indigo-900/50 border-indigo-500/40 text-white'
      }`}>
        <div className="flex items-center justify-between pb-2 border-b border-indigo-500/20">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-indigo-500" />
            <span>YOUR NEXT AI RECOMMENDED ACTION</span>
          </span>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-500/15 text-indigo-600 dark:text-indigo-300">
            Priority 1
          </span>
        </div>

        <div className="py-2.5 space-y-1.5">
          <h2 className="text-sm font-bold font-display leading-snug">
            Read "Power BI Beginner Notes" and build Sales KPI Dashboard
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            AI detected this as your highest-ROI step. Demonstrating this practical skill increases your <strong>{currentStudent.careerGoal}</strong> Career Readiness from <strong>{currentStudent.careerReadinessScore}%</strong> to <strong>86%</strong>.
          </p>
        </div>

        <div className="pt-2 flex items-center justify-between gap-2 border-t border-indigo-500/20">
          <button
            onClick={() => {
              const pbiRes = sharedResources.find(r => r.skill.toLowerCase().includes('power bi'));
              if (pbiRes) {
                setSelectedResourceForDetail(pbiRes);
              } else {
                setMobileTab('learn');
              }
            }}
            className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-1.5 transition-all active:scale-95"
          >
            <span>Open Study Notes & Task</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => {
              setMobileTab('career');
            }}
            className={`py-2 px-3 rounded-xl border text-xs font-semibold transition-colors ${
              isLight
                ? 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700'
                : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700 text-slate-300'
            }`}
          >
            Diagnostics
          </button>
        </div>
      </div>

      {/* 4. 4 Core Platform Action Launchers */}
      <div className="grid grid-cols-2 gap-2.5">
        {/* Learn Hub */}
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => {
            setMobileTab('learn');
            setLearnSubTab('shared');
          }}
          className={`p-3.5 rounded-2xl border text-left space-y-2 transition-all shadow-xs ${
            isLight
              ? 'bg-white border-slate-200 hover:border-indigo-400 hover:shadow-md'
              : 'bg-gradient-to-br from-indigo-900/40 to-slate-800/80 border-indigo-500/30 hover:border-indigo-400'
          }`}
        >
          <div className={`w-8 h-8 rounded-xl flex items-center justify-center border ${
            isLight
              ? 'bg-indigo-50 text-indigo-600 border-indigo-200'
              : 'bg-indigo-600/30 text-indigo-300 border-indigo-500/30'
          }`}>
            <BookOpen className="w-4 h-4" />
          </div>
          <div>
            <h3 className={`font-bold text-xs ${isLight ? 'text-slate-900' : 'text-white'}`}>Learning Hub</h3>
            <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Notes & document sharing</p>
          </div>
        </motion.button>

        {/* Career Analysis */}
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => setMobileTab('career')}
          className={`p-3.5 rounded-2xl border text-left space-y-2 transition-all shadow-xs ${
            isLight
              ? 'bg-white border-slate-200 hover:border-emerald-400 hover:shadow-md'
              : 'bg-gradient-to-br from-emerald-950/40 to-slate-800/80 border-emerald-500/30 hover:border-emerald-400'
          }`}
        >
          <div className={`w-8 h-8 rounded-xl flex items-center justify-center border ${
            isLight
              ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
              : 'bg-emerald-600/30 text-emerald-300 border-emerald-500/30'
          }`}>
            <TrendingUp className="w-4 h-4" />
          </div>
          <div>
            <h3 className={`font-bold text-xs ${isLight ? 'text-slate-900' : 'text-white'}`}>Career Analysis</h3>
            <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Skill gaps & readiness</p>
          </div>
        </motion.button>

        {/* Find Opportunities */}
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => setMobileTab('jobs')}
          className={`p-3.5 rounded-2xl border text-left space-y-2 transition-all shadow-xs ${
            isLight
              ? 'bg-white border-slate-200 hover:border-blue-400 hover:shadow-md'
              : 'bg-gradient-to-br from-blue-950/40 to-slate-800/80 border-blue-500/30 hover:border-blue-400'
          }`}
        >
          <div className={`w-8 h-8 rounded-xl flex items-center justify-center border ${
            isLight
              ? 'bg-blue-50 text-blue-600 border-blue-200'
              : 'bg-blue-600/30 text-blue-300 border-blue-500/30'
          }`}>
            <Briefcase className="w-4 h-4" />
          </div>
          <div>
            <h3 className={`font-bold text-xs ${isLight ? 'text-slate-900' : 'text-white'}`}>Opportunities</h3>
            <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>AI match ranked roles</p>
          </div>
        </motion.button>

        {/* Ask AI Coach */}
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => setMobileTab('ai')}
          className={`p-3.5 rounded-2xl border text-left space-y-2 transition-all shadow-xs ${
            isLight
              ? 'bg-white border-slate-200 hover:border-purple-400 hover:shadow-md'
              : 'bg-gradient-to-br from-purple-950/40 to-slate-800/80 border-purple-500/30 hover:border-purple-400'
          }`}
        >
          <div className={`w-8 h-8 rounded-xl flex items-center justify-center border ${
            isLight
              ? 'bg-purple-50 text-purple-600 border-purple-200'
              : 'bg-purple-600/30 text-purple-300 border-purple-500/30'
          }`}>
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <h3 className={`font-bold text-xs ${isLight ? 'text-slate-900' : 'text-white'}`}>AI Coach</h3>
            <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Career intelligence chat</p>
          </div>
        </motion.button>
      </div>

      {/* 5. Career Readiness Diagnostic Mini-Card */}
      <div className={`p-4 rounded-2xl border shadow-xs transition-colors ${
        isLight ? 'bg-white border-slate-200' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between mb-2">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              AI CAREER READINESS
            </span>
            <h3 className={`font-bold text-sm font-display ${isLight ? 'text-slate-900' : 'text-white'}`}>
              Target: {currentStudent.careerGoal}
            </h3>
          </div>
          <div className="text-right">
            <span className="text-xl font-extrabold text-indigo-600 dark:text-indigo-400 font-display">
              {currentStudent.careerReadinessScore}%
            </span>
            <span className="text-[10px] text-emerald-500 block font-semibold">Job Ready</span>
          </div>
        </div>

        <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 to-emerald-500 rounded-full"
            style={{ width: `${currentStudent.careerReadinessScore}%` }}
          />
        </div>

        <div className="flex items-center justify-between pt-2.5 text-xs">
          <span className="text-slate-400 text-[11px]">Priority Gap: Power BI (35%)</span>
          <button
            onClick={() => setMobileTab('career')}
            className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline flex items-center gap-1 text-[11px]"
          >
            <span>View Full Analysis</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* 6. AI Recommended Shared Community Resources Snippet */}
      <div className="space-y-2.5 pt-1">
        <div className="flex items-center justify-between">
          <div>
            <h2 className={`text-sm font-bold ${isLight ? 'text-slate-900' : 'text-white'} flex items-center gap-1.5`}>
              <BookOpen className="w-4 h-4 text-indigo-500" />
              <span>Recommended Study Resources</span>
            </h2>
            <p className="text-[11px] text-slate-400">
              Shared by learners & mentors to close target skill gaps
            </p>
          </div>
          <button
            onClick={() => {
              setMobileTab('learn');
              setLearnSubTab('shared');
            }}
            className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            Explore All ({sharedResources.length})
          </button>
        </div>

        <div className="space-y-2">
          {recommendedCommunityResources.map((resource) => (
            <div
              key={resource.id}
              onClick={() => setSelectedResourceForDetail(resource)}
              className={`p-3 rounded-2xl border flex items-center justify-between gap-3 cursor-pointer transition-all hover:border-indigo-400 ${
                isLight ? 'bg-white border-slate-200 hover:shadow-xs' : 'bg-slate-800/70 border-slate-700/80'
              }`}
            >
              <div className="truncate space-y-0.5">
                <span className="text-[9px] font-bold uppercase tracking-wider text-indigo-500">
                  {resource.skill} • {resource.category}
                </span>
                <p className="text-xs font-bold truncate">{resource.title}</p>
                <p className="text-[10px] text-slate-400">{resource.uploaderName} • {resource.fileSize}</p>
              </div>

              <div className="shrink-0 flex items-center gap-2">
                <span className="text-[10px] px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold">
                  Preview
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 6.5. AI Certified Learning Path Snippet */}
      <div className="space-y-2.5 pt-1">
        <div className="flex items-center justify-between">
          <div>
            <h2 className={`text-sm font-bold ${isLight ? 'text-slate-900' : 'text-white'} flex items-center gap-1.5`}>
              <Award className="w-4 h-4 text-amber-500" />
              <span>Certified Learning Path</span>
            </h2>
            <p className="text-[11px] text-slate-400">
              Video lessons & capstone exams to earn verified credentials
            </p>
          </div>
          <button
            onClick={() => {
              setMobileTab('learn');
              setLearnSubTab('certifications');
            }}
            className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            All Courses ({certifiedCourses.length})
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {certifiedCourses.slice(0, 2).map((course) => (
            <div
              key={course.id}
              onClick={() => openCourseLearning(course.id)}
              className={`p-3 rounded-2xl border space-y-2 cursor-pointer transition-all hover:border-indigo-400 ${
                isLight ? 'bg-white border-slate-200 hover:shadow-xs' : 'bg-slate-800/70 border-slate-700/80'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-extrabold uppercase tracking-wider text-indigo-500 truncate max-w-[80px]">
                  {course.skill}
                </span>
                <span className="text-[9px] px-1.5 py-0.5 rounded-sm bg-emerald-500/10 text-emerald-500 font-bold">
                  {course.isCertificateEarned ? 'Earned ✓' : `${course.progressPercent}%`}
                </span>
              </div>
              <h4 className="text-xs font-bold line-clamp-1">{course.title}</h4>
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-800">
                <span>{course.modulesCount} Modules</span>
                <span className="font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-0.5">
                  <Play className="w-2.5 h-2.5 fill-current" />
                  <span>Resume</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 6.8. Smart Network Recommendations ("People You May Want to Connect With") */}
      <div className="space-y-2.5 pt-1">
        <div className="flex items-center justify-between">
          <div>
            <h2 className={`text-sm font-bold ${isLight ? 'text-slate-900' : 'text-white'} flex items-center gap-1.5`}>
              <Sparkles className="w-4 h-4 text-indigo-500" />
              <span>People You May Want to Connect With</span>
            </h2>
            <p className="text-[11px] text-slate-400">
              AI curated for your career goal & skill profile
            </p>
          </div>
          <button
            onClick={() => setSubView('network')}
            className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            Explore Network ({smartRecommendations.length})
          </button>
        </div>

        <div className="space-y-2.5">
          {smartRecommendations.slice(0, 2).map((rec) => {
            const status = getConnectionStatusWithUser(rec.userId);

            return (
              <div
                key={rec.userId}
                className={`p-3.5 rounded-2xl border transition-all ${
                  isLight
                    ? 'bg-white border-slate-200 hover:border-indigo-300 shadow-xs'
                    : 'bg-slate-800/70 border-slate-700/80 hover:border-slate-600'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div
                    className="flex items-start gap-2.5 flex-1 cursor-pointer"
                    onClick={() => openUserProfile(rec.userId)}
                  >
                    <img
                      src={rec.avatarUrl}
                      alt={rec.name}
                      className="w-10 h-10 rounded-full object-cover border border-indigo-500/30 shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="font-bold text-xs hover:text-indigo-500 truncate leading-tight">
                          {rec.name}
                        </h4>
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 uppercase">
                          {rec.role}
                        </span>
                      </div>
                      <p className={`text-[11px] truncate mt-0.5 ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                        {rec.headline}
                      </p>
                      <p className={`text-[10px] ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
                        {rec.organization}
                      </p>
                    </div>
                  </div>

                  <div className="shrink-0 flex items-center gap-1">
                    {status === 'connected' ? (
                      <button
                        onClick={() => startOrOpenConversation(rec.userId)}
                        className="p-1.5 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 transition-colors"
                        title="Send Message"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                      </button>
                    ) : status === 'pending_sent' ? (
                      <span className="text-[10px] font-semibold text-amber-500 px-2 py-1 rounded-lg bg-amber-500/10">
                        Pending
                      </span>
                    ) : (
                      <button
                        onClick={() => sendConnectionRequest(rec.userId)}
                        className="px-2.5 py-1 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold flex items-center gap-1 shadow-xs transition-transform active:scale-95"
                      >
                        <UserPlus className="w-3 h-3" />
                        <span>Connect</span>
                      </button>
                    )}
                  </div>
                </div>

                <div className={`mt-2 p-2 rounded-xl text-[10px] leading-relaxed border flex items-start gap-1.5 ${
                  isLight ? 'bg-indigo-50/50 border-indigo-100 text-indigo-900' : 'bg-indigo-950/30 border-indigo-900/40 text-indigo-200'
                }`}>
                  <Sparkles className="w-3 h-3 text-indigo-500 shrink-0 mt-0.5" />
                  <span><strong>AI Match:</strong> {rec.whyAiRecommended}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 7. Matched Opportunities (Jobs with Transparent AI Breakdown) */}

      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <div>
            <h2 className={`text-base font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
              AI-Matched Opportunities
            </h2>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Ranked using your verified skills & target requirements
            </p>
          </div>
          <button
            onClick={() => setMobileTab('jobs')}
            className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            See All ({jobs.length})
          </button>
        </div>

        <div className="space-y-3">
          {topRecommendedJobs.map((job) => {
            const isSaved = savedJobIds.includes(job.id);
            const isApplied = applications.some(
              a => a.jobId === job.id && a.candidateId === currentStudent.id
            );

            return (
              <div
                key={job.id}
                className={`p-4 rounded-2xl border shadow-xs space-y-3 transition-all ${
                  isLight
                    ? 'bg-white border-slate-200 hover:border-indigo-300 shadow-sm'
                    : 'bg-slate-800/70 border-slate-700/80 hover:border-slate-600'
                }`}
              >
                {/* Top Row: Job Title, Company, Match Badge */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-3">
                    <img
                      src={job.companyLogoUrl}
                      alt={job.companyName}
                      className={`w-10 h-10 rounded-xl object-cover border shrink-0 mt-0.5 ${
                        isLight ? 'border-slate-200' : 'border-slate-700'
                      }`}
                    />
                    <div>
                      <h3 className={`font-bold text-sm leading-snug ${
                        isLight ? 'text-slate-900' : 'text-white'
                      }`}>
                        {job.title}
                      </h3>
                      <p className={`text-xs font-medium mt-0.5 ${
                        isLight ? 'text-slate-600' : 'text-slate-300'
                      }`}>
                        {job.companyName}
                      </p>
                    </div>
                  </div>

                  {/* Match Badge */}
                  <div className="shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold">
                    <Zap className="w-3 h-3" />
                    <span>{job.matchScore || 94}% Match</span>
                  </div>
                </div>

                {/* Location, Salary, Work Type */}
                <div className={`flex flex-wrap items-center gap-2 text-xs ${
                  isLight ? 'text-slate-600' : 'text-slate-300'
                }`}>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    {job.location}
                  </span>
                  <span>•</span>
                  <span className={`font-semibold ${isLight ? 'text-slate-900' : 'text-slate-200'}`}>
                    {job.salaryRange || job.salaryDisplay}
                  </span>
                  <span>•</span>
                  <span className={`capitalize px-1.5 py-0.5 rounded-md text-[10px] ${
                    isLight ? 'bg-slate-100 text-slate-700' : 'bg-slate-700/70 text-slate-300'
                  }`}>
                    {job.workMode}
                  </span>
                </div>

                {/* Why This Matches You */}
                {job.matchReasons && job.matchReasons.length > 0 && (
                  <div className={`text-[11px] p-2 rounded-xl border leading-relaxed ${
                    isLight ? 'bg-slate-50 border-slate-200 text-slate-600' : 'bg-slate-900/50 border-slate-800 text-slate-400'
                  }`}>
                    💡 <span className={isLight ? 'text-slate-800 font-medium' : 'text-slate-300'}>Why this matches: {job.matchReasons[0]}</span>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => setSelectedJobForDetails(job)}
                    className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold text-center transition-colors ${
                      isLight
                        ? 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                        : 'bg-slate-700/80 hover:bg-slate-700 text-slate-200'
                    }`}
                  >
                    View Details
                  </button>

                  <button
                    onClick={() => {
                      if (isApplied) {
                        setMobileTab('applications');
                      } else {
                        setSelectedJobForApply(job);
                      }
                    }}
                    disabled={isApplied}
                    className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold text-center transition-colors ${
                      isApplied
                        ? isLight
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-emerald-900/50 text-emerald-300 border border-emerald-700/50'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs'
                    }`}
                  >
                    {isApplied ? '✓ Applied' : 'Apply'}
                  </button>

                  <button
                    onClick={() => toggleSaveJob(job.id)}
                    className={`p-2 rounded-xl border transition-colors ${
                      isSaved
                        ? 'bg-indigo-600/20 border-indigo-500 text-indigo-600 dark:text-indigo-400'
                        : isLight
                        ? 'bg-slate-100 border-slate-200 text-slate-500 hover:text-slate-800'
                        : 'bg-slate-700/60 border-slate-700 text-slate-400 hover:text-slate-200'
                    }`}
                    title={isSaved ? 'Saved' : 'Save Job'}
                  >
                    <Bookmark className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 8. Active Applications Tracker */}
      {myApps.length > 0 && (
        <div className={`p-4 rounded-2xl border space-y-2 ${
          isLight
            ? 'bg-indigo-50/70 border-indigo-200 text-slate-900'
            : 'bg-indigo-950/40 border-indigo-800/40 text-white'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-indigo-600 dark:text-indigo-300 uppercase tracking-wider">
              Application Tracker
            </span>
            <button
              onClick={() => setMobileTab('applications')}
              className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              View All ({myApps.length})
            </button>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold">{myApps[0].jobTitle} — {myApps[0].companyName}</span>
            <span className="px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-600 dark:text-indigo-300 text-[10px] font-bold capitalize">
              {myApps[0].status.replace('_', ' ')}
            </span>
          </div>
        </div>
      )}

      {/* 9. Career Journey Execution Flow Banner (Prompt Section: Education → Skills → Career → Opportunities → Industry Connect → Outcomes) */}
      <div className={`p-3.5 rounded-2xl border text-center space-y-1.5 ${
        isLight ? 'bg-slate-100/70 border-slate-200 text-slate-600' : 'bg-slate-800/40 border-slate-800 text-slate-400'
      }`}>
        <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-500">
          NEXIF5 AI CAREER JOURNEY
        </span>
        <div className="flex items-center justify-center gap-1 text-[10px] font-semibold flex-wrap">
          <span>Education</span>
          <span>→</span>
          <span className="text-indigo-600 dark:text-indigo-400">Skills</span>
          <span>→</span>
          <span>Career</span>
          <span>→</span>
          <span>Opportunities</span>
          <span>→</span>
          <span>Outcomes</span>
        </div>
      </div>
    </div>
  );
};
