import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { JobApplication, ApplicationStatus } from '../../types';
import {
  Layers,
  Search,
  Filter,
  CheckCircle2,
  CalendarCheck,
  Award,
  XCircle,
  Eye,
  FileText,
  Video,
  Sparkles,
  MapPin,
  Bot,
  ShieldCheck,
  School,
  X,
  Send
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const RecruiterApplications: React.FC = () => {
  const {
    currentCompany,
    applications,
    updateApplicationStatus,
    students
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [candidateTypeFilter, setCandidateTypeFilter] = useState<string>('all');
  const [selectedApp, setSelectedApp] = useState<JobApplication | null>(null);

  // Modals for actions
  const [showInterviewModal, setShowInterviewModal] = useState(false);
  const [interviewDate, setInterviewDate] = useState('2025-02-25');
  const [interviewTime, setInterviewTime] = useState('11:30 AM IST');
  const [interviewRound, setInterviewRound] = useState('Technical Case Study Round');
  const [interviewerName, setInterviewerName] = useState('Rajesh Menon (Lead Architect)');
  const [meetingLink, setMeetingLink] = useState('https://meet.google.com/nexif-round');

  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectReasonCategory, setRejectReasonCategory] = useState<'skill_gap' | 'qualification' | 'experience' | 'culture_fit' | 'position_filled'>('skill_gap');
  const [rejectComment, setRejectComment] = useState('Candidate demonstrated good analytical foundation, but needs deeper practical experience in SQL multi-table joins and subqueries.');
  const [suggestedSkills, setSuggestedSkills] = useState('SQL (Advanced), Power BI DAX');

  const companyApps = applications.filter(a => a.companyId === currentCompany.id);

  const filteredApps = companyApps.filter(app => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchesName = app.candidateName.toLowerCase().includes(q);
      const matchesRole = app.jobTitle.toLowerCase().includes(q);
      const matchesDeg = app.candidateEducation.toLowerCase().includes(q);
      if (!matchesName && !matchesRole && !matchesDeg) return false;
    }
    if (statusFilter !== 'all' && app.status !== statusFilter) return false;
    if (sourceFilter !== 'all') {
      if (sourceFilter === 'nexif5' && !app.applicationSource?.toLowerCase().includes('nexif')) return false;
      if (sourceFilter === 'campus' && !app.applicationSource?.toLowerCase().includes('campus')) return false;
    }
    if (candidateTypeFilter !== 'all') {
      const type = app.candidateType || (app.candidateCollegeId ? 'student' : 'job_seeker');
      if (candidateTypeFilter !== type) return false;
    }
    return true;
  });

  const handleShortlist = (app: JobApplication) => {
    updateApplicationStatus(app.id, 'shortlisted', {
      note: 'Profile shortlisted based on 85%+ AI match score & verified achievements.'
    });
    if (selectedApp?.id === app.id) {
      setSelectedApp(prev => prev ? { ...prev, status: 'shortlisted' } : null);
    }
  };

  const handleSelectOffer = (app: JobApplication) => {
    updateApplicationStatus(app.id, 'selected', {
      note: 'Candidate cleared final review. Official selection / offer extended.'
    });
    confetti({ particleCount: 70, spread: 50, origin: { y: 0.6 } });
    if (selectedApp?.id === app.id) {
      setSelectedApp(prev => prev ? { ...prev, status: 'selected' } : null);
    }
  };

  const handleScheduleInterviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedApp) return;

    updateApplicationStatus(selectedApp.id, 'interview', {
      note: `Scheduled ${interviewRound} on ${interviewDate} at ${interviewTime}`,
      interview: {
        date: interviewDate,
        time: interviewTime,
        roundType: interviewRound,
        interviewerName,
        meetingLink,
        interviewMode: 'Virtual Video Call'
      }
    });

    setShowInterviewModal(false);
    setSelectedApp(prev => prev ? { ...prev, status: 'interview' } : null);
  };

  const handleRejectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedApp) return;

    updateApplicationStatus(selectedApp.id, 'rejected', {
      note: 'Application closed with feedback provided.',
      rejectionFeedback: {
        provided: true,
        reasonCategory: rejectReasonCategory,
        comment: rejectComment,
        suggestedSkillsToLearn: suggestedSkills.split(',').map(s => s.trim()).filter(Boolean)
      }
    });

    setShowRejectModal(false);
    setSelectedApp(prev => prev ? { ...prev, status: 'rejected' } : null);
  };

  // Find candidate profile in student database for deep artifact inspection
  const candidateStudentProfile = selectedApp ? students.find(s => s.id === selectedApp.candidateId) : null;

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 mb-1">
            <Layers className="w-4 h-4" />
            <span>CANDIDATE APPLICATION REVIEW</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 font-display">
            Applications Workspace ({companyApps.length})
          </h1>
          <p className="text-xs text-slate-500">
            Review candidate qualifications, verified achievements, AI match scores, and manage hiring decisions
          </p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative flex-1 w-full sm:max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by candidate name, target role, or degree..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <select
            value={candidateTypeFilter}
            onChange={(e) => setCandidateTypeFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 bg-white focus:outline-none"
          >
            <option value="all">All Candidate Types</option>
            <option value="student">College Students</option>
            <option value="job_seeker">Job Seekers & Professionals</option>
          </select>

          <select
            value={sourceFilter}
            onChange={(e) => setSourceFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 bg-white focus:outline-none"
          >
            <option value="all">All Sources</option>
            <option value="nexif5">Nexif5 Direct</option>
            <option value="campus">Campus Drive</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 bg-white focus:outline-none"
          >
            <option value="all">All Stages</option>
            <option value="applied">Applied</option>
            <option value="shortlisted">Shortlisted</option>
            <option value="interview">Interviewing</option>
            <option value="selected">Selected / Hired</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Applications Mobile Card List (sm:hidden) */}
      <div className="sm:hidden space-y-3">
        {filteredApps.map((app) => {
          const isNexif5Source = app.applicationSource?.toLowerCase().includes('nexif') || !app.candidateCollegeId;
          const isJobSeeker = app.candidateType === 'job_seeker' || !app.candidateCollegeId;

          return (
            <div
              key={app.id}
              className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3"
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img
                    src={app.candidateAvatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                    alt={app.candidateName}
                    className="w-11 h-11 rounded-xl object-cover border border-slate-200 shrink-0"
                  />
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{app.candidateName}</h3>
                    <p className="text-[11px] text-slate-500 font-mono">{app.candidateEmail}</p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="px-2 py-0.5 rounded-lg bg-indigo-50 text-indigo-700 font-bold text-xs">
                    {app.matchScore}% Match
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">{app.applicationDate}</span>
                </div>
              </div>

              {/* Badges & Role */}
              <div className="space-y-1 pt-1 border-t border-slate-100">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">Requisition:</span>
                  <strong className="text-slate-900 font-semibold">{app.jobTitle}</strong>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">Source:</span>
                  <div className="flex items-center gap-1.5">
                    {isJobSeeker ? (
                      <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-bold">
                        Job Seeker
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-800 border border-blue-200 text-[10px] font-bold">
                        Student
                      </span>
                    )}
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-semibold flex items-center gap-1">
                      {isNexif5Source ? (
                        <>
                          <Sparkles className="w-2.5 h-2.5 text-indigo-500" />
                          <span>Nexif5 Direct</span>
                        </>
                      ) : (
                        <>
                          <School className="w-2.5 h-2.5 text-purple-500" />
                          <span>Campus</span>
                        </>
                      )}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs pt-1">
                  <span className="text-slate-500">Stage:</span>
                  <span className={`px-2.5 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                    app.status === 'selected' ? 'bg-emerald-100 text-emerald-800' :
                    app.status === 'rejected' ? 'bg-rose-100 text-rose-800' :
                    app.status === 'interview' ? 'bg-blue-100 text-blue-800' :
                    app.status === 'shortlisted' ? 'bg-purple-100 text-purple-800' :
                    'bg-slate-100 text-slate-700'
                  }`}>
                    {app.status.replace('_', ' ')}
                  </span>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                <button
                  onClick={() => setSelectedApp(app)}
                  className="w-full py-2 bg-slate-900 hover:bg-indigo-600 text-white rounded-xl font-bold text-xs text-center transition-colors min-h-[40px] active:scale-98"
                >
                  Inspect Profile & Actions
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Applications Table (hidden sm:block) */}
      <div className="hidden sm:block bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-semibold text-[10px] tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Candidate</th>
                <th className="py-3.5 px-4">Type & Source</th>
                <th className="py-3.5 px-4">Job Requisition</th>
                <th className="py-3.5 px-4">AI Match</th>
                <th className="py-3.5 px-4">Applied Date</th>
                <th className="py-3.5 px-4">Current Stage</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredApps.map((app) => {
                const isNexif5Source = app.applicationSource?.toLowerCase().includes('nexif') || !app.candidateCollegeId;
                const isJobSeeker = app.candidateType === 'job_seeker' || !app.candidateCollegeId;

                return (
                  <tr key={app.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={app.candidateAvatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                          alt={app.candidateName}
                          className="w-9 h-9 rounded-xl object-cover border border-slate-200"
                        />
                        <div>
                          <strong className="text-slate-900 font-bold text-xs block">{app.candidateName}</strong>
                          <span className="text-[10px] text-slate-400 font-mono">{app.candidateEmail}</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5">
                          {isJobSeeker ? (
                            <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-bold">
                              Job Seeker
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-800 border border-blue-200 text-[10px] font-bold">
                              Student
                            </span>
                          )}
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-semibold flex items-center gap-1">
                            {isNexif5Source ? (
                              <>
                                <Sparkles className="w-2.5 h-2.5 text-indigo-500" />
                                <span>Nexif5</span>
                              </>
                            ) : (
                              <>
                                <School className="w-2.5 h-2.5 text-purple-500" />
                                <span>Campus</span>
                              </>
                            )}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-500 block truncate max-w-[180px]">
                          {app.candidateCollegeName || app.candidateEducation}
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-4 font-medium text-slate-900">
                      {app.jobTitle}
                    </td>
                    <td className="py-4 px-4">
                      <span className="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 font-bold text-xs">
                        {app.matchScore}%
                      </span>
                    </td>
                    <td className="py-4 px-4 text-slate-500">
                      {app.applicationDate}
                    </td>
                    <td className="py-4 px-4">
                      <span className={`px-2.5 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                        app.status === 'selected' ? 'bg-emerald-100 text-emerald-800' :
                        app.status === 'rejected' ? 'bg-rose-100 text-rose-800' :
                        app.status === 'interview' ? 'bg-blue-100 text-blue-800' :
                        app.status === 'shortlisted' ? 'bg-purple-100 text-purple-800' :
                        'bg-slate-100 text-slate-700'
                      }`}>
                        {app.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <button
                        onClick={() => setSelectedApp(app)}
                        className="px-3 py-1.5 bg-slate-900 hover:bg-indigo-600 text-white rounded-lg font-bold text-[11px] transition-colors"
                      >
                        Inspect Profile
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Candidate Deep Inspection & Decision Drawer Modal */}
      {selectedApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-6">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/60">
              <div className="flex items-center gap-3">
                <img
                  src={selectedApp.candidateAvatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                  alt={selectedApp.candidateName}
                  className="w-12 h-12 rounded-xl object-cover border border-slate-200"
                />
                <div>
                  <h3 className="font-bold text-slate-900 text-base">{selectedApp.candidateName}</h3>
                  <p className="text-xs text-slate-500">
                    Applying for <strong>{selectedApp.jobTitle}</strong> • {selectedApp.applicationSource}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedApp(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-5 text-xs text-slate-700 max-h-[60vh] overflow-y-auto">
              {/* AI Match Overview */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-50 to-blue-50 border border-indigo-100 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-indigo-950 text-xs flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-indigo-600" />
                    <span>AI Deterministic Match Analysis: {selectedApp.matchScore}% Match</span>
                  </span>
                  <span className="text-[11px] font-bold text-emerald-700 bg-white px-2 py-0.5 rounded-full border border-emerald-200">
                    {selectedApp.candidateReadinessScore || 78}/100 Career Readiness
                  </span>
                </div>

                {selectedApp.matchReasons && selectedApp.matchReasons.length > 0 && (
                  <ul className="space-y-1 text-slate-700 pt-1">
                    {selectedApp.matchReasons.map((r, i) => (
                      <li key={i} className="flex items-start gap-1.5 text-[11px]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{r}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Academic & Affiliation Details */}
              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-400 block text-[10px]">Academic Degree</span>
                  <strong className="text-slate-900">{selectedApp.candidateEducation}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">College / Affiliation</span>
                  <strong className="text-slate-900">
                    {selectedApp.candidateCollegeName || 'Independent Candidate'}
                  </strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Contact Phone</span>
                  <strong className="text-slate-900">{selectedApp.candidatePhone}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Target Ambition</span>
                  <strong className="text-indigo-600">{selectedApp.candidateCareerGoal || 'Business Analyst'}</strong>
                </div>
              </div>

              {/* Experience (if Job Seeker or Experienced) */}
              {((candidateStudentProfile?.experiences && candidateStudentProfile.experiences.length > 0) || (candidateStudentProfile?.experience && candidateStudentProfile.experience.length > 0)) && (
                <div className="space-y-2">
                  <span className="font-bold text-slate-900 block text-xs uppercase tracking-wider text-slate-500">
                    Professional Experience
                  </span>
                  <div className="space-y-2">
                    {(candidateStudentProfile.experiences || candidateStudentProfile.experience || []).map((exp: any) => (
                      <div key={exp.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                        <div className="flex items-center justify-between">
                          <strong className="text-slate-900 font-bold">{exp.role}</strong>
                          <span className="text-[10px] text-slate-500 font-medium">{exp.duration || `${exp.startDate || ''} - ${exp.endDate || (exp.isCurrent ? 'Present' : '')}`}</span>
                        </div>
                        <span className="text-indigo-600 text-[11px] font-semibold block">{exp.company} • {exp.location}</span>
                        <p className="text-slate-600 text-[11px] mt-1">{exp.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Verified Achievements from Profile */}
              {candidateStudentProfile?.achievements && candidateStudentProfile.achievements.length > 0 && (
                <div className="space-y-2">
                  <span className="font-bold text-slate-900 block text-xs uppercase tracking-wider text-slate-500">
                    Verified Candidate Achievements
                  </span>
                  <div className="space-y-1.5">
                    {candidateStudentProfile.achievements.map((ach) => (
                      <div key={ach.id} className="p-2.5 rounded-lg bg-amber-50/50 border border-amber-200">
                        <strong className="text-slate-900 block">{ach.title} ({ach.category})</strong>
                        <p className="text-slate-600 text-[11px] mt-0.5">{ach.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Note / Cover Letter from Student */}
              {selectedApp.coverNote && (
                <div className="space-y-1">
                  <span className="font-bold text-slate-900 block text-xs uppercase tracking-wider text-slate-500">
                    Candidate Note to Recruiter
                  </span>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-700 italic">
                    "{selectedApp.coverNote}"
                  </div>
                </div>
              )}
            </div>

            {/* Recruiter Decision Actions Footer */}
            <div className="p-4 sm:p-5 border-t border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-2">
              <div className="text-xs">
                Status: <strong className="text-indigo-600 uppercase">{selectedApp.status.replace('_', ' ')}</strong>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setShowRejectModal(true)}
                  className="px-3 py-2 text-rose-700 hover:bg-rose-50 border border-rose-200 rounded-xl font-semibold transition-colors"
                >
                  Reject with Feedback
                </button>

                <button
                  onClick={() => handleShortlist(selectedApp)}
                  className="px-3.5 py-2 bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200 rounded-xl font-bold transition-colors"
                >
                  Shortlist
                </button>

                <button
                  onClick={() => setShowInterviewModal(true)}
                  className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-xs transition-colors flex items-center gap-1.5"
                >
                  <CalendarCheck className="w-3.5 h-3.5" />
                  <span>Schedule Interview</span>
                </button>

                <button
                  onClick={() => handleSelectOffer(selectedApp)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-xs transition-colors flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Select / Extend Offer</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Schedule Interview Modal */}
      {showInterviewModal && selectedApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">Schedule Candidate Interview</h3>
              <button onClick={() => setShowInterviewModal(false)}><X className="w-4 h-4 text-slate-400" /></button>
            </div>
            <form onSubmit={handleScheduleInterviewSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Interview Round</label>
                <input
                  type="text"
                  value={interviewRound}
                  onChange={(e) => setInterviewRound(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Date</label>
                  <input
                    type="date"
                    value={interviewDate}
                    onChange={(e) => setInterviewDate(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Time</label>
                  <input
                    type="text"
                    value={interviewTime}
                    onChange={(e) => setInterviewTime(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Interviewer Name</label>
                <input
                  type="text"
                  value={interviewerName}
                  onChange={(e) => setInterviewerName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Video Meeting Link</label>
                <input
                  type="url"
                  value={meetingLink}
                  onChange={(e) => setMeetingLink(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                  required
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowInterviewModal(false)}
                  className="px-3 py-2 text-slate-500 hover:text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl"
                >
                  Confirm & Send Invitation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reject with Feedback Modal */}
      {showRejectModal && selectedApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">Provide Constructive Feedback</h3>
              <button onClick={() => setShowRejectModal(false)}><X className="w-4 h-4 text-slate-400" /></button>
            </div>
            <p className="text-[11px] text-slate-500">
              Nexif5 uses your feedback to build targeted remedial learning plans for the candidate rather than creating dead ends.
            </p>
            <form onSubmit={handleRejectSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Primary Reason Category</label>
                <select
                  value={rejectReasonCategory}
                  onChange={(e) => setRejectReasonCategory(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                >
                  <option value="skill_gap">Skill Gap (Missing technical tool)</option>
                  <option value="experience">Experience Level</option>
                  <option value="qualification">Academic Qualification</option>
                  <option value="culture_fit">Role Alignment</option>
                  <option value="position_filled">Position Filled</option>
                </select>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Constructive Comment for Candidate</label>
                <textarea
                  rows={3}
                  value={rejectComment}
                  onChange={(e) => setRejectComment(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Suggested Competencies to Upgrade</label>
                <input
                  type="text"
                  value={suggestedSkills}
                  onChange={(e) => setSuggestedSkills(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowRejectModal(false)}
                  className="px-3 py-2 text-slate-500 hover:text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl"
                >
                  Submit Decision
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
