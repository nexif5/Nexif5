import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ResourceCategory, ResourceFileType } from '../../types';
import {
  X,
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  ShieldAlert,
  Globe,
  Lock
} from 'lucide-react';

export const MobileUploadResourceModal: React.FC = () => {
  const {
    isUploadResourceModalOpen,
    setIsUploadResourceModalOpen,
    uploadResource,
    currentStudent,
    theme
  } = useApp();

  const isLight = theme === 'light';

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ResourceCategory>('Skill Learning');
  const [subject, setSubject] = useState('Business Analytics');
  const [skill, setSkill] = useState('Power BI');
  const [careerRelevance, setCareerRelevance] = useState('Finance / Business / Analytics');
  const [tagsInput, setTagsInput] = useState('Power BI, Dashboard, Beginner, Finance');
  const [visibility, setVisibility] = useState<'community' | 'private'>('community');
  const [selectedFileName, setSelectedFileName] = useState('Power_BI_Beginner_Notes.pdf');
  const [fileSize, setFileSize] = useState('2.8 MB');
  const [fileType, setFileType] = useState<ResourceFileType>('pdf');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [previewSnippetText, setPreviewSnippetText] = useState(
    'Key fundamentals, conceptual architecture, and step-by-step practical implementation guidelines.'
  );

  if (!isUploadResourceModalOpen) return null;

  const categories: ResourceCategory[] = [
    'Skill Learning',
    'Interview Prep',
    'Exam Preparation',
    'Career Guide',
    'Project Resources',
    'Templates'
  ];

  const handleSimulatedFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const f = e.target.files[0];
      setSelectedFileName(f.name);
      setFileSize(`${(f.size / (1024 * 1024)).toFixed(1)} MB`);
      if (f.name.endsWith('.pdf')) setFileType('pdf');
      else if (f.name.endsWith('.docx') || f.name.endsWith('.doc')) setFileType('doc');
      else if (f.name.endsWith('.pptx') || f.name.endsWith('.ppt')) setFileType('presentation');
      else setFileType('notes');

      if (!title) {
        setTitle(f.name.replace(/\.[^/.]+$/, '').replace(/_/g, ' '));
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('Please provide a descriptive resource title.');
      return;
    }
    if (!skill.trim()) {
      setErrorMsg('Please specify the primary skill covered.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg('');

    const tagsArray = tagsInput
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    setTimeout(() => {
      uploadResource({
        title: title.trim(),
        description: description.trim() || `Useful ${category.toLowerCase()} material on ${skill} for ${careerRelevance}.`,
        category,
        subject: subject.trim() || 'Applied Career Skills',
        skill: skill.trim(),
        careerRelevance: careerRelevance.trim(),
        tags: tagsArray.length > 0 ? tagsArray : [skill, category, 'NEXIF5'],
        fileType,
        fileSize: fileSize || '2.4 MB',
        fileName: selectedFileName || 'resource_notes.pdf',
        visibility,
        previewSnippet: `1. OVERVIEW OF ${title.toUpperCase()}:
${description || 'Comprehensive study notes and practice tasks to master core competencies.'}
2. PRACTICAL APPLICATION IN INDUSTRY:
• Core Concepts: Elicitation, Modeling, and Data Translation.
• Recommended Implementation: Complete practical portfolio exercise.`,
        contentOutline: [
          `1. Introduction to ${skill}`,
          `2. Core Principles & Practical Walkthrough`,
          `3. Best Practices in Modern Industry`,
          `4. Exercises & Practice Assessment Questions`
        ],
        aiRelevanceReason: `Matches ${skill} learning requirements and peer knowledge exchange for ${careerRelevance}.`,
        practicalTaskTitle: `Complete practical ${skill} exercise based on this study material`
      });

      setIsSubmitting(false);
      setIsUploadResourceModalOpen(false);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-slate-950/75 backdrop-blur-xs font-sans">
      {/* Backdrop */}
      <div
        className="flex-1"
        onClick={() => setIsUploadResourceModalOpen(false)}
      />

      {/* Modal Dialog */}
      <div className={`rounded-t-3xl border-t p-5 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto transition-colors duration-200 ${
        isLight
          ? 'bg-white border-slate-200 text-slate-900'
          : 'bg-slate-900 border-slate-800 text-white'
      }`}>
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h2 className="text-base font-bold font-display flex items-center gap-2">
              <Upload className="w-4 h-4 text-indigo-500" />
              <span>Share Educational Resource</span>
            </h2>
            <p className="text-xs text-slate-400">
              Contribute verified study notes, career guides, or interview preparation materials.
            </p>
          </div>
          <button
            onClick={() => setIsUploadResourceModalOpen(false)}
            className={`p-2 rounded-xl transition-colors ${
              isLight ? 'text-slate-500 hover:text-slate-900 bg-slate-100' : 'text-slate-400 hover:text-white bg-slate-800'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-500 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          {/* File Upload Zone */}
          <div className={`p-4 rounded-2xl border-2 border-dashed text-center transition-colors ${
            isLight
              ? 'border-indigo-300 bg-indigo-50/40 hover:bg-indigo-50'
              : 'border-indigo-500/40 bg-slate-800/40 hover:bg-slate-800/80'
          }`}>
            <label className="cursor-pointer block space-y-1.5">
              <input
                type="file"
                className="hidden"
                accept=".pdf,.doc,.docx,.ppt,.pptx,.txt"
                onChange={handleSimulatedFileChange}
              />
              <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-500 flex items-center justify-center mx-auto">
                <FileText className="w-5 h-5" />
              </div>
              <p className="font-bold text-xs text-indigo-600 dark:text-indigo-400">
                {selectedFileName ? selectedFileName : 'Tap to select document'}
              </p>
              <p className="text-[10px] text-slate-400">
                Supports PDF, Word (.docx), PPT, Study Notes (Up to 25 MB)
              </p>
            </label>
          </div>

          {/* Title */}
          <div className="space-y-1">
            <label className="font-bold text-slate-700 dark:text-slate-300">
              Resource Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Power BI Beginner Notes & DAX Cheat Sheet"
              className={`w-full p-2.5 rounded-xl border text-xs focus:outline-hidden focus:border-indigo-500 ${
                isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>

          {/* Category & Subject */}
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label className="font-bold text-slate-700 dark:text-slate-300">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ResourceCategory)}
                className={`w-full p-2.5 rounded-xl border text-xs focus:outline-hidden focus:border-indigo-500 ${
                  isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              >
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-700 dark:text-slate-300">
                Subject
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Business Analytics"
                className={`w-full p-2.5 rounded-xl border text-xs focus:outline-hidden focus:border-indigo-500 ${
                  isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>
          </div>

          {/* Skill & Career Relevance */}
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label className="font-bold text-slate-700 dark:text-slate-300">
                Primary Skill *
              </label>
              <input
                type="text"
                required
                value={skill}
                onChange={(e) => setSkill(e.target.value)}
                placeholder="e.g. Power BI, SQL, Excel"
                className={`w-full p-2.5 rounded-xl border text-xs focus:outline-hidden focus:border-indigo-500 ${
                  isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-700 dark:text-slate-300">
                Career Relevance
              </label>
              <input
                type="text"
                value={careerRelevance}
                onChange={(e) => setCareerRelevance(e.target.value)}
                placeholder="e.g. Finance / Business / Analytics"
                className={`w-full p-2.5 rounded-xl border text-xs focus:outline-hidden focus:border-indigo-500 ${
                  isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>
          </div>

          {/* Description */}
          <div className="space-y-1">
            <label className="font-bold text-slate-700 dark:text-slate-300">
              Description & Key Takeaways
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Beginner-friendly study notes covering fundamentals, real case setups, and practice questions..."
              className={`w-full p-2.5 rounded-xl border text-xs focus:outline-hidden focus:border-indigo-500 resize-none ${
                isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>

          {/* Tags */}
          <div className="space-y-1">
            <label className="font-bold text-slate-700 dark:text-slate-300">
              Tags (Comma separated)
            </label>
            <input
              type="text"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="Power BI, DAX, Beginner, Dashboard"
              className={`w-full p-2.5 rounded-xl border text-xs focus:outline-hidden focus:border-indigo-500 ${
                isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>

          {/* Visibility Controls */}
          <div className="space-y-1">
            <label className="font-bold text-slate-700 dark:text-slate-300 block">
              Sharing Visibility
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setVisibility('community')}
                className={`p-2.5 rounded-xl border flex items-center gap-2 transition-all text-left ${
                  visibility === 'community'
                    ? 'border-indigo-500 bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 font-bold'
                    : isLight
                    ? 'border-slate-200 bg-slate-50 text-slate-600'
                    : 'border-slate-700 bg-slate-800 text-slate-400'
                }`}
              >
                <Globe className="w-4 h-4 shrink-0" />
                <div>
                  <p className="text-xs">NEXIF5 Community</p>
                  <p className="text-[10px] text-slate-400 font-normal">All learners can discover & learn</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setVisibility('private')}
                className={`p-2.5 rounded-xl border flex items-center gap-2 transition-all text-left ${
                  visibility === 'private'
                    ? 'border-indigo-500 bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 font-bold'
                    : isLight
                    ? 'border-slate-200 bg-slate-50 text-slate-600'
                    : 'border-slate-700 bg-slate-800 text-slate-400'
                }`}
              >
                <Lock className="w-4 h-4 shrink-0" />
                <div>
                  <p className="text-xs">Private Library</p>
                  <p className="text-[10px] text-slate-400 font-normal">Visible only to your account</p>
                </div>
              </button>
            </div>
          </div>

          {/* Privacy & Copyright Notice */}
          <div className={`p-3 rounded-xl border text-[11px] leading-relaxed flex items-start gap-2 ${
            isLight
              ? 'bg-amber-50 border-amber-200 text-amber-800'
              : 'bg-amber-950/30 border-amber-500/30 text-amber-200'
          }`}>
            <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <span>
              By sharing, you confirm this document contains educational, study, or career notes and does not include confidential personal information or copyrighted proprietary material.
            </span>
          </div>

          {/* Submit CTA */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all active:scale-98 flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <span>Publishing Resource to NEXIF5...</span>
            ) : (
              <>
                <Upload className="w-4 h-4" />
                <span>Publish to Learning Hub</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
