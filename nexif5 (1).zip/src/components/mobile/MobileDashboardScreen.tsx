import React from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, TrendingUp, ShieldCheck, CheckCircle2, AlertTriangle, Sparkles, BookOpen, Target } from 'lucide-react';

export const MobileDashboardScreen: React.FC = () => {
  const { setSubView, currentStudent, setMobileTab } = useApp();

  return (
    <div className="space-y-4 px-4 pt-4 pb-20 font-sans bg-slate-900 text-white min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSubView(null)}
            className="p-2 -ml-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-lg font-bold text-white font-display">Career Readiness</h1>
            <p className="text-xs text-slate-400">Diagnostic score & market benchmark</p>
          </div>
        </div>
      </div>

      {/* Main Score Hero Card */}
      <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-900/60 to-slate-900 border border-indigo-500/40 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
              Overall Benchmark
            </span>
            <h2 className="text-3xl font-extrabold text-white mt-1 font-display">
              {currentStudent.careerReadinessScore}%
            </h2>
            <p className="text-xs text-emerald-400 font-semibold mt-0.5">
              Top 10% in Candidate Pool
            </p>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-indigo-600/30 text-indigo-400 flex items-center justify-center border border-indigo-500/40">
            <TrendingUp className="w-7 h-7" />
          </div>
        </div>

        <div className="space-y-2 pt-2 border-t border-indigo-500/20 text-xs">
          <div className="flex justify-between text-slate-300">
            <span>Profile Completeness</span>
            <span className="font-bold text-white">95%</span>
          </div>
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full w-[95%]" />
          </div>

          <div className="flex justify-between text-slate-300 pt-1">
            <span>Core Skill Verification</span>
            <span className="font-bold text-white">88%</span>
          </div>
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-indigo-500 rounded-full w-[88%]" />
          </div>

          <div className="flex justify-between text-slate-300 pt-1">
            <span>ATS Resume Strength</span>
            <span className="font-bold text-white">92%</span>
          </div>
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-purple-500 rounded-full w-[92%]" />
          </div>
        </div>
      </div>

      {/* Target Role Diagnostic */}
      <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-3">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
          <Target className="w-4 h-4 text-indigo-400" />
          <span>Target Role: Business Analyst</span>
        </h3>

        <div className="space-y-2 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-300">SQL & Query Optimization</span>
            <span className="text-emerald-400 font-bold">Verified ✓</span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-300">Power BI & Data Storytelling</span>
            <span className="text-emerald-400 font-bold">Verified ✓</span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-300">Stakeholder Communication</span>
            <span className="text-emerald-400 font-bold">Verified ✓</span>
          </div>

          <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between">
            <span className="text-amber-200">Tableau Dashboarding (Recommended)</span>
            <span className="text-amber-400 font-bold text-[10px]">Gap (+8% Match)</span>
          </div>
        </div>
      </div>

      {/* Recommended Next Actions */}
      <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-3">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
          Suggested Action Plan
        </h3>

        <div className="space-y-2">
          <button
            onClick={() => setSubView('resume')}
            className="w-full p-3 rounded-xl bg-slate-900/70 hover:bg-slate-900 border border-slate-800 flex items-center justify-between text-left text-xs"
          >
            <div>
              <p className="font-bold text-white">Generate Tailored ATS Resume</p>
              <p className="text-[10px] text-slate-400">Match keywords for top tech companies</p>
            </div>
            <span className="text-indigo-400 font-bold">Open</span>
          </button>

          <button
            onClick={() => setSubView('interview_prep')}
            className="w-full p-3 rounded-xl bg-slate-900/70 hover:bg-slate-900 border border-slate-800 flex items-center justify-between text-left text-xs"
          >
            <div>
              <p className="font-bold text-white">Practice Mock Interview</p>
              <p className="text-[10px] text-slate-400">Answer 5 high-frequency questions</p>
            </div>
            <span className="text-indigo-400 font-bold">Start</span>
          </button>

          <button
            onClick={() => {
              setSubView(null);
              setMobileTab('jobs');
            }}
            className="w-full p-3 rounded-xl bg-slate-900/70 hover:bg-slate-900 border border-slate-800 flex items-center justify-between text-left text-xs"
          >
            <div>
              <p className="font-bold text-white">Apply to 3 Matching Roles</p>
              <p className="text-[10px] text-slate-400">Companies actively reviewing today</p>
            </div>
            <span className="text-indigo-400 font-bold">View</span>
          </button>
        </div>
      </div>
    </div>
  );
};
