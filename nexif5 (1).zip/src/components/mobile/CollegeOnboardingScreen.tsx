import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, School, User, Award, MapPin, Check, Mail, Phone, Globe } from 'lucide-react';

export const CollegeOnboardingScreen: React.FC = () => {
  const { setAuthState, setCurrentRole, currentCollege, setCurrentCollege } = useApp();

  // Institution Details
  const [institutionName, setInstitutionName] = useState('Rathinam Global University');
  const [logoUrl, setLogoUrl] = useState('https://images.unsplash.com/photo-1562774053-701939374585?w=150&auto=format&fit=crop&q=80');
  const [type, setType] = useState('Autonomous University');
  const [location, setLocation] = useState('Coimbatore, Tamil Nadu');
  const [website, setWebsite] = useState('https://rathinam.ac.in');
  const [accreditation, setAccreditation] = useState('NAAC A++ • NIRF Band 101-150');

  // Contact Person Details
  const [officerName, setOfficerName] = useState('Dr. K. Ramanathan');
  const [officerEmail, setOfficerEmail] = useState('ramanathan.placement@rathinam.ac.in');
  const [officerPhone, setOfficerPhone] = useState('+91 94432 10987');
  const [designation, setDesignation] = useState('Director of Placements & Corporate Relations');

  const [step, setStep] = useState<1 | 2>(1);

  const handleFinish = () => {
    setCurrentCollege({
      ...currentCollege,
      name: institutionName,
      logoUrl,
      type,
      location,
      nirfRank: accreditation
    });

    setCurrentRole('college');
    setAuthState('authenticated');
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col justify-between px-5 py-6 font-sans">
      <div>
        {/* Top Header */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (step > 1) setStep(1);
                else setAuthState('account_type');
              }}
              className="p-2 -ml-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors active:scale-95"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white font-display">
                College & Institution Setup
              </h1>
              <p className="text-xs text-slate-400">
                Step {step} of 2 — {step === 1 ? 'Institutional Details' : 'Placement Cell Contact'}
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-purple-400">{step === 1 ? '50%' : '100%'}</span>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1.5 bg-slate-800 rounded-full mb-4 overflow-hidden">
          <div
            className="h-full bg-purple-500 rounded-full transition-all duration-300"
            style={{ width: `${(step / 2) * 100}%` }}
          />
        </div>

        {/* Step 1: Institutional Details */}
        {step === 1 && (
          <div className="space-y-3.5 max-h-[68vh] overflow-y-auto pr-1">
            <div className="flex items-center gap-3.5 p-3.5 bg-slate-800/60 border border-slate-700/80 rounded-2xl">
              <img
                src={logoUrl}
                alt={institutionName}
                className="w-14 h-14 rounded-xl object-cover border border-purple-500/50"
              />
              <div>
                <p className="text-xs font-bold text-white">Campus Institutional Portal</p>
                <p className="text-[11px] text-slate-400">Track student skill analytics & recruitment drives</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Institution Name</label>
              <input
                type="text"
                value={institutionName}
                onChange={(e) => setInstitutionName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Institution Type</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                >
                  <option value="Autonomous University">Autonomous University</option>
                  <option value="Affiliated Engineering College">Affiliated Engineering College</option>
                  <option value="Arts & Science Institute">Arts & Science Institute</option>
                  <option value="National Institute (NIT/IIT/IIIT)">National Institute</option>
                  <option value="Polytechnic / Diploma">Polytechnic / Diploma</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Accreditation</label>
                <input
                  type="text"
                  value={accreditation}
                  onChange={(e) => setAccreditation(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                  placeholder="e.g. NAAC A++ / NIRF"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Campus Location / State</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Official Website</label>
              <input
                type="url"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
              />
            </div>
          </div>
        )}

        {/* Step 2: Placement Officer / Dean Details */}
        {step === 2 && (
          <div className="space-y-3.5 max-h-[68vh] overflow-y-auto pr-1">
            <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded-2xl flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-lg">
                <School className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs font-bold text-purple-300">Placement Officer Authorized Contact</p>
                <p className="text-[11px] text-slate-400">Directly coordinates recruiter connections</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Authorized Officer / Dean Name</label>
              <input
                type="text"
                value={officerName}
                onChange={(e) => setOfficerName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Official Institutional Email</label>
              <input
                type="email"
                value={officerEmail}
                onChange={(e) => setOfficerEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Phone Number</label>
                <input
                  type="text"
                  value={officerPhone}
                  onChange={(e) => setOfficerPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Designation</label>
                <input
                  type="text"
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Button */}
      <div className="pt-4">
        {step < 2 ? (
          <button
            onClick={() => setStep(2)}
            className="w-full py-3.5 px-6 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm shadow-lg shadow-purple-600/30 flex items-center justify-center transition-all active:scale-[0.98]"
          >
            Continue to Placement Officer Details
          </button>
        ) : (
          <button
            onClick={handleFinish}
            className="w-full py-3.5 px-6 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
          >
            <Check className="w-4 h-4" />
            <span>Launch Placement Cell Hub</span>
          </button>
        )}
      </div>
    </div>
  );
};
