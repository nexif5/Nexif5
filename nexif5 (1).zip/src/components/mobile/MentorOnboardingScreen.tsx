import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, Award, User, Briefcase, Clock, Check, Sparkles, X, Plus } from 'lucide-react';

export const MentorOnboardingScreen: React.FC = () => {
  const { setAuthState, setCurrentRole, updateMentorProfile, currentMentor } = useApp();

  // Personal & Professional Details
  const [name, setName] = useState('Dr. Ananya Sen');
  const [avatarUrl, setAvatarUrl] = useState('https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80');
  const [location, setLocation] = useState('Bengaluru / Global');
  const [jobTitle, setJobTitle] = useState('Principal Solutions Architect');
  const [company, setCompany] = useState('Google Cloud Partner Network');
  const [experienceYears, setExperienceYears] = useState(12);

  // Mentorship Setup
  const [domains, setDomains] = useState<string[]>(['Cloud Architecture', 'Distributed Systems', 'Tech Leadership', 'Mock Interviews']);
  const [newDomain, setNewDomain] = useState('');
  const [bio, setBio] = useState('12+ years building hyper-scale systems. Dedicated to mentoring aspiring engineers and business analysts on real-world engineering and career acceleration.');
  const [availabilityHours, setAvailabilityHours] = useState(6);
  const [mentorshipTypes, setMentorshipTypes] = useState<string[]>([
    '1:1 Mentoring',
    'Mock Interview',
    'Resume Review',
    'Career Guidance'
  ]);
  const [linkedInUrl, setLinkedInUrl] = useState('https://linkedin.com/in/ananya-sen-cloud');

  const [step, setStep] = useState<1 | 2>(1);

  const toggleType = (t: string) => {
    if (mentorshipTypes.includes(t)) {
      setMentorshipTypes(mentorshipTypes.filter(x => x !== t));
    } else {
      setMentorshipTypes([...mentorshipTypes, t]);
    }
  };

  const handleAddDomain = (e: React.FormEvent) => {
    e.preventDefault();
    if (newDomain.trim() && !domains.includes(newDomain.trim())) {
      setDomains([...domains, newDomain.trim()]);
      setNewDomain('');
    }
  };

  const handleFinish = () => {
    updateMentorProfile({
      name,
      avatarUrl,
      location,
      jobTitle,
      company,
      experienceYears,
      domains,
      bio,
      availabilityHoursPerWeek: availabilityHours,
      mentorshipTypes: mentorshipTypes as any,
      linkedInUrl
    });

    setCurrentRole('mentor');
    setAuthState('authenticated');
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col justify-between px-5 py-6 font-sans">
      <div>
        {/* Top Header */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (step > 1) setStep(1);
                else setAuthState('account_type');
              }}
              className="p-2 -ml-1 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors active:scale-95"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white font-display">
                Mentor Profile Setup
              </h1>
              <p className="text-xs text-slate-400">
                Step {step} of 2 — {step === 1 ? 'Expert Background' : 'Mentorship Offerings'}
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-cyan-400">{step === 1 ? '50%' : '100%'}</span>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1.5 bg-slate-800 rounded-full mb-4 overflow-hidden">
          <div
            className="h-full bg-cyan-500 rounded-full transition-all duration-300"
            style={{ width: `${(step / 2) * 100}%` }}
          />
        </div>

        {/* Step 1: Personal & Professional Background */}
        {step === 1 && (
          <div className="space-y-3.5 max-h-[68vh] overflow-y-auto pr-1">
            <div className="flex items-center gap-3.5 p-3.5 bg-slate-800/60 border border-slate-700/80 rounded-2xl">
              <img
                src={avatarUrl}
                alt={name}
                className="w-14 h-14 rounded-full object-cover border-2 border-cyan-500"
              />
              <div>
                <p className="text-xs font-bold text-white">NEXIF5 Certified Mentor</p>
                <p className="text-[11px] text-slate-400">Share your industry experience and review mentees</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Mentor Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Job Title</label>
                <input
                  type="text"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Company</label>
                <input
                  type="text"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Total Experience (Years)</label>
                <input
                  type="number"
                  value={experienceYears}
                  onChange={(e) => setExperienceYears(parseInt(e.target.value) || 0)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Location</label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">LinkedIn Profile</label>
              <input
                type="url"
                value={linkedInUrl}
                onChange={(e) => setLinkedInUrl(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
              />
            </div>
          </div>
        )}

        {/* Step 2: Mentorship Details & Offerings */}
        {step === 2 && (
          <div className="space-y-4 max-h-[68vh] overflow-y-auto pr-1">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Areas of Expertise & Domains
              </label>
              <div className="flex flex-wrap gap-1.5 mb-2.5">
                {domains.map((d) => (
                  <span
                    key={d}
                    className="inline-flex items-center gap-1 px-3 py-1 bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 rounded-lg text-xs font-medium"
                  >
                    <span>{d}</span>
                    <button
                      type="button"
                      onClick={() => setDomains(domains.filter(x => x !== d))}
                      className="hover:text-white"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>

              <form onSubmit={handleAddDomain} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Add domain (e.g. System Design, Product Strategy)"
                  value={newDomain}
                  onChange={(e) => setNewDomain(e.target.value)}
                  className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white"
                />
                <button
                  type="submit"
                  className="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold"
                >
                  Add
                </button>
              </form>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Mentorship Services Offered
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {['1:1 Mentoring', 'Mock Interview', 'Resume Review', 'Career Guidance'].map((opt) => {
                  const isChecked = mentorshipTypes.includes(opt);
                  return (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => toggleType(opt)}
                      className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                        isChecked
                          ? 'bg-cyan-500/20 border-cyan-500 text-cyan-200'
                          : 'bg-slate-800/80 border-slate-700 text-slate-400'
                      }`}
                    >
                      <span>{opt}</span>
                      {isChecked && <Check className="w-4 h-4 text-cyan-400 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Weekly Availability (Hours / Week)
              </label>
              <input
                type="number"
                min={1}
                max={40}
                value={availabilityHours}
                onChange={(e) => setAvailabilityHours(parseInt(e.target.value) || 2)}
                className="w-full px-3.5 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Mentor Bio / Introduction</label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-800/80 border border-slate-700/80 rounded-xl text-xs text-white"
              />
            </div>
          </div>
        )}
      </div>

      {/* Bottom Button */}
      <div className="pt-4">
        {step < 2 ? (
          <button
            onClick={() => setStep(2)}
            className="w-full py-3.5 px-6 rounded-2xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-sm shadow-lg shadow-cyan-600/30 flex items-center justify-center transition-all active:scale-[0.98]"
          >
            Continue to Mentorship Setup
          </button>
        ) : (
          <button
            onClick={handleFinish}
            className="w-full py-3.5 px-6 rounded-2xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-sm shadow-lg shadow-cyan-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
          >
            <Check className="w-4 h-4" />
            <span>Launch Mentor Workspace</span>
          </button>
        )}
      </div>
    </div>
  );
};
