import React from 'react';
import { useApp } from '../../context/AppContext';
import { Bell, CheckCheck, X, Sparkles, Briefcase, Award, ArrowRight } from 'lucide-react';

interface MobileNotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileNotificationsModal: React.FC<MobileNotificationsModalProps> = ({
  isOpen,
  onClose
}) => {
  const { notifications, markAllNotificationsAsRead, setMobileTab, setSubView } = useApp();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-slate-950/80 backdrop-blur-xs font-sans">
      <div className="flex-1" onClick={onClose} />
      <div className="bg-slate-900 rounded-t-3xl border-t border-slate-800 p-5 space-y-4 shadow-2xl max-h-[85vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-indigo-400" />
            <h3 className="font-bold text-white text-base">Notifications</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={markAllNotificationsAsRead}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
            >
              Mark all read
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* List */}
        <div className="space-y-2.5">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              className={`p-3.5 rounded-2xl border transition-all ${
                !notif.read
                  ? 'bg-indigo-950/30 border-indigo-500/40 shadow-xs'
                  : 'bg-slate-800/60 border-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <h4 className="text-xs font-bold text-white">{notif.title}</h4>
                <span className="text-[10px] text-slate-400 shrink-0">{notif.timestamp}</span>
              </div>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">{notif.message}</p>
            </div>
          ))}

          {notifications.length === 0 && (
            <div className="py-10 text-center text-slate-400 text-xs">
              No notifications yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
