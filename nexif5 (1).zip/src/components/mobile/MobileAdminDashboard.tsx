import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldCheck,
  Users,
  Briefcase,
  Award,
  School,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Activity,
  Server,
  RefreshCw,
  Lock
} from 'lucide-react';
import { UserRole } from '../../types';

export const MobileAdminDashboard: React.FC = () => {
  const { adminUsers, toggleAdminUserStatus, jobs, certifiedCourses, theme } = useApp();
  const isLight = theme === 'light';

  const [roleFilter, setRoleFilter] = useState<'all' | UserRole>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredUsers = adminUsers.filter((u) => {
    const matchesRole = roleFilter === 'all' || u.role === roleFilter;
    const matchesSearch =
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.organizationOrCollege && u.organizationOrCollege.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesRole && matchesSearch;
  });

  return (
    <div className={`p-4 space-y-4 pb-24 font-sans ${isLight ? 'text-slate-900' : 'text-white'}`}>
      {/* Admin Header */}
      <div className={`p-4 rounded-2xl border ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-950 border-slate-800'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-extrabold font-display">NEXIF5 Admin Console</h1>
                <span className="text-[10px] px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-400 font-mono font-bold">
                  ROOT
                </span>
              </div>
              <p className="text-xs text-slate-400">
                System Governance & User Role Management
              </p>
            </div>
          </div>
          <span className="text-[10px] px-2 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono">
            SYS_HEALTH: 99.98%
          </span>
        </div>
      </div>

      {/* Platform Overview Metrics */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-900/80 border-slate-800'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Users className="w-4 h-4 text-indigo-400" />
            <span className="text-[10px] text-emerald-400 font-bold">+24 today</span>
          </div>
          <p className="text-xl font-black font-display">1,482</p>
          <p className="text-[11px] text-slate-400">Total Registered Users</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-900/80 border-slate-800'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Briefcase className="w-4 h-4 text-emerald-400" />
            <span className="text-[10px] text-emerald-400 font-bold">Active</span>
          </div>
          <p className="text-xl font-black font-display">{jobs.length}</p>
          <p className="text-[11px] text-slate-400">Live Requisitions</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-900/80 border-slate-800'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Award className="w-4 h-4 text-purple-400" />
            <span className="text-[10px] text-purple-400 font-bold">Verifiable</span>
          </div>
          <p className="text-xl font-black font-display">312</p>
          <p className="text-[11px] text-slate-400">Earned Certifications</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-900/80 border-slate-800'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <School className="w-4 h-4 text-cyan-400" />
            <span className="text-[10px] text-cyan-400 font-bold">MoU Verified</span>
          </div>
          <p className="text-xl font-black font-display">12</p>
          <p className="text-[11px] text-slate-400">Campus Institutions</p>
        </div>
      </div>

      {/* User Directory & Management */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-900/80 border-slate-800'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-indigo-400" />
            <h2 className="text-sm font-bold">User Directory & Status Control</h2>
          </div>
          <span className="text-[10px] text-slate-400">{filteredUsers.length} Users</span>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name, email, or institution..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950/80 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500"
          />
        </div>

        {/* Role Filters */}
        <div className="flex gap-1 overflow-x-auto pb-1 text-xs">
          {[
            { id: 'all', label: 'All Roles' },
            { id: 'student', label: 'Students' },
            { id: 'professional', label: 'Professionals' },
            { id: 'recruiter', label: 'Recruiters' },
            { id: 'college', label: 'Colleges' },
            { id: 'mentor', label: 'Mentors' },
            { id: 'admin', label: 'Admins' }
          ].map((rf) => (
            <button
              key={rf.id}
              onClick={() => setRoleFilter(rf.id as any)}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold whitespace-nowrap transition-all ${
                roleFilter === rf.id
                  ? 'bg-rose-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {rf.label}
            </button>
          ))}
        </div>

        {/* User List */}
        <div className="space-y-2">
          {filteredUsers.map((user) => (
            <div
              key={user.id}
              className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between text-xs"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white">{user.name}</span>
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-mono capitalize">
                    {user.role}
                  </span>
                </div>
                <p className="text-[10px] text-slate-400">{user.email}</p>
                {user.organizationOrCollege && (
                  <p className="text-[9px] text-slate-500">{user.organizationOrCollege}</p>
                )}
              </div>

              <div className="flex items-center gap-2">
                <span className={`text-[10px] px-2 py-0.5 rounded font-bold capitalize ${
                  user.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                }`}>
                  {user.status}
                </span>

                {user.role !== 'admin' && (
                  <button
                    onClick={() => toggleAdminUserStatus(user.id)}
                    className="text-[10px] px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-medium"
                  >
                    {user.status === 'active' ? 'Suspend' : 'Activate'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* System Security Audit Log */}
      <div className={`p-4 rounded-2xl border space-y-2.5 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-900/80 border-slate-800'
      }`}>
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400" />
          <h2 className="text-sm font-bold">Platform Audit & Security Logs</h2>
        </div>

        <div className="space-y-1.5 text-[11px] font-mono text-slate-400">
          <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800/50 flex items-center justify-between">
            <span>[2026-10-07 23:14:02] Certificate ID verification query logged</span>
            <span className="text-emerald-400">SUCCESS</span>
          </div>
          <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800/50 flex items-center justify-between">
            <span>[2026-10-07 23:12:44] Role switch to Recruiter executed</span>
            <span className="text-cyan-400">AUDITED</span>
          </div>
          <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800/50 flex items-center justify-between">
            <span>[2026-10-07 23:09:18] Cryptographic hash check passed</span>
            <span className="text-emerald-400">VERIFIED</span>
          </div>
        </div>
      </div>
    </div>
  );
};
