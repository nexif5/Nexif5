import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CollegeStaff } from '../../types';
import {
  Users,
  School,
  UserPlus,
  ShieldCheck,
  Trash2,
  X
} from 'lucide-react';

export const CollegeTeam: React.FC = () => {
  const { currentCollege } = useApp();

  const [members, setMembers] = useState<CollegeStaff[]>(currentCollege.placementStaff || []);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<CollegeStaff['role']>('placement_officer');
  const [department, setDepartment] = useState('Central Career Development Cell');

  const handleInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;

    const newStaff: CollegeStaff = {
      id: `staff-${Date.now()}`,
      collegeId: currentCollege.id,
      name: name.trim(),
      email: email.trim(),
      role,
      department
    };

    setMembers(prev => [...prev, newStaff]);
    setName('');
    setEmail('');
    setShowInviteModal(false);
  };

  const handleRemove = (id: string) => {
    setMembers(prev => prev.filter(m => m.id !== id));
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-purple-600 mb-1">
            <Users className="w-4 h-4" />
            <span>INSTITUTIONAL PLACEMENT CELL ROLES</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 font-display">
            Placement Officers & Faculty Coordinators
          </h1>
          <p className="text-xs text-slate-500">
            Manage institutional access levels and departmental coordinators for {currentCollege.name}
          </p>
        </div>

        <button
          onClick={() => setShowInviteModal(true)}
          className="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold text-xs shadow-xs hover:shadow transition-all flex items-center gap-2 w-fit"
        >
          <UserPlus className="w-4 h-4" />
          <span>Add Staff Coordinator</span>
        </button>
      </div>

      {/* Institutional Group Summary */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <img
            src={currentCollege.logoUrl}
            alt={currentCollege.name}
            className="w-14 h-14 rounded-2xl object-cover border border-slate-200"
          />
          <div>
            <h3 className="font-bold text-slate-900 text-base font-display">{currentCollege.name}</h3>
            <p className="text-xs text-slate-500">
              Institutional Affiliation ID: <span className="font-mono text-slate-700">{currentCollege.id}</span> • {currentCollege.type}
            </p>
            <span className="inline-block mt-1 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200">
              Verified Academic Institution
            </span>
          </div>
        </div>

        <div className="text-xs text-slate-600 space-y-1 sm:text-right">
          <div>Authorized Staff: <strong>{members.length} Officers</strong></div>
          <div className="text-purple-700 font-semibold">Department-Wise Access Active</div>
        </div>
      </div>

      {/* Staff Members List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Placement Cell Members ({members.length})
          </span>
        </div>

        <div className="divide-y divide-slate-100">
          {members.map((member) => (
            <div
              key={member.id}
              className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs hover:bg-slate-50/50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 font-bold flex items-center justify-center text-sm border border-purple-200">
                  {member.name.charAt(0)}
                </div>
                <div>
                  <strong className="text-slate-900 font-bold text-sm block">{member.name}</strong>
                  <span className="text-[11px] text-slate-500 font-mono">{member.email}</span>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-left sm:text-right">
                  <span className={`px-2.5 py-1 rounded-full font-bold uppercase text-[10px] ${
                    member.role === 'admin' ? 'bg-purple-100 text-purple-800' :
                    member.role === 'placement_officer' ? 'bg-blue-100 text-blue-800' :
                    'bg-slate-100 text-slate-700'
                  }`}>
                    {member.role.replace('_', ' ')}
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    {member.department}
                  </span>
                </div>

                {members.length > 1 && (
                  <button
                    onClick={() => handleRemove(member.id)}
                    className="p-1.5 rounded-lg text-slate-300 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="Remove Coordinator"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Invite Staff Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">Add Placement Coordinator</h3>
              <button onClick={() => setShowInviteModal(false)}><X className="w-4 h-4 text-slate-400" /></button>
            </div>
            <form onSubmit={handleInvite} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  placeholder="e.g. Dr. Sudhir Roy"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Institutional Email</label>
                <input
                  type="email"
                  placeholder="name@college.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Assigned Department</label>
                <input
                  type="text"
                  placeholder="e.g. Department of Commerce"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Staff Role</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none font-medium"
                >
                  <option value="placement_officer">Placement Officer (Manage drives & analytics)</option>
                  <option value="faculty_coordinator">Faculty Coordinator (Department student tracking)</option>
                  <option value="admin">College Admin (Full campus control)</option>
                </select>
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowInviteModal(false)}
                  className="px-3 py-2 text-slate-500 hover:text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl"
                >
                  Add Staff Member
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
