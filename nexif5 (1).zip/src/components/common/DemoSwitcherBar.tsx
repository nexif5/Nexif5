import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  GraduationCap,
  Briefcase,
  Building2,
  School,
  Compass,
  Code2,
  ChevronUp,
  ChevronDown,
  Wrench
} from 'lucide-react';

export const DemoSwitcherBar: React.FC = () => {
  const {
    currentRole,
    setCurrentRole,
    switchToStudentDemo,
    switchToJobSeekerDemo,
    switchToRecruiterDemo,
    switchToCollegeDemo,
    currentStudent,
    currentCompany,
    currentCollege
  } = useApp();

  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <div className="bg-slate-950 border-b border-slate-800/80 text-xs text-slate-300 transition-all z-50 select-none">
      {/* Top micro bar with Developer indicator and minimize control */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-1 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-indigo-950 text-indigo-300 border border-indigo-800/60 font-mono text-[10px] font-bold uppercase tracking-wider">
            <Wrench className="w-3 h-3 text-indigo-400" />
            Developer Demo Mode
          </span>
          <span className="hidden sm:inline-block text-[11px] text-slate-400">
            Active Layer: <strong className="text-white capitalize">{currentRole === 'job_seeker' ? 'Job Seeker' : currentRole}</strong>
            {(currentRole === 'student' || currentRole === 'job_seeker') && ` (${currentStudent?.name || 'Aarav'})`}
            {currentRole === 'recruiter' && ` (${currentCompany?.name || 'ABC Tech'})`}
            {currentRole === 'college' && ` (${currentCollege?.name || 'Rathinam'})`}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Quick pills when collapsed or inline */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentRole('landing')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                currentRole === 'landing'
                  ? 'bg-indigo-600 text-white font-bold'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Landing
            </button>
            <button
              onClick={() => switchToStudentDemo('std-1')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                currentRole === 'student'
                  ? 'bg-blue-600 text-white font-bold'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Student
            </button>
            <button
              onClick={() => switchToJobSeekerDemo('std-jobseeker')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                currentRole === 'job_seeker'
                  ? 'bg-amber-600 text-white font-bold'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Job Seeker
            </button>
            <button
              onClick={() => switchToRecruiterDemo('comp-1')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                currentRole === 'recruiter'
                  ? 'bg-emerald-600 text-white font-bold'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Recruiter
            </button>
            <button
              onClick={() => switchToCollegeDemo('clg-1')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                currentRole === 'college'
                  ? 'bg-purple-600 text-white font-bold'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              College
            </button>
          </div>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 ml-1"
            title={isExpanded ? 'Minimize Developer Toolbar' : 'Expand Developer Toolbar'}
          >
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Expanded Details Bar */}
      {isExpanded && (
        <div className="bg-slate-900/90 border-t border-slate-800/80 px-3 sm:px-6 py-1.5 hidden md:block">
          <div className="max-w-7xl mx-auto flex items-center justify-between text-[11px] text-slate-400">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-indigo-300 uppercase tracking-wide">
                NEXIF5 PROTOTYPE DEMO CONTROLLER
              </span>
              <span>— Use this toolbar to quickly demonstrate multi-persona workflows during reviews and testing.</span>
            </div>
            <div className="flex items-center gap-3">
              <span>Status: <strong className="text-emerald-400">Deterministic Engine Active</strong></span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
