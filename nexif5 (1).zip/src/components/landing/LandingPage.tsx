import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CareerExecutionLoop } from '../common/CareerExecutionLoop';
import { AuthModal } from '../common/AuthModal';
import { CareerOnboardingModal } from '../onboarding/CareerOnboardingModal';
import { LanguageSelectorModal } from '../common/LanguageSelectorModal';
import {
  Sparkles,
  GraduationCap,
  Briefcase,
  Building2,
  School,
  ArrowRight,
  CheckCircle2,
  Zap,
  Target,
  BarChart3,
  ShieldCheck,
  Bot,
  Users,
  Compass,
  FileCheck,
  TrendingUp,
  MapPin,
  Clock,
  Search,
  Globe,
  FileText,
  CheckSquare
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const {
    jobs,
    companies,
    switchToStudentDemo,
    switchToJobSeekerDemo,
    switchToRecruiterDemo,
    switchToCollegeDemo,
    setActiveStudentTab,
    setCurrentRole,
    currentLanguage,
    t
  } = useApp();

  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signup');
  const [selectedAuthRole, setSelectedAuthRole] = useState<'student' | 'job_seeker' | 'recruiter' | 'college'>('student');
  const [onboardingOpen, setOnboardingOpen] = useState(false);
  const [languageModalOpen, setLanguageModalOpen] = useState(false);
  const [registeredUser, setRegisteredUser] = useState<{ name: string; email: string; role: any }>({
    name: 'Aadhi Kesavan',
    email: 'aadhikesavanks@gmail.com',
    role: 'student'
  });

  const [publicSearchQuery, setPublicSearchQuery] = useState('');

  const handleLaunchRoleAuth = (role: 'student' | 'job_seeker' | 'recruiter' | 'college') => {
    setSelectedAuthRole(role);
    setAuthMode('signin');
    setAuthModalOpen(true);
  };

  const handleSuccessSignUp = (user: { name: string; email: string; role: any }) => {
    setRegisteredUser(user);
    if (user.role === 'student' || user.role === 'job_seeker') {
      setOnboardingOpen(true);
    } else if (user.role === 'recruiter') {
      switchToRecruiterDemo('comp-1');
    } else if (user.role === 'college') {
      switchToCollegeDemo('clg-1');
    }
  };

  const filteredPublicJobs = jobs.filter(j =>
    j.title.toLowerCase().includes(publicSearchQuery.toLowerCase()) ||
    j.companyName.toLowerCase().includes(publicSearchQuery.toLowerCase()) ||
    j.location.toLowerCase().includes(publicSearchQuery.toLowerCase())
  ).slice(0, 4);

  return (
    <div className="space-y-20 pb-20">
      {/* Hero Section */}
      <section className="relative pt-12 sm:pt-16 pb-8 px-4 sm:px-6 overflow-hidden">
        <div className="max-w-5xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200/80 text-indigo-700 text-xs font-semibold tracking-wide shadow-xs">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            <span>{t('brand.tagline')}</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold text-slate-950 tracking-tight font-display max-w-4xl mx-auto leading-[1.15]">
            {t('hero.title')}
          </h1>

          <p className="text-base sm:text-xl text-slate-600 max-w-3xl mx-auto font-normal leading-relaxed">
            {t('hero.subtitle')}
          </p>

          {/* Primary Action Buttons */}
          <div className="pt-2 flex flex-wrap items-center justify-center gap-3 sm:gap-4">
            <button
              onClick={() => {
                setAuthMode('signup');
                setSelectedAuthRole('student');
                setAuthModalOpen(true);
              }}
              className="px-7 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-md shadow-indigo-500/20 hover:shadow-lg transition-all flex items-center gap-2"
            >
              <span>{t('nav.get_started')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                switchToStudentDemo('std-1');
                setActiveStudentTab('jobs');
              }}
              className="px-7 py-3.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-bold text-sm border border-slate-200 shadow-xs transition-all flex items-center gap-2"
            >
              <span>{t('hero.explore_jobs')}</span>
            </button>

            <button
              onClick={() => setLanguageModalOpen(true)}
              className="px-4 py-3.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs border border-slate-200/80 transition-all flex items-center gap-1.5"
              title="Choose Your Language"
            >
              <Globe className="w-4 h-4 text-slate-500" />
              <span className="uppercase">{currentLanguage}</span>
            </button>
          </div>

          {/* TRUST / VALUE SECTION (5 Core Pillars) */}
          <div className="pt-10 grid grid-cols-2 sm:grid-cols-5 gap-3 sm:gap-4 max-w-5xl mx-auto text-left">
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs hover:border-indigo-300 transition-colors">
              <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-2">
                <Bot className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold text-slate-900 leading-tight">
                {t('value.ai_guidance')}
              </h4>
              <p className="text-[11px] text-slate-500 mt-1">Deterministic readiness engine</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs hover:border-indigo-300 transition-colors">
              <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-2">
                <Target className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold text-slate-900 leading-tight">
                {t('value.personalized_opps')}
              </h4>
              <p className="text-[11px] text-slate-500 mt-1">Direct matching algorithm</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs hover:border-indigo-300 transition-colors">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-2">
                <FileText className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold text-slate-900 leading-tight">
                {t('value.smart_resume')}
              </h4>
              <p className="text-[11px] text-slate-500 mt-1">ATS & capability alignment</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs hover:border-indigo-300 transition-colors">
              <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-2">
                <BarChart3 className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold text-slate-900 leading-tight">
                {t('value.career_readiness')}
              </h4>
              <p className="text-[11px] text-slate-500 mt-1">Transparent score & diagnostics</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs hover:border-indigo-300 transition-colors col-span-2 sm:col-span-1">
              <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-2">
                <CheckSquare className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold text-slate-900 leading-tight">
                {t('value.direct_applications')}
              </h4>
              <p className="text-[11px] text-slate-500 mt-1">Real-time status tracking</p>
            </div>
          </div>
        </div>
      </section>

      {/* Public Job Opportunities Preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">Live Opportunities</span>
              <h2 className="text-2xl font-extrabold text-slate-900 font-display mt-0.5">
                Explore Verified Job & Internship Openings
              </h2>
              <p className="text-xs text-slate-500">
                Browse positions actively hiring through Nexif5's matching network
              </p>
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search job title, skill, city..."
                value={publicSearchQuery}
                onChange={(e) => setPublicSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredPublicJobs.map((job) => (
              <div
                key={job.id}
                className="p-5 rounded-2xl border border-slate-200 hover:border-indigo-300 hover:shadow-md transition-all flex flex-col justify-between bg-slate-50/50"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={job.companyLogoUrl}
                        alt={job.companyName}
                        className="w-10 h-10 rounded-xl object-cover border border-slate-200 bg-white p-0.5"
                      />
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm leading-tight hover:text-indigo-600 cursor-pointer">
                          {job.title}
                        </h4>
                        <p className="text-xs text-slate-500 font-medium">{job.companyName}</p>
                      </div>
                    </div>

                    <span className="px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 text-[11px] font-bold shrink-0">
                      {job.salaryDisplay || `${job.salaryMinLPA}-${job.salaryMaxLPA} LPA`}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-2 text-[11px] text-slate-500">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {job.location} ({job.workMode})
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {job.type === 'internship' ? 'Internship' : 'Full-time'}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {(job.requiredSkills || []).slice(0, 3).map((sk, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded-lg bg-white border border-slate-200 text-slate-700 text-[11px]"
                      >
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-4 mt-3 border-t border-slate-200/80 flex items-center justify-between">
                  <span className="text-[11px] text-slate-500 font-medium">
                    {job.applicantsCount} candidates applied
                  </span>

                  <button
                    onClick={() => {
                      setAuthMode('signin');
                      setSelectedAuthRole('student');
                      setAuthModalOpen(true);
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors flex items-center gap-1"
                  >
                    <span>Sign In to Apply</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center pt-2">
            <button
              onClick={() => {
                switchToStudentDemo('std-1');
                setActiveStudentTab('jobs');
              }}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 inline-flex items-center gap-1.5"
            >
              <span>View all {jobs.length} open opportunities in Candidate Portal</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Interactive Career Execution Loop Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <CareerExecutionLoop />
      </section>

      {/* 4 Stakeholder Portals */}
      <section id="platform-pillars" className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
            Tailored Experiences
          </span>
          <h2 className="text-3xl font-extrabold text-slate-950 font-display">
            Designed for Every Stakeholder in Career Growth & Hiring
          </h2>
          <p className="text-sm text-slate-600">
            Sign in to access your customized role-based dashboard and tools.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* 1. Student Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-100">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">For Students</span>
                <h3 className="text-lg font-bold text-slate-900 font-display mt-0.5">
                  Student Portal
                </h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Start with a clear career goal. Get transparent AI readiness analysis, skill gap diagnostics, and apply directly to verified openings.
                </p>
              </div>

              <ul className="space-y-2 text-xs text-slate-700 pt-2 border-t border-slate-100">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Job & Internship Search</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>AI Career Readiness & Gaps</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Transparent Application Pipeline</span>
                </li>
              </ul>
            </div>

            <div className="pt-6 mt-4">
              <button
                onClick={() => handleLaunchRoleAuth('student')}
                className="w-full py-2.5 px-3 rounded-xl bg-blue-50 hover:bg-blue-600 text-blue-700 hover:text-white font-bold text-xs transition-all flex items-center justify-center gap-1.5 border border-blue-200 group-hover:bg-blue-600 group-hover:text-white"
              >
                <span>Enter Student Portal</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* 2. General Job Seeker Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100">
                <Briefcase className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">For Job Seekers</span>
                <h3 className="text-lg font-bold text-slate-900 font-display mt-0.5">
                  Job Seeker Portal
                </h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  For experienced professionals and independent job seekers. Discover roles matched to your verified skills, experience, and salary targets.
                </p>
              </div>

              <ul className="space-y-2 text-xs text-slate-700 pt-2 border-t border-slate-100">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Direct Company Applications</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Experienced Skill Gap AI</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Salary Benchmarks & Offers</span>
                </li>
              </ul>
            </div>

            <div className="pt-6 mt-4">
              <button
                onClick={() => handleLaunchRoleAuth('job_seeker')}
                className="w-full py-2.5 px-3 rounded-xl bg-amber-50 hover:bg-amber-600 text-amber-700 hover:text-white font-bold text-xs transition-all flex items-center justify-center gap-1.5 border border-amber-200 group-hover:bg-amber-600 group-hover:text-white"
              >
                <span>Enter Job Seeker Portal</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* 3. Recruiter / Company Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
                <Building2 className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">For Recruiters</span>
                <h3 className="text-lg font-bold text-slate-900 font-display mt-0.5">
                  Recruiter ATS
                </h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Post opportunities, review candidates with automated AI match scores, schedule interviews, and provide structured feedback.
                </p>
              </div>

              <ul className="space-y-2 text-xs text-slate-700 pt-2 border-t border-slate-100">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Deterministic Candidate Scoring</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Interview Scheduling System</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Structured Candidate Feedback</span>
                </li>
              </ul>
            </div>

            <div className="pt-6 mt-4">
              <button
                onClick={() => handleLaunchRoleAuth('recruiter')}
                className="w-full py-2.5 px-3 rounded-xl bg-emerald-50 hover:bg-emerald-600 text-emerald-700 hover:text-white font-bold text-xs transition-all flex items-center justify-center gap-1.5 border border-emerald-200 group-hover:bg-emerald-600 group-hover:text-white"
              >
                <span>Enter Recruiter Portal</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* 4. College / Placement Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center border border-purple-100">
                <School className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-bold text-purple-600 uppercase tracking-wider">For Colleges</span>
                <h3 className="text-lg font-bold text-slate-900 font-display mt-0.5">
                  Placement Cell
                </h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Track department placement drives, analyze batch skill gaps with AI diagnostics, and partner with visiting enterprise recruiters.
                </p>
              </div>

              <ul className="space-y-2 text-xs text-slate-700 pt-2 border-t border-slate-100">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Department Placement Analytics</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Batch Skill Gap Heatmaps</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Recruiter Relationship Hub</span>
                </li>
              </ul>
            </div>

            <div className="pt-6 mt-4">
              <button
                onClick={() => handleLaunchRoleAuth('college')}
                className="w-full py-2.5 px-3 rounded-xl bg-purple-50 hover:bg-purple-600 text-purple-700 hover:text-white font-bold text-xs transition-all flex items-center justify-center gap-1.5 border border-purple-200 group-hover:bg-purple-600 group-hover:text-white"
              >
                <span>Enter College Portal</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Modals */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authMode}
        initialRole={selectedAuthRole}
        onSuccessSignUp={handleSuccessSignUp}
      />

      <CareerOnboardingModal
        isOpen={onboardingOpen}
        onClose={() => setOnboardingOpen(false)}
        initialRole={registeredUser.role}
        userEmail={registeredUser.email}
        initialName={registeredUser.name}
      />

      <LanguageSelectorModal
        isOpen={languageModalOpen}
        onClose={() => setLanguageModalOpen(false)}
      />
    </div>
  );
};
