import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  School,
  Users,
  Award,
  TrendingUp,
  Building2,
  DollarSign,
  Briefcase,
  Bot,
  ArrowRight,
  Sparkles,
  ShieldCheck
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell
} from 'recharts';

export const CollegeDashboard: React.FC = () => {
  const { currentCollege, setActiveCollegeTab, students } = useApp();

  const deptData = [
    { name: 'Commerce (B.Com)', placed: 84, seeking: 16 },
    { name: 'Computer Sci (B.Tech)', placed: 92, seeking: 8 },
    { name: 'Management (BBA)', placed: 78, seeking: 22 },
    { name: 'Data Sci (BCA)', placed: 88, seeking: 12 }
  ];

  const COLORS = ['#10b981', '#6366f1', '#f59e0b', '#8b5cf6'];

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <img
            src={currentCollege.logoUrl}
            alt={currentCollege.name}
            className="w-12 h-12 rounded-2xl object-cover border border-slate-200 shadow-xs"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-slate-900 font-display">
                {currentCollege.name} Placement Hub
              </h1>
              <span className="px-2.5 py-0.5 rounded-full bg-purple-50 text-purple-700 text-xs font-bold border border-purple-200">
                Institutional Portal
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Campus Placement Cell • {currentCollege.location} • {currentCollege.type}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveCollegeTab('ai_advisor')}
            className="px-4 py-2.5 rounded-xl bg-purple-50 text-purple-700 hover:bg-purple-100 text-xs font-bold transition-colors flex items-center gap-1.5"
          >
            <Bot className="w-4 h-4" />
            <span>AI Placement Advisor</span>
          </button>
          <button
            onClick={() => setActiveCollegeTab('skill_gap')}
            className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-xs hover:shadow transition-all flex items-center gap-1.5"
          >
            <Sparkles className="w-4 h-4" />
            <span>Skill Gap Report</span>
          </button>
        </div>
      </div>

      {/* Section 21: 6 Institutional Key Metric Tiles */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* 1. Total Students */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="p-2 bg-slate-100 text-slate-700 rounded-xl">
              <Users className="w-4 h-4" />
            </span>
            <span className="text-[10px] font-bold text-slate-500">2025 Batch</span>
          </div>
          <div>
            <span className="text-2xl font-black text-slate-900 font-display block">1,200</span>
            <span className="text-[11px] text-slate-500 font-medium">Total Students</span>
          </div>
        </div>

        {/* 2. Placed Students */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
              <Award className="w-4 h-4" />
            </span>
            <span className="text-[10px] font-bold text-emerald-700">Offers</span>
          </div>
          <div>
            <span className="text-2xl font-black text-emerald-600 font-display block">850</span>
            <span className="text-[11px] text-slate-500 font-medium">Placed Students</span>
          </div>
        </div>

        {/* 3. Placement Rate */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <TrendingUp className="w-4 h-4" />
            </span>
            <span className="text-[10px] font-bold text-indigo-600">+12% YoY</span>
          </div>
          <div>
            <span className="text-2xl font-black text-indigo-600 font-display block">70.8%</span>
            <span className="text-[11px] text-slate-500 font-medium">Placement Rate</span>
          </div>
        </div>

        {/* 4. Average Package */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="p-2 bg-blue-50 text-blue-600 rounded-xl">
              <DollarSign className="w-4 h-4" />
            </span>
            <span className="text-[10px] font-bold text-blue-600">Mean</span>
          </div>
          <div>
            <span className="text-2xl font-black text-blue-600 font-display block">6.5 LPA</span>
            <span className="text-[11px] text-slate-500 font-medium">Avg Package</span>
          </div>
        </div>

        {/* 5. Highest Package */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="p-2 bg-amber-50 text-amber-600 rounded-xl">
              <Award className="w-4 h-4" />
            </span>
            <span className="text-[10px] font-bold text-amber-700">Top Offer</span>
          </div>
          <div>
            <span className="text-2xl font-black text-amber-600 font-display block">18.0 LPA</span>
            <span className="text-[11px] text-slate-500 font-medium">Top Package</span>
          </div>
        </div>

        {/* 6. Active Companies */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="p-2 bg-purple-50 text-purple-600 rounded-xl">
              <Building2 className="w-4 h-4" />
            </span>
            <span className="text-[10px] font-bold text-purple-700">Recruiters</span>
          </div>
          <div>
            <span className="text-2xl font-black text-purple-600 font-display block">45</span>
            <span className="text-[11px] text-slate-500 font-medium">Active Partners</span>
          </div>
        </div>
      </div>

      {/* Analytics Breakdown & AI Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left (7 cols): Department Placement Comparison Chart */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-base font-display">
                Departmental Placement Success (% Placed)
              </h3>
              <p className="text-xs text-slate-500">
                Comparing conversion rates across enrolled undergraduate programs
              </p>
            </div>

            <button
              onClick={() => setActiveCollegeTab('analytics')}
              className="text-xs font-bold text-purple-600 hover:text-purple-800"
            >
              Full Analytics
            </button>
          </div>

          <div className="h-64 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={deptData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis unit="%" tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip
                  contentStyle={{
                    borderRadius: '12px',
                    backgroundColor: '#0f172a',
                    color: '#fff',
                    border: 'none',
                    fontSize: '12px'
                  }}
                />
                <Bar dataKey="placed" name="% Placed" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right (5 cols): AI Department Skill Gap Callout */}
        <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-purple-950 text-white rounded-2xl p-6 shadow-xs space-y-5 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-semibold border border-purple-500/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI CURRICULUM GAP DETECTION</span>
            </div>

            <h3 className="text-xl font-bold font-display leading-snug">
              "B.Com students are missing SQL & Power BI for high-paying Business Analyst roles."
            </h3>

            <p className="text-xs text-slate-300 leading-relaxed">
              Nexif5 AI compared your 2025 student cohort against 1,400+ live job requisitions across top recruiters like Deloitte, FinEdge, and HealthScale.
            </p>
          </div>

          <div className="space-y-3 pt-2">
            <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-xl border border-white/10 text-xs space-y-1">
              <span className="text-purple-300 font-semibold block text-[11px]">Recommended Intervention:</span>
              <p className="text-slate-200 text-[11px]">
                Host a 2-week weekend boot camp on SQL joins & interactive Power BI dashboards to unlock 45+ additional corporate drives.
              </p>
            </div>

            <button
              onClick={() => setActiveCollegeTab('skill_gap')}
              className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2"
            >
              <span>View Department Skill Gap Heatmap</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
