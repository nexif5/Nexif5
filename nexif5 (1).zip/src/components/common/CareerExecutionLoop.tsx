import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Target,
  BrainCircuit,
  AlertTriangle,
  Zap,
  Sparkles,
  Send,
  Building,
  CalendarCheck,
  Award,
  RefreshCw,
  ChevronRight,
  ArrowRight
} from 'lucide-react';

interface LoopStep {
  id: string;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
  borderColor: string;
  details: {
    description: string;
    studentExample: string;
    aiEngineRole: string;
  };
}

const LOOP_STEPS: LoopStep[] = [
  {
    id: 'goal',
    title: '1. Career Goal',
    subtitle: 'Define Ambition',
    icon: <Target className="w-5 h-5" />,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
    details: {
      description: 'The student explicitly sets their target role (e.g. Business Analyst, Full Stack Dev, Data Scientist) without being restricted by legacy job board algorithms.',
      studentExample: 'Aarav selects "Business Analyst" with target salary ₹6.5 - 9.0 LPA in Bengaluru/Coimbatore.',
      aiEngineRole: 'Establishes target competency benchmarks, required tools (SQL, Power BI, Excel), and salary expectations.'
    }
  },
  {
    id: 'analysis',
    title: '2. AI Career Analysis',
    subtitle: 'Deep Diagnostics',
    icon: <BrainCircuit className="w-5 h-5" />,
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-50',
    borderColor: 'border-indigo-200',
    details: {
      description: 'Nexif5 AI analyzes current skills, achievements, college coursework, projects, and certifications against live corporate criteria.',
      studentExample: 'Readiness evaluated at 78/100 based on verified Excel mastery and National Case Challenge win.',
      aiEngineRole: 'Evaluates multi-dimensional readiness across Technical, Analytics, Domain, and Soft skills.'
    }
  },
  {
    id: 'skillgap',
    title: '3. Skill Gap',
    subtitle: 'Pinpoint Deficits',
    icon: <AlertTriangle className="w-5 h-5" />,
    color: 'text-amber-600',
    bgColor: 'bg-amber-50',
    borderColor: 'border-amber-200',
    details: {
      description: 'Transparently reveals which exact skills are strong vs intermediate vs needing improvement.',
      studentExample: 'Excel: Strong (Advanced) • Power BI: Intermediate • SQL: Needs Improvement (Subqueries).',
      aiEngineRole: 'Eliminates guesswork by categorizing every required competency for the target role.'
    }
  },
  {
    id: 'action',
    title: '4. Next Best Action',
    subtitle: 'Guided Execution',
    icon: <Zap className="w-5 h-5" />,
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-50',
    borderColor: 'border-emerald-200',
    details: {
      description: 'Gives the student a single, high-leverage immediate action instead of vague generic advice.',
      studentExample: '"Complete one SQL multi-table analytics project and attach live demo to resume."',
      aiEngineRole: 'Calculates the highest ROI task to boost interview shortlisting probability.'
    }
  },
  {
    id: 'matching',
    title: '5. Opportunity Match',
    subtitle: '94% Transparent Match',
    icon: <Sparkles className="w-5 h-5" />,
    color: 'text-purple-600',
    bgColor: 'bg-purple-50',
    borderColor: 'border-purple-200',
    details: {
      description: 'Matches students to verified jobs, internships, hackathons, and campus drives with granular match reason breakdowns.',
      studentExample: 'ABC Technologies Associate Business Analyst — 94% Match (Skills 95%, Degree 100%, Goal 96%).',
      aiEngineRole: 'Generates transparent "Why this matches you" explanations without arbitrary scores.'
    }
  },
  {
    id: 'application',
    title: '6. Application',
    subtitle: '1-Click Verification',
    icon: <Send className="w-5 h-5" />,
    color: 'text-cyan-600',
    bgColor: 'bg-cyan-50',
    borderColor: 'border-cyan-200',
    details: {
      description: 'Direct submission with candidate profile, verified achievements, and chosen resume tagged as "Applied through Nexif5".',
      studentExample: 'Application submitted directly to ABC Technologies with portfolio artifacts and cover note.',
      aiEngineRole: 'Packages verified candidate credentials and highlights why the candidate excels.'
    }
  },
  {
    id: 'response',
    title: '7. Recruiter Response',
    subtitle: 'Pipeline Transparency',
    icon: <Building className="w-5 h-5" />,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
    details: {
      description: 'Recruiters view candidate match reasons, achievements, and code/dashboards to make human-in-the-loop hiring decisions.',
      studentExample: 'Recruiter Smita Kulkarni reviews 94% match profile and moves candidate to Shortlist status.',
      aiEngineRole: 'Assists recruiter filtering while ensuring AI does NOT make unilateral hiring decisions.'
    }
  },
  {
    id: 'interview',
    title: '8. Interview',
    subtitle: 'Smart Preparation',
    icon: <CalendarCheck className="w-5 h-5" />,
    color: 'text-teal-600',
    bgColor: 'bg-teal-50',
    borderColor: 'border-teal-200',
    details: {
      description: 'Seamless interview scheduling with video call links, interviewer details, and role-specific AI prep drills.',
      studentExample: 'Analytics Case Study round scheduled for Feb 18, 3:30 PM with Google Meet integration.',
      aiEngineRole: 'Generates tailored interview questions and framework walk-throughs for the specific company.'
    }
  },
  {
    id: 'outcome',
    title: '9. Selection / Rejection',
    subtitle: 'Fair Feedback Loop',
    icon: <Award className="w-5 h-5" />,
    color: 'text-rose-600',
    bgColor: 'bg-rose-50',
    borderColor: 'border-rose-200',
    details: {
      description: 'If selected: offer extended and recorded in college placement analytics. If rejected: constructive recruiter feedback is analyzed by AI.',
      studentExample: 'Constructive feedback: "SQL query optimization needed" triggers targeted remedial exercises.',
      aiEngineRole: 'Guarantees that rejections turn into immediate learning cycles rather than dead ends.'
    }
  },
  {
    id: 'repeat',
    title: '10. AI Next Action & Loop',
    subtitle: 'Continuous Growth',
    icon: <RefreshCw className="w-5 h-5" />,
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-50',
    borderColor: 'border-indigo-200',
    details: {
      description: 'The loop restarts with updated skills, higher readiness scores, and elevated opportunities until successful career execution.',
      studentExample: 'Aarav completes SQL project → Readiness jumps to 88/100 → Receives ₹25k/mo PPO Intern Offer!',
      aiEngineRole: 'Dynamically updates candidate ranking across all partner company talent pools.'
    }
  }
];

export const CareerExecutionLoop: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const [selectedStepId, setSelectedStepId] = useState<string>('matching');
  const selectedStep = LOOP_STEPS.find(s => s.id === selectedStepId) || LOOP_STEPS[4];

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-6 md:p-8 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 text-xs font-semibold uppercase tracking-wider mb-2">
            <RefreshCw className="w-3.5 h-3.5" />
            <span>The Nexif5 Core Framework</span>
          </div>
          <h2 className="text-2xl font-bold text-slate-900 font-display">
            The Continuous Career Execution Loop
          </h2>
          <p className="text-sm text-slate-600 max-w-2xl mt-1">
            Unlike static job boards, Nexif5 turns every application into an active learning, matching, and execution cycle.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 px-3 py-2 rounded-lg border border-slate-200">
          <span>Click any node in the sequence to inspect the execution logic</span>
        </div>
      </div>

      {/* Visual Sequence Chain */}
      <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-2 mb-6">
        {LOOP_STEPS.map((step, idx) => {
          const isSelected = selectedStepId === step.id;
          return (
            <button
              key={step.id}
              onClick={() => setSelectedStepId(step.id)}
              className={`p-2.5 rounded-xl border text-left transition-all flex flex-col justify-between relative group ${
                isSelected
                  ? `${step.bgColor} ${step.borderColor} border-2 shadow-sm ring-2 ring-indigo-500/20`
                  : 'bg-slate-50/70 hover:bg-slate-100 border-slate-200 text-slate-700'
              }`}
            >
              <div className="flex items-center justify-between w-full mb-2">
                <span className={`p-1.5 rounded-lg ${isSelected ? 'bg-white shadow-xs' : 'bg-slate-200/60'} ${step.color}`}>
                  {step.icon}
                </span>
                <span className="text-[10px] font-bold text-slate-400">0{idx + 1}</span>
              </div>
              <div>
                <p className="text-xs font-bold leading-tight text-slate-900 truncate">
                  {step.title.split('. ')[1]}
                </p>
                <p className="text-[10px] text-slate-500 truncate mt-0.5">
                  {step.subtitle}
                </p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Step Deep Dive Card */}
      <AnimatePresence mode="wait">
        <motion.div
          key={selectedStep.id}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.18 }}
          className={`p-5 sm:p-6 rounded-xl border ${selectedStep.borderColor} ${selectedStep.bgColor} relative overflow-hidden`}
        >
          <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-6">
            <div className="space-y-3 max-w-2xl">
              <div className="flex items-center gap-3">
                <span className={`p-2 rounded-xl bg-white shadow-xs border ${selectedStep.borderColor} ${selectedStep.color}`}>
                  {selectedStep.icon}
                </span>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 font-display">
                    {selectedStep.title}: {selectedStep.subtitle}
                  </h3>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Phase {LOOP_STEPS.findIndex(s => s.id === selectedStep.id) + 1} of 10 in Career Execution
                  </p>
                </div>
              </div>

              <p className="text-sm text-slate-700 leading-relaxed font-normal">
                {selectedStep.details.description}
              </p>

              <div className="pt-2">
                <div className="bg-white/80 backdrop-blur-xs p-3.5 rounded-lg border border-slate-200/80 text-xs">
                  <span className="font-semibold text-slate-900 block mb-1">
                    🎯 Live Prototype Demonstration Example:
                  </span>
                  <p className="text-slate-700 italic">
                    "{selectedStep.details.studentExample}"
                  </p>
                </div>
              </div>
            </div>

            <div className="lg:w-80 shrink-0 bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-indigo-600">
                <BrainCircuit className="w-4 h-4" />
                <span>NEXIF5 AI ENGINE ROLE</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                {selectedStep.details.aiEngineRole}
              </p>
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">Step {LOOP_STEPS.findIndex(s => s.id === selectedStep.id) + 1}/10</span>
                <button
                  onClick={() => {
                    const currentIndex = LOOP_STEPS.findIndex(s => s.id === selectedStep.id);
                    const nextIndex = (currentIndex + 1) % LOOP_STEPS.length;
                    setSelectedStepId(LOOP_STEPS[nextIndex].id);
                  }}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
                >
                  <span>Next Step</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
