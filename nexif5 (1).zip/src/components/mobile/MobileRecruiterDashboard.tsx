import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Building2,
  Briefcase,
  Users,
  Sparkles,
  Layers,
  CalendarCheck,
  Plus,
  Bot,
  CheckCircle2,
  ChevronRight,
  Filter,
  ArrowUpRight,
  School
} from 'lucide-react';

export const MobileRecruiterDashboard: React.FC = () => {
  const {
    currentCompany,
    jobs,
    applications,
    students,
    activeRecruiterTab,
    setActiveRecruiterTab,
    theme
  } = useApp();

  const isLight = theme === 'light';

  const companyJobs = jobs.filter(j => j.companyId === currentCompany.id || !j.companyId);
  const companyApps = applications;

  const [activePipelineStage, setActivePipelineStage] = useState<'all' | 'applied' | 'shortlisted' | 'interview' | 'selected'>('all');

  const filteredApps = activePipelineStage === 'all'
    ? companyApps
    : companyApps.filter(a => a.status === activePipelineStage);

  // Top AI Matched Candidates from student pool
  const topCandidateMatches = students.slice(0, 3).map((st, idx) => ({
    student: st,
    matchScore: 92 - idx * 4,
    matchingJobTitle: companyJobs[idx % companyJobs.length]?.title || 'Business Analyst',
    matchedSkills: st.skills.slice(0, 3).map(s => s.name),
    whyItMatches: 'Strong SQL and analytics foundations with verified capstone projects.'
  }));

  return (
    <div className={`p-4 space-y-4 pb-24 font-sans ${isLight ? 'text-slate-900' : 'text-white'}`}>
      {/* Recruiter / Company Header */}
      <div className={`p-4 rounded-2xl border ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <img
              src={currentCompany.logoUrl}
              alt={currentCompany.name}
              className="w-14 h-14 rounded-2xl object-cover border border-slate-600 shadow-md"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold font-display">{currentCompany.name}</h1>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 font-bold">
                  Verified
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {currentCompany.industry}
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {currentCompany.headquarters} • {currentCompany.employeeCount} employees
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2 mt-3.5 pt-3 border-t border-slate-700/50">
          <button
            onClick={() => setActiveRecruiterTab('jobs')}
            className="py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Post Requisition</span>
          </button>
          <button
            onClick={() => setActiveRecruiterTab('candidates')}
            className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95 transition-all"
          >
            <Bot className="w-3.5 h-3.5 text-emerald-400" />
            <span>AI Talent Search</span>
          </button>
        </div>
      </div>

      {/* 4 Key Recruiter Performance Metrics */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Briefcase className="w-4 h-4 text-emerald-500" />
            <span className="text-[10px] text-emerald-500 font-bold">Active</span>
          </div>
          <p className="text-xl font-black font-display">{companyJobs.length}</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Open Requisitions</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Users className="w-4 h-4 text-blue-500" />
            <span className="text-[10px] text-blue-400 font-bold">Pipeline</span>
          </div>
          <p className="text-xl font-black font-display">{companyApps.length + 38}</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Total Applicants</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span className="text-[10px] text-amber-500 font-bold">80%+ Match</span>
          </div>
          <p className="text-xl font-black font-display">24</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">AI High Match</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <CalendarCheck className="w-4 h-4 text-purple-500" />
            <span className="text-[10px] text-purple-400 font-bold">This Week</span>
          </div>
          <p className="text-xl font-black font-display">6</p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Interviews Slotted</p>
        </div>
      </div>

      {/* AI Talent Match Recommendations */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-500" />
            <h2 className="text-sm font-bold">AI Recommended Candidate Matches</h2>
          </div>
          <span className="text-[10px] text-emerald-500 font-bold">Ranked by Match</span>
        </div>

        <div className="space-y-2.5">
          {topCandidateMatches.map((item, idx) => (
            <div
              key={idx}
              className={`p-3 rounded-xl border space-y-2 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <img
                    src={item.student.avatarUrl}
                    alt={item.student.name}
                    className="w-10 h-10 rounded-full object-cover border border-emerald-500/50"
                  />
                  <div>
                    <h3 className="text-xs font-bold">{item.student.name}</h3>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      {item.student.education.institution} • {item.student.careerGoal}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-extrabold text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                    {item.matchScore}% Match
                  </span>
                </div>
              </div>

              {/* Skills matched */}
              <div className="flex flex-wrap gap-1">
                {item.matchedSkills.map((sk, sidx) => (
                  <span
                    key={sidx}
                    className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700"
                  >
                    ✓ {sk}
                  </span>
                ))}
              </div>

              <p className="text-[11px] text-slate-400 italic">
                "{item.whyItMatches}"
              </p>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[10px] text-slate-400">
                  Target: {item.matchingJobTitle}
                </span>
                <button
                  onClick={() => alert(`Interview invitation queued for ${item.student.name}`)}
                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[11px] font-bold"
                >
                  Invite to Apply
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Candidate Pipeline Kanban / Flow */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-500" />
            <h2 className="text-sm font-bold">Applicant Pipeline</h2>
          </div>
          <span className="text-[10px] text-slate-400">{filteredApps.length} in view</span>
        </div>

        {/* Pipeline Filter Tabs */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs">
          {[
            { id: 'all', label: 'All' },
            { id: 'applied', label: 'Applied' },
            { id: 'shortlisted', label: 'Shortlisted' },
            { id: 'interview', label: 'Interview' },
            { id: 'selected', label: 'Hired' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActivePipelineStage(tab.id as any)}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] whitespace-nowrap transition-all ${
                activePipelineStage === tab.id
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* List of Applications in Pipeline */}
        <div className="space-y-2">
          {filteredApps.slice(0, 4).map((app) => (
            <div
              key={app.id}
              className={`p-3 rounded-xl border flex items-center justify-between ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <img
                  src={app.candidateAvatarUrl}
                  alt={app.candidateName}
                  className="w-9 h-9 rounded-full object-cover"
                />
                <div>
                  <h3 className="text-xs font-bold">{app.candidateName}</h3>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    {app.jobTitle} • {app.matchScore}% Match Score
                  </p>
                </div>
              </div>

              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md capitalize ${
                app.status === 'selected' ? 'bg-emerald-500/20 text-emerald-400' :
                app.status === 'interview' ? 'bg-purple-500/20 text-purple-400' :
                app.status === 'shortlisted' ? 'bg-blue-500/20 text-blue-400' :
                'bg-slate-700 text-slate-300'
              }`}>
                {app.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Campus Connect & College Partnerships */}
      <div className={`p-4 rounded-2xl border space-y-3 ${
        isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <School className="w-4 h-4 text-purple-500" />
            <h2 className="text-sm font-bold">Campus Hiring & College Connect</h2>
          </div>
          <span className="text-[10px] text-purple-400 font-bold">Direct Channels</span>
        </div>

        <div className="space-y-2">
          <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-between text-xs">
            <div>
              <p className="font-bold text-purple-300">Rathinam Global University</p>
              <p className="text-[10px] text-slate-400">140 Eligible Analytics & Tech Candidates</p>
            </div>
            <button
              onClick={() => alert('Campus drive requisition request initiated')}
              className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-[10px] font-bold"
            >
              Request Drive
            </button>
          </div>

          <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-between text-xs">
            <div>
              <p className="font-bold text-purple-300">PSG College of Technology</p>
              <p className="text-[10px] text-slate-400">95 Engineering & Data Science Candidates</p>
            </div>
            <button
              onClick={() => alert('Campus drive requisition request initiated')}
              className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-[10px] font-bold"
            >
              Request Drive
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
