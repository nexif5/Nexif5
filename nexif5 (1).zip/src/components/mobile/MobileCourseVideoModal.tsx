import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  CheckCircle2,
  FileText,
  Sparkles,
  Award,
  BookOpen,
  Volume2,
  Maximize2,
  RotateCcw,
  Send,
  ExternalLink,
  Clock,
  Layers,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';

export const MobileCourseVideoModal: React.FC = () => {
  const {
    isCourseVideoModalOpen,
    setIsCourseVideoModalOpen,
    selectedCourseForLearning,
    activeVideoLessonId,
    setActiveVideoLessonId,
    completeVideoLesson,
    submitLessonPracticeTask,
    openCourseAssessment,
    openCertificateView,
    sharedResources,
    setSelectedResourceForDetail,
    theme
  } = useApp();

  const isLight = theme === 'light';

  // Video player playback simulation states
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [videoProgressSeconds, setVideoProgressSeconds] = useState<number>(65);
  const [practiceSubmission, setPracticeSubmission] = useState<string>('');
  const [isSubmittingTask, setIsSubmittingTask] = useState<boolean>(false);
  const [taskSubmittedToast, setTaskSubmittedToast] = useState<boolean>(false);

  const course = selectedCourseForLearning;

  // Active lesson
  const currentLesson =
    course?.videoLessons.find(l => l.id === activeVideoLessonId) ||
    course?.videoLessons[0];

  const currentLessonIndex = course && currentLesson
    ? course.videoLessons.findIndex(l => l.id === currentLesson.id)
    : 0;

  // Pause playback when modal is closed
  useEffect(() => {
    if (!isCourseVideoModalOpen) {
      setIsPlaying(false);
    }
  }, [isCourseVideoModalOpen]);

  // Check for video completion cleanly in an effect, rather than inside a setState updater
  useEffect(() => {
    if (!isPlaying || !currentLesson || !course) return;
    const totalSec = currentLesson.durationMinutes * 60;
    if (videoProgressSeconds >= totalSec) {
      setIsPlaying(false);
      completeVideoLesson(course.id, currentLesson.id);
    }
  }, [videoProgressSeconds, isPlaying, currentLesson, course, completeVideoLesson]);

  // Timer simulation for playback with pure updater
  useEffect(() => {
    let interval: any;
    if (isPlaying && currentLesson) {
      const totalSec = currentLesson.durationMinutes * 60;
      interval = setInterval(() => {
        setVideoProgressSeconds(prev => Math.min(totalSec, prev + Math.floor(playbackSpeed)));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed, currentLesson]);

  // Reset progress and input on lesson switch
  useEffect(() => {
    if (currentLesson) {
      setVideoProgressSeconds(currentLesson.isCompleted ? currentLesson.durationMinutes * 60 : 45);
      setIsPlaying(false);
      setPracticeSubmission(currentLesson.practiceTask?.userSubmission || '');
    }
  }, [currentLesson?.id]);

  if (!isCourseVideoModalOpen || !course || !currentLesson) {
    return null;
  }

  const totalLessons = course.videoLessons.length;
  const completedLessons = course.videoLessons.filter(l => l.isCompleted).length;
  const totalDurationSec = currentLesson.durationMinutes * 60;
  const progressRatio = Math.min(1, videoProgressSeconds / (totalDurationSec || 1));

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleNextLesson = () => {
    if (currentLessonIndex < totalLessons - 1) {
      setActiveVideoLessonId(course.videoLessons[currentLessonIndex + 1].id);
    }
  };

  const handlePrevLesson = () => {
    if (currentLessonIndex > 0) {
      setActiveVideoLessonId(course.videoLessons[currentLessonIndex - 1].id);
    }
  };

  const handleSpeedToggle = () => {
    const speeds = [1.0, 1.25, 1.5, 2.0];
    const nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.length;
    setPlaybackSpeed(speeds[nextIdx]);
  };

  const handlePracticeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!practiceSubmission.trim()) return;

    setIsSubmittingTask(true);
    setTimeout(() => {
      submitLessonPracticeTask(course.id, currentLesson.id, practiceSubmission.trim());
      setIsSubmittingTask(false);
      setTaskSubmittedToast(true);
      setTimeout(() => setTaskSubmittedToast(false), 3000);
    }, 400);
  };

  const handleOpenRelatedNotes = (resId: string) => {
    const target = sharedResources.find(r => r.id === resId);
    if (target) {
      setSelectedResourceForDetail(target);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className={`w-full max-w-xl max-h-[92vh] flex flex-col rounded-t-3xl sm:rounded-3xl border shadow-2xl overflow-hidden font-sans transition-all ${
          isLight ? 'bg-slate-50 text-slate-900 border-slate-200' : 'bg-slate-900 text-white border-slate-800'
        }`}
      >
        {/* Modal Top Header */}
        <div
          className={`px-4 py-3 border-b flex items-center justify-between shrink-0 ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-800/80 border-slate-700/80'
          }`}
        >
          <div className="min-w-0 pr-2">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-500">
                {course.provider} • {course.partner}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-500 font-bold">
                {course.level}
              </span>
            </div>
            <h2 className="text-sm font-bold truncate mt-0.5 font-display">{course.title}</h2>
          </div>

          <button
            onClick={() => setIsCourseVideoModalOpen(false)}
            className={`p-1.5 rounded-full transition-colors shrink-0 ${
              isLight ? 'hover:bg-slate-100 text-slate-500' : 'hover:bg-slate-800 text-slate-400'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Container */}
        <div className="flex-1 overflow-y-auto no-scrollbar space-y-4 p-4 pb-20">
          {/* ========================================================= */}
          {/* 1. INTERACTIVE VIDEO PLAYER SCREEN */}
          {/* ========================================================= */}
          <div className="rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 shadow-lg relative group">
            {/* Video Stage / Visual Screen */}
            <div className="relative aspect-video w-full bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950/80 flex flex-col justify-between p-4 overflow-hidden">
              {/* Subtle background graphics */}
              <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#6366f1_1px,transparent_1px)] [background-size:16px_16px]" />

              {/* Top Video Overlay Info */}
              <div className="relative z-10 flex items-center justify-between text-white/90 text-xs">
                <span className="px-2 py-1 rounded-md bg-black/60 backdrop-blur-xs font-mono font-bold text-[11px] flex items-center gap-1.5 border border-white/10">
                  <span className={`w-2 h-2 rounded-full ${isPlaying ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                  <span>Module {currentLesson.moduleNumber}</span>
                </span>
                <span className="text-[11px] font-semibold text-white/70">
                  {currentLesson.videoSourceLabel}
                </span>
              </div>

              {/* Center Presentation Preview Display */}
              <div className="relative z-10 my-auto text-center px-4 space-y-1.5">
                <div className="inline-flex p-3 rounded-2xl bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 backdrop-blur-md shadow-inner">
                  <BookOpen className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-bold text-white tracking-wide drop-shadow-sm line-clamp-2">
                  {currentLesson.title}
                </h3>
                <p className="text-[11px] text-indigo-200/80 max-w-sm mx-auto">
                  Developing: <span className="font-semibold text-white">{currentLesson.skillDeveloped}</span>
                </p>
              </div>

              {/* Bottom Scrubber & Time */}
              <div className="relative z-10 space-y-1">
                {/* Progress bar scrubber */}
                <div
                  onClick={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect();
                    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                    setVideoProgressSeconds(Math.floor(ratio * totalDurationSec));
                  }}
                  className="w-full h-2 bg-white/20 rounded-full cursor-pointer relative overflow-hidden group/bar"
                >
                  <div
                    className="h-full bg-gradient-to-r from-indigo-500 to-indigo-400 rounded-full transition-all"
                    style={{ width: `${progressRatio * 100}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-white/80 pt-0.5">
                  <span>{formatTime(videoProgressSeconds)}</span>
                  <span>{formatTime(totalDurationSec)}</span>
                </div>
              </div>
            </div>

            {/* Video Controls Toolbar */}
            <div className="bg-slate-900/90 border-t border-slate-800 px-4 py-2.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {/* Previous Lesson */}
                <button
                  onClick={handlePrevLesson}
                  disabled={currentLessonIndex === 0}
                  className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 disabled:opacity-30 disabled:pointer-events-none transition-colors"
                  title="Previous Lesson"
                >
                  <SkipBack className="w-4 h-4" />
                </button>

                {/* Play / Pause Toggle */}
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md active:scale-95 transition-all"
                  title={isPlaying ? 'Pause' : 'Play'}
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                </button>

                {/* Next Lesson */}
                <button
                  onClick={handleNextLesson}
                  disabled={currentLessonIndex === totalLessons - 1}
                  className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 disabled:opacity-30 disabled:pointer-events-none transition-colors"
                  title="Next Lesson"
                >
                  <SkipForward className="w-4 h-4" />
                </button>

                {/* Playback Speed */}
                <button
                  onClick={handleSpeedToggle}
                  className="px-2 py-1 rounded-md text-[11px] font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors font-mono"
                  title="Playback Speed"
                >
                  {playbackSpeed}x
                </button>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  {currentLesson.difficulty}
                </span>
                <span className="text-[11px] text-slate-400 font-medium">
                  {currentLesson.videoDurationFormatted}
                </span>
              </div>
            </div>
          </div>

          {/* ========================================================= */}
          {/* 2. LESSON OVERVIEW & RELATED STUDY RESOURCES */}
          {/* ========================================================= */}
          <div
            className={`p-4 rounded-2xl border space-y-2.5 ${
              isLight ? 'bg-white border-slate-200' : 'bg-slate-800/80 border-slate-700'
            }`}
          >
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-500">
                  Lesson Description
                </span>
                <h3 className="text-sm font-bold font-display mt-0.5">{currentLesson.title}</h3>
              </div>
              {currentLesson.isCompleted ? (
                <span className="shrink-0 text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-500 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Completed</span>
                </span>
              ) : (
                <button
                  onClick={() => completeVideoLesson(course.id, currentLesson.id)}
                  className="shrink-0 px-2.5 py-1 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-indigo-600 hover:text-white text-xs font-bold transition-all"
                >
                  Mark Watched
                </button>
              )}
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {currentLesson.description}
            </p>

            {/* Related Resource Quick Link */}
            {currentLesson.relatedResourceId && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs">
                  <FileText className="w-3.5 h-3.5 text-indigo-500" />
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    Accompanying Study Notes:
                  </span>
                </div>
                <button
                  onClick={() => handleOpenRelatedNotes(currentLesson.relatedResourceId!)}
                  className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                >
                  <span>Open PDF Cheat Sheet</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>

          {/* ========================================================= */}
          {/* 3. PRACTICE AFTER VIDEO (MANDATORY PRACTICAL APPLICATION) */}
          {/* ========================================================= */}
          {currentLesson.practiceTask && (
            <div
              className={`p-4 rounded-2xl border space-y-3 ${
                currentLesson.practiceTask.isCompleted
                  ? isLight
                    ? 'bg-emerald-50/70 border-emerald-200'
                    : 'bg-emerald-950/20 border-emerald-500/30'
                  : isLight
                  ? 'bg-amber-50/70 border-amber-200'
                  : 'bg-amber-950/20 border-amber-500/30'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs ${
                      currentLesson.practiceTask.isCompleted
                        ? 'bg-emerald-500 text-white'
                        : 'bg-amber-500/20 text-amber-500'
                    }`}
                  >
                    ⚡
                  </div>
                  <div>
                    <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 dark:text-white">
                      Practice After Video
                    </h4>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      Watching alone does not mark a skill as mastered. Complete practical work.
                    </p>
                  </div>
                </div>

                {currentLesson.practiceTask.isCompleted && (
                  <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified</span>
                  </span>
                )}
              </div>

              <div className="p-3 rounded-xl bg-white/70 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800 space-y-2 text-xs">
                <p className="font-bold text-slate-900 dark:text-white">
                  {currentLesson.practiceTask.title}
                </p>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  {currentLesson.practiceTask.description}
                </p>

                {currentLesson.practiceTask.instructions.length > 0 && (
                  <div className="space-y-1 pt-1">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Required Action Steps:
                    </span>
                    <ul className="space-y-1 list-disc list-inside text-[11px] text-slate-600 dark:text-slate-300">
                      {currentLesson.practiceTask.instructions.map((inst, i) => (
                        <li key={i}>{inst}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Submission Box */}
              <form onSubmit={handlePracticeSubmit} className="space-y-2">
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300">
                  {currentLesson.practiceTask.isCompleted
                    ? 'Your Submitted Practice Evidence / Notes:'
                    : 'Submit Your Practical Findings / Formulas / Dashboard Notes:'}
                </label>
                <textarea
                  value={practiceSubmission}
                  onChange={(e) => setPracticeSubmission(e.target.value)}
                  disabled={currentLesson.practiceTask.isCompleted}
                  placeholder="Paste your DAX formula, SQL query, financial model numbers, or summary of your completed exercise..."
                  rows={3}
                  className={`w-full p-2.5 rounded-xl border text-xs outline-hidden transition-all ${
                    isLight
                      ? 'bg-white border-slate-300 text-slate-900 focus:border-indigo-500'
                      : 'bg-slate-800 border-slate-700 text-white focus:border-indigo-400'
                  } ${currentLesson.practiceTask.isCompleted ? 'opacity-80 cursor-not-allowed' : ''}`}
                />

                {!currentLesson.practiceTask.isCompleted && (
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={isSubmittingTask || !practiceSubmission.trim()}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{isSubmittingTask ? 'Verifying Work...' : 'Submit & Verify Task'}</span>
                    </button>
                  </div>
                )}

                {taskSubmittedToast && (
                  <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold flex items-center gap-2 animate-fade-in">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>Practical task submitted! AI Coach recorded your demonstration.</span>
                  </div>
                )}
              </form>
            </div>
          )}

          {/* ========================================================= */}
          {/* 4. MODULES & LESSONS BREAKDOWN LIST */}
          {/* ========================================================= */}
          <div className="space-y-2 pt-1">
            <div className="flex items-center justify-between text-xs font-bold text-slate-400 uppercase tracking-wider">
              <span>Course Curriculum ({completedLessons}/{totalLessons} completed)</span>
              <span>{course.progressPercent}%</span>
            </div>

            <div className="space-y-1.5">
              {course.videoLessons.map((lesson, idx) => {
                const isActive = lesson.id === currentLesson.id;
                return (
                  <div
                    key={lesson.id}
                    onClick={() => setActiveVideoLessonId(lesson.id)}
                    className={`p-3 rounded-2xl border flex items-center justify-between gap-3 cursor-pointer transition-all ${
                      isActive
                        ? isLight
                          ? 'bg-indigo-50/90 border-indigo-300 shadow-xs ring-1 ring-indigo-400'
                          : 'bg-indigo-950/40 border-indigo-500/60 ring-1 ring-indigo-500'
                        : isLight
                        ? 'bg-white hover:bg-slate-50 border-slate-200'
                        : 'bg-slate-800/60 hover:bg-slate-800 border-slate-700/80'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                          lesson.isCompleted
                            ? 'bg-emerald-500 text-white'
                            : isActive
                            ? 'bg-indigo-600 text-white'
                            : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {lesson.isCompleted ? '✓' : idx + 1}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold truncate">{lesson.title}</p>
                        <p className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                          <span>{lesson.videoDurationFormatted}</span>
                          <span>•</span>
                          <span>{lesson.skillDeveloped}</span>
                        </p>
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-2">
                      {lesson.practiceTask && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded-sm bg-amber-500/10 text-amber-500 font-bold">
                          Practice
                        </span>
                      )}
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Modal Bottom Sticky Footer */}
        <div
          className={`px-4 py-3 border-t flex items-center justify-between gap-3 shrink-0 ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-800/90 border-slate-700'
          }`}
        >
          <div className="text-xs">
            <span className="text-slate-400 block text-[10px]">Course Progress</span>
            <span className="font-extrabold text-indigo-600 dark:text-indigo-400">
              {course.progressPercent}% Completed
            </span>
          </div>

          <div className="flex items-center gap-2">
            {course.isCertificateEarned ? (
              <button
                onClick={() => {
                  setIsCourseVideoModalOpen(false);
                  openCertificateView(course.id);
                }}
                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center gap-1.5"
              >
                <Award className="w-3.5 h-3.5" />
                <span>View Certificate</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  setIsCourseVideoModalOpen(false);
                  openCourseAssessment(course.id);
                }}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Take AI Assessment</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
