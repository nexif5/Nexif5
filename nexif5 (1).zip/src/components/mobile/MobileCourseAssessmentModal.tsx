import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Award,
  ChevronRight,
  ChevronLeft,
  RotateCcw,
  ShieldCheck,
  TrendingUp,
  BookOpen,
  ArrowRight
} from 'lucide-react';

export const MobileCourseAssessmentModal: React.FC = () => {
  const {
    isAssessmentModalOpen,
    setIsAssessmentModalOpen,
    selectedCourseForAssessment,
    submitCourseAssessment,
    openCertificateView,
    openCourseLearning,
    theme
  } = useApp();

  const isLight = theme === 'light';
  const course = selectedCourseForAssessment;

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [assessmentResult, setAssessmentResult] = useState<{
    scorePercent: number;
    passed: boolean;
    certificate?: any;
  } | null>(null);

  if (!isAssessmentModalOpen || !course) {
    return null;
  }

  const questions = course.assessment.questions;
  const currentQ = questions[currentQuestionIndex];
  const totalQuestions = questions.length;
  const isLastQuestion = currentQuestionIndex === totalQuestions - 1;

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex
    }));
  };

  const handleNext = () => {
    if (currentQuestionIndex < totalQuestions - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const handleSubmit = () => {
    const result = submitCourseAssessment(course.id, selectedAnswers);
    setAssessmentResult(result);
    setIsSubmitted(true);
  };

  const handleRetake = () => {
    setSelectedAnswers({});
    setCurrentQuestionIndex(0);
    setIsSubmitted(false);
    setAssessmentResult(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className={`w-full max-w-xl max-h-[92vh] flex flex-col rounded-t-3xl sm:rounded-3xl border shadow-2xl overflow-hidden font-sans transition-all ${
          isLight ? 'bg-slate-50 text-slate-900 border-slate-200' : 'bg-slate-900 text-white border-slate-800'
        }`}
      >
        {/* Header */}
        <div
          className={`px-4 py-3.5 border-b flex items-center justify-between shrink-0 ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-800/80 border-slate-700/80'
          }`}
        >
          <div className="min-w-0 pr-2">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-500 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>AI Skill Assessment</span>
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 font-bold">
                Passing: {course.assessment.passingScorePercent}%
              </span>
            </div>
            <h2 className="text-sm font-bold truncate mt-0.5 font-display">{course.assessment.title}</h2>
          </div>

          <button
            onClick={() => setIsAssessmentModalOpen(false)}
            className={`p-1.5 rounded-full transition-colors shrink-0 ${
              isLight ? 'hover:bg-slate-100 text-slate-500' : 'hover:bg-slate-800 text-slate-400'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Container */}
        <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
          {!isSubmitted ? (
            /* ======================================================== */
            /* QUESTION VIEW & STEPPER */
            /* ======================================================== */
            <div className="space-y-4">
              {/* Stepper Progress Bar */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="font-bold">
                    Question {currentQuestionIndex + 1} of {totalQuestions}
                  </span>
                  <span>
                    Focus: <strong className="text-indigo-500">{currentQ.skillFocus}</strong>
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                    style={{ width: `${((currentQuestionIndex + 1) / totalQuestions) * 100}%` }}
                  />
                </div>
              </div>

              {/* Question Card */}
              <div
                className={`p-4 rounded-2xl border space-y-3 ${
                  isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-800/80 border-slate-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                    {currentQ.type} Question
                  </span>
                </div>

                <p className="text-sm font-bold text-slate-900 dark:text-white leading-relaxed">
                  {currentQ.question}
                </p>

                {currentQ.scenarioContext && (
                  <div
                    className={`p-3 rounded-xl text-xs leading-relaxed ${
                      isLight ? 'bg-slate-50 text-slate-700' : 'bg-slate-900/60 text-slate-300'
                    }`}
                  >
                    {currentQ.scenarioContext}
                  </div>
                )}
              </div>

              {/* Options List */}
              <div className="space-y-2">
                <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  Select the most accurate response:
                </label>

                {currentQ.options?.map((option, optIdx) => {
                  const isSelected = selectedAnswers[currentQ.id] === optIdx;
                  const optionLetters = ['A', 'B', 'C', 'D'];

                  return (
                    <button
                      key={optIdx}
                      type="button"
                      onClick={() => handleSelectOption(currentQ.id, optIdx)}
                      className={`w-full p-3.5 rounded-2xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                        isSelected
                          ? isLight
                            ? 'bg-indigo-50 border-indigo-400 ring-2 ring-indigo-400/20 text-slate-900'
                            : 'bg-indigo-950/50 border-indigo-500 ring-2 ring-indigo-500/30 text-white'
                          : isLight
                          ? 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                          : 'bg-slate-800/60 hover:bg-slate-800 border-slate-700/80 text-slate-200'
                      }`}
                    >
                      <span
                        className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 ${
                          isSelected
                            ? 'bg-indigo-600 text-white shadow-xs'
                            : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {optionLetters[optIdx]}
                      </span>
                      <span className="text-xs font-medium leading-relaxed">{option}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            /* ======================================================== */
            /* RESULTS & AI DIAGNOSTIC REPORT */
            /* ======================================================== */
            <div className="space-y-4">
              {/* Score Hero Card */}
              <div
                className={`p-5 rounded-2xl border text-center space-y-3 ${
                  assessmentResult?.passed
                    ? isLight
                      ? 'bg-gradient-to-br from-emerald-50 via-white to-blue-50/50 border-emerald-300'
                      : 'bg-gradient-to-br from-emerald-950/60 via-slate-900 to-indigo-950/40 border-emerald-500/40'
                    : isLight
                    ? 'bg-amber-50/80 border-amber-200'
                    : 'bg-amber-950/30 border-amber-500/30'
                }`}
              >
                <div className="inline-flex p-3 rounded-2xl bg-emerald-500/15 text-emerald-500 mx-auto">
                  {assessmentResult?.passed ? (
                    <Award className="w-8 h-8" />
                  ) : (
                    <AlertTriangle className="w-8 h-8 text-amber-500" />
                  )}
                </div>

                <div>
                  <h3 className="text-2xl font-black font-display tracking-tight">
                    Score: {assessmentResult?.scorePercent}%
                  </h3>
                  <p className="text-xs font-bold text-slate-500 dark:text-slate-400 mt-0.5">
                    {assessmentResult?.passed
                      ? 'Assessment Passed! Certificate Unlocked'
                      : 'Passing score of 80% required to earn certificate.'}
                  </p>
                </div>

                <div className="inline-block px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wider bg-emerald-500/20 text-emerald-600 dark:text-emerald-400">
                  {assessmentResult?.passed ? 'Certificate Eligible ✓' : 'Requires Review'}
                </div>
              </div>

              {/* AI Diagnostic Breakdown */}
              <div
                className={`p-4 rounded-2xl border space-y-3 text-xs ${
                  isLight ? 'bg-white border-slate-200' : 'bg-slate-800/80 border-slate-700'
                }`}
              >
                <h4 className="font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                  <span>AI Diagnostic Evaluation</span>
                </h4>

                <div className="space-y-2">
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white">Awarded Skill Level: </span>
                    <span className="font-semibold text-indigo-600 dark:text-indigo-400">
                      {assessmentResult?.passed ? 'Working Proficiency (Verified)' : 'Developing'}
                    </span>
                  </div>

                  <div>
                    <span className="font-bold text-slate-900 dark:text-white">Identified Strengths: </span>
                    <ul className="list-disc list-inside text-slate-600 dark:text-slate-300 mt-1 space-y-0.5">
                      {course.assessment.strengths?.map((str, i) => (
                        <li key={i}>{str}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <span className="font-bold text-slate-900 dark:text-white">Recommended Next Action: </span>
                    <p className="text-slate-600 dark:text-slate-300 mt-0.5">
                      {course.assessment.recommendedNextAction || 'Apply these concepts to live recruiter challenges.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Review Question Explanations */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Question Review & Explanations ({questions.length})
                </h4>

                <div className="space-y-2">
                  {questions.map((q, idx) => {
                    const userAns = selectedAnswers[q.id];
                    const isCorrect = userAns === q.correctAnswerIndex;

                    return (
                      <div
                        key={q.id}
                        className={`p-3 rounded-2xl border space-y-1.5 text-xs ${
                          isCorrect
                            ? isLight
                              ? 'bg-emerald-50/50 border-emerald-200'
                              : 'bg-emerald-950/20 border-emerald-500/30'
                            : isLight
                            ? 'bg-amber-50/50 border-amber-200'
                            : 'bg-amber-950/20 border-amber-500/30'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-900 dark:text-white">
                            Question {idx + 1}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-1.5 py-0.5 rounded-sm ${
                              isCorrect ? 'bg-emerald-500/20 text-emerald-600' : 'bg-amber-500/20 text-amber-600'
                            }`}
                          >
                            {isCorrect ? 'Correct ✓' : 'Review'}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 dark:text-slate-300">
                          {q.question}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 italic pt-1 border-t border-slate-200/50 dark:border-slate-800">
                          <strong>Explanation: </strong> {q.explanation}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Sticky Controls */}
        <div
          className={`px-4 py-3 border-t flex items-center justify-between gap-3 shrink-0 ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-800/90 border-slate-700'
          }`}
        >
          {!isSubmitted ? (
            <>
              <button
                type="button"
                onClick={handlePrev}
                disabled={currentQuestionIndex === 0}
                className="px-3.5 py-2 rounded-xl border text-xs font-bold disabled:opacity-40 transition-colors flex items-center gap-1"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>Previous</span>
              </button>

              {isLastQuestion ? (
                <button
                  type="button"
                  onClick={handleSubmit}
                  disabled={selectedAnswers[currentQ.id] === undefined}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center gap-1.5"
                >
                  <span>Submit Assessment</span>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleNext}
                  disabled={selectedAnswers[currentQ.id] === undefined}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center gap-1.5"
                >
                  <span>Next Question</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={handleRetake}
                className="px-3 py-2 rounded-xl border text-xs font-bold flex items-center gap-1 text-slate-600 dark:text-slate-300"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retake</span>
              </button>

              {assessmentResult?.passed ? (
                <button
                  type="button"
                  onClick={() => {
                    setIsAssessmentModalOpen(false);
                    openCertificateView(course.id);
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center gap-1.5"
                >
                  <Award className="w-4 h-4" />
                  <span>View Official Certificate</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setIsAssessmentModalOpen(false);
                    openCourseLearning(course.id);
                  }}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center gap-1.5"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Review Video Modules</span>
                </button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
