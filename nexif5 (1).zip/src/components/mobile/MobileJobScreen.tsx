import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { calculateJobMatch } from '../../services/aiEngine';
import { Search, Filter, MapPin, Zap, Bookmark, Check, Briefcase, GraduationCap, X } from 'lucide-react';

export const MobileJobScreen: React.FC = () => {
  const {
    jobs,
    currentStudent,
    setSelectedJobForDetails,
    setSelectedJobForApply,
    savedJobIds,
    toggleSaveJob,
    applications,
    setMobileTab,
    searchQuery,
    setSearchQuery
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'internships' | 'saved'>('all');
  const [selectedMode, setSelectedMode] = useState<string>('all');
  const [selectedLocation, setSelectedLocation] = useState<string>('all');
  const [showFilterSheet, setShowFilterSheet] = useState(false);

  // Filter jobs
  const filteredJobs = jobs.filter(job => {
    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchSearch =
        job.title.toLowerCase().includes(q) ||
        job.companyName.toLowerCase().includes(q) ||
        job.location.toLowerCase().includes(q) ||
        job.requiredSkills.some(s => s.toLowerCase().includes(q));
      if (!matchSearch) return false;
    }

    // Tab filter
    if (activeTab === 'internships' && job.type !== 'internship') return false;
    if (activeTab === 'saved' && !savedJobIds.includes(job.id)) return false;

    // Work mode filter
    if (selectedMode !== 'all' && job.workMode !== selectedMode) return false;

    // Location filter
    if (selectedLocation !== 'all' && !job.location.toLowerCase().includes(selectedLocation.toLowerCase())) return false;

    return true;
  }).map(job => {
    const match = calculateJobMatch(currentStudent, job);
    return {
      ...job,
      matchScore: match.overallScore,
      matchReasons: match.whyItMatches
    };
  }).sort((a, b) => b.matchScore - a.matchScore);

  return (
    <div className="space-y-4 px-4 pt-4 pb-20 font-sans bg-slate-900 text-white min-h-screen">
      {/* Top Title */}
      <div>
        <h1 className="text-xl font-bold text-white font-display">
          Opportunities for You
        </h1>
        <p className="text-xs text-slate-400">
          AI-matched jobs and internships
        </p>
      </div>

      {/* Search Bar & Filter Button */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search role, skill, company..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-800/90 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-hidden focus:border-indigo-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <button
          onClick={() => setShowFilterSheet(true)}
          className={`p-2.5 rounded-xl border flex items-center justify-center transition-colors ${
            selectedMode !== 'all' || selectedLocation !== 'all'
              ? 'bg-indigo-600 border-indigo-500 text-white'
              : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
          }`}
          title="Filter Opportunities"
        >
          <Filter className="w-4 h-4" />
        </button>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
            activeTab === 'all'
              ? 'bg-indigo-600 text-white'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          All Jobs ({jobs.length})
        </button>

        <button
          onClick={() => setActiveTab('internships')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
            activeTab === 'internships'
              ? 'bg-indigo-600 text-white'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          Internships ({jobs.filter(j => j.type === 'internship').length})
        </button>

        <button
          onClick={() => setActiveTab('saved')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
            activeTab === 'saved'
              ? 'bg-indigo-600 text-white'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          Saved ({savedJobIds.length})
        </button>
      </div>

      {/* Results Count & Active Filters */}
      <div className="flex items-center justify-between text-xs text-slate-400">
        <span>Showing {filteredJobs.length} opportunities</span>
        {(selectedMode !== 'all' || selectedLocation !== 'all') && (
          <button
            onClick={() => {
              setSelectedMode('all');
              setSelectedLocation('all');
            }}
            className="text-indigo-400 hover:underline"
          >
            Clear Filters
          </button>
        )}
      </div>

      {/* Job Cards List */}
      <div className="space-y-3">
        {filteredJobs.map((job) => {
          const isSaved = savedJobIds.includes(job.id);
          const isApplied = applications.some(
            a => a.jobId === job.id && a.candidateId === currentStudent.id
          );

          return (
            <div
              key={job.id}
              className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/80 shadow-md space-y-3 hover:border-slate-600 transition-all"
            >
              {/* Top Row: Job Title, Company, Match Badge */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-3">
                  <img
                    src={job.companyLogoUrl}
                    alt={job.companyName}
                    className="w-10 h-10 rounded-xl object-cover border border-slate-700 shrink-0 mt-0.5"
                  />
                  <div>
                    <h3 className="font-bold text-white text-base leading-snug">
                      {job.title}
                    </h3>
                    <p className="text-xs text-slate-300 font-medium mt-0.5">
                      {job.companyName}
                    </p>
                  </div>
                </div>

                {/* 94% Match Badge */}
                <div className="shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
                  <Zap className="w-3 h-3" />
                  <span>{job.matchScore || 94}% Match</span>
                </div>
              </div>

              {/* Info Row: Location, Salary, Work Type */}
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  {job.location}
                </span>
                <span>•</span>
                <span className="font-semibold text-slate-200">
                  {job.salaryRange}
                </span>
                <span>•</span>
                <span className="capitalize px-1.5 py-0.5 rounded-md bg-slate-700/70 text-slate-300 text-[10px]">
                  {job.workMode}
                </span>
              </div>

              {/* Skills preview */}
              <div className="flex flex-wrap gap-1">
                {job.requiredSkills.slice(0, 4).map(skill => (
                  <span
                    key={skill}
                    className="px-2 py-0.5 rounded-md bg-slate-700/50 text-slate-300 text-[10px]"
                  >
                    {skill}
                  </span>
                ))}
                {job.requiredSkills.length > 4 && (
                  <span className="px-1.5 py-0.5 text-slate-500 text-[10px]">
                    +{job.requiredSkills.length - 4}
                  </span>
                )}
              </div>

              {/* Action Buttons: [View Job] [Apply] */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={() => setSelectedJobForDetails(job)}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-xs font-bold text-slate-200 text-center transition-colors"
                >
                  View Job
                </button>

                <button
                  onClick={() => {
                    if (isApplied) {
                      setMobileTab('applications');
                    } else {
                      setSelectedJobForApply(job);
                    }
                  }}
                  disabled={isApplied}
                  className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold text-center transition-colors ${
                    isApplied
                      ? 'bg-emerald-900/50 text-emerald-300 border border-emerald-700/50'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs'
                  }`}
                >
                  {isApplied ? '✓ Applied' : 'Apply'}
                </button>

                {/* Bookmark Button */}
                <button
                  onClick={() => toggleSaveJob(job.id)}
                  className={`p-2.5 rounded-xl border transition-colors ${
                    isSaved
                      ? 'bg-indigo-600/20 border-indigo-500 text-indigo-400'
                      : 'bg-slate-700/60 border-slate-700 text-slate-400 hover:text-slate-200'
                  }`}
                  title={isSaved ? 'Saved' : 'Save Job'}
                >
                  <Bookmark className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}

        {filteredJobs.length === 0 && (
          <div className="py-16 text-center text-slate-400 space-y-2">
            <p className="text-sm font-semibold text-slate-300">No opportunities found</p>
            <p className="text-xs">Try adjusting your search terms or filters.</p>
          </div>
        )}
      </div>

      {/* Filter Bottom Sheet */}
      {showFilterSheet && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-slate-950/80 backdrop-blur-xs">
          <div className="flex-1" onClick={() => setShowFilterSheet(false)} />
          <div className="bg-slate-900 rounded-t-3xl border-t border-slate-800 p-5 space-y-4 shadow-2xl max-h-[75vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-white text-base">Filter Opportunities</h3>
              <button
                onClick={() => setShowFilterSheet(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Work Mode */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                Work Mode
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {['all', 'hybrid', 'remote', 'on_site'].map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setSelectedMode(mode)}
                    className={`py-2 px-1 rounded-xl text-center text-xs font-medium capitalize border transition-colors ${
                      selectedMode === mode
                        ? 'bg-indigo-600 border-indigo-500 text-white font-bold'
                        : 'bg-slate-800 border-slate-700 text-slate-300'
                    }`}
                  >
                    {mode.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            {/* Location */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                Location
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {['all', 'Coimbatore', 'Bangalore', 'Chennai', 'Hyderabad'].map((loc) => (
                  <button
                    key={loc}
                    onClick={() => setSelectedLocation(loc)}
                    className={`py-2 px-3 rounded-xl text-left text-xs font-medium border transition-colors ${
                      selectedLocation === loc
                        ? 'bg-indigo-600 border-indigo-500 text-white font-bold'
                        : 'bg-slate-800 border-slate-700 text-slate-300'
                    }`}
                  >
                    {loc === 'all' ? 'All Locations' : `📍 ${loc}`}
                  </button>
                ))}
              </div>
            </div>

            {/* Apply & Reset Buttons */}
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => {
                  setSelectedMode('all');
                  setSelectedLocation('all');
                }}
                className="py-3 px-4 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
              >
                Reset
              </button>
              <button
                onClick={() => setShowFilterSheet(false)}
                className="flex-1 py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold text-center"
              >
                Apply Filters
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
