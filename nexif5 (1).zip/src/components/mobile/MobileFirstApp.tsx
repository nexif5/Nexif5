import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { MobileTopBar } from './MobileTopBar';
import { MobileBottomNavigation } from './MobileBottomNavigation';
import { MobileHomeScreen } from './MobileHomeScreen';
import { MobileJobScreen } from './MobileJobScreen';
import { MobileAIScreen } from './MobileAIScreen';
import { MobileApplicationsScreen } from './MobileApplicationsScreen';
import { MobileProfileScreen } from './MobileProfileScreen';
import { MobileLearnScreen } from './MobileLearnScreen';
import { MobileCareerScreen } from './MobileCareerScreen';
import { MobileSettingsScreen } from './MobileSettingsScreen';
import { MobileDashboardScreen } from './MobileDashboardScreen';
import { MobileResumeBuilderScreen } from './MobileResumeBuilderScreen';
import { MobileInterviewPrepScreen } from './MobileInterviewPrepScreen';
import { MobileJobDetailsModal } from './MobileJobDetailsModal';
import { MobileApplicationFlowModal } from './MobileApplicationFlowModal';
import { MobileProfileMenuDrawer } from './MobileProfileMenuDrawer';
import { MobileNotificationsModal } from './MobileNotificationsModal';
import { MobileResourceDetailModal } from './MobileResourceDetailModal';
import { MobileUploadResourceModal } from './MobileUploadResourceModal';
import { MobileCourseVideoModal } from './MobileCourseVideoModal';
import { MobileCourseAssessmentModal } from './MobileCourseAssessmentModal';
import { MobileCertificateModal } from './MobileCertificateModal';
import { MobileCertificateVerificationModal } from './MobileCertificateVerificationModal';

// Dedicated Role Dashboards & Profiles
import { MobileProfessionalDashboard } from './MobileProfessionalDashboard';
import { MobileProfessionalProfile } from './MobileProfessionalProfile';
import { MobileRecruiterDashboard } from './MobileRecruiterDashboard';
import { MobileRecruiterProfile } from './MobileRecruiterProfile';
import { MobileCollegeDashboard } from './MobileCollegeDashboard';
import { MobileCollegeProfile } from './MobileCollegeProfile';
import { MobileMentorDashboard } from './MobileMentorDashboard';
import { MobileMentorProfile } from './MobileMentorProfile';
import { MobileAdminDashboard } from './MobileAdminDashboard';

// Advanced Connect & Professional Messaging
import { MobileNetworkHubScreen } from './MobileNetworkHubScreen';
import { MobileMessagingScreen } from './MobileMessagingScreen';
import { MobileUserProfileViewScreen } from './MobileUserProfileViewScreen';

export const MobileFirstApp: React.FC = () => {

  const {
    mobileTab,
    setMobileTab,
    subView,
    currentRole,
    theme,
    isCourseVideoModalOpen,
    isAssessmentModalOpen,
    isCertificateModalOpen,
    isVerificationModalOpen
  } = useApp();
  const [showProfileDrawer, setShowProfileDrawer] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const isLight = theme === 'light';

  const renderMainContent = () => {
    // Check if subView is active
    if (subView === 'settings') return <MobileSettingsScreen />;
    if (subView === 'dashboard') return <MobileCareerScreen />;
    if (subView === 'resume') return <MobileResumeBuilderScreen />;
    if (subView === 'interview_prep') return <MobileInterviewPrepScreen />;
    if (subView === 'network') return <MobileNetworkHubScreen />;
    if (subView === 'messages') return <MobileMessagingScreen />;
    if (subView === 'view_profile') return <MobileUserProfileViewScreen />;

    // 1. ADMIN ROLE VIEW
    if (currentRole === 'admin') {
      return <MobileAdminDashboard />;
    }

    // 2. RECRUITER ROLE VIEW
    if (currentRole === 'recruiter') {
      if (mobileTab === 'profile') return <MobileRecruiterProfile />;
      return <MobileRecruiterDashboard />;
    }

    // 3. COLLEGE ROLE VIEW
    if (currentRole === 'college') {
      if (mobileTab === 'profile') return <MobileCollegeProfile />;
      return <MobileCollegeDashboard />;
    }

    // 4. MENTOR ROLE VIEW
    if (currentRole === 'mentor') {
      if (mobileTab === 'profile') return <MobileMentorProfile />;
      return <MobileMentorDashboard />;
    }

    // 5. WORKING PROFESSIONAL ROLE VIEW
    if (currentRole === 'professional' || currentRole === 'job_seeker') {
      if (mobileTab === 'profile') return <MobileProfessionalProfile />;
      if (mobileTab === 'learn') return <MobileLearnScreen />;
      if (mobileTab === 'career') return <MobileCareerScreen />;
      if (mobileTab === 'jobs') return <MobileJobScreen />;
      if (mobileTab === 'applications') return <MobileApplicationsScreen />;
      if (mobileTab === 'ai') return <MobileAIScreen />;
      return <MobileProfessionalDashboard />;
    }

    // 6. STUDENT ROLE VIEW
    switch (mobileTab) {
      case 'home':
        return <MobileHomeScreen />;
      case 'learn':
        return <MobileLearnScreen />;
      case 'career':
        return <MobileCareerScreen />;
      case 'jobs':
        return <MobileJobScreen />;
      case 'ai':
        return <MobileAIScreen />;
      case 'applications':
        return <MobileApplicationsScreen />;
      case 'profile':
        return <MobileProfileScreen />;
      default:
        return <MobileHomeScreen />;
    }
  };

  return (
    <div className={`min-h-screen flex flex-col justify-between select-none max-w-md mx-auto relative shadow-2xl overflow-x-hidden transition-colors duration-200 ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-slate-100'
    }`}>
      {/* Top App Bar (Only when subView is null) */}
      {!subView && (
        <MobileTopBar
          onOpenNotifications={() => setShowNotifications(true)}
          onOpenProfileMenu={() => setShowProfileDrawer(true)}
          onOpenSearch={() => setMobileTab('jobs')}
        />
      )}

      {/* Main Screen View Content */}
      <main className="flex-1 w-full overflow-y-auto">
        {renderMainContent()}
      </main>

      {/* Bottom Navigation (Only when subView is null) */}
      {!subView && <MobileBottomNavigation />}

      {/* Overlays / Modals */}
      <MobileJobDetailsModal />
      <MobileApplicationFlowModal />
      <MobileResourceDetailModal />
      <MobileUploadResourceModal />
      {isCourseVideoModalOpen && <MobileCourseVideoModal />}
      {isAssessmentModalOpen && <MobileCourseAssessmentModal />}
      {isCertificateModalOpen && <MobileCertificateModal />}
      {isVerificationModalOpen && <MobileCertificateVerificationModal />}
      <MobileProfileMenuDrawer

        isOpen={showProfileDrawer}
        onClose={() => setShowProfileDrawer(false)}
        onOpenNotifications={() => setShowNotifications(true)}
      />
      <MobileNotificationsModal
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
      />
    </div>
  );
};
