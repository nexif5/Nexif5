import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StudentCandidate } from '../../types';
import {
  Users,
  Search,
  Filter,
  GraduationCap,
  Sparkles,
  Award,
  CheckCircle2,
  Clock,
  Eye,
  School,
  FileText
} from 'lucide-react';

export const CollegeStudents: React.FC = () => {
  const { currentCollege, students } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedStudent, setSelectedStudent] = useState<StudentCandidate | null>(null);

  // Filter students affiliated with this college or show demo cohort
  const collegeStudents = students.filter(s => s.collegeId === currentCollege.id || s.collegeName === currentCollege.name);

  const filteredStudents = collegeStudents.filter(st => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchesName = st.name.toLowerCase().includes(q);
      const matchesSkill = st.skills.some(s => s.name.toLowerCase().includes(q));
      const matchesGoal = st.careerGoal.toLowerCase().includes(q);
      if (!matchesName && !matchesSkill && !matchesGoal) return false;
    }
    if (departmentFilter !== 'all' && st.department !== departmentFilter && st.education.course !== departmentFilter) return false;
    if (statusFilter !== 'all' && st.placementStatus !== statusFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-purple-600 mb-1">
            <Users className="w-4 h-4" />
            <span>STUDENT COHORT DIRECTORY</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 font-display">
            Enrolled Students ({collegeStudents.length})
          </h1>
          <p className="text-xs text-slate-500">
            Track student career readiness scores, verified achievements, and placement status under {currentCollege.name}
          </p>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative flex-1 w-full sm:max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search students by name, skill, or career ambition..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 bg-white focus:outline-none"
          >
            <option value="all">All Placement Statuses</option>
            <option value="placed">Placed</option>
            <option value="interviewing">Interviewing</option>
            <option value="seeking">Seeking Opportunity</option>
          </select>
        </div>
      </div>

      {/* Mobile Student Cohort Cards (sm:hidden) */}
      <div className="sm:hidden space-y-3">
        {filteredStudents.map((st) => (
          <div
            key={st.id}
            className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <img
                  src={st.avatarUrl}
                  alt={st.name}
                  className="w-11 h-11 rounded-xl object-cover border border-slate-200 shrink-0"
                />
                <div>
                  <strong className="text-slate-900 font-bold text-sm block">{st.name}</strong>
                  <span className="text-[10px] text-slate-400 font-mono">{st.email}</span>
                </div>
              </div>
              <div className="text-right shrink-0">
                <span className="px-2 py-0.5 rounded-lg bg-indigo-50 text-indigo-700 font-bold text-xs">
                  {st.careerReadinessScore}/100
                </span>
                <span className="text-[9px] text-slate-400 block mt-0.5">Readiness</span>
              </div>
            </div>

            <div className="space-y-1.5 text-xs pt-1 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Degree & Batch:</span>
                <span className="font-semibold text-slate-800">{st.education.course} ('{String(st.education.yearOfPassing).slice(-2)})</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Academic Score:</span>
                <span className="font-bold text-slate-900">{st.education.cgpaOrPercentage}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Career Ambition:</span>
                <span className="font-medium text-indigo-600 truncate max-w-[180px]">{st.careerGoal}</span>
              </div>
            </div>

            <button
              onClick={() => setSelectedStudent(st)}
              className="w-full py-2 bg-slate-900 hover:bg-purple-600 text-white rounded-xl font-bold text-xs text-center transition-colors min-h-[40px] active:scale-98"
            >
              Inspect Student Record
            </button>
          </div>
        ))}
      </div>

      {/* Students Table (hidden sm:block) */}
      <div className="hidden sm:block bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-semibold text-[10px] tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Student</th>
                <th className="py-3.5 px-4">Course & Batch</th>
                <th className="py-3.5 px-4">CGPA</th>
                <th className="py-3.5 px-4">Career Goal</th>
                <th className="py-3.5 px-4">Readiness Score</th>
                <th className="py-3.5 px-4">Placement Status</th>
                <th className="py-3.5 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredStudents.map((st) => (
                <tr key={st.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={st.avatarUrl}
                        alt={st.name}
                        className="w-9 h-9 rounded-xl object-cover border border-slate-200"
                      />
                      <div>
                        <strong className="text-slate-900 font-bold text-xs block">{st.name}</strong>
                        <span className="text-[10px] text-slate-400 font-mono">{st.email}</span>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span className="font-semibold text-slate-800 block">{st.education.course}</span>
                    <span className="text-[10px] text-slate-400">Class of {st.education.yearOfPassing || 2025}</span>
                  </td>
                  <td className="py-4 px-4 font-bold text-slate-800">
                    {st.education.cgpaOrPercentage}
                  </td>
                  <td className="py-4 px-4 font-medium text-indigo-600">
                    {st.careerGoal}
                  </td>
                  <td className="py-4 px-4">
                    <span className="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 font-bold text-xs">
                      {st.careerReadinessScore}/100
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <span className="px-2.5 py-0.5 rounded-full font-bold uppercase text-[10px] bg-emerald-100 text-emerald-800">
                      Active
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <button
                      onClick={() => setSelectedStudent(st)}
                      className="px-3 py-1.5 bg-slate-900 hover:bg-purple-600 text-white rounded-lg font-bold text-[11px] transition-colors"
                    >
                      View Record
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Student Record Modal */}
      {selectedStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 border border-slate-200 shadow-xl space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <img src={selectedStudent.avatarUrl} alt={selectedStudent.name} className="w-12 h-12 rounded-xl object-cover" />
                <div>
                  <h3 className="font-bold text-slate-900 text-base">{selectedStudent.name}</h3>
                  <p className="text-[11px] text-slate-500">{selectedStudent.education.course} • Batch of {selectedStudent.education.yearOfPassing || 2025}</p>
                </div>
              </div>
              <button onClick={() => setSelectedStudent(null)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <div className="space-y-3">
              <div className="bg-purple-50 p-3 rounded-xl border border-purple-100 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-purple-700 font-bold uppercase block">Career Readiness Score</span>
                  <span className="text-xl font-bold text-purple-950 font-display">{selectedStudent.careerReadinessScore}/100</span>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-white text-purple-800 text-xs font-bold border border-purple-200">
                  Target: {selectedStudent.careerGoal}
                </span>
              </div>

              <div>
                <span className="font-bold text-slate-900 block mb-1">Verified Skills:</span>
                <div className="flex flex-wrap gap-1">
                  {selectedStudent.skills.map(s => (
                    <span key={s.id} className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[11px]">
                      {s.name} ({s.level})
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <span className="font-bold text-slate-900 block mb-1">Key Achievements:</span>
                <div className="space-y-1">
                  {selectedStudent.achievements.map(a => (
                    <div key={a.id} className="p-2 rounded-lg bg-amber-50/60 border border-amber-200 text-[11px]">
                      <strong>{a.title}</strong>: {a.description}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedStudent(null)}
                className="px-4 py-2 bg-slate-900 text-white font-bold rounded-xl"
              >
                Close Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
