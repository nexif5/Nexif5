import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { JobOpportunity } from '../../types';
import { calculateJobMatch } from '../../services/aiEngine';
import {
  X,
  CheckCircle2,
  FileText,
  Building,
  Sparkles,
  MapPin,
  Briefcase,
  AlertCircle,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface JobApplyModalProps {
  job: JobOpportunity | null;
  onClose: () => void;
  onSuccess?: () => void;
}

export const JobApplyModal: React.FC<JobApplyModalProps> = ({ job, onClose, onSuccess }) => {
  const { currentStudent, applyForJob } = useApp();
  const [selectedResume, setSelectedResume] = useState(currentStudent.resumeName);
  const [coverNote, setCoverNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!job) return null;

  const match = calculateJobMatch(currentStudent, job);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMessage('');

    setTimeout(() => {
      const result = applyForJob(job.id, selectedResume, coverNote);
      setIsSubmitting(false);

      if (result.success) {
        setSubmittedSuccess(true);
        confetti({
          particleCount: 80,
          spread: 60,
          origin: { y: 0.6 }
        });
        if (onSuccess) onSuccess();
      } else {
        setErrorMessage(result.message);
      }
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        className="bg-white rounded-2xl max-w-xl w-full border border-slate-200 shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-3">
            <img
              src={job.companyLogoUrl}
              alt={job.companyName}
              className="w-10 h-10 rounded-xl object-cover border border-slate-200"
            />
            <div>
              <h3 className="font-bold text-slate-900 text-base">{job.title}</h3>
              <p className="text-xs text-slate-500 flex items-center gap-2">
                <span>{job.companyName}</span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {job.location}
                </span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {!submittedSuccess ? (
          <form onSubmit={handleSubmit} className="p-6 space-y-5">
            {/* AI Match Overview Banner */}
            <div className="p-3.5 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="p-2 bg-indigo-600 text-white rounded-lg font-bold text-sm">
                  {match.overallScore}%
                </span>
                <div>
                  <span className="text-xs font-bold text-indigo-900 block">AI Match Confidence</span>
                  <p className="text-[11px] text-indigo-700">
                    {match.matchedSkills.length} skills matched directly with recruiter criteria
                  </p>
                </div>
              </div>
              <span className="text-[11px] font-semibold text-indigo-600 bg-white px-2.5 py-1 rounded-full border border-indigo-200">
                Verified Candidate
              </span>
            </div>

            {/* Candidate Profile Summary */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-700">Applicant Profile:</span>
                <span className="text-slate-500 font-mono">{currentStudent.email}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-slate-600 pt-1 border-t border-slate-200">
                <div>
                  <span className="text-slate-400 block text-[10px]">Name</span>
                  <strong className="text-slate-900">{currentStudent.name}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Degree & College</span>
                  <strong className="text-slate-900 truncate block">
                    {currentStudent.education.degree}
                    {currentStudent.collegeName ? ` • ${currentStudent.collegeName}` : ' (Independent Candidate)'}
                  </strong>
                </div>
              </div>
            </div>

            {/* Resume Selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-800 mb-1.5 flex items-center justify-between">
                <span>Select Resume to Attach:</span>
                <span className="text-[11px] text-slate-400">PDF format</span>
              </label>
              <div className="border border-slate-200 rounded-xl p-3 flex items-center justify-between bg-white hover:border-indigo-300 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="p-2 rounded-lg bg-rose-50 text-rose-600 border border-rose-100">
                    <FileText className="w-5 h-5" />
                  </span>
                  <div>
                    <p className="text-xs font-bold text-slate-900">{selectedResume}</p>
                    <p className="text-[10px] text-slate-500">Updated {currentStudent.resumeUpdatedDate} • Verified</p>
                  </div>
                </div>
                <span className="text-xs font-medium text-emerald-600 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" /> Ready
                </span>
              </div>
            </div>

            {/* Note to Recruiter */}
            <div>
              <label className="block text-xs font-semibold text-slate-800 mb-1.5">
                Note to Recruiter (Optional):
              </label>
              <textarea
                value={coverNote}
                onChange={(e) => setCoverNote(e.target.value)}
                placeholder="Briefly highlight your key project outcomes or why you are excited about this specific role..."
                rows={3}
                className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-slate-800"
              />
            </div>

            {/* Source Stamp Notice */}
            <div className="flex items-center gap-2 text-[11px] text-slate-500 bg-slate-50 px-3 py-2 rounded-lg border border-slate-100">
              <ShieldCheck className="w-4 h-4 text-indigo-500 shrink-0" />
              <span>
                Application will be stamped with <strong>"Applied through Nexif5"</strong> and delivered directly into the recruiter's candidate workspace.
              </span>
            </div>

            {errorMessage && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-sm hover:shadow transition-all flex items-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>Submitting...</span>
                ) : (
                  <>
                    <span>Confirm & Apply Now</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </form>
        ) : (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border-4 border-emerald-100">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-900 font-display">
                Application Submitted Successfully!
              </h3>
              <p className="text-xs text-slate-600 mt-1 max-w-sm mx-auto">
                Your profile, verified skills, and resume have been forwarded directly to <strong>{job.companyName}</strong>.
              </p>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs text-left max-w-md mx-auto space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Position:</span>
                <span className="font-semibold text-slate-900">{job.title}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Company:</span>
                <span className="font-semibold text-slate-900">{job.companyName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Application Source:</span>
                <span className="font-semibold text-indigo-600">Applied through Nexif5</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Initial Status:</span>
                <span className="font-semibold text-blue-600">Applied (Under Review)</span>
              </div>
            </div>

            <div className="pt-3 flex justify-center gap-3">
              <button
                onClick={onClose}
                className="px-6 py-2.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-sm transition-all"
              >
                Track in My Applications
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};
